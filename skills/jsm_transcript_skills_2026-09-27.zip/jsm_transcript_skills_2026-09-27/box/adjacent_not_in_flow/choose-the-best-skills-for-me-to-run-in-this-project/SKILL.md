---
name: choose-the-best-skills-for-me-to-run-in-this-project
description: >-
  Rank every local and jeffreys-skills.md skill against a project's profile and
  current juncture into evidence-backed campaigns. Use when asking which skills
  to run here, what fits, or what to do next.
---

<!-- TOC: One Rule | Produces | Confirmations | Bootstrap | Invariants | Phases | Proportionality | Staleness | Scoring | Operators | Anti-Patterns | Checklist | Reference Index | Scripts | Subagents | Assets | Self-Test -->

# Choose The Best Skills For Me To Run In This Project

> **The One Rule:** recommend from evidence about THIS project at THIS juncture — never
> from vibes, directory names, or the tempting subset of a ~130-skill catalog. Every
> skill gets exactly one ledger row; "unknown" is never treated as "absent"; RUN NOW is
> a portfolio of at most three complementary campaigns, not a leaderboard.

## What This Skill Produces

- `docs/COMPREHENSIVE_ANALYSIS_OF_PROJECT_USED_FOR_AUTOMATED_SKILL_SELECTION.md` — the reusable, fingerprinted project profile (cheap reruns).
- `docs/RECOMMENDED_SKILLS_FOR_THIS_PROJECT.md` — 1–3 RUN NOW campaigns with paste-ready kickoff prompts and install lines, tiered tables, gaps, and a machine-readable ledger proving whole-catalog consideration.
- Terminal output of the campaigns; optional `jsm install` of the winners.

The workflow is **read-only toward the target project**: it never touches source, tests, config, issues, beads, branches, tags, or deployments. Its only writes are the two docs above (with permission), or `/tmp/<repo>__skill_selection/` for an ephemeral clone.

## Up-Front User Confirmations (ONE permission envelope, asked once)

1. **Target?** Working directory by default; or a named path; or a GitHub URL cloned read-only into `/tmp/`. Monorepo → confirm the component scope.
2. **Write the two docs into `docs/`** (create `docs/` if missing)? Ephemeral clone → sibling `/tmp/<repo>__skill_selection/` instead.
3. **Search remote cass sources** (configured sources, or a one-shot ssh fan-out over hosts you name)? Recommend yes when agents run on other machines — that's where the real juncture signal usually lives.
4. **Use authenticated catalog metadata via jsm/API?**
5. **Install skills via jsm** — missing referenced engines now (bootstrap below) and the recommended winners at the end?
6. **Commit** (and push, only if granted here) the two docs at the end, per the target's own AGENTS.md?

**Defaults without permission:** read-only analysis, local sources only, no installs, no commit; report to terminal + a temp file. Never re-ask mid-run for something the envelope covered; never exceed what it granted. Public repo target → `--public` is mandatory unless the user explicitly approves private classes. It recursively redacts local-only skill names, paths, hostnames, source payloads, commands, and evidence locators from prose and machine-readable blocks; the private run and evidence files remain outside the target.

## Skill Bootstrap (non-blocking)

Referenced engines: `/codebase-archaeology`, `/codebase-report`, `/cass`, `/idea-wizard`, `/reality-check-for-project`. If one is missing and `jsm` is authenticated, offer `jsm install <name>` — once, in the envelope. **No phase blocks on a missing skill**: every engine has an inline fallback (references/ORCHESTRATION.md#fallbacks). `jsm` absent/unauthenticated → say so once, use the catalog fallback ladder (references/CATALOG-ACQUISITION.md).

## Invariants (verbatim, non-negotiable)

1. Read-only toward the target; only the two approved docs are written; installs/commits need the envelope.
2. Canonical machine-readable data is the source of truth — the JSON in `references/data/` and the run records; every Markdown table is a generated view.
3. Every normalized catalog skill gets exactly one candidate-disposition row per run — `validate-run.py` blocks artifact writing otherwise.
4. `unknown` ≠ negative evidence: a timeout, missing tool, or unreachable host never proves absence.
5. RUN NOW is a portfolio (≤ 3 complementary, prerequisite-correct campaigns within the run budget).
6. Determinism: same inputs → byte-identical scored JSON (`SKILL_SELECTION_NOW` pins the clock).
7. Proportionality is budgeted: a reused-profile rerun invokes no profiler subagent.

## The Phase Loop

```
0 CONFIRM+BOOTSTRAP → 1 STALENESS → 2 PROFILE* → 3 JUNCTURE → 4 CATALOG → 5 MATCH
      → 6 SCORE+PORTFOLIO+LEDGER → 7 WRITE DOCS → 8 REVIEW (A,B,C, ≤4 passes) → 9 INSTALL+KICKOFF → 10 RECORD
                                   (* skipped when Phase 1 says reuse)
```

| Phase | Engine | Output |
|---|---|---|
| 1 | `bash scripts/check-doc-staleness.sh --target <dir>` | exit 0 reuse / 1 re-profile + reason JSON; announce it |
| 2 | `bash scripts/profile-project.sh` + profiler subagents | evidence records (three-state, signal-tagged) |
| 3 | `bash scripts/juncture-signals.sh` + `bash scripts/cass-juncture-mine.sh` + subagents | juncture evidence + already-done mentions |
| 4 | `bash scripts/local-skills-inventory.sh` + `bash scripts/catalog-fetch.sh` | normalized catalog + drift + provisional rows |
| 5 | matcher + idea-wizard round (30→5→10) | scorer-verified activations, evidence-gated recipe candidates, provenance-bearing overrides, exact-query gaps |
| 6 | `python3 scripts/score-recommendations.py` then `python3 scripts/validate-run.py` | run JSON + ledger; violations block Phase 7 — repair and re-score |
| 7 | `python3 scripts/render-recommendations.py` | the two docs (Agent Mail reservation, else single writer) |
| 8 | Passes A/B/C (subagents/) once each; repeat A once iff a tier or campaign changed | corrected docs + run data only |
| 9–10 | installer-and-kickoff + record | terminal campaigns, installs, history appendix, header bumps |

Full phase contracts: references/ORCHESTRATION.md. Run id = first 12 hex of sha256(target + HEAD-or-digest + pinned timestamp).

## Proportionality Budgets

```
< 250 tracked files:    ≤ 4 profiler subagents, single juncture agent
250–2,500:              one subagent per dimension/source
> 2,500 or > 20 members: component map first; per-component profiling; ≤ 8 concurrent
Reused profile:         NO Phase 2 profiler; no large source reads unless verifying a changed juncture claim
Timeouts: gh 30s; jsm/API 30s; each remote cass host 60s → failure records `unknown` and the run continues.
```

## Staleness (when is the profile reused?)

Reuse unless: the header or durable embedded profile evidence fails schema/correction validation; requested scope is missing, escapes the target, or differs; the profiled commit is not an ancestor of HEAD; ≥ 25 commits since; ≥ 15% of scoped tracked files changed; any tracked worktree edit; any recursively discovered manifest/lockfile digest changed; ≥ 10 changed Beads issue records; `profiled_at` > 30 days; a non-git path/content digest changed; or the user asked for fresh. Git paths are NUL-delimited, including odd filenames. Reuse reloads the embedded profile records and refreshes the juncture every run. Details: references/STALENESS.md.

## Scoring (the contract, fixed in `references/data/scoring-constants.json`)

```
score = 5·J + 4·A + 3·E − 2·C − 2·R − 3·D                     (−28 … 48)
RUN NOW eligible: score ≥ 30 ∧ J ≥ 3 ∧ E ≥ 3 ∧ ≥ 2 independent anchors
                  (≥ 1 profile AND ≥ 1 juncture; hygiene gaps: 2 profile anchors)
                  ∧ prerequisites satisfied or in-campaign
RUN SOON ≥ 22 ∧ J ≥ 2 · KEEP HANDY ≥ 12 (names its promotion trigger) · else CONSIDERED
Suppression gates run BEFORE tiers: completed-in-window / declined-while-condition-holds /
in-progress cap a row at KEEP HANDY regardless of score.
Tie-break: J desc → E desc → C asc → R asc → name.
```

Dimension meanings, worked examples, portfolio constraints: references/SCORING-RUBRIC.md. Already-done state machine: references/JUNCTURE-SIGNALS.md.

## Operator Library (the moves)

★ PROFILE · ◎ FINGERPRINT · ✦ LISTEN (cass first — it outranks git) · ◐ CORROBORATE (git/beads) · ⬡ MATCH · ⊘ ANTI-SIGNAL (say "not now" as clearly as "yes") · ⊕ COMBINE (recipes over singletons) · ⚖ SCORE · ⊙ DEBOUNCE-ALREADY-DONE · ⌘ KICKOFF (the user's own phrasing) · ⊞ RECORD · ∅ UNKNOWN-IS-NOT-ABSENT. Cards: references/OPERATOR-LIBRARY.md.

## Anti-Patterns (Never Do)

| ✗ | Why |
|---|---|
| Recommend everything / from directory names | The ledger exists to prove judgment, not enthusiasm |
| Ignore anti-signals or re-recommend what was just done | `D` and the suppression gates exist; check the run history |
| Treat `jsm suggest`/`jsm scan` as ground truth | Weak signals only — recorded, never decisive |
| Treat a timeout as absence | Violates invariant 4; record `unknown` + the error |
| Heavy analysis on a fresh profile | Budget violation; the fingerprint said reuse |
| Fill RUN NOW with three steps of one campaign | It's a portfolio; steps live inside one campaign |
| Name a skill that isn't in the normalized catalog | validate-run.py blocks it |
| Modify anything in the target project | The one hard runtime rule |

More: references/ANTI-PATTERNS.md. Troubleshooting (jsm auth, stale cass index, unreachable hosts, monorepos, no-history projects): references/TROUBLESHOOTING.md.

## Pre-Flight & End Checklist

- [ ] Envelope asked once; grants recorded
- [ ] Target governance read before commands; no-delete mode active where required; staleness announced with changed Beads issue-record count (not an invented event count)
- [ ] Catalog normalized; drift reported; provisional rows for unmapped skills (E capped at 2)
- [ ] Ledger: one row per catalog skill; `validate-run.py` passed BEFORE writing docs
- [ ] Campaigns printed with verbatim kickoff prompts + install lines
- [ ] Gaps offered to `jsm requests`; `jsm outcome` reminder given
- [ ] Docs written/committed only per the envelope; history appendix updated with retention

## Reference Index

| Need | File |
|---|---|
| Profile taxonomy + detection commands | [PROJECT-PROFILE-TAXONOMY.md](references/PROJECT-PROFILE-TAXONOMY.md) |
| Juncture sources, weighing, already-done machine | [JUNCTURE-SIGNALS.md](references/JUNCTURE-SIGNALS.md) |
| jsm surface, fallback ladder, drift protocol | [CATALOG-ACQUISITION.md](references/CATALOG-ACQUISITION.md) |
| Campaign recipes (generated view) | [COMBO-RECIPES.md](references/COMBO-RECIPES.md) |
| Scoring contract + worked examples | [SCORING-RUBRIC.md](references/SCORING-RUBRIC.md) |
| Operator cards | [OPERATOR-LIBRARY.md](references/OPERATOR-LIBRARY.md) |
| Fan-out, merge, envelope, Agent Mail conventions | [ORCHESTRATION.md](references/ORCHESTRATION.md) |
| Fingerprint + reuse rules | [STALENESS.md](references/STALENESS.md) |
| Anti-patterns | [ANTI-PATTERNS.md](references/ANTI-PATTERNS.md) |
| Failure modes + degraded paths | [TROUBLESHOOTING.md](references/TROUBLESHOOTING.md) |
| Mined rituals & phrasings | [EXEMPLARS.md](references/EXEMPLARS.md) |
| Catalog table (generated view) | [CATALOG-SNAPSHOT.md](references/CATALOG-SNAPSHOT.md) |
| Trigger map (generated view) | [SIGNAL-TO-SKILL-MAP.md](references/SIGNAL-TO-SKILL-MAP.md) |

Canonical data: `references/data/*.json` (edit these, then `python3 scripts/render-reference-views.py`). Schemas: `references/schemas/*.json`.

## Scripts

| Script | Purpose |
|---|---|
| check-doc-staleness.sh | Fingerprint delta; exit 0 reuse / 1 re-profile; reason JSON |
| profile-project.sh | Deterministic Phase 2 detectors → evidence JSON |
| juncture-signals.sh | git/gh/beads/smells → juncture evidence JSON |
| cass-juncture-mine.sh | Local + remote session mining; hosts from `cass sources list --json` or `$SKILL_SELECTION_CASS_HOSTS`; per-host timeout → unknown |
| local-skills-inventory.sh | Every skills dir → normalized entries; precedence + skew |
| catalog-fetch.sh | zero-call offline mode + aggregate deadline; jsm → complete-sitemap website → snapshot; drift/source errors/provisional marks |
| prepare-evidence.py | durable profile evidence reload + append-only `supersedes` correction validation |
| refresh-catalog-snapshot.sh | Authoring-time snapshot rebuild (+ re-render views) |
| score-recommendations.py | The contract → scores, tiers, portfolio, ledger, run JSON |
| validate-run.py | Schemas + ledger invariants; non-zero blocks Phase 7 |
| render-recommendations.py | Validated run + merged evidence → both docs; generated analysis, history + retention, fail-closed public projection |
| render-reference-views.py | data JSON → generated Markdown views |
| validate-skill.py | Self-contained package validator (+ optional `jsm validate` report) |
| scan-shipped-package.sh | Prohibited-name/portability/privacy scan (lists passed as build-time file args) |

Run scripts with `bash`/`python3` (shipped non-executable). All honor `SKILL_SELECTION_NOW`.

## Subagents

`subagents/` holds one charter per role: orchestrator, staleness-checker, six profilers (identity, build-and-deps, code-kinds, tests, docs-and-process, delivery-surface), five juncture miners (git, beads, cass-local, cass-remote, code-smells), three catalog agents (local-inventory, cloud, relationships), matcher, idea-wizard-orchestrator, scorer, synthesizer, three reviewers (artifact-integrity A, evidence-auditor B, consistency C), installer-and-kickoff.

## Assets

`assets/analysis-doc-template.md` · `assets/recommendations-doc-template.md` · `assets/kickoff-block-template.md`

## Self-Test

Trigger phrases and end-to-end fixture scenarios (with assertions): [SELF-TEST.md](SELF-TEST.md). Unit tests: `python3 tests/test_scoring.py` etc.; full fixture run: `bash tests/run-self-test.sh`.
