#!/usr/bin/env bash
# refresh-catalog-snapshot.sh — AUTHORING-TIME full rebuild of catalog-snapshot.json in place.
#
# Usage: bash refresh-catalog-snapshot.sh [--snapshot FILE] [--packs-file FILE]
#          [--cache-dir DIR] [--api-key KEY]
#   --snapshot FILE  the snapshot to rebuild (default: ../references/data/catalog-snapshot.json).
#                    This is the ONE script allowed to write into references/data/.
#   --packs-file F   pack membership JSON: {"packs":{id:{"skills":[...]}}} or {id:[names]}.
#   --api-key KEY    (or $SKILL_SELECTION_JSM_API_KEY) fetch packs live from
#                    https://jeffreys-skills.md/api/v1/packs (+ per-pack member pages).
#                    Never a hardcoded local path. With neither flag, the EXISTING snapshot's
#                    pack assignments are kept (with a warning).
#   --cache-dir DIR  where per-skill `jsm show`/`jsm related` output is cached (default: a
#                    temp dir). A cached file that parses as JSON is reused without refetching
#                    (delete the cache dir's files, or point at a fresh dir, to force refetch).
#
# Behavior: REFUSES to run when `jsm` is absent (authoring tool). Names = public sitemap slugs
#   ∪ `jsm list --remote --jeffreys --json`; each name is confirmed via `timeout 40 jsm show
#   <name> --json` and kept only when is_jeffreys && is_public. `jsm related <name> --json`
#   may print the plain text "No related skills found." instead of JSON — only that exact
#   sentinel means empty; other malformed responses retain existing edges and are errors.
#   Assembly is done by
#   `python3 skillsel_common.py assemble-snapshot NAMES SHOW_DIR RELATED_DIR PACKS OUT EXISTING`
#   (EXISTING = a pre-run copy of the snapshot, supplying detect_rules and gap-filling fields).
#   Finally, render-reference-views.py is run IF it exists (it may not yet; a note is printed
#   and the exit code stays 0 either way).
#
# Read-only toward everything except --snapshot and --cache-dir. Every network call is
#   timeboxed (curl --max-time 30, jsm under timeout 30/40/60). Exit codes: 0 = snapshot
#   rebuilt; 1 = jsm absent, bad arguments, or the rebuild failed.
# Determinism: same remote catalog + same SKILL_SELECTION_NOW (pins harmonized_against
#   .refreshed_at) => byte-identical snapshot across runs.
# Portability: bash 3.2+, python3 (stdlib only), jsm required; optional curl.
set -uo pipefail

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)
SNAPSHOT="$SCRIPT_DIR/../references/data/catalog-snapshot.json"
PACKS_FILE=""; CACHE_DIR=""; API_KEY="${SKILL_SELECTION_JSM_API_KEY:-}"
while [ $# -gt 0 ]; do
  case "$1" in
    --snapshot) SNAPSHOT="$2"; shift 2;;
    --packs-file) PACKS_FILE="$2"; shift 2;;
    --cache-dir) CACHE_DIR="$2"; shift 2;;
    --api-key) API_KEY="$2"; shift 2;;
    -h|--help) sed -n '2,32p' "$0"; exit 0;;
    *) echo "unknown arg: $1" >&2; exit 1;;
  esac
done
command -v jsm >/dev/null 2>&1 || { echo "refresh-catalog-snapshot: jsm is required (this is an authoring tool); refusing to run" >&2; exit 1; }
command -v python3 >/dev/null 2>&1 || { echo "python3 is required" >&2; exit 1; }
case "$SNAPSHOT" in /*) ;; *) SNAPSHOT="$PWD/$SNAPSHOT";; esac
[ -n "$PACKS_FILE" ] && [ ! -f "$PACKS_FILE" ] && { echo "packs file not found: $PACKS_FILE" >&2; exit 1; }
[ -f "$PWD/AGENTS.md" ] && grep -Eqi 'NO FILE DELETION|NEVER (ALLOWED TO )?DELETE' "$PWD/AGENTS.md" && export SKILL_SELECTION_KEEP_TEMP=1

TMPD=$(mktemp -d "${TMPDIR:-/tmp}/skillsel-refresh.XXXXXX") || { echo "mktemp failed" >&2; exit 1; }
cleanup() {
  if [ "${SKILL_SELECTION_KEEP_TEMP:-0}" = 1 ]; then
    echo "refresh-catalog-snapshot: kept temporary workspace $TMPD" >&2
    return
  fi
  rm -f "$TMPD"/cache/show/* "$TMPD"/cache/related/* "$TMPD"/* 2>/dev/null
  rmdir "$TMPD/cache/show" "$TMPD/cache/related" "$TMPD/cache" "$TMPD" 2>/dev/null
}
trap cleanup EXIT
[ -n "$CACHE_DIR" ] || CACHE_DIR="$TMPD/cache"
case "$CACHE_DIR" in /*) ;; *) CACHE_DIR="$PWD/$CACHE_DIR";; esac
SHOW_DIR="$CACHE_DIR/show"; RELATED_DIR="$CACHE_DIR/related"
mkdir -p "$SHOW_DIR" "$RELATED_DIR" || { echo "cannot create cache dir" >&2; exit 1; }

TMO_BIN=""
if command -v timeout >/dev/null 2>&1; then TMO_BIN=timeout; elif command -v gtimeout >/dev/null 2>&1; then TMO_BIN=gtimeout; fi
tmo() { local s="$1"; shift
  if [ -n "$TMO_BIN" ]; then "$TMO_BIN" "$s" "$@"
  elif command -v perl >/dev/null 2>&1; then perl -e 'alarm shift; exec @ARGV' "$s" "$@"
  else "$@"; fi
}
UA="OpenAI File Downloader, XaiImageApiFetch/1.0"
SITE="https://jeffreys-skills.md"

# preserve the existing snapshot as the assembler's EXISTING input (gap-filler, detect_rules)
EXISTING="$TMPD/existing.json"
if [ -f "$SNAPSHOT" ]; then cp "$SNAPSHOT" "$EXISTING"; else : > "$EXISTING"; fi

# --------------------------------------------------------- candidate names
tmo 60 jsm list --remote --jeffreys --json > "$TMPD/list.json" 2>/dev/null \
  || { echo "refresh-catalog-snapshot: jsm list --remote failed (network/auth?); refusing to rebuild from nothing" >&2; exit 1; }
if command -v curl >/dev/null 2>&1; then
  curl -s --max-time 30 -A "$UA" "$SITE/skills/sitemap.xml" -o "$TMPD/sitemap.xml" || : > "$TMPD/sitemap.xml"
  grep -q '</urlset>' "$TMPD/sitemap.xml" 2>/dev/null || : > "$TMPD/sitemap.xml"
else
  : > "$TMPD/sitemap.xml"
fi
python3 - "$TMPD/list.json" "$TMPD/sitemap.xml" "$TMPD/candidates.txt" <<'PY'
import json, re, sys
list_path, sitemap_path, out_path = sys.argv[1:4]
NAME_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")
names = set()
try:
    for row in json.load(open(list_path, encoding="utf-8")).get("skills", []):
        n = str(row.get("name", ""))
        if NAME_RE.match(n): names.add(n)
except Exception as e:
    sys.stderr.write("refresh-catalog-snapshot: list.json parse error: %s\n" % e)
    sys.exit(1)
xml = open(sitemap_path, encoding="utf-8", errors="replace").read()
for m in re.finditer(r"<loc>\s*https://jeffreys-skills\.md/skills/([a-z0-9-]+)\s*</loc>", xml):
    if NAME_RE.match(m.group(1)): names.add(m.group(1))
if not names:
    sys.stderr.write("refresh-catalog-snapshot: no candidate names found\n")
    sys.exit(1)
open(out_path, "w").write("\n".join(sorted(names)) + "\n")
sys.stderr.write("refresh-catalog-snapshot: %d candidate names\n" % len(names))
PY
[ $? -eq 0 ] || exit 1

# ------------------------------------- confirm each name via jsm show; fetch related
: > "$TMPD/names.txt"
while IFS= read -r NAME; do
  [ -n "$NAME" ] || continue
  case "$NAME" in *[!a-z0-9-]*) continue;; esac
  SHOWF="$SHOW_DIR/$NAME.json"
  if ! python3 -c 'import json,sys; json.load(open(sys.argv[1]))' "$SHOWF" 2>/dev/null; then
    tmo 40 jsm show "$NAME" --json < /dev/null > "$TMPD/show.tmp" 2>/dev/null && mv "$TMPD/show.tmp" "$SHOWF" || true
  fi
  KEEP=$(python3 -c '
import json, sys
try: s = json.load(open(sys.argv[1], encoding="utf-8")).get("skill") or {}
except Exception: sys.exit(0)
print("keep" if (s.get("is_jeffreys") and s.get("is_public")) else "drop")' "$SHOWF" 2>/dev/null)
  [ "$KEEP" = "keep" ] || { echo "refresh-catalog-snapshot: dropping $NAME (${KEEP:-show unavailable})" >&2; continue; }
  printf '%s\n' "$NAME" >> "$TMPD/names.txt"
  RELF="$RELATED_DIR/$NAME.json"
  if [ ! -s "$RELF" ]; then
    # `jsm related` prints plain text "No related skills found." when a skill has no edges.
    # The assembler treats only that exact sentinel as empty and retains old edges otherwise.
    tmo 40 jsm related "$NAME" --json < /dev/null > "$TMPD/rel.tmp" 2>/dev/null && mv "$TMPD/rel.tmp" "$RELF" || true
  fi
done < "$TMPD/candidates.txt"
[ -s "$TMPD/names.txt" ] || { echo "refresh-catalog-snapshot: zero confirmed public skills; refusing to write an empty snapshot" >&2; exit 1; }

# ----------------------------------------------------------------- packs source
PACKS_JSON="$TMPD/packs.json"
if [ -n "$PACKS_FILE" ]; then
  cp "$PACKS_FILE" "$PACKS_JSON"
elif [ -n "$API_KEY" ] && command -v curl >/dev/null 2>&1; then
  curl -s --max-time 30 -A "$UA" -H "Authorization: Bearer $API_KEY" "$SITE/api/v1/packs" -o "$TMPD/packs-index.json" 2>/dev/null || : > "$TMPD/packs-index.json"
  PACK_IDS=$(python3 -c '
import json, re, sys
try: d = json.load(open(sys.argv[1], encoding="utf-8"))
except Exception: sys.exit(0)
packs = d.get("packs", d)
ids = []
if isinstance(packs, dict): ids = list(packs)
elif isinstance(packs, list): ids = [p.get("id") or p.get("name") or p.get("slug") for p in packs if isinstance(p, dict)]
for i in ids:
    if i and re.match(r"^[a-z0-9][a-z0-9-]{0,63}$", str(i)): print(i)' "$TMPD/packs-index.json")
  for P in $PACK_IDS; do
    curl -s --max-time 30 -A "$UA" -H "Authorization: Bearer $API_KEY" "$SITE/api/v1/packs/$P" -o "$TMPD/pack.$P.json" 2>/dev/null || true
  done
  python3 - "$TMPD" "$PACKS_JSON" <<'PY'
import glob, json, os, sys
tmpd, out = sys.argv[1:3]
packs = {}
for f in sorted(glob.glob(os.path.join(tmpd, "pack.*.json"))):
    pid = os.path.basename(f)[len("pack."):-len(".json")]
    try: d = json.load(open(f, encoding="utf-8"))
    except Exception: continue
    body = d.get("pack", d)
    skills = body.get("skills", []) if isinstance(body, dict) else []
    names = [s if isinstance(s, str) else (s.get("slug") or s.get("name")) for s in skills]
    packs[pid] = {"skills": [n for n in names if n]}
json.dump({"packs": packs}, open(out, "w", encoding="utf-8"), indent=2, sort_keys=True)
sys.stderr.write("refresh-catalog-snapshot: %d packs from the API\n" % len(packs))
PY
else
  echo "refresh-catalog-snapshot: WARNING no --packs-file and no API key; keeping the existing snapshot's pack assignments" >&2
  python3 - "$EXISTING" "$PACKS_JSON" <<'PY'
import json, sys
existing, out = sys.argv[1:3]
packs = {}
try:
    for s in json.load(open(existing, encoding="utf-8")).get("skills", []):
        for p in s.get("packs", []):
            packs.setdefault(p, {"skills": []})["skills"].append(s["canonical_name"])
except Exception:
    pass
json.dump({"packs": packs}, open(out, "w", encoding="utf-8"), indent=2, sort_keys=True)
PY
fi
[ -s "$PACKS_JSON" ] || printf '{"packs":{}}\n' > "$PACKS_JSON"

# ------------------------------------------------------------------- assemble
python3 "$SCRIPT_DIR/skillsel_common.py" assemble-snapshot \
  "$TMPD/names.txt" "$SHOW_DIR" "$RELATED_DIR" "$PACKS_JSON" "$SNAPSHOT" "$EXISTING" \
  || { echo "refresh-catalog-snapshot: assemble-snapshot failed" >&2; exit 1; }

# ------------------------------------------------- optional reference-view render
if [ -f "$SCRIPT_DIR/render-reference-views.py" ]; then
  python3 "$SCRIPT_DIR/render-reference-views.py" || echo "refresh-catalog-snapshot: render-reference-views.py failed (snapshot itself was written)" >&2
else
  echo "refresh-catalog-snapshot: note: render-reference-views.py not present yet; skipped" >&2
fi
exit 0
