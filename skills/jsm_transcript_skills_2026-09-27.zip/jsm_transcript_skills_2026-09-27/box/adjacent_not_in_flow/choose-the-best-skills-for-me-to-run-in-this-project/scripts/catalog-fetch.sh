#!/usr/bin/env bash
# catalog-fetch.sh — produce the PUBLIC catalog via the fallback ladder.
#
# Usage: bash catalog-fetch.sh --out FILE [--snapshot FILE] [--cache-dir DIR]
#        [--offline] [--deadline SECONDS]
#
# Output: a JSON object written to --out:
#   {"skills": [catalog-entry...], "source_tier": "jsm|website|snapshot",
#    "drift": {"new": [], "changed": [], "retired": []},
#    "drift_known": true|false, "retirement_known": true|false}
#   Every skills[] element validates against references/schemas/catalog-entry.schema.json.
#
# Fallback ladder:
#   Tier 1 "jsm": requires `jsm` on PATH and `timeout 30 jsm whoami --json` authenticated.
#     Names = `timeout 60 jsm list --remote --jeffreys --json` (the newest page) ∪ the public
#     sitemap slugs (when reachable) ∪ the bundled snapshot's names. Names that are NEW or whose
#     updated_at/content_hash differs from the snapshot are fetched live (`jsm show/related
#     <name> --json` into --cache-dir; a cache file is reused only when written this run).
#     `jsm related` may print the plain text "No related skills found." instead of JSON —
#     only that exact sentinel is empty; other malformed output retains prior edges and records
#     a source error. Live-confirmed entries get catalog_sources
#     ["public"]; unchanged names reuse the snapshot entry normalized to ["snapshot"].
#   Tier 2 "website": jsm missing/unauthenticated but curl + network. Slugs come from
#     https://jeffreys-skills.md/skills/sitemap.xml; snapshot names reuse snapshot entries;
#     new names get their preview page's <meta name="description"> (catalog_sources
#     ["website"], lower confidence).
#   Tier 3 "snapshot": the bundled snapshot's skills as ["snapshot"], with a stderr warning.
#
# Drift: new = live names not in the snapshot; changed = updated_at/content_hash differs;
#   retired = snapshot names absent from the COMPLETE sitemap. A newest-page `jsm list`
#   can establish new/changed entries but never retirement. `retirement_known` and the
#   aggregate `drift_known` are true only when the complete sitemap was read. Tier 3 emits
#   empty arrays with both flags false. Former names
#   resolve through aliases.json before comparison. provisional_mapping is true for any
#   name absent from signal-to-skill-map.json's skills object.
#
# Read-only toward everything except --out and --cache-dir. One aggregate --deadline budget
#   bounds all network calls. Exit codes: 0 = valid output written;
#   1 = bad arguments, missing helper, or the output failed schema validation.
# Portability: bash 3.2+, python3 (stdlib only); optional jsm/curl.
set -uo pipefail

OUT=""; SNAPSHOT=""; CACHE_DIR=""; OFFLINE="${JSM_OFFLINE:-0}"; DEADLINE=30
while [ $# -gt 0 ]; do
  case "$1" in
    --out) OUT="$2"; shift 2;;
    --snapshot) SNAPSHOT="$2"; shift 2;;
    --cache-dir) CACHE_DIR="$2"; shift 2;;
    --offline) OFFLINE=1; shift;;
    --deadline) DEADLINE="$2"; shift 2;;
    -h|--help) sed -n '2,35p' "$0"; exit 0;;
    *) echo "unknown arg: $1" >&2; exit 1;;
  esac
done
[ -n "$OUT" ] || { echo "--out FILE is required (use - for stdout)" >&2; exit 1; }
case "$DEADLINE" in ''|*[!0-9]*) echo "--deadline must be a positive integer" >&2; exit 1;; esac
[ "$DEADLINE" -gt 0 ] || { echo "--deadline must be a positive integer" >&2; exit 1; }
SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)
ALIASES="$SCRIPT_DIR/../references/data/aliases.json"
MAP="$SCRIPT_DIR/../references/data/signal-to-skill-map.json"
[ -n "$SNAPSHOT" ] || SNAPSHOT="$SCRIPT_DIR/../references/data/catalog-snapshot.json"
[ -f "$SNAPSHOT" ] || { echo "snapshot not found: $SNAPSHOT" >&2; exit 1; }
if [ "$OUT" != "-" ]; then case "$OUT" in /*) ;; *) OUT="$PWD/$OUT";; esac; fi
[ -f "$PWD/AGENTS.md" ] && grep -Eqi 'NO FILE DELETION|NEVER (ALLOWED TO )?DELETE' "$PWD/AGENTS.md" && export SKILL_SELECTION_KEEP_TEMP=1

TMPD=$(mktemp -d "${TMPDIR:-/tmp}/skillsel-catalog.XXXXXX") || { echo "mktemp failed" >&2; exit 1; }
cleanup() {
  if [ "${SKILL_SELECTION_KEEP_TEMP:-0}" = 1 ]; then
    echo "catalog-fetch: kept temporary workspace $TMPD" >&2
    return
  fi
  rm -f "$TMPD"/cache/show/* "$TMPD"/cache/related/* "$TMPD"/cache/pages/* "$TMPD"/* 2>/dev/null
  rmdir "$TMPD/cache/show" "$TMPD/cache/related" "$TMPD/cache/pages" "$TMPD/cache" "$TMPD" 2>/dev/null
}
trap cleanup EXIT
[ -n "$CACHE_DIR" ] || CACHE_DIR="$TMPD/cache"
case "$CACHE_DIR" in /*) ;; *) CACHE_DIR="$PWD/$CACHE_DIR";; esac
mkdir -p "$CACHE_DIR/show" "$CACHE_DIR/related" "$CACHE_DIR/pages" || { echo "cannot create cache dir" >&2; exit 1; }
STAMP="$TMPD/run-stamp"; : > "$STAMP"

TMO_BIN=""
if command -v timeout >/dev/null 2>&1; then TMO_BIN=timeout; elif command -v gtimeout >/dev/null 2>&1; then TMO_BIN=gtimeout; fi
tmo() { local requested="$1"; shift; local remain cap
  remain=$(python3 -c 'import sys,time; print(max(0,int(float(sys.argv[1])-(time.time()-float(sys.argv[2])))))' "$DEADLINE" "$STARTED_AT")
  [ "$remain" -gt 0 ] || return 124
  cap="$requested"; [ "$remain" -lt "$cap" ] && cap="$remain"
  if [ -n "$TMO_BIN" ]; then "$TMO_BIN" "$cap" "$@"
  elif command -v perl >/dev/null 2>&1; then perl -e 'alarm shift; exec @ARGV' "$cap" "$@"
  else "$@"; fi
}
remaining() { python3 -c 'import sys,time; print(max(0,int(float(sys.argv[1])-(time.time()-float(sys.argv[2])))))' "$DEADLINE" "$STARTED_AT"; }
STARTED_AT=$(python3 -c 'import time; print(time.time())')
UA="OpenAI File Downloader, XaiImageApiFetch/1.0"
SITE="https://jeffreys-skills.md"

# ------------------------------------------------------------- gather raw inputs
TIER=""
HAVE_LIST=0; HAVE_SITEMAP=0
if [ "$OFFLINE" != 1 ] && command -v jsm >/dev/null 2>&1; then
  if tmo 30 jsm whoami --json > "$TMPD/whoami.json" \
     && python3 -c 'import json,sys; sys.exit(0 if json.load(open(sys.argv[1])).get("authenticated") else 1)' "$TMPD/whoami.json" 2>/dev/null; then
    if tmo 60 jsm list --remote --jeffreys --json > "$TMPD/list.json"; then
      TIER=jsm; HAVE_LIST=1
    fi
  fi
fi
if [ "$OFFLINE" != 1 ] && command -v curl >/dev/null 2>&1; then
  CURL_REMAIN=$(remaining)
  if [ "$CURL_REMAIN" -gt 0 ] && curl -sS --max-time "$CURL_REMAIN" -A "$UA" "$SITE/skills/sitemap.xml" -o "$TMPD/sitemap.xml" \
     && grep -q '<loc>' "$TMPD/sitemap.xml" 2>/dev/null && grep -q '</urlset>' "$TMPD/sitemap.xml" 2>/dev/null; then
    HAVE_SITEMAP=1
  fi
fi
if [ -z "$TIER" ] && [ $HAVE_SITEMAP -eq 1 ]; then TIER=website; fi
if [ -z "$TIER" ]; then
  TIER=snapshot
  echo "catalog-fetch: WARNING falling back to tier 3 (bundled snapshot only; offline requested or live sources unavailable)" >&2
fi

# ------------------------------------ pass 1 (python): union names + what to fetch live
python3 - "$SNAPSHOT" "$ALIASES" "$TMPD" "$TIER" "$HAVE_LIST" "$HAVE_SITEMAP" <<'PY'
import json, re, sys, os
snap_path, aliases_path, tmpd, tier, have_list, have_sitemap = sys.argv[1:7]
NAME_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")
aliases = {}
try: aliases = json.load(open(aliases_path, encoding="utf-8")).get("aliases", {})
except Exception: pass
canon = lambda n: aliases.get(n, n)
snap = json.load(open(snap_path, encoding="utf-8"))
snap_names = {s["canonical_name"] for s in snap.get("skills", [])}
snap_upd = {s["canonical_name"]: s.get("updated_at") for s in snap.get("skills", [])}
snap_hash = {s["canonical_name"]: s.get("content_hash") for s in snap.get("skills", [])}
live = {}   # canonical -> live metadata from list and/or sitemap
if have_list == "1":
    try:
        for row in json.load(open(os.path.join(tmpd, "list.json"), encoding="utf-8")).get("skills", []):
            n = canon(str(row.get("name", "")))
            if NAME_RE.match(n):
                live[n] = {"updated_at": row.get("updated_at"), "content_hash": row.get("content_hash")}
    except Exception:
        pass
if have_sitemap == "1":
    xml = open(os.path.join(tmpd, "sitemap.xml"), encoding="utf-8", errors="replace").read()
    for m in re.finditer(r"<loc>\s*https://jeffreys-skills\.md/skills/([a-z0-9-]+)\s*</loc>(?:\s*<lastmod>([^<]*)</lastmod>)?", xml):
        n = canon(m.group(1))
        lm = (m.group(2) or "").strip() or None
        if NAME_RE.match(n):
            if n not in live:
                live[n] = {"updated_at": lm, "content_hash": None}
            elif live[n].get("updated_at") is None and lm:
                live[n]["updated_at"] = lm
new = sorted(n for n in live if n not in snap_names)
changed = sorted(n for n, meta in live.items() if n in snap_names and (
    (meta.get("updated_at") and snap_upd.get(n) and meta["updated_at"] != snap_upd[n]) or
    (meta.get("content_hash") and snap_hash.get(n) and meta["content_hash"] != snap_hash[n])))
retirement_known = have_sitemap == "1"
retired = sorted(n for n in snap_names if retirement_known and n not in live)
union = sorted(snap_names | set(live))
open(os.path.join(tmpd, "union.names"), "w").write("\n".join(union) + "\n")
open(os.path.join(tmpd, "fetch.names"), "w").write("\n".join(sorted(set(new) | set(changed))) + "\n")
json.dump({"new": new, "changed": changed, "retired": retired,
           "retirement_known": retirement_known,
           "live": sorted(live), "live_metadata": live},
          open(os.path.join(tmpd, "drift.json"), "w", encoding="utf-8"), indent=2, sort_keys=True)
PY
[ $? -eq 0 ] || { echo "catalog-fetch: name-union pass failed" >&2; exit 1; }

# ------------------------------------------------ live fetches (tier 1: jsm show/related)
if [ "$TIER" = "jsm" ] && [ -s "$TMPD/fetch.names" ]; then
  while IFS= read -r NAME; do
    [ -n "$NAME" ] || continue
    case "$NAME" in *[!a-z0-9-]*) continue;; esac
    SHOWF="$CACHE_DIR/show/$NAME.json"; RELF="$CACHE_DIR/related/$NAME.json"
    if [ ! -f "$SHOWF" ] || [ ! "$SHOWF" -nt "$STAMP" ]; then
      tmo 40 jsm show "$NAME" --json < /dev/null > "$TMPD/show.tmp" && mv "$TMPD/show.tmp" "$SHOWF" || true
    fi
    if [ ! -f "$RELF" ] || [ ! "$RELF" -nt "$STAMP" ]; then
      # `jsm related` may print plain text "No related skills found." — cached as-is, parsed leniently
      tmo 40 jsm related "$NAME" --json < /dev/null > "$TMPD/rel.tmp" && mv "$TMPD/rel.tmp" "$RELF" || true
    fi
  done < "$TMPD/fetch.names"
fi

# ------------------------------------------- preview pages (tier 2: new names only)
if [ "$TIER" = "website" ]; then
  python3 -c '
import json, sys
d = json.load(open(sys.argv[1]))
print("\n".join(d.get("new", [])))' "$TMPD/drift.json" > "$TMPD/preview.names"
  while IFS= read -r NAME; do
    [ -n "$NAME" ] || continue
    case "$NAME" in *[!a-z0-9-]*) continue;; esac
    PF="$CACHE_DIR/pages/$NAME.html"
    if [ ! -f "$PF" ] || [ ! "$PF" -nt "$STAMP" ]; then
      # -f: an HTTP error page (404 etc.) must not be cached — its <meta description>
      # would otherwise be mined as the skill's description
      CURL_REMAIN=$(remaining)
      [ "$CURL_REMAIN" -gt 0 ] && curl -fsS --max-time "$CURL_REMAIN" -A "$UA" "$SITE/skills/$NAME" -o "$TMPD/page.tmp" && mv "$TMPD/page.tmp" "$PF" || true
    fi
  done < "$TMPD/preview.names"
fi

# --------------------------------------------- pass 2 (python): assemble + validate
python3 - "$SNAPSHOT" "$ALIASES" "$MAP" "$TMPD" "$CACHE_DIR" "$TIER" "$SCRIPT_DIR" "$TMPD/out.json" <<'PY'
import json, os, re, sys
from pathlib import Path
snap_path, aliases_path, map_path, tmpd, cache, tier, script_dir, out_path = sys.argv[1:9]
sys.path.insert(0, script_dir)
import skillsel_common as slib

snap = slib.load_json(snap_path)
snap_by = {s["canonical_name"]: s for s in snap.get("skills", [])}
map_skills = set()
try: map_skills = set(slib.load_json(map_path).get("skills", {}))
except Exception: pass
drift = slib.load_json(os.path.join(tmpd, "drift.json"))
union = [l.strip() for l in open(os.path.join(tmpd, "union.names")) if l.strip()]
fetchset = set()
fp = os.path.join(tmpd, "fetch.names")
if os.path.exists(fp):
    fetchset = {l.strip() for l in open(fp) if l.strip()}
live_metadata = drift.get("live_metadata", {})

EMPTY_REL = {"pairs_with": [], "alternative_to": [], "extends": [], "prerequisite": []}

source_errors = []

def load_related(name):
    """Normalize exact empty output; malformed output is unknown and falls back."""
    p = os.path.join(cache, "related", name + ".json")
    if not os.path.exists(p):
        return None
    raw = open(p, encoding="utf-8", errors="replace").read()
    if raw.strip() == "No related skills found.":
        return dict(EMPTY_REL)
    try:
        r = json.loads(raw).get("related", {})
        return {k: sorted({e.get("name") for e in r.get(k, []) if isinstance(e, dict) and e.get("name")})
                for k in EMPTY_REL}
    except Exception as exc:
        source_errors.append({"source": "jsm-related", "skill": name, "error": "malformed-output:" + type(exc).__name__})
        return None

def meta_description(name):
    p = os.path.join(cache, "pages", name + ".html")
    if not os.path.exists(p):
        return ""
    html = open(p, encoding="utf-8", errors="replace").read()
    m = re.search(r'<meta\s+name=["\']description["\']\s+content=["\']([^"\']*)["\']', html, re.I) \
        or re.search(r'<meta\s+content=["\']([^"\']*)["\']\s+name=["\']description["\']', html, re.I)
    import html as H
    return H.unescape(m.group(1)).strip() if m else ""

def base_entry(name):
    return {
        "canonical_name": name, "catalog_sources": ["snapshot"], "installed": False,
        "resolved_path": None, "description": "", "use_when": None, "tags": [],
        "category": None, "packs": [], "related": dict(EMPTY_REL), "detect_rules": [],
        "provisional_mapping": name not in map_skills, "updated_at": None,
        "version": None, "content_hash": None, "author": None, "is_public": None,
    }

skills, changed_extra = [], set()
for name in union:
    prev = snap_by.get(name)
    entry = None
    if tier == "jsm" and name in fetchset:
        showp = os.path.join(cache, "show", name + ".json")
        show = None
        if os.path.exists(showp):
            try: show = slib.load_json(showp).get("skill") or None
            except Exception: show = None
        if show:
            e = base_entry(name)
            e["catalog_sources"] = ["public"]
            e["description"] = show.get("description") or ""
            e["use_when"] = slib.extract_use_when(e["description"])
            e["tags"] = sorted(show.get("compatibility_tags") or [])
            e["category"] = show.get("category")
            e["packs"] = sorted((prev or {}).get("packs", []))
            e["related"] = load_related(name) or (prev or {}).get("related") or dict(EMPTY_REL)
            e["detect_rules"] = (prev or {}).get("detect_rules", [])
            e["updated_at"] = show.get("updated_at")
            e["version"] = show.get("version")
            e["content_hash"] = show.get("content_hash")
            e["author"] = show.get("author")
            e["is_public"] = show.get("is_public")
            if prev and prev.get("content_hash") and e["content_hash"] and prev["content_hash"] != e["content_hash"]:
                changed_extra.add(name)
            entry = e
        elif prev is None:
            source_errors.append({"source": "jsm-show", "skill": name, "error": "missing-or-malformed-output"})
            # live name whose jsm show failed: only the website knows it
            e = base_entry(name)
            e["catalog_sources"] = ["website"]
            e["updated_at"] = (live_metadata.get(name) or {}).get("updated_at")
            entry = e
        else:
            source_errors.append({"source": "jsm-show", "skill": name, "error": "missing-or-malformed-output;used-snapshot"})
    if entry is None and tier == "website" and prev is None:
        e = base_entry(name)
        e["catalog_sources"] = ["website"]
        e["description"] = meta_description(name)
        e["use_when"] = slib.extract_use_when(e["description"])
        e["updated_at"] = (live_metadata.get(name) or {}).get("updated_at")
        entry = e
    if entry is None:
        if prev is None:
            continue  # unreachable: union = snapshot ∪ live
        e = dict(prev)
        e["catalog_sources"] = ["snapshot"]   # reused = ["snapshot"], even when the snapshot says public
        e["provisional_mapping"] = name not in map_skills
        e.setdefault("use_when", slib.extract_use_when(e.get("description") or ""))
        entry = e
    skills.append(entry)

skills.sort(key=lambda e: e["canonical_name"])
live_drift_available = tier in ("jsm", "website")
retirement_known = bool(drift.get("retirement_known"))
drift_known = live_drift_available and retirement_known
out = {
    "skills": skills,
    "source_tier": tier,
    "drift": ({"new": drift.get("new", []),
               "changed": sorted(set(drift.get("changed", [])) | changed_extra),
               "retired": drift.get("retired", [])}
              if live_drift_available else {"new": [], "changed": [], "retired": []}),
    "drift_known": drift_known,
    "retirement_known": retirement_known,
    "source_errors": source_errors,
}
with open(out_path, "w", encoding="utf-8") as fh:
    fh.write(slib.canonical_json(out))

schema_path = os.path.join(script_dir, "..", "references", "schemas", "catalog-entry.schema.json")
schema = slib.load_json(schema_path)
base = Path(os.path.dirname(os.path.abspath(schema_path)))
errs = []
for i, row in enumerate(skills):
    errs.extend(slib.validate_against(row, schema, base, "$.skills[%d]" % i))
if errs:
    for e in errs: sys.stderr.write(e + "\n")
    sys.stderr.write("catalog-fetch: output failed schema validation\n")
    sys.exit(1)
d = out["drift"]
sys.stderr.write("catalog-fetch: tier=%s skills=%d drift new=%d changed=%d retired=%d known=%s retirement_known=%s\n"
                 % (tier, len(skills), len(d["new"]), len(d["changed"]), len(d["retired"]),
                    drift_known, retirement_known))
PY
RC=$?
[ $RC -eq 0 ] || exit 1
if [ "$OUT" = "-" ]; then cat "$TMPD/out.json"; else cp "$TMPD/out.json" "$OUT" && echo "catalog-fetch: wrote $OUT" >&2; fi
exit 0
