#!/usr/bin/env python3
"""Apply the scoring contract (references/SCORING-RUBRIC.md) deterministically.

Inputs (all JSON):
  --evidence FILE        array of evidence records (evidence.schema.json)
  --catalog FILE         {"skills": [catalog entries]}  (normalized catalog, catalog-entry.schema.json)
  --already-done FILE    {"<skill>": {"state": ..., "since": ISO|null, "condition": str|null,
                                      "condition_holds": bool|null, "evidence_ids": [...], "suggested_by": str|null}}
  --run-config FILE      {"run_id", "generated_at", "target", "fingerprint", "sources", "catalog_drift"?,
                          "run_budget"?, "weak_signals"?}
  --gaps FILE            required array of gap objects (empty is explicit)
  --activations FILE     required complete matcher activation output; disagreement is fatal
  --recipe-candidates FILE required matcher-selected recipe ids with evidence provenance
  --overrides FILE       required matcher overrides (empty object is explicit): {"signals": {id: {kind, description, detector}},
                          "skills": {name: {"positive_signals": [...], "anti_signals": [...], "domain_gate_additions": [...]}},
                          "provisional_mappings": {name: <full map entry>}}
  --previous-run FILE    optional previous recommendation-run JSON (for the cross-check)
  --map / --recipes / --constants   default to references/data/*.json
  --out FILE             the recommendation-run JSON (recommendation-run.schema.json)

Same inputs -> byte-identical output. Nothing here consults the clock except through
run-config.generated_at (which the orchestrator pins with SKILL_SELECTION_NOW).
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import skillsel_common as slib  # noqa: E402

PRESENT = "present"
ABSENT = "absent-with-positive-evidence"
UNKNOWN = "unknown"
DONE_STATES = {"not_seen", "suggested_untried", "in_progress", "completed_successfully",
               "attempted_failed", "declined", "superseded", "unknown"}


# ----------------------------------------------------------------- inputs --
def load_inputs(a):
    consts = slib.load_json(a.constants)
    smap = slib.load_json(a.map)
    recipes = slib.load_json(a.recipes)["recipes"]
    evidence = slib.load_json(a.evidence)
    catalog = slib.load_json(a.catalog)["skills"]
    already = slib.load_json(a.already_done) if a.already_done else {}
    cfg = slib.load_json(a.run_config)
    gaps = slib.load_json(a.gaps) if a.gaps else []
    overrides = slib.load_json(a.overrides) if a.overrides else {}
    supplied_activations = slib.load_json(a.activations) if a.activations else None
    recipe_candidates = slib.load_json(a.recipe_candidates) if a.recipe_candidates else None
    prev = slib.load_json(a.previous_run) if a.previous_run and Path(a.previous_run).exists() else None
    return (consts, smap, recipes, evidence, catalog, already, cfg, gaps, overrides,
            supplied_activations, recipe_candidates, prev)


def validate_override_provenance(overrides, evidence):
    active = slib.active_evidence(evidence)
    by_id = {row["id"]: row for row in active}
    evidence_ids = set(by_id)
    for section in ("signals", "skills", "provisional_mappings"):
        for key, value in (overrides.get(section) or {}).items():
            if not isinstance(value, dict) or not value.get("reason") or not value.get("evidence_ids"):
                raise ValueError(f"override {section}.{key} requires reason and evidence_ids")
            missing = set(value["evidence_ids"]) - evidence_ids
            if missing:
                raise ValueError(f"override {section}.{key} cites missing or superseded evidence ids: {sorted(missing)}")
            cited = [by_id[eid] for eid in value["evidence_ids"]]
            cited_signals = {signal for row in cited for signal in row.get("signals", [])}
            if section == "signals":
                if key not in cited_signals:
                    raise ValueError(f"override signals.{key} has no cited evidence support")
                wrong_kind = [row["id"] for row in cited
                              if key in row.get("signals", []) and row.get("kind") != value.get("kind")]
                if wrong_kind:
                    raise ValueError(f"override signals.{key} kind disagrees with evidence {wrong_kind}")
            elif section == "skills":
                additions = {
                    spec["signal"] for field in ("positive_signals", "anti_signals")
                    for spec in value.get(field, [])
                } | set(value.get("domain_gate_additions", []))
                unsupported = additions - cited_signals
                if unsupported:
                    raise ValueError(
                        f"override skills.{key} additions lack cited evidence support: {sorted(unsupported)}"
                    )
            else:
                proposed = {
                    spec["signal"] for field in ("positive_signals", "anti_signals")
                    for spec in value.get(field, [])
                } | set(value.get("domain_gate", []))
                unsupported = proposed - cited_signals
                if unsupported:
                    raise ValueError(
                        f"override provisional_mappings.{key} signals lack cited evidence support: "
                        f"{sorted(unsupported)}"
                    )


def validate_catalog_retirement(catalog_document, run_config):
    requested = set(run_config.get("catalog_drift", {}).get("retired", []))
    if not requested:
        return
    source_drift = catalog_document.get("drift")
    if not catalog_document.get("retirement_known") or not isinstance(source_drift, dict):
        raise ValueError("catalog retirement was requested without a complete catalog source")
    established = set(source_drift.get("retired", []))
    if requested != established:
        raise ValueError(
            "run-config retired names disagree with normalized catalog: "
            f"requested={sorted(requested)} established={sorted(established)}"
        )


def validate_gap_provenance(gaps, evidence, sigs, catalog_names):
    if not isinstance(gaps, list):
        raise ValueError("gaps file must be an array")
    active = {row["id"]: row for row in slib.active_evidence(evidence)}
    for gap in gaps:
        gid = gap.get("id", "gap") if isinstance(gap, dict) else "gap"
        if not isinstance(gap, dict) or not gap.get("catalog_query", "").strip():
            raise ValueError(f"gap {gid} requires an exact catalog_query")
        signals = set(gap.get("signals", []))
        ids = gap.get("evidence_ids", [])
        if not signals or not ids:
            raise ValueError(f"gap {gid} requires signals and evidence_ids")
        unknown = signals - set(sigs)
        if unknown:
            raise ValueError(f"gap {gid} names unknown signals: {sorted(unknown)}")
        missing = set(ids) - set(active)
        if missing:
            raise ValueError(f"gap {gid} cites missing or superseded evidence ids: {sorted(missing)}")
        cited_signals = {signal for eid in ids for signal in active[eid].get("signals", [])}
        unsupported = signals - cited_signals
        if unsupported:
            raise ValueError(f"gap {gid} signals lack cited evidence support: {sorted(unsupported)}")
        if gap.get("names_existing_skill") is not None:
            raise ValueError(f"gap {gid} names an existing skill")
        text = " ".join(str(gap.get(field) or "")
                        for field in ("description", "catalog_query", "proposed_request_title")).lower()
        for name in catalog_names:
            if re.search(rf"(^|[^a-z0-9-])/?{re.escape(name)}([^a-z0-9-]|$)", text):
                raise ValueError(f"gap {gid} mentions existing catalog skill {name}")


def merged_signals(smap, overrides):
    sigs = dict(smap["signals"])
    for k, v in (overrides.get("signals") or {}).items():
        sigs[k] = {x: y for x, y in v.items() if x not in ("reason", "evidence_ids")}
    return sigs


def mapping_for(name, smap, overrides, provisional):
    entry = smap["skills"].get(name)
    if entry is None:
        entry = (overrides.get("provisional_mappings") or {}).get(name)
        if entry is None:
            entry = {"domain_gate": [], "positive_signals": [], "anti_signals": [], "prerequisites": [],
                     "pairs": [], "kickoff_phrasing": f"Use /{name}.", "baseline_hygiene": None,
                     "cost": 2, "risk": 2, "accretive_base": 1, "expected_artifact": "n/a",
                     "stop_condition": "n/a", "notes": "provisional: no trigger model supplied"}
    entry = {k: v for k, v in dict(entry).items() if k not in ("reason", "evidence_ids")}
    ov = (overrides.get("skills") or {}).get(name) or {}
    entry["positive_signals"] = list(entry.get("positive_signals", [])) + list(ov.get("positive_signals", []))
    entry["anti_signals"] = list(entry.get("anti_signals", [])) + list(ov.get("anti_signals", []))
    entry["domain_gate"] = list(entry.get("domain_gate", [])) + list(ov.get("domain_gate_additions", []))
    return entry


# ------------------------------------------------------------- activation --
def activate(evidence, sigs):
    """signal id -> {"state", "present": [records], "absent": [records]}"""
    act = {}
    for e in slib.active_evidence(evidence):
        for s in e.get("signals", []):
            slot = act.setdefault(s, {"state": UNKNOWN, "present": [], "absent": []})
            if e["state"] == PRESENT:
                slot["present"].append(e)
            elif e["state"] == ABSENT:
                slot["absent"].append(e)
    for s, slot in act.items():
        if slot["present"]:
            slot["state"] = PRESENT
        elif slot["absent"]:
            slot["state"] = ABSENT
    for s, meta in sigs.items():
        if s not in act:
            act[s] = {"state": meta.get("default_state", UNKNOWN), "present": [], "absent": []}
    return act


def check_supplied_activations(supplied, act, sigs):
    states = supplied.get("signals", supplied) if isinstance(supplied, dict) else None
    if not isinstance(states, dict):
        raise ValueError("activation file must be an object or contain a signals object")
    missing = set(sigs) - set(states)
    extra = set(states) - set(sigs)
    if missing or extra:
        raise ValueError(f"activation coverage mismatch: missing={sorted(missing)} extra={sorted(extra)}")
    for signal in sorted(sigs):
        value = states[signal]
        if not isinstance(value, dict) or set(value) != {"state", "evidence_ids"}:
            raise ValueError(f"activation {signal} requires exactly state and evidence_ids")
        state = value["state"]
        actual = state_of(act, signal)
        if state != actual:
            raise ValueError(f"activation disagreement for {signal}: matcher={state}, scorer={actual}")
        slot = act[signal]
        rows = slot["present"] if actual == PRESENT else slot["absent"] if actual == ABSENT else []
        expected_ids = sorted(row["id"] for row in rows)
        if value["evidence_ids"] != expected_ids:
            raise ValueError(
                f"activation evidence mismatch for {signal}: matcher={value['evidence_ids']} scorer={expected_ids}"
            )


def allowed_recipe_ids(recipe_candidates, evidence, recipes=None, act=None):
    rows = recipe_candidates.get("recipes", recipe_candidates) if isinstance(recipe_candidates, dict) else recipe_candidates
    if not isinstance(rows, list):
        raise ValueError("recipe candidates must be an array or contain a recipes array")
    active_rows = slib.active_evidence(evidence)
    evidence_by_id = {row["id"]: row for row in active_rows}
    evidence_ids = set(evidence_by_id)
    recipe_by_id = {row["id"]: row for row in (recipes or [])}
    allowed = set()
    for row in rows:
        if not isinstance(row, dict) or not row.get("recipe_id") or not row.get("evidence_ids"):
            raise ValueError("every recipe candidate requires recipe_id and evidence_ids")
        missing = set(row["evidence_ids"]) - evidence_ids
        if missing:
            raise ValueError(f"recipe {row['recipe_id']} cites missing or superseded evidence ids: {sorted(missing)}")
        recipe_id = row["recipe_id"]
        if recipe_id in allowed:
            raise ValueError(f"duplicate recipe candidate {recipe_id}")
        if recipes is not None and recipe_id not in recipe_by_id:
            raise ValueError(f"unknown recipe candidate {recipe_id}")
        if recipes is not None:
            triggers = set(recipe_by_id[recipe_id].get("triggers", []))
            supported = any(
                evidence_by_id[eid].get("state") == PRESENT
                and triggers.intersection(evidence_by_id[eid].get("signals", []))
                for eid in row["evidence_ids"]
            )
            if not supported or (act is not None and not any(state_of(act, trigger) == PRESENT for trigger in triggers)):
                raise ValueError(f"recipe {recipe_id} lacks cited present trigger evidence")
        allowed.add(recipe_id)
    return allowed


def state_of(act, s):
    return act.get(s, {}).get("state", UNKNOWN)


def fires(spec, act):
    when = spec.get("when", "present")
    st = state_of(act, spec["signal"])
    return (when == "present" and st == PRESENT) or (when == "absent" and st == ABSENT)


def supporting(spec, act):
    when = spec.get("when", "present")
    slot = act.get(spec["signal"], {})
    return list(slot.get("present" if when == "present" else "absent", []))


def distinct_anchor_key(e):
    return e.get("locator") or e["id"]


# ------------------------------------------------------------ dimensions --
def already_done_D(name, already, consts, now_iso):
    info = already.get(name) or {"state": "not_seen"}
    st = info.get("state", "not_seen")
    if st not in DONE_STATES:
        st = "unknown"
    table = consts["already_done_D"]
    gate = None
    if st == "completed_successfully":
        since = info.get("since")
        window = consts["suppression"]["completed_window_days"]
        in_window = True if not since else slib.days_between(since, now_iso) <= window
        if in_window:
            gate = "completed_recently"
            return table["completed_successfully_in_window"], st, gate
        return table["completed_successfully_after_window"], st, gate
    if st == "declined":
        holds = info.get("condition_holds")
        holds = True if holds is None else bool(holds)
        if holds:
            gate = "declined_condition_holds"
            return table["declined_condition_holds"], st, gate
        return table["declined_condition_lifted"], st, gate
    if st == "in_progress":
        gate = "in_progress"
    return table[st], st, gate


def prereq_status(entry, already, act):
    prs = entry.get("prerequisites", [])
    if not prs:
        return "none", []
    unsatisfied = []
    for p in prs:
        st = (already.get(p["skill"]) or {}).get("state")
        by_signal = any(state_of(act, s) == PRESENT for s in p.get("satisfied_by_signals", []))
        if st in ("completed_successfully", "superseded") or by_signal:
            continue
        unsatisfied.append(p["skill"])
    return ("satisfied" if not unsatisfied else "unsatisfied"), unsatisfied


def score_skill(name, cat, entry, act, sigs, already, consts, now_iso, retired=False):
    w = consts["weights"]
    dmin, dmax = consts["dimension_range"]["min"], consts["dimension_range"]["max"]
    clamp = lambda x: max(dmin, min(dmax, int(x)))

    # applicability gate
    gate = entry.get("domain_gate", [])
    if retired:
        applicable, basis = False, "catalog-retired"
    elif not gate:
        applicable, basis = True, "universal"
    else:
        states = [state_of(act, g) for g in gate]
        if any(s == PRESENT for s in states):
            applicable, basis = True, "gate-present"
        elif all(s == ABSENT for s in states):
            applicable, basis = False, "gate-absent"
        else:
            applicable, basis = True, "gate-unknown"

    firing = [p for p in entry.get("positive_signals", []) if fires(p, act)]
    anti_firing = [a for a in entry.get("anti_signals", []) if fires(a, act)]
    hyg = entry.get("baseline_hygiene")
    hyg_fires = bool(hyg) and fires({"signal": hyg["gap_signal"], "when": hyg.get("gap_when", "present")}, act)

    j_juncture = max([p["weight"] for p in firing if sigs.get(p["signal"], {}).get("kind") == "juncture"], default=0)
    J = clamp(max(j_juncture, hyg["severity"] if hyg_fires else 0))
    a_profile = max([p["weight"] for p in firing if sigs.get(p["signal"], {}).get("kind") == "profile"], default=0)
    pen = sum(consts["accretiveness"]["anti_signal_penalty"][a.get("strength", "weak")] for a in anti_firing)
    A = clamp(entry.get("accretive_base", consts["accretiveness"]["default_base"]) + a_profile - pen)

    anchors = {}
    for p in firing:
        for e in supporting(p, act):
            anchors[e["id"]] = e
    if hyg_fires:
        for e in supporting({"signal": hyg["gap_signal"], "when": hyg.get("gap_when", "present")}, act):
            anchors[e["id"]] = e
    anchor_list = sorted(anchors.values(), key=lambda e: e["id"])
    best_by_source = {}
    for anchor in anchor_list:
        source = anchor["source_type"]
        best_by_source[source] = max(best_by_source.get(source, 0), anchor["confidence"])
    E = max(best_by_source.values(), default=0)
    corroboration_floor = consts["evidence_quality"]["corroborating_source_min_confidence"]
    corroborated_sources = sum(1 for confidence in best_by_source.values() if confidence >= corroboration_floor)
    if anchor_list and corroborated_sources < 2:
        E -= consts["evidence_quality"]["single_source_type_penalty"]
    if cat.get("provisional_mapping"):
        E = min(E, consts["evidence_quality"]["provisional_mapping_cap"])
    E = clamp(E)
    C = clamp(entry.get("cost", 2))
    R = clamp(entry.get("risk", 2))
    D, done_state, gate_name = already_done_D(name, already, consts, now_iso)

    total = w["J"] * J + w["A"] * A + w["E"] * E + w["C"] * C + w["R"] * R + w["D"] * D
    profile_anchors = sorted({distinct_anchor_key(e) for e in anchor_list if e["kind"] == "profile"})
    juncture_anchors = sorted({distinct_anchor_key(e) for e in anchor_list if e["kind"] == "juncture"})
    pstatus, unsatisfied = prereq_status(entry, already, act)
    return {
        "applicable": applicable, "basis": basis, "firing": firing, "anti_firing": anti_firing,
        "hyg_fires": hyg_fires, "scores": {"J": J, "A": A, "E": E, "C": C, "R": R, "D": D, "total": total},
        "anchors": anchor_list, "profile_anchor_keys": profile_anchors, "juncture_anchor_keys": juncture_anchors,
        "done_state": done_state, "gate": gate_name, "prereq_status": pstatus, "unsatisfied": unsatisfied,
    }


def run_now_eligible(r, consts):
    t = consts["tiers"]
    s = r["scores"]
    if not r["applicable"] or r["gate"]:
        return False
    # The normal route (>= 2 independent anchors, at least one profile AND one juncture)
    # is tried first. Baseline-hygiene is an ADDITIONAL route — "the only route WITHOUT a
    # juncture anchor" (SCORING-RUBRIC.md) — so a hygiene skill that also has a juncture
    # anchor must still be able to qualify normally; it must never be *demoted* by the
    # stricter two-profile-anchor hygiene rule. This matches validate-run.py, which takes
    # the hygiene route only when the anchor has no juncture anchor.
    rn = t["run_now"]
    distinct = set(r["profile_anchor_keys"]) | set(r["juncture_anchor_keys"])
    if (s["total"] >= rn["min_score"] and s["J"] >= rn["min_J"] and s["E"] >= rn["min_E"]
            and len(distinct) >= rn["min_anchors"]
            and (not rn["require_profile_anchor"] or r["profile_anchor_keys"])
            and (not rn["require_juncture_anchor"] or r["juncture_anchor_keys"])):
        return True
    if r["hyg_fires"]:
        h = t["run_now_baseline_hygiene"]
        return (s["total"] >= h["min_score"] and s["J"] >= h["min_J"] and s["E"] >= h["min_E"]
                and len(r["profile_anchor_keys"]) >= h["min_profile_anchors"])
    return False


def sort_key(name, r):
    s = r["scores"]
    return (-s["total"], -s["J"], -s["E"], s["C"], s["R"], name)


# --------------------------------------------------------------- portfolio --
def build_campaigns(eligible, results, entries, catalog_by, recipes, already, act, consts,
                    allowed_recipes):
    pf = consts["portfolio"]
    selected = []
    rejected = {}  # name -> (reason, blocking campaign id or None)
    covered = set()
    alt = {n: set(catalog_by[n]["related"]["alternative_to"]) for n in catalog_by}

    def recipe_is_live(recipe):
        if allowed_recipes is not None and recipe["id"] not in allowed_recipes:
            return False
        return any(state_of(act, trigger) == PRESENT for trigger in recipe.get("triggers", []))

    def members_for(name):
        recipe = next((rc for rc in recipes if rc["anchor"] == name and recipe_is_live(rc)), None)
        requested = recipe["sequence"] if recipe else [{"skill": name, "role": "anchor"}]
        seq = []
        included = set()

        def add_member(skill, role, note=None, stack=()):
            if skill in included:
                return True
            if skill in stack:
                return False
            result = results.get(skill)
            if result is None or not result["applicable"] or result["gate"]:
                return False
            start = len(seq)
            included_before = set(included)
            for prerequisite in result["unsatisfied"]:
                if not add_member(prerequisite, "prerequisite", None, stack + (skill,)):
                    del seq[start:]
                    included.clear()
                    included.update(included_before)
                    return False
            seq.append({"skill": skill, "role": role, "note": note})
            included.add(skill)
            return True

        for member in requested:
            skill = member["skill"]
            role = "anchor" if skill == name else member["role"]
            if not add_member(skill, role, member.get("note")) and role == "anchor":
                return recipe, []
        if name not in included:
            return recipe, []
        return recipe, seq

    for name in eligible:
        if len(selected) >= pf["max_campaigns"]:
            rejected[name] = ("portfolio_capacity", None)
            continue
        if name in covered:
            rejected[name] = ("portfolio_capacity", next(c["id"] for c in selected if any(m["skill"] == name for m in c["sequence"])))
            continue
        recipe, seq = members_for(name)
        if not seq:
            rejected[name] = ("prerequisite_unavailable", None)
            continue
        member_names = [m["skill"] for m in seq]
        effort = sum(results[m]["scores"]["C"] for m in dict.fromkeys(member_names))
        effort_limit = pf["first_campaign_max_effort"] if not selected else pf["other_campaign_max_effort"]
        if effort > effort_limit:
            rejected[name] = ("portfolio_budget", selected[0]["id"] if selected else None)
            continue
        clash = None
        my_sigs = {p["signal"] for p in results[name]["firing"]}
        for c in selected:
            c_members = {m["skill"] for m in c["sequence"]}
            if any(m in alt.get(o, set()) or o in alt.get(m, set()) for m in member_names for o in c_members):
                clash = c["id"]
                break
            other_sigs = {p["signal"] for p in results[c["anchor"]]["firing"]}
            small = min(len(my_sigs), len(other_sigs)) or 1
            if my_sigs and other_sigs and len(my_sigs & other_sigs) / small > pf["overlap_shared_signal_fraction"]:
                clash = c["id"]
                break
        if clash:
            rejected[name] = ("portfolio_overlap", clash)
            continue
        cid = f"camp-{len(selected) + 1:02d}"
        selected.append({"id": cid, "anchor": name, "recipe": recipe, "sequence": seq, "effort": effort})
        covered.update(member_names)
    return selected, rejected


def kickoff_for(camp, entries):
    if camp["recipe"] and [(m["skill"], m["role"]) for m in camp["sequence"]] == [
            (m["skill"], m["role"]) for m in camp["recipe"]["sequence"]]:
        return camp["recipe"]["kickoff_prompt"]
    parts = []
    for m in camp["sequence"]:
        parts.append(entries[m["skill"]]["kickoff_phrasing"])
    if len(parts) == 1:
        return parts[0]
    return "First " + parts[0] + " Then: " + " Then: ".join(parts[1:])


def install_line(camp, catalog_by):
    missing = [m["skill"] for m in camp["sequence"] if not catalog_by[m["skill"]].get("installed")]
    if not missing:
        return "echo 'every skill in this campaign is already installed'"
    return "for s in " + " ".join(missing) + "; do jsm install \"$s\"; done"


# ------------------------------------------------------------------ main --
def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--evidence", required=True)
    ap.add_argument("--catalog", required=True)
    ap.add_argument("--already-done", required=True)
    ap.add_argument("--run-config", required=True)
    ap.add_argument("--gaps", required=True)
    ap.add_argument("--overrides", required=True)
    ap.add_argument("--activations", required=True)
    ap.add_argument("--recipe-candidates", required=True)
    ap.add_argument("--previous-run")
    ap.add_argument("--map", default=str(slib.DATA_DIR / "signal-to-skill-map.json"))
    ap.add_argument("--recipes", default=str(slib.DATA_DIR / "combo-recipes.json"))
    ap.add_argument("--constants", default=str(slib.DATA_DIR / "scoring-constants.json"))
    ap.add_argument("--out", required=True)
    a = ap.parse_args(argv)

    (consts, smap, recipes, evidence, catalog, already, cfg, gaps, overrides,
     supplied_activations, recipe_candidates, prev) = load_inputs(a)
    validate_catalog_retirement(slib.load_json(a.catalog), cfg)
    validate_override_provenance(overrides, evidence)
    sigs = merged_signals(smap, overrides)
    act = activate(evidence, sigs)
    check_supplied_activations(supplied_activations, act, sigs)
    allowed_recipes = allowed_recipe_ids(recipe_candidates, evidence, recipes, act)
    now_iso = cfg["generated_at"]
    catalog_by = {c["canonical_name"]: c for c in catalog}
    names = sorted(catalog_by)
    validate_gap_provenance(gaps, evidence, sigs, names)
    retired_names = set(cfg.get("catalog_drift", {}).get("retired", []))
    entries = {n: mapping_for(n, smap, overrides, catalog_by[n].get("provisional_mapping")) for n in names}
    results = {
        n: score_skill(n, catalog_by[n], entries[n], act, sigs, already, consts, now_iso,
                       retired=n in retired_names)
        for n in names
    }

    eligible = sorted([n for n in names if run_now_eligible(results[n], consts)], key=lambda n: sort_key(n, results[n]))
    campaigns, rejected = build_campaigns(
        eligible, results, entries, catalog_by, recipes, already, act, consts, allowed_recipes
    )
    role_of = {}
    for c in campaigns:
        for m in c["sequence"]:
            role_of[m["skill"]] = (c["id"], m["role"])

    t = consts["tiers"]
    ledger = []
    tiers = {"run_now": [], "run_soon": [], "keep_handy": [], "considered_not_now": [], "not_applicable": []}
    for n in names:
        r, e, cat = results[n], entries[n], catalog_by[n]
        s = r["scores"]
        pos = sorted({p["signal"] + ("" if p.get("when", "present") == "present" else " (absent)") for p in r["firing"]})
        neg = sorted({x["signal"] + ("" if x.get("when", "present") == "present" else " (absent)") for x in r["anti_firing"]})
        camp_id, role = role_of.get(n, (None, None))
        promo = None
        if not r["applicable"]:
            if r["basis"] == "catalog-retired":
                disp, why = "not_applicable", "catalog_retired"
                reason = "Retired from the complete live catalog; retained only for audit history."
            else:
                disp, why = "not_applicable", "gate_absent"
                reason = "Domain gate absent with positive evidence: " + ", ".join(e.get("domain_gate", [])[:4]) + "."
        elif camp_id:
            disp, why = "run_now", "run_now_rule" if role == "anchor" else f"campaign_{role}"
            reason = ("RUN NOW anchor: " if role == "anchor" else f"Joins {camp_id} as {role}: ") + (
                "signals " + ", ".join(pos) if pos else "declared by the campaign recipe") + "."
        elif r["gate"]:
            disp = "keep_handy" if s["total"] >= t["keep_handy"]["min_score"] else "considered_not_now"
            why = f"suppressed:{r['gate']}"
            reason = f"Suppressed by already-done state {r['done_state']} ({r['gate']}); score {s['total']} otherwise."
        elif n in rejected:
            disp, why = "run_soon", rejected[n][0]
            reason = f"RUN NOW eligible but not selected into the portfolio ({rejected[n][0]}" + (
                f", clashes with {rejected[n][1]}" if rejected[n][1] else "") + ")."
        elif s["total"] >= t["run_soon"]["min_score"] and s["J"] >= t["run_soon"]["min_J"]:
            disp, why = "run_soon", "run_soon_rule"
            reason = "Score and juncture fit clear the RUN SOON bar: " + ", ".join(pos) + "."
            if r["prereq_status"] == "unsatisfied":
                reason += " Prerequisites unsatisfied: " + ", ".join(r["unsatisfied"]) + "."
        elif s["total"] >= t["keep_handy"]["min_score"]:
            disp, why = "keep_handy", "keep_handy_rule"
            not_firing = sorted((p for p in e.get("positive_signals", []) if not fires(p, act)), key=lambda p: (-p["weight"], p["signal"]))
            promo = not_firing[0]["signal"] if not_firing else None
            reason = "Applicable; promote when " + (promo or "a juncture signal") + " appears. Present: " + (", ".join(pos) or "none") + "."
        else:
            disp, why = "considered_not_now", ("score_below_12" if r["basis"] != "gate-unknown" else "gate_unknown")
            reason = ("Domain could not be verified (gate unknown)." if r["basis"] == "gate-unknown" else
                      "Applicable but nothing in the profile or juncture calls for it now.") + (
                " Anti-signals: " + ", ".join(neg) + "." if neg else "")
        if r["prereq_status"] == "unsatisfied" and camp_id:
            pstat = "in_campaign" if all(p in {m["skill"] for c in campaigns for m in c["sequence"] if c["id"] == camp_id} for p in r["unsatisfied"]) else "unsatisfied"
        else:
            pstat = r["prereq_status"]
        row = {
            "canonical_name": n,
            "catalog_sources": cat["catalog_sources"],
            "provisional_mapping": bool(cat.get("provisional_mapping")),
            "applicability": r["applicable"],
            "applicability_basis": r["basis"],
            "positive_signals": pos,
            "anti_signals": neg,
            "prerequisite_status": pstat,
            "already_done_state": r["done_state"],
            "suppression_gate": r["gate"],
            "scores": s,
            "anchors": {"profile": r["profile_anchor_keys"], "juncture": r["juncture_anchor_keys"]},
            "disposition": disp,
            "tier_reason": why,
            "campaign_id": camp_id,
            "campaign_role": role,
            "promotion_trigger": promo,
            "reason": reason,
            "evidence_ids": sorted({x["id"] for x in r["anchors"]} | set((already.get(n) or {}).get("evidence_ids", []))),
        }
        ledger.append(row)
        tiers[disp].append(n)

    camp_out = []
    for c in campaigns:
        anchor_r = results[c["anchor"]]
        ev = {x["id"] for x in anchor_r["anchors"]}
        for m in c["sequence"]:
            ev |= {x["id"] for x in results[m["skill"]]["anchors"]}
        runners = []
        runner_names = set()
        retained_names = {m["skill"] for m in c["sequence"]}

        def add_runner(candidate, why, retained_names=retained_names,
                       runner_names=runner_names, runners=runners):
            if candidate in retained_names or candidate in runner_names:
                return
            runner_names.add(candidate)
            runners.append({"candidate": candidate, "why_it_lost": why})

        for n, (why, clash) in sorted(rejected.items()):
            if clash == c["id"]:
                add_runner(n, f"{why}: " + ("overlaps this campaign" if why == "portfolio_overlap" else "exceeds the run budget alongside it" if why == "portfolio_budget" else "already covered by this campaign"))
        if c["recipe"] and c["recipe"].get("runner_up"):
            ru = c["recipe"]["runner_up"]
            if ru.get("candidate") in catalog_by:
                add_runner(ru["candidate"], ru["why_it_lost"])
        camp_out.append({
            "id": c["id"],
            "title": c["recipe"]["title"] if c["recipe"] else f"Run {c['anchor']}",
            "anchor": c["anchor"],
            "sequence": [{"skill": m["skill"], "role": m["role"], "note": m.get("note")} for m in c["sequence"]],
            "kickoff_prompt": kickoff_for(c, entries),
            "expected_artifact": c["recipe"]["expected_artifact"] if c["recipe"] else entries[c["anchor"]]["expected_artifact"],
            "stop_condition": c["recipe"]["stop_condition"] if c["recipe"] else entries[c["anchor"]]["stop_condition"],
            "evidence_ids": sorted(ev) or ["ev-0000"],
            "install_command": install_line(c, catalog_by),
            "runners_up": runners,
            "effort": c["effort"],
            "recipe_id": c["recipe"]["id"] if c["recipe"] else None,
        })

    crosscheck = {"previous_run_id": None, "acted_on": [], "declined": [], "still_pending": []}
    if prev:
        crosscheck["previous_run_id"] = prev.get("run_id")
        prev_rec = sorted(set(prev.get("tiers", {}).get("run_now", [])) | set(prev.get("tiers", {}).get("run_soon", [])))
        for n in prev_rec:
            st = (already.get(n) or {}).get("state", "not_seen")
            if st in ("completed_successfully", "in_progress", "attempted_failed", "superseded"):
                crosscheck["acted_on"].append(n)
            elif st == "declined":
                crosscheck["declined"].append({"skill": n, "condition": (already.get(n) or {}).get("condition")})
            elif n in set(prev.get("tiers", {}).get("run_now", [])) | set(prev.get("tiers", {}).get("run_soon", [])):
                crosscheck["still_pending"].append(n)

    out = {
        "run_id": cfg["run_id"],
        "generator_version": consts["generator_version"],
        "generated_at": now_iso,
        "target": cfg["target"],
        "fingerprint": cfg["fingerprint"],
        "inputs": {
            "evidence_sha256": slib.sha256_file(a.evidence),
            "catalog_sha256": slib.sha256_file(a.catalog),
            "signal_map_sha256": slib.sha256_file(a.map),
            "recipes_sha256": slib.sha256_file(a.recipes),
            "constants_sha256": slib.sha256_file(a.constants),
            "already_done_sha256": slib.sha256_file(a.already_done),
            "run_config_sha256": slib.sha256_file(a.run_config),
            "gaps_sha256": slib.sha256_file(a.gaps),
            "overrides_sha256": slib.sha256_file(a.overrides),
            "recipe_candidates_sha256": slib.sha256_file(a.recipe_candidates),
            "activations_sha256": slib.sha256_file(a.activations),
            "previous_run_sha256": slib.sha256_file(a.previous_run) if a.previous_run and Path(a.previous_run).exists() else None,
            "catalog_count": len(names),
            "run_budget": {"max_campaigns": consts["portfolio"]["max_campaigns"],
                            "first_campaign_max_effort": consts["portfolio"]["first_campaign_max_effort"],
                            "other_campaign_max_effort": consts["portfolio"]["other_campaign_max_effort"]},
        },
        "sources": cfg.get("sources", {}),
        "catalog_drift": cfg.get("catalog_drift", {"new": [], "renamed": [], "retired": [], "provisional": [n for n in names if catalog_by[n].get("provisional_mapping")]}),
        "campaigns": camp_out,
        "tiers": tiers,
        "ledger": ledger,
        "gaps": gaps,
        "weak_signals": cfg.get("weak_signals", {"jsm_scan": None, "jsm_suggest": None}),
        "previous_run_crosscheck": crosscheck,
    }
    slib.write_json(a.out, out)
    print(f"scored {len(names)} skills: run_now={len(tiers['run_now'])} run_soon={len(tiers['run_soon'])} "
          f"keep_handy={len(tiers['keep_handy'])} considered={len(tiers['considered_not_now'])} "
          f"not_applicable={len(tiers['not_applicable'])} campaigns={len(camp_out)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
