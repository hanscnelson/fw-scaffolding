#!/usr/bin/env python3
"""Render the generated Markdown views from their canonical JSON sources.

  references/data/catalog-snapshot.json    -> references/CATALOG-SNAPSHOT.md
  references/data/signal-to-skill-map.json -> references/SIGNAL-TO-SKILL-MAP.md
  references/data/combo-recipes.json       -> references/COMBO-RECIPES.md

Each view begins with a provenance header:

    <!-- generated_from_sha256: ... -->
    <!-- generated_at: ... -->
    <!-- generator_version: ... -->

The body is a pure function of the JSON, so validate-skill.py can re-render and
compare (ignoring the generated_at line). Never hand-edit a generated view —
edit the JSON and re-run this script. (House rule: the JSON is the hand-written
source; these views are build artifacts, like a binary to its code.)
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import skillsel_common as slib  # noqa: E402

REFS = slib.PKG_ROOT / "references"


def header(src: Path) -> str:
    version = slib.load_json(src).get("generator_version", "unknown")
    return (
        f"<!-- generated_from_sha256: {slib.sha256_file(src)} -->\n"
        f"<!-- generated_at: {slib.now_iso()} -->\n"
        f"<!-- generator_version: {version} -->\n"
        "<!-- GENERATED VIEW - do not hand-edit. Source: "
        f"references/data/{src.name}; regenerate with scripts/render-reference-views.py -->\n\n"
    )


def cell(s, limit=110):
    s = (s or "").replace("|", "\\|").replace("\n", " ").strip()
    return s if len(s) <= limit else s[: limit - 1] + "…"


def render_catalog(src: Path) -> str:
    data = slib.load_json(src)
    h = data["harmonized_against"]
    out = [header(src)]
    out.append("# Catalog Snapshot (generated view)\n")
    out.append(f"Refreshed {h['refreshed_at']} — {h['skill_count']} public skills; newest update {h['newest_updated_at']}; listing sha `{h['source_listing_sha256'][:16]}…`.\n")
    out.append("| Skill | Category | Packs | Updated | Related | Use when |")
    out.append("|---|---|---|---|---|---|")
    for e in data["skills"]:
        rel = e["related"]
        edges = sum(len(v) for v in rel.values())
        packs = ", ".join(p for p in e["packs"] if p != "complete") or "—"
        out.append(
            f"| {e['canonical_name']} | {e.get('category') or '—'} | {cell(packs, 40)} | "
            f"{(e.get('updated_at') or '—')[:10]} | {edges} | {cell(e.get('use_when') or '', 120)} |"
        )
    out.append("")
    out.append("Related-edge detail lives in the JSON (`related.pairs_with/alternative_to/extends/prerequisite`).")
    return "\n".join(out) + "\n"


def render_map(src: Path) -> str:
    data = slib.load_json(src)
    sigs, skills = data["signals"], data["skills"]
    out = [header(src)]
    out.append("# Signal-to-Skill Map (generated view)\n")
    h = data["harmonized_against"]
    out.append(f"Covers {len(skills)} skills with {len(sigs)} signals; harmonized against the catalog listing of {h['refreshed_at']}.\n")
    out.append("## Signal vocabulary\n")
    out.append("| Signal | Kind | Detector | Description |")
    out.append("|---|---|---|---|")
    for sid in sorted(sigs):
        m = sigs[sid]
        d = m["description"] + (" (defaults to absent when no evidence mentions it)" if m.get("default_state") else "")
        out.append(f"| {sid} | {m['kind']} | {cell(m['detector'], 44)} | {cell(d, 130)} |")
    out.append("\n## Per-skill trigger models\n")
    out.append("Weights are 1–4; `(absent)` marks a signal that fires on verified absence. C/R = cost/risk 0–4; H = baseline-hygiene severity.\n")
    out.append("| Skill | Gate | Positive signals | Anti-signals | Prereqs | Pairs | C/R | H |")
    out.append("|---|---|---|---|---|---|---|---|")
    for name in sorted(skills):
        e = skills[name]
        gate = ", ".join(e["domain_gate"]) or "universal"
        pos = ", ".join(
            f"{p['signal']}{'(absent)' if p.get('when') == 'absent' else ''}:{p['weight']}"
            for p in e["positive_signals"]
        ) or "—"
        anti = ", ".join(
            f"{a['signal']}{'(absent)' if a.get('when') == 'absent' else ''}:{a.get('strength', 'weak')}"
            for a in e["anti_signals"]
        ) or "—"
        pre = ", ".join(p["skill"] for p in e["prerequisites"]) or "—"
        pairs = ", ".join(e["pairs"]) or "—"
        hyg = str(e["baseline_hygiene"]["severity"]) if e.get("baseline_hygiene") else "—"
        out.append(
            f"| {name} | {cell(gate, 60)} | {cell(pos, 100)} | {cell(anti, 60)} | "
            f"{cell(pre, 40)} | {cell(pairs, 50)} | {e['cost']}/{e['risk']} | {hyg} |"
        )
    out.append("\nKickoff phrasings, expected artifacts, and stop conditions live in the JSON — the scorer reads them verbatim.")
    return "\n".join(out) + "\n"


def render_recipes(src: Path) -> str:
    data = slib.load_json(src)
    out = [header(src)]
    out.append("# Combo Recipes (generated view)\n")
    out.append("Campaigns the portfolio selector can pick when their anchor is RUN NOW eligible. The kickoff prompt is pasted verbatim.\n")
    for r in data["recipes"]:
        out.append(f"## {r['title']}  \n`{r['id']}` — anchor **{r['anchor']}**, triggers: {', '.join(r['triggers'])}\n")
        seq = " → ".join(
            f"{m['skill']}" + (f" ({m['role']})" if m["role"] != "anchor" else "")
            for m in r["sequence"]
        )
        out.append(f"**Sequence:** {seq}\n")
        out.append(f"**Kickoff (paste verbatim):**\n> {r['kickoff_prompt']}\n")
        out.append(f"**Expected artifact:** {r['expected_artifact']}\n")
        out.append(f"**Stop condition:** {r['stop_condition']}\n")
        ru = r.get("runner_up")
        if ru:
            out.append(f"**Runner-up:** {ru['candidate']} — {ru['why_it_lost']}\n")
    return "\n".join(out) + "\n"


VIEWS = [
    ("catalog-snapshot.json", "CATALOG-SNAPSHOT.md", render_catalog),
    ("signal-to-skill-map.json", "SIGNAL-TO-SKILL-MAP.md", render_map),
    ("combo-recipes.json", "COMBO-RECIPES.md", render_recipes),
]


def render_all(write: bool = True) -> dict[str, str]:
    rendered = {}
    for src_name, dst_name, fn in VIEWS:
        src = slib.DATA_DIR / src_name
        body = fn(src)
        rendered[dst_name] = body
        if write:
            (REFS / dst_name).write_text(body, encoding="utf-8")
            print(f"wrote references/{dst_name} ({body.count(chr(10))} lines)")
    return rendered


if __name__ == "__main__":
    render_all(write="--check" not in sys.argv)
