#!/usr/bin/env bash
# scan-shipped-package.sh — prohibited-name / portability / privacy scan for this package.
#
# Usage:
#   bash scan-shipped-package.sh --strict FILE --except 'name1|name2' --allowed FILE \
#        --hostnames FILE --repo-names FILE [--pkg DIR] [--aliases FILE]
#
# The deny/allow lists are BUILD-TIME INPUTS generated on the authoring machine and
# passed as file arguments — they are never embedded here (a scanner that contained the
# private-name list would itself be a leak). List files: one token per line; blank lines
# and lines starting with # ignored.
#   --strict     private-only skill names that must not appear anywhere, in any form
#   --except     regex alternation of names allowed as plain CLI invocations but not as
#                skill references (public tools whose names collide with private dirs)
#   --allowed    current public skill names (+ this skill's own name) that hard skill
#                references must resolve to
#   --hostnames  machine hostnames that must not appear
#   --repo-names private repository/project names that must not appear
#   --aliases    the package's aliases.json (defaults to references/data/aliases.json);
#                alias keys may appear ONLY inside that file
#
# Exit 0 with "scan clean" when there are no hard findings; every `review:` line printed
# must be resolved (fix the reference, or list the benign token in scripts/scan-ignore.txt
# with a justification comment) before the package counts as clean.
# Exit 1 on any hard finding.
set -uo pipefail

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)
PKG=$(cd "$SCRIPT_DIR/.." && pwd -P)
STRICT="" EXCEPT="" ALLOWED="" HOSTNAMES="" REPO_NAMES="" ALIASES=""
while [ $# -gt 0 ]; do
  case "$1" in
    --strict) STRICT="$2"; shift 2;;
    --except) EXCEPT="$2"; shift 2;;
    --allowed) ALLOWED="$2"; shift 2;;
    --hostnames) HOSTNAMES="$2"; shift 2;;
    --repo-names) REPO_NAMES="$2"; shift 2;;
    --pkg) PKG=$(cd "$2" && pwd -P); shift 2;;
    --aliases) ALIASES="$2"; shift 2;;
    -h|--help) sed -n '2,25p' "$0"; exit 0;;
    *) echo "unknown arg: $1" >&2; exit 2;;
  esac
done
[ -z "$ALIASES" ] && ALIASES="$PKG/references/data/aliases.json"
FAIL=0

clean_list() { # FILE -> tokens, one per line
  [ -n "$1" ] && [ -f "$1" ] && grep -vE '^[[:space:]]*(#|$)' "$1" | tr -d ' \t' | sort -u || true
}
GREP() { grep -rnE --binary-files=without-match "$@" "$PKG"; }

# Word boundary that treats '-' and '_' as word characters, so a two-letter name never
# matches inside a longer word, CLI flags (leading '-') don't fire, and a hyphenated
# private name never matches as a prefix of a longer hyphenated public token.
B_L='(^|[^[:alnum:]_-])'
B_R='([^[:alnum:]_-]|$)'

# ---- 1. strict private names: whole-token, any form ------------------------------
ALIAS_KEYS=$( [ -f "$ALIASES" ] && jq -r '.aliases | keys[]' "$ALIASES" 2>/dev/null | sort -u || true )
STRICT_TOKENS=$(clean_list "$STRICT")
if [ -n "$EXCEPT" ]; then STRICT_TOKENS=$(printf '%s\n' "$STRICT_TOKENS" | grep -vxE "$EXCEPT" || true); fi
if [ -n "$ALIAS_KEYS" ]; then STRICT_TOKENS=$(printf '%s\n' "$STRICT_TOKENS" | grep -vxF "$ALIAS_KEYS" || true); fi
if [ -n "$STRICT_TOKENS" ]; then
  strict_re=$(printf '%s\n' "$STRICT_TOKENS" | paste -sd'|' -)
  if [ -n "$strict_re" ] && GREP "${B_L}(${strict_re})${B_R}"; then
    echo "PRIVATE NAME LEAK (strict list)"; FAIL=1
  fi
fi

# ---- 2. exception names: prohibited only in skill-reference forms ----------------
if [ -n "$EXCEPT" ]; then
  if GREP "${B_L}/(${EXCEPT})${B_R}|skills/(${EXCEPT})${B_R}|(${EXCEPT})/SKILL\.md|the (${EXCEPT}) skill"; then
    echo "PRIVATE SKILL REFERENCE (exception list used as a skill, not a CLI)"; FAIL=1
  fi
fi

# ---- 3. allowlist resolution -----------------------------------------------------
# Benign path segments that look like slugs (kept short and generic on purpose).
IGNORE='tmp|dev|data|docs|api|usr|etc|home|Users|opt|var|proc|sys|bin|lib|mnt|srv|root|run|projects|skills|scripts|references|assets|tests|schemas|subagents|fixtures|stubs'
SCAN_IGNORE="$PKG/scripts/scan-ignore.txt"
ALLOWED_ALL=$( { clean_list "$ALLOWED"; clean_list "$SCAN_IGNORE"; } | sort -u )
# HARD: unambiguous reference forms must resolve to an allowed name.
# (extraction uses -rhoE, NOT the -n-carrying GREP helper: -n would glue line
# numbers onto the extracted tokens and break the allowlist comparison)
HARD_REFS=$(grep -rhoE --binary-files=without-match "skills/[a-z0-9][a-z0-9-]*|jsm install [a-z0-9][a-z0-9-]*" "$PKG" 2>/dev/null \
  | sed -E 's#^skills/##; s#^jsm install ##' | grep -vxE "$IGNORE" | sort -u || true)
if [ -n "$HARD_REFS" ]; then
  UNRESOLVED=$(printf '%s\n' "$HARD_REFS" | grep -vxF "$ALLOWED_ALL" || true)
  if [ -n "$UNRESOLVED" ]; then
    printf 'UNRESOLVED SKILL REFERENCE (typo, retired, or private):\n%s\n' "$UNRESOLVED"; FAIL=1
  fi
fi
# REVIEW: backticked `/name` shares its shape with system paths and placeholders.
SOFT_REFS=$(grep -rhoE --binary-files=without-match '`/[a-z0-9][a-z0-9-]*`' "$PKG" 2>/dev/null | sed -E 's#^`/##; s#`$##' | grep -vxE "$IGNORE" | sort -u || true)
if [ -n "$SOFT_REFS" ]; then
  printf '%s\n' "$SOFT_REFS" | grep -vxF "$ALLOWED_ALL" | sed 's#^#review: unresolved `/name` token: #' || true
fi

# ---- 4. aliases: data only, never references -------------------------------------
if [ -n "$ALIAS_KEYS" ]; then
  aliases_re=$(printf '%s\n' "$ALIAS_KEYS" | paste -sd'|' -)
  if grep -rnE --binary-files=without-match --exclude=aliases.json "${B_L}(${aliases_re})${B_R}" "$PKG"; then
    echo "STALE ALIAS USED AS REFERENCE (use the canonical name)"; FAIL=1
  fi
fi

# ---- 5. portability / privacy classes --------------------------------------------
if GREP '(/Users/[A-Za-z0-9_.-]+/|/home/[A-Za-z0-9_.-]+/)'; then
  echo "ABSOLUTE HOME PATH (use ~ or \$HOME)"; FAIL=1
fi
# Pattern assembled from pieces so the scanner's own source never self-matches.
DP_SEG="/d""p/"
if GREP "${B_L}${DP_SEG}"; then
  echo "PERSONAL PATH ALIAS (${DP_SEG})"; FAIL=1
fi
HOST_TOKENS=$(clean_list "$HOSTNAMES")
if [ -n "$HOST_TOKENS" ]; then
  hosts_re=$(printf '%s\n' "$HOST_TOKENS" | paste -sd'|' -)
  if [ -n "$hosts_re" ] && GREP "${B_L}(${hosts_re})${B_R}"; then
    echo "MACHINE HOSTNAME LEAK"; FAIL=1
  fi
fi
REPO_TOKENS=$(clean_list "$REPO_NAMES")
if [ -n "$REPO_TOKENS" ]; then
  repos_re=$(printf '%s\n' "$REPO_TOKENS" | paste -sd'|' -)
  if [ -n "$repos_re" ] && GREP "${B_L}(${repos_re})${B_R}"; then
    echo "PRIVATE REPO/PROJECT NAME LEAK"; FAIL=1
  fi
fi
# Authoring-repo path forms (the product domain jeffreys-skills.md itself is fine; a
# checkout path of the site repo is not).
if GREP 'projects/jeffreys-skills\.md'; then
  echo "AUTHORING REPO CHECKOUT PATH"; FAIL=1
fi
# Secrets / identifiers.
if GREP '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.(com|org|net|io|md|dev)'; then
  echo "EMAIL ADDRESS"; FAIL=1
fi
if GREP '(jsm_[A-Za-z0-9]{8,}|ghp_[A-Za-z0-9]{20,}|sk-[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16}|xox[baprs]-[A-Za-z0-9-]{10,}|eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{10,}|-----BEGIN [A-Z ]*PRIVATE KEY)'; then
  echo "TOKEN/KEY-SHAPED STRING"; FAIL=1
fi
if GREP "${B_L}(msg|thread)-[0-9a-f]{8,}${B_R}"; then
  echo "AGENT-MAIL/SESSION IDENTIFIER"; FAIL=1
fi

if [ "$FAIL" -eq 0 ]; then
  echo "scan clean"   # review: lines above (if any) must still be resolved by a human
  exit 0
fi
exit 1
