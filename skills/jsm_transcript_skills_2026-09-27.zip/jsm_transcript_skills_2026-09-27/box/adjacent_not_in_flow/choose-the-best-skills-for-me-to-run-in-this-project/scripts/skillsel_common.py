#!/usr/bin/env python3
"""Shared helpers for the skill-selection scripts (stdlib only).

Subcommands (used by the shell scripts):
  now                         print the pinned clock (SKILL_SELECTION_NOW) or UTC now, ISO-8601 Z
  sha256 FILE                 print 'sha256:<hex>' of a file
  validate-json SCHEMA FILE   validate a JSON file (object or array of objects) against a schema
  frontmatter SKILL_MD        print the YAML front matter of a SKILL.md as JSON (no PyYAML needed)
  assemble-snapshot ...       build catalog-snapshot.json from cached `jsm show`/`jsm related` output
  run-id TARGET HEAD_OR_DIGEST  print the 12-hex run id for the pinned clock

The JSON-schema validator implements the subset used by references/schemas/*.json:
type (incl. lists), properties, required, additionalProperties, enum, const, items,
minItems, maxItems, uniqueItems, minimum, maximum, minLength, maxLength, pattern,
allOf, anyOf, if/then/else, and $ref to a sibling schema file. It is deliberately
small so the package has no third-party dependency.
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
import os
import re
import sys
from pathlib import Path

PKG_ROOT = Path(__file__).resolve().parent.parent
SCHEMA_DIR = PKG_ROOT / "references" / "schemas"
DATA_DIR = PKG_ROOT / "references" / "data"

ISO_Z = "%Y-%m-%dT%H:%M:%SZ"


# ---------------------------------------------------------------- clock ----
def now_iso() -> str:
    """Pinned clock: SKILL_SELECTION_NOW (ISO-8601) wins so reruns are byte-identical."""
    pinned = os.environ.get("SKILL_SELECTION_NOW", "").strip()
    if pinned:
        return parse_iso(pinned).strftime(ISO_Z)
    return _dt.datetime.now(_dt.timezone.utc).strftime(ISO_Z)


def parse_iso(s: str) -> _dt.datetime:
    s = s.strip()
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    d = _dt.datetime.fromisoformat(s)
    if d.tzinfo is None:
        d = d.replace(tzinfo=_dt.timezone.utc)
    return d.astimezone(_dt.timezone.utc)


def days_between(a_iso: str, b_iso: str) -> float:
    return (parse_iso(b_iso) - parse_iso(a_iso)).total_seconds() / 86400.0


# ------------------------------------------------------------- hashing ----
def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return "sha256:" + h.hexdigest()


def sha256_text(text: str) -> str:
    return "sha256:" + hashlib.sha256(text.encode("utf-8")).hexdigest()


def canonical_json(obj) -> str:
    """Deterministic serialization: sorted keys, fixed separators, trailing newline."""
    return json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False) + "\n"


def load_json(path: str | Path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: str | Path, obj) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(canonical_json(obj))


def run_id(target: str, head_or_digest: str, now: str | None = None) -> str:
    now = now or now_iso()
    return hashlib.sha256(f"{target}\n{head_or_digest}\n{now}".encode("utf-8")).hexdigest()[:12]


# ----------------------------------------------------------- evidence ----
def active_evidence(records: list[dict]) -> list[dict]:
    """Return the unsuperseded evidence records after validating correction links.

    Corrections are append-only: a newer record names every record it replaces in
    ``supersedes``. The old bytes remain auditable, but only the active records may
    activate signals or contribute confidence. Missing targets, self-links, duplicate
    ids, and correction cycles are input errors rather than ambiguous scoring rules.
    """
    by_id: dict[str, dict] = {}
    for row in records:
        eid = row.get("id")
        if eid in by_id:
            raise ValueError(f"duplicate evidence id: {eid}")
        by_id[eid] = row
    for eid, row in by_id.items():
        for old in row.get("supersedes", []):
            if old == eid:
                raise ValueError(f"evidence {eid} supersedes itself")
            if old not in by_id:
                raise ValueError(f"evidence {eid} supersedes missing id {old}")
            previous = by_id[old]
            if row.get("kind") != previous.get("kind"):
                raise ValueError(
                    f"evidence {eid} supersedes {old} from a different kind"
                )
            current_signals = set(row.get("signals", []))
            previous_signals = set(previous.get("signals", []))
            if (current_signals or previous_signals) and not (current_signals & previous_signals):
                raise ValueError(
                    f"evidence {eid} supersedes {old} with unrelated signals"
                )
            if row.get("observed_at", "") < previous.get("observed_at", ""):
                raise ValueError(
                    f"evidence {eid} is older than superseded evidence {old}"
                )

    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(eid: str) -> None:
        if eid in visiting:
            raise ValueError(f"evidence supersession cycle includes {eid}")
        if eid in visited:
            return
        visiting.add(eid)
        for old in by_id[eid].get("supersedes", []):
            visit(old)
        visiting.remove(eid)
        visited.add(eid)

    for eid in sorted(by_id):
        visit(eid)
    superseded = {old for row in records for old in row.get("supersedes", [])}
    return [by_id[eid] for eid in sorted(by_id) if eid not in superseded]


# ------------------------------------------------------ schema validator ----
class SchemaError(Exception):
    pass


def _load_schema(ref: str, base_dir: Path):
    path = base_dir / ref
    return load_json(path)


def _type_ok(value, t: str) -> bool:
    return {
        "object": isinstance(value, dict),
        "array": isinstance(value, list),
        "string": isinstance(value, str),
        "integer": isinstance(value, int) and not isinstance(value, bool),
        "number": (isinstance(value, (int, float)) and not isinstance(value, bool)),
        "boolean": isinstance(value, bool),
        "null": value is None,
    }[t]


def validate_against(value, schema: dict, base_dir: Path, path: str = "$") -> list[str]:
    """Return a list of error strings (empty = valid)."""
    errs: list[str] = []
    if "$ref" in schema:
        schema = _load_schema(schema["$ref"], base_dir)
    for sub in schema.get("allOf", []):
        errs.extend(validate_against(value, sub, base_dir, path))
    if "anyOf" in schema:
        alternatives = [validate_against(value, sub, base_dir, path) for sub in schema["anyOf"]]
        if alternatives and all(a for a in alternatives):
            errs.append(f"{path}: does not satisfy anyOf")
    if "if" in schema:
        condition_errors = validate_against(value, schema["if"], base_dir, path)
        branch = schema.get("then") if not condition_errors else schema.get("else")
        if branch:
            errs.extend(validate_against(value, branch, base_dir, path))
    t = schema.get("type")
    if t is not None:
        types = t if isinstance(t, list) else [t]
        if not any(_type_ok(value, x) for x in types):
            errs.append(f"{path}: expected type {types}, got {type(value).__name__}")
            return errs
    if "enum" in schema and value not in schema["enum"]:
        errs.append(f"{path}: {value!r} not in enum {schema['enum']}")
    if "const" in schema and value != schema["const"]:
        errs.append(f"{path}: {value!r} != const {schema['const']!r}")
    if isinstance(value, str):
        if "minLength" in schema and len(value) < schema["minLength"]:
            errs.append(f"{path}: shorter than minLength {schema['minLength']}")
        if "maxLength" in schema and len(value) > schema["maxLength"]:
            errs.append(f"{path}: longer than maxLength {schema['maxLength']}")
        if "pattern" in schema and not re.search(schema["pattern"], value):
            errs.append(f"{path}: {value!r} does not match /{schema['pattern']}/")
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if "minimum" in schema and value < schema["minimum"]:
            errs.append(f"{path}: {value} < minimum {schema['minimum']}")
        if "maximum" in schema and value > schema["maximum"]:
            errs.append(f"{path}: {value} > maximum {schema['maximum']}")
    if isinstance(value, list):
        if "minItems" in schema and len(value) < schema["minItems"]:
            errs.append(f"{path}: fewer than minItems {schema['minItems']}")
        if "maxItems" in schema and len(value) > schema["maxItems"]:
            errs.append(f"{path}: more than maxItems {schema['maxItems']}")
        if schema.get("uniqueItems"):
            seen: set[str] = set()
            for i, item in enumerate(value):
                key = json.dumps(item, sort_keys=True, ensure_ascii=False)
                if key in seen:
                    errs.append(f"{path}[{i}]: duplicate item violates uniqueItems")
                seen.add(key)
        if "items" in schema:
            for i, item in enumerate(value):
                errs.extend(validate_against(item, schema["items"], base_dir, f"{path}[{i}]"))
    if isinstance(value, dict):
        props = schema.get("properties", {})
        for req in schema.get("required", []):
            if req not in value:
                errs.append(f"{path}: missing required property {req!r}")
        for k, v in value.items():
            if k in props:
                errs.extend(validate_against(v, props[k], base_dir, f"{path}.{k}"))
            else:
                ap = schema.get("additionalProperties", True)
                if ap is False:
                    errs.append(f"{path}: unexpected property {k!r}")
                elif isinstance(ap, dict):
                    errs.extend(validate_against(v, ap, base_dir, f"{path}.{k}"))
        if "propertyNames" in schema:
            for k in value:
                errs.extend(validate_against(k, schema["propertyNames"], base_dir, f"{path}.<key {k}>"))
    return errs


def validate_file(schema_path: str | Path, data_path: str | Path, each: bool | None = None) -> list[str]:
    schema = load_json(schema_path)
    data = load_json(data_path)
    base = Path(schema_path).resolve().parent
    if each is None:
        each = isinstance(data, list) and schema.get("type") == "object"
    if each:
        errs = []
        for i, row in enumerate(data):
            errs.extend(validate_against(row, schema, base, f"$[{i}]"))
        return errs
    return validate_against(data, schema, base)


# ------------------------------------------------------- frontmatter -------
def parse_frontmatter(text: str) -> dict:
    """Parse the simple YAML subset used by SKILL.md front matter.

    Supports `key: value`, `key: >-`/`>`/`|`/`|-` block scalars, `key:` followed by
    an indented list (`- item`) or an indented mapping (one level), and quoted scalars.
    Returns {} when the file has no front matter.
    """
    m = re.match(r"^---[ \t]*\n(.*?)\n---[ \t]*(\n|$)", text, re.S)
    if not m:
        return {}
    lines = m.group(1).split("\n")
    out: dict = {}
    i = 0
    while i < len(lines):
        line = lines[i]
        km = re.match(r"^([A-Za-z_][A-Za-z0-9_-]*):[ \t]*(.*)$", line)
        if not km:
            i += 1
            continue
        key, rest = km.group(1), km.group(2).strip()
        if rest in (">-", ">", "|", "|-", ">+", "|+"):
            buf = []
            i += 1
            while i < len(lines) and (lines[i].startswith(" ") or lines[i].startswith("\t") or lines[i].strip() == ""):
                buf.append(lines[i].strip())
                i += 1
            joiner = "\n" if rest.startswith("|") else " "
            out[key] = joiner.join(b for b in buf if b != "").strip()
            continue
        if rest == "":
            # nested list or mapping
            items: list = []
            mapping: dict = {}
            i += 1
            while i < len(lines) and (lines[i].startswith(" ") or lines[i].startswith("\t")):
                s = lines[i].strip()
                if s.startswith("- "):
                    items.append(_unquote(s[2:].strip()))
                elif ":" in s:
                    k2, v2 = s.split(":", 1)
                    mapping[k2.strip()] = _unquote(v2.strip())
                i += 1
            out[key] = items if items else mapping
            continue
        if rest.startswith("[") and rest.endswith("]"):
            out[key] = [_unquote(x.strip()) for x in rest[1:-1].split(",") if x.strip()]
        else:
            out[key] = _unquote(rest)
        i += 1
    return out


def _unquote(s: str):
    if not isinstance(s, str):
        return s
    if s.lower() in ("null", "~"):
        return None
    if re.fullmatch(r"-?(?:0|[1-9][0-9]*)", s):
        return int(s)
    if s.startswith(("[", "{")):
        try:
            return json.loads(s)
        except json.JSONDecodeError:
            pass
    if len(s) >= 2 and s[0] == s[-1] == '"':
        try:
            return json.loads(s)
        except json.JSONDecodeError:
            return s[1:-1]
    if len(s) >= 2 and s[0] == s[-1] == "'":
        return s[1:-1].replace("''", "'")
    return s


USE_WHEN_RE = re.compile(r"(Use when\b.*)$", re.S | re.I)


def extract_use_when(description: str) -> str | None:
    m = USE_WHEN_RE.search(description or "")
    return m.group(1).strip() if m else None


# ------------------------------------------------- snapshot assembly -------
def assemble_snapshot(names: list[str], show_dir: Path, related_dir: Path, packs: dict[str, list[str]],
                      refreshed_at: str, existing: dict | None = None) -> dict:
    """Build catalog-snapshot.json from cached per-skill `jsm show --json` / `jsm related --json`.

    The exact plain response ``No related skills found.`` means no edges. Any other
    malformed response is recorded as a source error and retains prior relations.
    `packs` maps pack id -> list of skill names. `existing` (the previous snapshot) supplies
    detect_rules for names whose show output lacks them.
    """
    prev = {s["canonical_name"]: s for s in (existing or {}).get("skills", [])}
    entries = []
    listing_lines = []
    source_errors = []
    for n in sorted(names):
        show_path = show_dir / f"{n}.json"
        show = {}
        try:
            show = load_json(show_path).get("skill", {})
        except Exception:
            show = prev.get(n, {})
        rel = {"pairs_with": [], "alternative_to": [], "extends": [], "prerequisite": []}
        rel_path = related_dir / f"{n}.json"
        if rel_path.exists():
            raw = rel_path.read_text(encoding="utf-8", errors="replace")
            try:
                if raw.strip() == "No related skills found.":
                    r = {}
                else:
                    r = json.loads(raw).get("related", {})
                for k in rel:
                    rel[k] = sorted({e.get("name") for e in r.get(k, []) if e.get("name")})
            except Exception as exc:
                rel = dict(prev.get(n, {}).get("related") or rel)
                source_errors.append({"source": "jsm-related", "skill": n,
                                      "error": "malformed-output:" + type(exc).__name__})
        desc = show.get("description") or prev.get(n, {}).get("description", "")
        entry = {
            "canonical_name": n,
            "catalog_sources": ["public"],
            "installed": False,
            "resolved_path": None,
            "description": desc,
            "use_when": extract_use_when(desc),
            "tags": sorted(show.get("compatibility_tags") or prev.get(n, {}).get("tags", [])),
            "category": show.get("category") or prev.get(n, {}).get("category"),
            "packs": sorted(p for p, members in packs.items() if n in members),
            "related": rel,
            "detect_rules": prev.get(n, {}).get("detect_rules", []),
            "provisional_mapping": False,
            "updated_at": show.get("updated_at") or prev.get(n, {}).get("updated_at"),
            "version": show.get("version", prev.get(n, {}).get("version")),
            "content_hash": show.get("content_hash") or prev.get(n, {}).get("content_hash"),
            "author": show.get("author") or prev.get(n, {}).get("author"),
            "is_public": show.get("is_public", prev.get(n, {}).get("is_public")),
        }
        entries.append(entry)
        listing_lines.append(f"{n}\t{entry['updated_at']}\t{entry['content_hash']}")
    newest = max((e["updated_at"] or "" for e in entries), default=None) or None
    listing_sha = hashlib.sha256("\n".join(listing_lines).encode("utf-8")).hexdigest()
    return {
        "generator_version": "2.0.0",
        "harmonized_against": {
            "refreshed_at": refreshed_at,
            "skill_count": len(entries),
            "newest_updated_at": newest,
            "source_listing_sha256": listing_sha,
            "source_listing_format": "sorted lines of '<name>\\t<updated_at>\\t<content_hash>' over every public Jeffrey's skill (sitemap slugs plus jsm list --remote --jeffreys, each confirmed via jsm show --json)",
        },
        "skills": entries,
        "source_errors": source_errors,
    }


# -------------------------------------------------------------- CLI --------
def _main(argv: list[str]) -> int:
    if not argv:
        print(__doc__)
        return 2
    cmd, args = argv[0], argv[1:]
    if cmd == "now":
        print(now_iso())
        return 0
    if cmd == "sha256":
        print(sha256_file(args[0]))
        return 0
    if cmd == "run-id":
        print(run_id(args[0], args[1]))
        return 0
    if cmd == "validate-json":
        errs = validate_file(args[0], args[1])
        for e in errs:
            print(e, file=sys.stderr)
        print("valid" if not errs else f"{len(errs)} error(s)")
        return 0 if not errs else 1
    if cmd == "frontmatter":
        print(json.dumps(parse_frontmatter(Path(args[0]).read_text(encoding="utf-8")), indent=2, sort_keys=True))
        return 0
    if cmd == "assemble-snapshot":
        # assemble-snapshot NAMES_FILE SHOW_DIR RELATED_DIR PACKS_JSON OUT [EXISTING]
        names = [x.strip() for x in Path(args[0]).read_text().split() if x.strip()]
        packs_raw = load_json(args[3]) if args[3] and args[3] != "-" else {}
        packs = _normalize_packs(packs_raw)
        existing = None
        if len(args) > 5 and Path(args[5]).exists():
            try:
                existing = load_json(args[5])
            except (json.JSONDecodeError, UnicodeDecodeError):
                # an empty/unparseable EXISTING placeholder (fresh rebuild) means "no prior snapshot"
                existing = None
        snap = assemble_snapshot(names, Path(args[1]), Path(args[2]), packs, now_iso(), existing)
        write_json(args[4], snap)
        print(f"wrote {args[4]}: {snap['harmonized_against']['skill_count']} skills")
        return 0
    print(f"unknown subcommand {cmd}", file=sys.stderr)
    return 2


def _normalize_packs(raw) -> dict[str, list[str]]:
    """Accept {packs: {id: {skills: [...]}}}, {packs: [{name|id, skills: [...]}]}, or {id: [names]}."""
    if not raw:
        return {}
    packs = raw.get("packs", raw) if isinstance(raw, dict) else raw
    out: dict[str, list[str]] = {}
    if isinstance(packs, dict):
        for pid, body in packs.items():
            if isinstance(body, list):
                out[pid] = [s if isinstance(s, str) else s.get("slug") or s.get("name") for s in body]
            elif isinstance(body, dict):
                out[pid] = [s if isinstance(s, str) else s.get("slug") or s.get("name") for s in body.get("skills", [])]
    elif isinstance(packs, list):
        for p in packs:
            pid = p.get("id") or p.get("name")
            out[pid] = [s if isinstance(s, str) else s.get("slug") or s.get("name") for s in p.get("skills", [])]
    return {k: [x for x in v if x] for k, v in out.items()}


if __name__ == "__main__":
    sys.exit(_main(sys.argv[1:]))
