#!/usr/bin/env bash
# check-doc-staleness.sh — Phase 1 fingerprint delta (references/STALENESS.md).
#
# Usage: check-doc-staleness.sh [--target DIR] [--scope PATH[,PATH...]] [--doc FILE] [--fresh] [--json-only]
#
# Exit 0 = reuse the profile (refresh juncture only); exit 1 = re-profile.
# Always prints one JSON object on stdout:
#   {"decision":"reuse"|"reprofile","reason":"...","commits_since_profile":N|null,
#    "bead_issue_records_since_profile":N|null,"changed_file_ratio":F|null,"worktree_digest":"sha256:...",
#    "profiled_at":"...","profile_head_sha":"...","is_git":true|false,"tracked_file_count":N,
#    "manifest_digests":{...},"beads_watermark":"...|null"}
# Any unexpected error exits 1 with reason "error:<what>" — re-profiling is the safe default.
#
# Fingerprint (all inside --scope): HEAD ancestry, commit count, changed-file ratio (committed AND
# uncommitted AND untracked), manifest + lockfile digests, beads watermark, profiled_at age (30 days),
# and the worktree digest as the fast "nothing changed at all" short-circuit.
set -uo pipefail

TARGET="."; SCOPE="."; DOC=""; FRESH=0
while [ $# -gt 0 ]; do
  case "$1" in
    --target) TARGET="$2"; shift 2;;
    --scope) SCOPE="$2"; shift 2;;
    --doc) DOC="$2"; shift 2;;
    --fresh) FRESH=1; shift;;
    --json-only) shift;;
    -h|--help) sed -n '2,16p' "$0"; exit 0;;
    *) echo "unknown arg: $1" >&2; exit 1;;
  esac
done
TARGET=$(cd "$TARGET" 2>/dev/null && pwd -P) || { echo '{"decision":"reprofile","reason":"error:target-not-found"}'; exit 1; }
[ -z "$DOC" ] && DOC="$TARGET/docs/COMPREHENSIVE_ANALYSIS_OF_PROJECT_USED_FOR_AUTOMATED_SKILL_SELECTION.md"
SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)
NOW=$(python3 "$SCRIPT_DIR/skillsel_common.py" now)
MAX_COMMITS=25; MAX_RATIO=0.15; MAX_BEAD_EVENTS=10; MAX_AGE_DAYS=30
IFS=',' read -r -a SCOPES <<< "$SCOPE"
[ "${#SCOPES[@]}" -eq 0 ] && SCOPES=(".")   # bash 3.2: empty "${arr[@]}" is unbound under set -u

# timeout/gtimeout/perl-alarm fallback (same ladder as the other package scripts,
# so the beads-watermark checks are not silently skipped on stock macOS)
TMO_BIN=""
if command -v timeout >/dev/null 2>&1; then TMO_BIN=timeout; elif command -v gtimeout >/dev/null 2>&1; then TMO_BIN=gtimeout; fi
tmo() { local s="$1"; shift
  if [ -n "$TMO_BIN" ]; then "$TMO_BIN" "$s" "$@"
  elif command -v perl >/dev/null 2>&1; then perl -e 'alarm shift; exec @ARGV' "$s" "$@"
  else "$@"; fi
}

emit() { # decision reason commits beads ratio digest profiled_at head is_git count manifests watermark
  python3 - "$@" <<'PY'
import json, sys
d, r, c, b, ratio, dig, pa, head, isgit, cnt, man, wm = sys.argv[1:13]
def num(x, f=int):
    return None if x in ("", "null") else f(x)
scope = [s for s in __import__('os').environ.get('SKILL_SELECTION_ACTIVE_SCOPE', '.').split(',') if s]
print(json.dumps({"decision": d, "reason": r, "commits_since_profile": num(c), "bead_issue_records_since_profile": num(b),
                  "changed_file_ratio": num(ratio, float), "worktree_digest": dig or None, "profiled_at": pa or None,
                  "profile_head_sha": head or None, "is_git": isgit == "true", "tracked_file_count": int(cnt or 0),
                  "profile_scope": scope, "manifest_digests": json.loads(man or "{}"),
                  "beads_watermark": wm or None,
                  "current_head_sha": __import__('os').environ.get('SKILL_SELECTION_CURRENT_HEAD') or None}, sort_keys=True))
PY
}
export SKILL_SELECTION_ACTIVE_SCOPE="$SCOPE"

# ---------------------------------------------------------------- git facts
IS_GIT=false; HEAD=""
if git -C "$TARGET" rev-parse --is-inside-work-tree >/dev/null 2>&1; then IS_GIT=true; HEAD=$(git -C "$TARGET" rev-parse HEAD 2>/dev/null || true); fi
export SKILL_SELECTION_CURRENT_HEAD="$HEAD"

SCOPE_STATUS=$(python3 - "$TARGET" "${SCOPES[@]}" <<'PY'
import json, sys
from pathlib import Path
root = Path(sys.argv[1]).resolve()
for raw in sys.argv[2:]:
    if not raw or Path(raw).is_absolute():
        print(json.dumps({"ok": False, "reason": "error:scope-outside-target"})); break
    candidate = (root / raw).resolve()
    try:
        candidate.relative_to(root)
    except ValueError:
        print(json.dumps({"ok": False, "reason": "error:scope-outside-target"})); break
    if not candidate.is_dir():
        print(json.dumps({"ok": False, "reason": "error:scope-not-found"})); break
else:
    print(json.dumps({"ok": True}))
PY
)
if [ "$(printf '%s' "$SCOPE_STATUS" | python3 -c 'import json,sys; print("1" if json.load(sys.stdin).get("ok") else "0")')" != 1 ]; then
  SCOPE_REASON=$(printf '%s' "$SCOPE_STATUS" | python3 -c 'import json,sys; print(json.load(sys.stdin)["reason"])')
  emit reprofile "$SCOPE_REASON" null null null "" "" "$HEAD" "$IS_GIT" 0 "{}" ""; exit 1
fi

sha_of() { python3 "$SCRIPT_DIR/skillsel_common.py" sha256 "$1"; }

# Manifest + lockfile digests recursively inside scope.
manifest_digests() {
  python3 - "$TARGET" "${SCOPES[@]}" <<'PY'
import hashlib, json, os, sys
from pathlib import Path
root = Path(sys.argv[1])
scopes = sys.argv[2:]
names = {"Cargo.toml", "Cargo.lock", "package.json", "package-lock.json", "pnpm-lock.yaml",
         "yarn.lock", "bun.lockb", "bun.lock", "pyproject.toml", "poetry.lock", "uv.lock",
         "requirements.txt", "go.mod", "go.sum", "Gemfile", "Gemfile.lock", "build.zig",
         "build.zig.zon", "CMakeLists.txt", "mix.exs", "mix.lock", "go.work", "go.work.sum",
         "deno.json", "deno.jsonc", "composer.json", "composer.lock", "gradle.lockfile",
         "settings.gradle", "settings.gradle.kts", "build.gradle", "build.gradle.kts"}
ignored = {".git", "node_modules", "target", "vendor", "dist", "build", ".next"}
out = {}
for scope in scopes:
    base = (root / scope).resolve()
    try:
        base.relative_to(root.resolve())
    except ValueError:
        raise SystemExit("scope escapes target")
    if not base.is_dir():
        continue
    for current, dirs, files in os.walk(base):
        dirs[:] = sorted(d for d in dirs if d not in ignored)
        for name in sorted(set(files) & names):
            path = Path(current) / name
            rel = path.relative_to(root).as_posix()
            out[rel] = "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()
print(json.dumps(out, sort_keys=True, separators=(",", ":")))
PY
}
if ! MANIFESTS=$(manifest_digests); then
  emit reprofile error:manifest-scan-failed null null null "" "" "$HEAD" "$IS_GIT" 0 "{}" ""; exit 1
fi

# Tracked file count and worktree digest inside scope.
if $IS_GIT; then
  COUNT=$(git -C "$TARGET" ls-files -z -- "${SCOPES[@]}" | python3 -c 'import sys; print(len([p for p in sys.stdin.buffer.read().split(b"\0") if p]))')
  # NOTE: "HEAD:." never resolves (git wants "HEAD:" for the root tree), so scope "."
  # must map to the empty path or committed changes become invisible to the digest.
  TREE=$(for s in "${SCOPES[@]}"; do sp="$s"; [ "$sp" = "." ] && sp=""; git -C "$TARGET" rev-parse "HEAD:$sp" 2>/dev/null || echo "none:$s"; done | tr '\n' ' ')
  DIRTY=$(git -C "$TARGET" diff --binary --full-index --no-ext-diff HEAD -- "${SCOPES[@]}" 2>/dev/null | shasum -a 256 | cut -d' ' -f1)
  DIRTY_TRACKED=0
  git -C "$TARGET" diff --quiet HEAD -- "${SCOPES[@]}" 2>/dev/null || DIRTY_TRACKED=1
  UNTRACKED_HASH=$(python3 - "$TARGET" "${SCOPES[@]}" <<'PY'
import hashlib, os, subprocess, sys
from pathlib import Path
root, scopes = Path(sys.argv[1]), sys.argv[2:]
raw = subprocess.check_output(["git", "-C", str(root), "ls-files", "--others",
                               "--exclude-standard", "-z", "--", *scopes])
paths = sorted(p for p in raw.split(b"\0") if p)
h = hashlib.sha256()
for encoded in paths:
    rel = os.fsdecode(encoded)
    path = root / rel
    if path.is_symlink():
        data = os.fsencode(os.readlink(path))
    else:
        data = path.read_bytes()
    h.update(len(encoded).to_bytes(8, "big")); h.update(encoded)
    h.update(len(data).to_bytes(8, "big")); h.update(data)
print(h.hexdigest())
PY
) || { emit reprofile error:untracked-hash-failed null null null "" "" "$HEAD" "$IS_GIT" "$COUNT" "$MANIFESTS" ""; exit 1; }
  DIGEST="sha256:$(printf '%s|%s|%s' "$TREE" "$DIRTY" "$UNTRACKED_HASH" | shasum -a 256 | cut -d' ' -f1)"
else
  DIRTY_TRACKED=0
  NON_GIT_FACTS=$(python3 - "$TARGET" "${SCOPES[@]}" <<'PY'
import hashlib, json, os, sys
from pathlib import Path
root = Path(sys.argv[1])
ignored = {".git", "node_modules", "target", "vendor", "dist", "build", ".next"}
paths = set()
for scope in sys.argv[2:]:
    base = (root / scope).resolve()
    if not base.is_dir():
        continue
    for current, dirs, files in os.walk(base):
        dirs[:] = sorted(d for d in dirs if d not in ignored)
        for name in files:
            paths.add(Path(current) / name)
h = hashlib.sha256()
for path in sorted(paths, key=lambda p: p.relative_to(root).as_posix()):
    rel = path.relative_to(root).as_posix().encode()
    data = path.read_bytes()
    h.update(len(rel).to_bytes(8, "big")); h.update(rel)
    h.update(len(data).to_bytes(8, "big")); h.update(data)
print(json.dumps({"count": len(paths), "digest": "sha256:" + h.hexdigest()}))
PY
)
  COUNT=$(printf '%s' "$NON_GIT_FACTS" | python3 -c 'import json,sys; print(json.load(sys.stdin)["count"])')
  DIGEST=$(printf '%s' "$NON_GIT_FACTS" | python3 -c 'import json,sys; print(json.load(sys.stdin)["digest"])')
fi

# Beads watermark: newest updated_at / count.
WATERMARK=""; BEADS_EXPECTED=0
if [ -d "$TARGET/.beads" ]; then BEADS_EXPECTED=1; fi
if [ "$BEADS_EXPECTED" -eq 1 ] && command -v br >/dev/null 2>&1; then
  WATERMARK=$(cd "$TARGET" && tmo 30 br --no-auto-flush --no-auto-import list --status all --json 2>/dev/null | python3 -c '
import json,sys
try:
    d=json.load(sys.stdin)
except Exception:
    sys.exit(0)
rows=d if isinstance(d,list) else d.get("issues") or d.get("items") or []
ts=[r.get("updated_at") or r.get("updated") or "" for r in rows]
ts=[t for t in ts if t]
print((max(ts) if ts else "")+"/"+str(len(rows)))' 2>/dev/null || true)
fi

# ------------------------------------------------------------ no document
if [ ! -f "$DOC" ]; then
  emit reprofile no_profile null null null "$DIGEST" "" "$HEAD" "$IS_GIT" "$COUNT" "$MANIFESTS" "$WATERMARK"; exit 1
fi
if [ $FRESH -eq 1 ]; then
  emit reprofile user_requested_fresh null null null "$DIGEST" "" "$HEAD" "$IS_GIT" "$COUNT" "$MANIFESTS" "$WATERMARK"; exit 1
fi

# ------------------------------------------------------ validate the document
DOC_VALIDATION=$(python3 - "$DOC" "$SCRIPT_DIR" <<'PY'
import json, re, sys
from pathlib import Path
sys.path.insert(0, sys.argv[2])
import skillsel_common as common

path = Path(sys.argv[1])
try:
    text = path.read_text(encoding="utf-8")
    header = common.parse_frontmatter(text)
    header_schema = common.load_json(common.SCHEMA_DIR / "analysis-header.schema.json")
    errors = common.validate_against(header, header_schema, common.SCHEMA_DIR)
    if errors:
        print(json.dumps({"status": "invalid-header", "detail": errors[:5]})); raise SystemExit
    match = re.search(r"<!-- skill-selection:profile-evidence:v1\n(.*?)\n-->", text, re.S)
    if not match:
        print(json.dumps({"status": "invalid-evidence", "detail": "missing block"})); raise SystemExit
    rows = json.loads(match.group(1))
    if not isinstance(rows, list) or not rows or any(not isinstance(row, dict) for row in rows):
        print(json.dumps({"status": "invalid-evidence", "detail": "expected nonempty object array"})); raise SystemExit
    evidence_schema = common.load_json(common.SCHEMA_DIR / "evidence.schema.json")
    evidence_errors = []
    for index, row in enumerate(rows):
        evidence_errors.extend(common.validate_against(row, evidence_schema, common.SCHEMA_DIR,
                                                       f"$[{index}]"))
    active = common.active_evidence(rows)
    if evidence_errors or any(row.get("kind") != "profile" for row in rows) or not active:
        detail = evidence_errors[:5] or "profile-only active evidence required"
        print(json.dumps({"status": "invalid-evidence", "detail": detail})); raise SystemExit
    print(json.dumps({"status": "ok", "header": header}, sort_keys=True))
except (OSError, ValueError, json.JSONDecodeError) as exc:
    print(json.dumps({"status": "invalid-evidence", "detail": str(exc)}))
PY
)
DOC_STATUS=$(printf '%s' "$DOC_VALIDATION" | python3 -c 'import json,sys; print(json.load(sys.stdin).get("status", "invalid-header"))')
if [ "$DOC_STATUS" = invalid-header ]; then
  emit reprofile error:invalid-analysis-header null null null "$DIGEST" "" "$HEAD" "$IS_GIT" "$COUNT" "$MANIFESTS" "$WATERMARK"; exit 1
fi
if [ "$DOC_STATUS" != ok ]; then
  emit reprofile error:profile-evidence-missing-or-invalid null null null "$DIGEST" "" "$HEAD" "$IS_GIT" "$COUNT" "$MANIFESTS" "$WATERMARK"; exit 1
fi
HDR=$(printf '%s' "$DOC_VALIDATION" | python3 -c 'import json,sys; print(json.dumps(json.load(sys.stdin)["header"], sort_keys=True))')
field() { printf '%s' "$HDR" | python3 -c 'import json,sys; d=json.load(sys.stdin); v=d.get(sys.argv[1]); empty=v in (None,"",{},[]) or (isinstance(v,str) and v.lower() in ("null","~")); print("" if empty else (json.dumps(v) if isinstance(v,(dict,list)) else v))' "$1"; }
PROFILED_AT=$(field profiled_at); P_HEAD=$(field profile_head_sha); P_COUNT=$(field profile_tracked_file_count)
P_DIGEST=$(field profile_worktree_digest)
P_MAN=$(printf '%s' "$HDR" | python3 -c 'import json,sys; print(json.dumps(json.load(sys.stdin)["profile_manifest_digests"], sort_keys=True, separators=(",", ":")))')
P_WM=$(field profile_beads_watermark)
P_SCOPE=$(field profile_scope)
[ -z "$PROFILED_AT" ] && { emit reprofile "error:header-missing-profiled_at" null null null "$DIGEST" "" "$HEAD" "$IS_GIT" "$COUNT" "$MANIFESTS" "$WATERMARK"; exit 1; }

CURRENT_SCOPE=$(python3 - "${SCOPES[@]}" <<'PY'
import json, sys
print(json.dumps(sys.argv[1:], separators=(",", ":")))
PY
)
if [ -z "$P_SCOPE" ] || ! python3 -c 'import json,sys; a=json.loads(sys.argv[1]); b=json.loads(sys.argv[2]); sys.exit(0 if a==b else 1)' "$P_SCOPE" "$CURRENT_SCOPE"; then
  emit reprofile profile_scope_changed null null null "$DIGEST" "$PROFILED_AT" "$P_HEAD" "$IS_GIT" "$COUNT" "$MANIFESTS" "$WATERMARK"; exit 1
fi
if $IS_GIT && [ -z "$P_HEAD" ]; then
  emit reprofile "error:header-missing-profile_head_sha" null null null "$DIGEST" "$PROFILED_AT" "" "$IS_GIT" "$COUNT" "$MANIFESTS" "$WATERMARK"; exit 1
fi

if ! python3 -c 'import json,sys; a=json.loads(sys.argv[1]); b=json.loads(sys.argv[2]); sys.exit(0 if a==b else 1)' "$P_MAN" "$MANIFESTS"; then
  emit reprofile manifest_or_lockfile_digest_changed null null null "$DIGEST" "$PROFILED_AT" "$P_HEAD" "$IS_GIT" "$COUNT" "$MANIFESTS" "$WATERMARK"; exit 1
fi

if [ "$BEADS_EXPECTED" -eq 1 ] && [ -z "$WATERMARK" ]; then
  emit reprofile beads_watermark_unavailable null null null "$DIGEST" "$PROFILED_AT" "$P_HEAD" "$IS_GIT" "$COUNT" "$MANIFESTS" "$WATERMARK"; exit 1
fi

# Beads exposes current issue rows, not an append-only event log. This count is
# therefore deliberately named changed issue records: rows updated after the saved
# timestamp plus the absolute issue-count delta. It never claims to count all events.
BEAD_RECORDS=null
if [ -n "$P_WM" ] || [ -n "$WATERMARK" ]; then
  if [ -z "$P_WM" ] || [ -z "$WATERMARK" ]; then
    emit reprofile beads_watermark_unavailable null null null "$DIGEST" "$PROFILED_AT" "$P_HEAD" "$IS_GIT" "$COUNT" "$MANIFESTS" "$WATERMARK"; exit 1
  fi
  if [ "$P_WM" = "$WATERMARK" ]; then
    BEAD_RECORDS=0
  else
    P_TS=${P_WM%%/*}; P_TOTAL=${P_WM##*/}
    BEAD_RECORDS=$(cd "$TARGET" && tmo 30 br --no-auto-flush --no-auto-import list --status all --json 2>/dev/null | python3 -c '
import json,sys
wm, previous_total = sys.argv[1], int(sys.argv[2])
try: d=json.load(sys.stdin)
except Exception: print("null"); sys.exit(0)
rows=d if isinstance(d,list) else d.get("issues") or d.get("items") or []
changed=sum(1 for r in rows if (r.get("updated_at") or r.get("updated") or "") > wm)
print(changed + abs(len(rows) - previous_total))' "$P_TS" "$P_TOTAL" 2>/dev/null || echo null)
    if [ "$BEAD_RECORDS" = "null" ]; then
      emit reprofile beads_change_count_unavailable null null null "$DIGEST" "$PROFILED_AT" "$P_HEAD" "$IS_GIT" "$COUNT" "$MANIFESTS" "$WATERMARK"; exit 1
    fi
    if [ "$BEAD_RECORDS" -ge "$MAX_BEAD_EVENTS" ]; then
      emit reprofile "bead_issue_records_since_profile>=${MAX_BEAD_EVENTS}" null "$BEAD_RECORDS" null "$DIGEST" "$PROFILED_AT" "$P_HEAD" "$IS_GIT" "$COUNT" "$MANIFESTS" "$WATERMARK"; exit 1
    fi
  fi
fi

# ----------------------------------------------------------- age (30 days)
AGE=$(python3 -c 'import sys; sys.path.insert(0, sys.argv[3]); import skillsel_common as c; print(c.days_between(sys.argv[1], sys.argv[2]))' "$PROFILED_AT" "$NOW" "$SCRIPT_DIR" 2>/dev/null || echo 9999)
if python3 -c 'import sys; sys.exit(0 if float(sys.argv[1]) > float(sys.argv[2]) else 1)' "$AGE" "$MAX_AGE_DAYS"; then
  emit reprofile "profile_older_than_${MAX_AGE_DAYS}_days" null "$BEAD_RECORDS" null "$DIGEST" "$PROFILED_AT" "$P_HEAD" "$IS_GIT" "$COUNT" "$MANIFESTS" "$WATERMARK"; exit 1
fi

# ------------------------------------------------ fast path: nothing changed
if [ -n "$P_DIGEST" ] && [ "$P_DIGEST" = "$DIGEST" ] && { [ -z "$P_WM$WATERMARK" ] || [ "$P_WM" = "$WATERMARK" ]; }; then
  emit reuse worktree_digest_unchanged 0 "$BEAD_RECORDS" 0 "$DIGEST" "$PROFILED_AT" "$P_HEAD" "$IS_GIT" "$COUNT" "$MANIFESTS" "$WATERMARK"; exit 0
fi

# ------------------------------------------------------------- non-git
if ! $IS_GIT; then
  emit reprofile no_git null "$BEAD_RECORDS" null "$DIGEST" "$PROFILED_AT" "$P_HEAD" "$IS_GIT" "$COUNT" "$MANIFESTS" "$WATERMARK"; exit 1
fi

# ------------------------------------------------------- ancestry / commits
[ -z "$P_HEAD" ] && { emit reprofile "error:header-missing-profile_head_sha" null "$BEAD_RECORDS" null "$DIGEST" "$PROFILED_AT" "" "$IS_GIT" "$COUNT" "$MANIFESTS" "$WATERMARK"; exit 1; }
if ! git -C "$TARGET" merge-base --is-ancestor "$P_HEAD" HEAD 2>/dev/null; then
  emit reprofile profiled_commit_not_ancestor null "$BEAD_RECORDS" null "$DIGEST" "$PROFILED_AT" "$P_HEAD" "$IS_GIT" "$COUNT" "$MANIFESTS" "$WATERMARK"; exit 1
fi
COMMITS=$(git -C "$TARGET" rev-list --count "$P_HEAD..HEAD" 2>/dev/null || echo 0)
if [ "$COMMITS" -ge "$MAX_COMMITS" ]; then
  emit reprofile "commits_since_profile>=${MAX_COMMITS}" "$COMMITS" "$BEAD_RECORDS" null "$DIGEST" "$PROFILED_AT" "$P_HEAD" "$IS_GIT" "$COUNT" "$MANIFESTS" "$WATERMARK"; exit 1
fi

# ------------------------------------------------------ changed-file ratio
CHANGED=$(python3 - "$TARGET" "$P_HEAD" "${SCOPES[@]}" <<'PY'
import subprocess, sys
target, head, scopes = sys.argv[1], sys.argv[2], sys.argv[3:]
changed = subprocess.check_output(
    ["git", "-C", target, "diff", "--name-only", "-z", head, "--", *scopes]
)
untracked = subprocess.check_output(
    ["git", "-C", target, "ls-files", "--others", "--exclude-standard", "-z", "--", *scopes]
)
print(len({path for path in (changed + untracked).split(b"\0") if path}))
PY
) || { emit reprofile error:changed-file-count-failed "$COMMITS" "$BEAD_RECORDS" null "$DIGEST" "$PROFILED_AT" "$P_HEAD" "$IS_GIT" "$COUNT" "$MANIFESTS" "$WATERMARK"; exit 1; }
DENOM=${P_COUNT:-$COUNT}; [ "$DENOM" -gt 0 ] 2>/dev/null || DENOM=1
RATIO=$(python3 -c 'print(round(float(__import__("sys").argv[1])/float(__import__("sys").argv[2]),4))' "$CHANGED" "$DENOM")
if python3 -c 'import sys; sys.exit(0 if float(sys.argv[1]) >= float(sys.argv[2]) else 1)' "$RATIO" "$MAX_RATIO"; then
  emit reprofile "changed_file_ratio>=${MAX_RATIO}" "$COMMITS" "$BEAD_RECORDS" "$RATIO" "$DIGEST" "$PROFILED_AT" "$P_HEAD" "$IS_GIT" "$COUNT" "$MANIFESTS" "$WATERMARK"; exit 1
fi

if [ "$DIRTY_TRACKED" -eq 1 ]; then
  emit reprofile uncommitted_tracked_changes "$COMMITS" "$BEAD_RECORDS" "$RATIO" "$DIGEST" "$PROFILED_AT" "$P_HEAD" "$IS_GIT" "$COUNT" "$MANIFESTS" "$WATERMARK"; exit 1
fi

emit reuse within_thresholds "$COMMITS" "$BEAD_RECORDS" "$RATIO" "$DIGEST" "$PROFILED_AT" "$P_HEAD" "$IS_GIT" "$COUNT" "$MANIFESTS" "$WATERMARK"
exit 0
