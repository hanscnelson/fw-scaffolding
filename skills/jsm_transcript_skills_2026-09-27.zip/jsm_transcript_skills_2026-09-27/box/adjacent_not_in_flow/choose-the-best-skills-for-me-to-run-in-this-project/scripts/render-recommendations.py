#!/usr/bin/env python3
"""Render docs/RECOMMENDED_SKILLS_FOR_THIS_PROJECT.md from a recommendation-run JSON.

  render-recommendations.py --run RUN.json --out DOC.md [--previous DOC.md]
                            [--update-analysis-header ANALYSIS.md --profiled|--juncture-only]

- The prose sections (campaign kickoff blocks, tiers, gaps) are a pure function of the
  run JSON (assets/recommendations-doc-template.md frames them).
- The appendix carries the machine-readable record: a bounded run history (last 12 runs
  in full, older compacted into monthly summaries, stable user decisions always kept),
  the current run JSON, and the candidate ledger as one-object-per-line JSONL (also the
  input for `jsm outcome --batch` after extraction).
- --previous points at the prior rendered doc (defaults to --out when it exists);
  its history block is parsed and carried forward with retention applied.
- --update-analysis-header renders the analysis document from the merged evidence set.
  --profiled creates or replaces the full document and refreshes every profile fingerprint;
  --juncture-only preserves the validated profile header/evidence and refreshes the analysis.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import skillsel_common as slib  # noqa: E402

HIST_RE = re.compile(r"<!-- skill-selection:run-history:v1\n(.*?)\n-->", re.S)
PROFILE_RE = re.compile(r"<!-- skill-selection:profile-evidence:v1\n(.*?)\n-->", re.S)
MAX_RUNS_KEPT = 12
PRIVATE_PATH_RE = re.compile(
    r"/(?:Users|home|private|Volumes|var/folders|tmp|opt)(?:/[^\n\r\t`'\";,)]+)+"
)
DNS_HOST_RE = re.compile(
    r"(?<![@/])\b(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,62})\.)+"
    r"(?:[A-Za-z]{2,63})\b"
)
HOST_KEYS = {"host", "hostname", "origin_host", "origin_hostname"}


def private_alias(name: str) -> str:
    """Return a stable opaque alias without persisting the private name."""
    digest = hashlib.sha256(("skill-selection-private-v1\0" + name).encode("utf-8")).hexdigest()
    return f"private-skill-{digest[:12]}"


def html_comment_json(value) -> str:
    """Serialize JSON that cannot terminate its surrounding HTML comment."""
    return json.dumps(value, sort_keys=True, ensure_ascii=False).replace("--", "\\u002d\\u002d")


def _sensitive_literals(value, key: str | None = None) -> set[str]:
    found: set[str] = set()
    if isinstance(value, dict):
        for child_key, child in value.items():
            found.update(_sensitive_literals(child, str(child_key)))
    elif isinstance(value, list):
        for child in value:
            found.update(_sensitive_literals(child, key))
    elif isinstance(value, str):
        if key in HOST_KEYS and value:
            found.add(value)
        if key in {"path", "resolved_path"} and value.startswith("/") and value != "/":
            found.add(value)
        if key == "locator":
            found.update(PRIVATE_PATH_RE.findall(value))
    return found


def scrub_public_value(value, aliases: dict[str, str], extra_secrets=()):
    """Recursively redact known names plus path/host-shaped strings."""
    secrets = set(extra_secrets)
    secrets.update(_sensitive_literals(value))
    secrets.update({os.path.expanduser("~")})

    def scrub(item, key: str | None = None):
        if isinstance(item, str):
            if key in HOST_KEYS:
                return None
            text = item
            replacements = dict(aliases)
            replacements.update({secret: "<redacted>" for secret in secrets if secret and secret != "/"})
            for old in sorted(replacements, key=len, reverse=True):
                text = text.replace(old, replacements[old])
            text = PRIVATE_PATH_RE.sub("<redacted-path>", text)
            text = DNS_HOST_RE.sub("<redacted-host>", text)
            return text
        if isinstance(item, list):
            return [scrub(child, key) for child in item]
        if isinstance(item, dict):
            return {scrub(str(child_key)): scrub(child, str(child_key))
                    for child_key, child in item.items()}
        return item

    return scrub(value)


def assert_public_safe(text: str, secrets, label: str):
    """Fail before publication if a known private literal or private locator survived."""
    leaked = sorted(
        {secret for secret in secrets if secret and secret != "/" and secret in text},
        key=len,
        reverse=True,
    )
    if leaked:
        raise ValueError(f"{label}: public projection retained a private literal")
    if PRIVATE_PATH_RE.search(text):
        raise ValueError(f"{label}: public projection retained a private path")
    if DNS_HOST_RE.search(text):
        raise ValueError(f"{label}: public projection retained a hostname")


def validate_renderable_run(run: dict, label: str):
    errors = slib.validate_against(
        run, slib.load_json(slib.SCHEMA_DIR / "recommendation-run.schema.json"),
        slib.SCHEMA_DIR,
    )
    if errors:
        raise ValueError(f"{label} is not a valid recommendation run: " + "; ".join(errors[:5]))


def _alias_skill(name: str, public_names: set[str]) -> str:
    if not name or name in public_names or name.startswith("private-skill-"):
        return name
    return private_alias(name)


def _sanitize_skill_fields(payload: dict, public_names: set[str]) -> dict:
    for tier in payload.get("tiers", {}).values():
        if isinstance(tier, list):
            tier[:] = [_alias_skill(name, public_names) for name in tier]
    for key in ("new", "renamed", "retired", "provisional"):
        values = payload.get("catalog_drift", {}).get(key)
        if isinstance(values, list):
            values[:] = [_alias_skill(name, public_names) for name in values]
    for campaign in payload.get("campaigns", []):
        campaign["anchor"] = _alias_skill(campaign.get("anchor", ""), public_names)
        for member in campaign.get("sequence", []):
            member["skill"] = _alias_skill(member.get("skill", ""), public_names)
        for runner in campaign.get("runners_up", []):
            runner["candidate"] = _alias_skill(runner.get("candidate", ""), public_names)
    crosscheck = payload.get("previous_run_crosscheck", {})
    for key in ("acted_on", "still_pending"):
        crosscheck[key] = [_alias_skill(name, public_names) for name in crosscheck.get(key, [])]
    for declined in crosscheck.get("declined", []):
        declined["skill"] = _alias_skill(declined.get("skill", ""), public_names)
    return payload


def load_history(prev_path: Path | None) -> dict:
    if prev_path and prev_path.exists():
        m = HIST_RE.search(prev_path.read_text(encoding="utf-8"))
        if m:
            try:
                h = json.loads(m.group(1))
                if isinstance(h, dict):
                    h.setdefault("runs", [])
                    h.setdefault("monthly", [])
                    h.setdefault("stable_decisions", [])
                    return h
            except json.JSONDecodeError:
                pass
    return {"runs": [], "monthly": [], "stable_decisions": []}


def apply_retention(history: dict) -> dict:
    runs = history["runs"]
    while len(runs) > MAX_RUNS_KEPT:
        old = runs.pop(0)
        month = (old.get("generated_at") or "unknown")[:7]
        slot = next((m for m in history["monthly"] if m["month"] == month), None)
        if slot is None:
            slot = {"month": month, "run_count": 0, "campaigns": []}
            history["monthly"].append(slot)
        slot["run_count"] += 1
        for c in old.get("run_now", []):
            if c not in slot["campaigns"]:
                slot["campaigns"].append(c)
    history["monthly"] = sorted(history["monthly"], key=lambda m: m["month"])
    return history


def summarize(run: dict) -> dict:
    cc = run["previous_run_crosscheck"]
    return {
        "run_id": run["run_id"],
        "generated_at": run["generated_at"],
        "fingerprint": run["fingerprint"]["reason"],
        "profile_reused": run["fingerprint"]["profile_reused"],
        "run_now": [f"{c['id']} {c['title']} [{c['anchor']}]" for c in run["campaigns"]],
        "acted_on": cc["acted_on"],
        "declined": cc["declined"],
        "still_pending": cc["still_pending"],
    }


def public_projection(run: dict) -> tuple[dict, dict[str, str]]:
    """Return a publication-safe copy; never mutate the private canonical run."""
    projected = copy.deepcopy(run)
    private = sorted(
        row["canonical_name"] for row in projected["ledger"]
        if set(row.get("catalog_sources", [])) == {"local"}
    )
    aliases = {name: private_alias(name) for name in private}
    public_names = {
        row["canonical_name"] for row in projected["ledger"]
        if "public" in row.get("catalog_sources", [])
    }
    target_path = projected.get("target", {}).get("path") or ""
    projected = scrub_public_value(projected, aliases, [target_path])
    projected = _sanitize_skill_fields(projected, public_names)
    projected["target"]["path"] = "."
    projected["sources"] = {key: "redacted" for key in projected.get("sources", {})}
    projected["weak_signals"] = {"jsm_scan": None, "jsm_suggest": None}
    for row in projected["ledger"]:
        original = next((old for old, alias in aliases.items() if alias == row["canonical_name"]), None)
        if original:
            row["catalog_sources"] = ["redacted"]
        row["anchors"] = {"profile": [], "juncture": []}
    return projected, aliases


def scrub_history_for_public(history: dict, aliases: dict[str, str], public_names: set[str]) -> dict:
    history = scrub_public_value(copy.deepcopy(history), aliases)
    for row in history.get("runs", []):
        row["run_now"] = [
            "[" + _alias_skill(match.group(1), public_names) + "]"
            for value in row.get("run_now", [])
            if (match := re.search(r"\[([^\]]+)\]\s*$", value))
        ]
        for key in ("acted_on", "still_pending"):
            row[key] = [_alias_skill(name, public_names) for name in row.get(key, [])]
        for declined in row.get("declined", []):
            declined["skill"] = _alias_skill(declined.get("skill", ""), public_names)
    for month in history.get("monthly", []):
        month["campaigns"] = [
            "[" + _alias_skill(match.group(1), public_names) + "]"
            for value in month.get("campaigns", [])
            if (match := re.search(r"\[([^\]]+)\]\s*$", value))
        ]
    for decision in history.get("stable_decisions", []):
        decision["skill"] = _alias_skill(decision.get("skill", ""), public_names)
    return history


def history_skill_names(history: dict) -> set[str]:
    names: set[str] = set()
    for row in history.get("runs", []):
        for value in row.get("run_now", []):
            match = re.search(r"\[([^\]]+)\]\s*$", value)
            if match:
                names.add(match.group(1))
        names.update(row.get("acted_on", []))
        names.update(row.get("still_pending", []))
        names.update(item.get("skill", "") for item in row.get("declined", []))
    for month in history.get("monthly", []):
        for value in month.get("campaigns", []):
            match = re.search(r"\[([^\]]+)\]\s*$", value)
            if match:
                names.add(match.group(1))
    names.update(item.get("skill", "") for item in history.get("stable_decisions", []))
    return {name for name in names if name}


def public_evidence_projection(records: list[dict], aliases: dict[str, str]) -> list[dict]:
    projected = scrub_public_value(copy.deepcopy(records), aliases)
    for row in projected:
        row["origin_host"] = None
        row["command"] = (f"redacted:{row.get('id', 'evidence')}"
                          if row.get("state") == "absent-with-positive-evidence" else None)
        if row.get("locator") is not None:
            row["locator"] = f"redacted:{row.get('id', 'evidence')}"
    return projected


def campaign_block(c: dict) -> str:
    seq = "\n".join(
        f"{i + 1}. /{m['skill']}" + (f" — {m['note']}" if m.get("note") else "") + (f" ({m['role']})" if m["role"] != "anchor" else "")
        for i, m in enumerate(c["sequence"])
    )
    runners = "\n".join(f"- {r['candidate']}: {r['why_it_lost']}" for r in c["runners_up"]) or "- none"
    return f"""### {c['id']}: {c['title']}

**Sequence:**
{seq}

**Kickoff prompt (paste verbatim):**
> {c['kickoff_prompt']}

**Expected artifact:** {c['expected_artifact']}

**Stop condition:** {c['stop_condition']}

**Evidence:** {', '.join(c['evidence_ids'])}

**Install:** `{c['install_command']}`

**Runners-up:**
{runners}
"""


def tier_table(run: dict, tier: str, limit: int | None = None) -> str:
    rows = [r for r in run["ledger"] if r["disposition"] == tier]
    rows.sort(key=lambda r: (-r["scores"]["total"], r["canonical_name"]))
    if limit:
        rows = rows[:limit]
    if not rows:
        return "_none_\n"
    out = ["| Skill | Score | J/A/E/C/R/D | Why | Evidence |", "|---|---|---|---|---|"]
    for r in rows:
        s = r["scores"]
        dims = f"{s['J']}/{s['A']}/{s['E']}/{s['C']}/{s['R']}/{s['D']}"
        why = r["reason"].replace("|", "\\|")
        if tier == "keep_handy" and r.get("promotion_trigger"):
            why += f" (promote on: {r['promotion_trigger']})"
        ev = ", ".join(r["evidence_ids"][:4]) or "—"
        out.append(f"| {r['canonical_name']} | {s['total']} | {dims} | {why} | {ev} |")
    return "\n".join(out) + "\n"


def interesting_considered(run: dict, n: int = 10) -> str:
    rows = [r for r in run["ledger"] if r["disposition"] == "considered_not_now" and (r["anti_signals"] or r["positive_signals"])]
    rows.sort(key=lambda r: (-len(r["anti_signals"]), -r["scores"]["total"], r["canonical_name"]))
    if not rows:
        return "_none worth calling out_\n"
    out = []
    for r in rows[:n]:
        out.append(f"- **{r['canonical_name']}** — {r['reason']}")
    return "\n".join(out) + "\n"


def render(run: dict, history: dict) -> str:
    t = run["tiers"]
    src_lines = "\n".join(f"- {k}: {v}" for k, v in sorted(run["sources"].items())) or "- (none recorded)"
    drift = run.get("catalog_drift", {})
    drift_line = (
        f"new: {', '.join(drift.get('new', [])) or '—'}; renamed: {', '.join(drift.get('renamed', [])) or '—'}; "
        f"retired: {', '.join(drift.get('retired', [])) or '—'}; provisional rows: {', '.join(drift.get('provisional', [])) or '—'}"
    )
    gaps = "\n".join(
        f"- **{g['id']}**: {g['description']} (signals: {', '.join(g['signals']) or '—'}; evidence: {', '.join(g['evidence_ids']) or '—'})"
        + (f" — suggested `jsm requests new` title: {g['proposed_request_title']}" if g.get("proposed_request_title") else "")
        for g in run["gaps"]
    ) or "_no gaps found this run_"
    campaigns = "\n".join(campaign_block(c) for c in run["campaigns"]) or "_no RUN NOW campaigns this run_\n"
    cc = run["previous_run_crosscheck"]
    hist_runs = "\n".join(
        f"- {r['generated_at']} `{r['run_id']}` ({'reused profile' if r['profile_reused'] else 'full profile'}; {r['fingerprint']}) — "
        f"RUN NOW: {'; '.join(r['run_now']) or '—'}; acted on: {', '.join(r['acted_on']) or '—'}; "
        f"declined: {', '.join(d['skill'] for d in r['declined']) or '—'}"
        for r in reversed(history["runs"])
    ) or "- first recorded run"
    monthly = "\n".join(
        f"- {m['month']}: {m['run_count']} run(s); campaigns: {'; '.join(m['campaigns']) or '—'}"
        for m in history["monthly"]
    )
    stable = "\n".join(
        f"- {d['skill']}: declined until {d.get('condition') or 'the user says otherwise'}"
        for d in history["stable_decisions"]
    ) or "- none"
    ledger_jsonl = "\n".join(html_comment_json(r) for r in run["ledger"])
    counts = {k: len(v) for k, v in t.items()}
    return f"""# Recommended Skills For This Project

Run `{run['run_id']}` — generated {run['generated_at']} (generator {run['generator_version']}).
Target: `{run['target']['path']}` (scope: {', '.join(run['target']['scope'])}); profile {'reused' if run['fingerprint']['profile_reused'] else 'rebuilt'} ({run['fingerprint']['reason']}).
Catalog considered: {run['inputs']['catalog_count']} skills — every one has exactly one row in the ledger below.
Tiers: {counts['run_now']} run now / {counts['run_soon']} run soon / {counts['keep_handy']} keep handy / {counts['considered_not_now']} considered / {counts['not_applicable']} not applicable.

## RUN NOW — the portfolio ({len(run['campaigns'])} campaign(s))

{campaigns}

## RUN SOON

{tier_table(run, 'run_soon')}

## KEEP HANDY

{tier_table(run, 'keep_handy')}

## Considered — not now (the interesting rejections)

{interesting_considered(run)}

## Gaps (no catalog skill covers these — candidates for `jsm requests`)

{gaps}

## Source status

{src_lines}

Catalog drift vs the bundled snapshot: {drift_line}

## Previous-run cross-check

- previous run: {cc['previous_run_id'] or '— (first run)'}
- acted on since: {', '.join(cc['acted_on']) or '—'}
- declined: {', '.join(f"{d['skill']} (until {d['condition'] or 'further notice'})" for d in cc['declined']) or '—'}
- still pending: {', '.join(cc['still_pending']) or '—'}

Report outcomes with `jsm outcome -s <skill> --success|--failure` so the recommender learns.

---

## Appendix A — run history (retention: last {MAX_RUNS_KEPT} in full, older compacted monthly)

{hist_runs}

{('### Older (monthly)' + chr(10) + monthly) if monthly else ''}

### Stable user decisions

{stable}

## Appendix B — machine-readable run record

<!-- skill-selection:run-history:v1
{html_comment_json(history)}
-->
<!-- skill-selection:last-run:v1
{html_comment_json(run)}
-->
<!-- skill-selection:ledger:v1
{ledger_jsonl}
-->
"""


ANALYSIS_HEADER_FIELDS = [
    "last_updated", "profiled_at", "profile_head_sha", "profile_branch", "profile_scope",
    "profile_tracked_file_count", "profile_worktree_digest", "profile_manifest_digests",
    "profile_beads_watermark", "profile_cass_watermark", "juncture_refreshed_at",
    "recommendations_generated_at", "generator_version",
]


def _yaml_value(value) -> str:
    if value is None:
        return "null"
    if isinstance(value, (dict, list)):
        return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False)
    return str(value).lower() if isinstance(value, bool) else str(value)


def _existing_profile_rows(path: Path) -> list[dict]:
    match = PROFILE_RE.search(path.read_text(encoding="utf-8"))
    if not match:
        raise ValueError(f"{path}: missing durable profile evidence block")
    rows = json.loads(match.group(1))
    if not isinstance(rows, list):
        raise ValueError(f"{path}: profile evidence block is not an array")
    return rows


def _analysis_header(path: Path, run: dict, profiled: bool, staleness: dict | None) -> dict:
    now = run["generated_at"]
    if profiled:
        if not staleness:
            raise ValueError("full analysis rendering requires staleness facts")
        head = staleness.get("current_head_sha") or run["target"].get("head_sha")
        header = {
            "last_updated": now,
            "profiled_at": now,
            "profile_head_sha": head,
            "profile_branch": run["target"].get("branch"),
            "profile_scope": staleness.get("profile_scope") or run["target"]["scope"],
            "profile_tracked_file_count": staleness["tracked_file_count"],
            "profile_worktree_digest": staleness["worktree_digest"],
            "profile_manifest_digests": staleness.get("manifest_digests") or {},
            "profile_beads_watermark": staleness.get("beads_watermark"),
            "profile_cass_watermark": staleness.get("cass_watermark"),
            "juncture_refreshed_at": now,
            "recommendations_generated_at": now,
            "generator_version": run["generator_version"],
        }
    else:
        if not path.exists():
            raise ValueError("--juncture-only cannot create an analysis document; re-profile first")
        header = slib.parse_frontmatter(path.read_text(encoding="utf-8"))
        errors = slib.validate_against(
            header, slib.load_json(slib.SCHEMA_DIR / "analysis-header.schema.json"),
            slib.SCHEMA_DIR,
        )
        if errors:
            raise ValueError("existing analysis header is invalid: " + "; ".join(errors[:3]))
        header.update({
            "last_updated": now,
            "juncture_refreshed_at": now,
            "recommendations_generated_at": now,
            "generator_version": run["generator_version"],
        })
    errors = slib.validate_against(
        header, slib.load_json(slib.SCHEMA_DIR / "analysis-header.schema.json"),
        slib.SCHEMA_DIR,
    )
    if errors:
        raise ValueError("rendered analysis header is invalid: " + "; ".join(errors[:3]))
    return header


def _markdown_text(value) -> str:
    return str(value or "").replace("\n", " ").replace("|", "\\|").strip()


def _evidence_lines(rows: list[dict]) -> str:
    if not rows:
        return "_No evidence records classified here._"
    lines = []
    for row in sorted(rows, key=lambda item: item["id"]):
        locator = _markdown_text(row.get("locator")) or "no locator"
        signals = ", ".join(row.get("signals", [])) or "narrative"
        lines.append(
            f"- **{row['state']}** — {_markdown_text(row['claim'])} "
            f"(`{row['id']}`; {row['source_type']}; {locator}; signals: {signals})"
        )
    return "\n".join(lines)


def _profile_section(row: dict) -> str:
    signals = " ".join(row.get("signals", []))
    if re.search(r"(^| )(lang-|build-|toolchain-|workspace-|dep-|fw-)", signals):
        return "Languages, build systems, toolchains"
    if re.search(r"(^| )code-", signals):
        return "Kinds of code present"
    if "test" in signals or "fuzz" in signals or "gap-" in signals:
        return "Tests — present and absent"
    if re.search(r"(^| )(docs?-|readme-|agent-|beads-|ci-|license-|plan-|governance-)", signals):
        return "Documentation & process artifacts"
    if re.search(r"(^| )(release-|changelog-|installer-|doctor-|perf-|monolith-|polish-)", signals):
        return "Delivery surface & polish gaps"
    return "Identity & purpose"


def render_analysis_document(path: Path, run: dict, profiled: bool, staleness: dict | None,
                             evidence_rows: list[dict], public_secrets=()):
    header = _analysis_header(path, run, profiled, staleness)
    schema = slib.load_json(slib.SCHEMA_DIR / "evidence.schema.json")
    supplied_errors = [error for index, row in enumerate(evidence_rows)
                       for error in slib.validate_against(
                           row, schema, slib.SCHEMA_DIR, f"$[{index}]"
                       )]
    if supplied_errors:
        raise ValueError("analysis evidence is invalid: " + "; ".join(supplied_errors[:3]))
    slib.active_evidence(evidence_rows)
    rows_by_id = {row["id"]: row for row in evidence_rows}
    if not profiled:
        for row in _existing_profile_rows(path):
            if row["id"] in rows_by_id and rows_by_id[row["id"]] != row:
                raise ValueError(
                    f"analysis evidence id {row['id']} conflicts with durable profile evidence"
                )
            rows_by_id.setdefault(row["id"], row)
    rows = [rows_by_id[eid] for eid in sorted(rows_by_id)]
    errors = [error for index, row in enumerate(rows)
              for error in slib.validate_against(row, schema, slib.SCHEMA_DIR, f"$[{index}]")]
    if errors:
        raise ValueError("analysis evidence is invalid: " + "; ".join(errors[:3]))
    active = slib.active_evidence(rows)
    profile_rows = [row for row in rows if row.get("kind") == "profile"]
    if not profile_rows or not any(row.get("kind") == "profile" for row in active):
        raise ValueError("analysis rendering requires active profile evidence")
    active_profile = [row for row in active if row.get("kind") == "profile"]
    active_juncture = [row for row in active if row.get("kind") == "juncture"]
    sections = {name: [] for name in (
        "Identity & purpose", "Languages, build systems, toolchains", "Kinds of code present",
        "Tests — present and absent", "Documentation & process artifacts",
        "Delivery surface & polish gaps",
    )}
    for row in active_profile:
        sections[_profile_section(row)].append(row)
    header_text = "---\n" + "\n".join(
        f"{field}: {_yaml_value(header[field])}" for field in ANALYSIS_HEADER_FIELDS
    ) + "\n---"
    profile_block = "<!-- skill-selection:profile-evidence:v1\n" + html_comment_json(profile_rows) + "\n-->"
    body = [
        header_text,
        "",
        profile_block,
        "",
        "# Comprehensive Analysis Of Project (Automated Skill Selection)",
        "",
        "> Generated from the canonical evidence set. Every factual line cites its evidence id;",
        "> unknown and positively established absence remain distinct states.",
    ]
    for title, section_rows in sections.items():
        body.extend(["", f"## {title}", "", _evidence_lines(section_rows)])
    body.extend([
        "", "## What this project is going through right now (juncture)", "",
        _evidence_lines(active_juncture),
        "", "## Evidence appendix", "",
        "| ID | Kind | State | Source | Claim | Locator |", "|---|---|---|---|---|---|",
    ])
    superseded = {eid for row in rows for eid in row.get("supersedes", [])}
    for row in rows:
        state = row["state"] + (" (superseded)" if row["id"] in superseded else "")
        body.append(
            f"| {row['id']} | {row['kind']} | {state} | {row['source_type']} | "
            f"{_markdown_text(row['claim'])} | {_markdown_text(row.get('locator')) or '—'} |"
        )
    rendered = "\n".join(body) + "\n"
    if public_secrets:
        assert_public_safe(rendered, public_secrets, "analysis document")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(rendered, encoding="utf-8")
    print(f"wrote {path}")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--run", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--previous")
    ap.add_argument("--update-analysis-header")
    mode = ap.add_mutually_exclusive_group()
    mode.add_argument("--profiled", action="store_true")
    mode.add_argument("--juncture-only", action="store_true")
    ap.add_argument("--profile-evidence")
    ap.add_argument("--staleness")
    ap.add_argument("--public", action="store_true", help="render a redacted projection; the input run remains private")
    a = ap.parse_args(argv)
    if a.profiled and not a.staleness:
        ap.error("--profiled requires --staleness so every profile fingerprint field is refreshed")
    if a.update_analysis_header and not (a.profiled or a.juncture_only):
        ap.error("--update-analysis-header requires --profiled or --juncture-only")
    if a.update_analysis_header and not a.profile_evidence:
        ap.error("--update-analysis-header requires --profile-evidence with the merged evidence set")

    run = slib.load_json(a.run)
    validate_renderable_run(run, "input")
    aliases = {}
    public_secrets: set[str] = set()
    public_names: set[str] = set()
    if a.public:
        public_secrets.update(_sensitive_literals(run))
        public_secrets.add(os.path.expanduser("~"))
        public_names = {
            row["canonical_name"] for row in run["ledger"]
            if "public" in row.get("catalog_sources", [])
        }
        run, aliases = public_projection(run)
        validate_renderable_run(run, "public projection")
        public_secrets.update(aliases)
    prev = Path(a.previous) if a.previous else Path(a.out)
    history = load_history(prev)  # retention applied once, after appends (below)
    if a.public:
        for name in history_skill_names(history) - public_names:
            aliases.setdefault(name, private_alias(name))
            public_secrets.add(name)
        history = scrub_history_for_public(history, aliases, public_names)
    current_declined = {d["skill"]: d for d in run["previous_run_crosscheck"]["declined"]}
    ledger_by = {row["canonical_name"]: row for row in run["ledger"]}
    history["stable_decisions"] = [
        d for d in history["stable_decisions"]
        if d["skill"] not in ledger_by or ledger_by[d["skill"]]["already_done_state"] == "declined"
    ]
    stable_by = {d["skill"]: d for d in history["stable_decisions"]}
    stable_by.update(current_declined)
    history["stable_decisions"] = [stable_by[name] for name in sorted(stable_by)]
    summary = summarize(run)
    existing = next((i for i, old in enumerate(history["runs"]) if old.get("run_id") == run["run_id"]), None)
    if existing is None:
        history["runs"].append(summary)
    else:
        history["runs"][existing] = summary
    history = apply_retention(history)

    rendered_recommendations = render(run, history)
    if a.public:
        assert_public_safe(rendered_recommendations, public_secrets, "recommendations document")
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(rendered_recommendations, encoding="utf-8")
    print(f"wrote {out}")

    if a.update_analysis_header:
        evidence_rows = slib.load_json(a.profile_evidence)
        if a.public:
            public_secrets.update(_sensitive_literals(evidence_rows))
            evidence_rows = public_evidence_projection(evidence_rows, aliases)
        stale = slib.load_json(a.staleness) if a.staleness else None
        render_analysis_document(
            Path(a.update_analysis_header), run, a.profiled, stale, evidence_rows,
            public_secrets if a.public else (),
        )
    return 0


if __name__ == "__main__":
    sys.exit(main())
