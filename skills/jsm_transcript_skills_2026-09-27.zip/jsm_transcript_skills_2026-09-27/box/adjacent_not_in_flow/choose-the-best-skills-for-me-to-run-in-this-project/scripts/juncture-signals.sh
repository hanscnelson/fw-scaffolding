#!/usr/bin/env bash
# juncture-signals.sh — deterministic JUNCTURE detector for the skill-selection package.
#
# Usage: bash juncture-signals.sh --target DIR [--scope PATH[,PATH...]] [--days N] --out FILE
#   --days N   the recent-activity window in days (default 14), ending at the pinned clock.
#
# Output: a JSON array of evidence records (references/schemas/evidence.schema.json) with ids
#   ev-j0001.. in emission order, written to --out (or stdout when --out is "-"), plus a one-line
#   summary on stderr. Sources: git history (source_type git), GitHub via gh (gh), beads via
#   br/bv (beads), and code smells via rg (file). Every record is present |
#   absent-with-positive-evidence | unknown; a missing tool, timeout, or failed command yields
#   unknown (never absent) with the error text in `detail`. A non-git target makes every
#   git-derived signal unknown with detail "not a git repository".
#
# Read-only toward the target: git/gh/br/bv are only queried (br runs with --no-auto-flush
#   --no-auto-import; bv with --no-cache). Nothing under --target is created, modified, or deleted.
# Exit codes: 0 = a schema-valid array was written; 1 = bad arguments, target/helper missing, or
#   the output failed schema validation. Individual detector failures never abort the run.
#
# Determinism: same tree + same SKILL_SELECTION_NOW => byte-identical output (the window is
#   computed from the pinned clock; every git log carries --since/--until; scans are sorted).
# Portability: bash 3.2+ (no associative arrays/mapfile), BSD or GNU find/sed, rg with a
#   grep -rE fallback, timeout/gtimeout/perl-alarm. External deps: bash, git, python3 (stdlib),
#   optional rg/gh/br/bv/jq.
set -uo pipefail
set -f   # no pathname expansion: glob strings like '*.rs' are passed to git/rg literally

TARGET="."; SCOPE="."; OUT=""; DAYS=14
while [ $# -gt 0 ]; do
  case "$1" in
    --target) TARGET="$2"; shift 2;;
    --scope) SCOPE="$2"; shift 2;;
    --days) DAYS="$2"; shift 2;;
    --out) OUT="$2"; shift 2;;
    -h|--help) sed -n '2,24p' "$0"; exit 0;;
    *) echo "unknown arg: $1" >&2; exit 1;;
  esac
done
[ -n "$OUT" ] || { echo "--out FILE is required (use - for stdout)" >&2; exit 1; }
case "$DAYS" in ''|*[!0-9]*) echo "--days must be a positive integer" >&2; exit 1;; esac
SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)
SCHEMA="$SCRIPT_DIR/../references/schemas/evidence.schema.json"
TARGET=$(cd "$TARGET" 2>/dev/null && pwd -P) || { echo "target not found: $TARGET" >&2; exit 1; }
[ -f "$TARGET/AGENTS.md" ] && grep -Eqi 'NO FILE DELETION|NEVER (ALLOWED TO )?DELETE' "$TARGET/AGENTS.md" && export SKILL_SELECTION_KEEP_TEMP=1
if [ "$OUT" != "-" ]; then case "$OUT" in /*) ;; *) OUT="$PWD/$OUT";; esac; fi
NOW=$(python3 "$SCRIPT_DIR/skillsel_common.py" now) || { echo "python3 helper failed" >&2; exit 1; }
KIND=juncture; ID_PREFIX=j
shift_days() { python3 -c 'import sys,datetime as d; s=sys.argv[1].replace("Z","+00:00"); print((d.datetime.fromisoformat(s)-d.timedelta(days=int(sys.argv[2]))).strftime("%Y-%m-%dT%H:%M:%SZ"))' "$NOW" "$1"; }
SINCE=$(shift_days "$DAYS"); SINCE7=$(shift_days 7); STALE=$(shift_days 60)
WINDOW="--since=$SINCE --until=$NOW"

SCOPES=(); IFS=',' read -r -a SCOPES_RAW <<< "$SCOPE"
for s in "${SCOPES_RAW[@]}"; do
  s="${s%/}"; [ -z "$s" ] && s="."; case "$s" in ./*) s="${s#./}";; esac; [ -z "$s" ] && s="."
  SCOPES+=("$s")
done
[ "${#SCOPES[@]}" -gt 0 ] || SCOPES=(.)

TMPD=$(mktemp -d "${TMPDIR:-/tmp}/skillsel-juncture.XXXXXX") || { echo "mktemp failed" >&2; exit 1; }
cleanup() {
  if [ "${SKILL_SELECTION_KEEP_TEMP:-0}" = 1 ]; then
    echo "juncture-signals: kept temporary workspace $TMPD" >&2
    return
  fi
  (set +f; rm -f "$TMPD"/* 2>/dev/null); rmdir "$TMPD" 2>/dev/null
}
trap cleanup EXIT
: > "$TMPD/records"; : > "$TMPD/states"
cd "$TARGET" || exit 1

# ------------------------------------------------------------------ helpers
TMO_BIN=""
if command -v timeout >/dev/null 2>&1; then TMO_BIN=timeout; elif command -v gtimeout >/dev/null 2>&1; then TMO_BIN=gtimeout; fi
tmo() { # tmo SECONDS cmd args...  (124/142 = timed out)
  local s="$1"; shift
  if [ -n "$TMO_BIN" ]; then "$TMO_BIN" "$s" "$@"
  elif command -v perl >/dev/null 2>&1; then perl -e 'alarm shift; exec @ARGV' "$s" "$@"
  else "$@"; fi
}
is_timeout() { [ "$1" = 124 ] || [ "$1" = 142 ]; }
HAVE_RG=0; command -v rg >/dev/null 2>&1 && HAVE_RG=1
HAVE_GIT=0; command -v git >/dev/null 2>&1 && HAVE_GIT=1
IS_GIT=false; HEAD_FULL=""; SHA=worktree; REPO_HEAD=""; BRANCH=""
if [ $HAVE_GIT = 1 ] && git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  IS_GIT=true
  HEAD_FULL=$(git rev-parse HEAD 2>/dev/null || true)
  if [ -n "$HEAD_FULL" ]; then SHA=$(git rev-parse --short HEAD 2>/dev/null || echo worktree); REPO_HEAD="$HEAD_FULL"; fi
  BRANCH=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || true)
fi
GITLOG="git log $WINDOW"

# emit STATE POLARITY SOURCE LOCATOR CONF SIGNALS CLAIM COMMAND DETAIL  (one record per line, US-separated)
emit() {
  printf '%s\037%s\037%s\037%s\037%s\037%s\037%s\037%s\037%s\n' "$1" "$2" "$3" "$4" "$5" "$6" "$7" "$8" "$(printf '%s' "$9" | tr '\n\r\037' '   ')" >> "$TMPD/records"
  local s; for s in $(printf '%s' "$6" | tr ',' ' '); do printf '%s\t%s\t%s\n' "$s" "$1" "$4" >> "$TMPD/states"; done
}
ev_present() { emit present positive "$2" "$3" "$4" "$1" "$5" "$6" "$7"; }                     # signals src loc conf claim cmd detail
ev_absent()  { emit absent-with-positive-evidence negative "$2" "$3" "$4" "$1" "$5" "$6" "$7"; }
ev_unknown() { emit unknown positive "$2" "" 0 "$1" "$3" "$4" "$5"; }                             # signals src claim cmd detail
ev_fact()    { emit present positive "$2" "$3" 4 "" "$1" "$4" "$5"; }                            # claim src loc cmd detail
loc() { if [ -n "${2:-}" ]; then printf '%s@%s:%s' "$1" "$SHA" "$2"; else printf '%s@%s' "$1" "$SHA"; fi; }
loc_of_match() { local p l; p=$(printf '%s' "$1" | cut -d: -f1); l=$(printf '%s' "$1" | cut -d: -f2); loc "$p" "$l"; }
snippet() { printf '%s' "$1" | cut -d: -f3- | tr -d '\000-\010\013-\037' | cut -c1-110; }
kv() { awk -F'\t' -v k="$1" '$1==k{print substr($0, length(k)+2)}' "$2"; }
# git_unknown SIGNALS "CLAIM" "CMD": every git-derived signal is unknown (never absent) without git history
git_unknown() { ev_unknown "$1" git "$2" "$3" "$( $IS_GIT && echo "git repository without commits" || echo "not a git repository" )"; }

# ---------------------------------------------------- generated/vendored + test exclusions (mirrors profile-project.sh)
EXCL_DIRS="target node_modules vendor dist build .git third_party upstream legacy* .next __pycache__ .venv venv coverage .beads .doctor"
EXCL_FILES="*.generated.* *.min.js *.min.css *.pb.go *_pb2.py Cargo.lock package-lock.json pnpm-lock.yaml yarn.lock bun.lockb bun.lock poetry.lock uv.lock go.sum Gemfile.lock composer.lock"
TEST_DIRS="tests test spec specs __tests__ e2e benches bench fuzz testdata fixtures __snapshots__"
TEST_FILES="*_test.* *.test.* *.spec.* test_*.py *_tests.rs tests.rs test.rs"
LINGUIST=""
for s in . "${SCOPES[@]}"; do
  f="$s/.gitattributes"; [ "$s" = "." ] && f=".gitattributes"
  [ -f "$f" ] && LINGUIST="$LINGUIST $(grep -E 'linguist-(generated|vendored)(=true)?([[:space:]]|$)' "$f" 2>/dev/null | grep -v '^#' | awk '{print $1}' | tr '\n' ' ')"
done
LINGUIST=$(printf '%s' "$LINGUIST" | tr ' ' '\n' | grep -v '^$' | LC_ALL=C sort -u | tr '\n' ' ')
RG_EXCL=(); for d in $EXCL_DIRS; do RG_EXCL+=(-g "!$d/"); done; for f in $EXCL_FILES $LINGUIST; do RG_EXCL+=(-g "!$f"); done
RG_TEST=(); for d in $TEST_DIRS; do RG_TEST+=(-g "!$d/"); done; for f in $TEST_FILES; do RG_TEST+=(-g "!$f"); done
CODE_GLOBS='*.rs *.py *.ts *.tsx *.js *.jsx *.mjs *.cjs *.go *.c *.cc *.cpp *.cxx *.h *.hpp *.hh *.zig *.swift *.kt *.kts *.java *.rb *.sh *.bash *.zsh *.cu *.cuh *.metal *.wgsl *.cl *.cs *.ex *.exs *.lua *.dart *.vue *.svelte *.astro *.php *.scala *.hs *.ml'
TEST_INC='**/tests/** **/test/** **/spec/** **/specs/** **/__tests__/** **/e2e/** *_test.* *.test.* *.spec.* test_*.py *_tests.rs tests.rs'
RG_RC=1; RG_CMD=""
rg_lines() { # rg_lines PATTERN NONTEST [include globs...] -> sorted "path:line:text"; sets RG_RC (0 hit, 1 none, 2 error, 124 timeout)
  local pat="$1" nontest="$2"; shift 2
  local inc=() x; for x in "$@"; do inc+=(-g "$x"); done
  local tst=(); [ "$nontest" = 1 ] && tst=("${RG_TEST[@]}")
  RG_CMD="rg -n --hidden -e '$pat'${1:+ -g '$*'} <generated/vendored exclusions>${nontest:+ <test-path exclusions>} -- ${SCOPES[*]}"
  if [ $HAVE_RG = 1 ]; then
    tmo 60 rg -n --no-messages --no-require-git --hidden --max-columns 200 --max-columns-preview -e "$pat" \
      ${inc[@]+"${inc[@]}"} "${RG_EXCL[@]}" ${tst[@]+"${tst[@]}"} -- "${SCOPES[@]}" > "$TMPD/rg.out" 2> "$TMPD/rg.err"; RG_RC=$?
  else
    RG_CMD="grep -rEn (rg fallback) -e '$pat' ... -- ${SCOPES[*]}"
    local ex=() d; for d in $EXCL_DIRS; do ex+=(--exclude-dir="$d"); done; for d in $EXCL_FILES $LINGUIST; do ex+=(--exclude="$d"); done
    if [ "$nontest" = 1 ]; then for d in $TEST_DIRS; do ex+=(--exclude-dir="$d"); done; for d in $TEST_FILES; do ex+=(--exclude="$d"); done; fi
    local gi=(); for x in "$@"; do gi+=(--include="${x##*/}"); done
    tmo 60 grep -rEn ${gi[@]+"${gi[@]}"} "${ex[@]}" -e "$pat" -- "${SCOPES[@]}" > "$TMPD/rg.out" 2> "$TMPD/rg.err"; RG_RC=$?
    [ "$RG_RC" -gt 2 ] && ! is_timeout "$RG_RC" && RG_RC=2
  fi
  [ "$RG_RC" = 2 ] && [ -s "$TMPD/rg.out" ] && RG_RC=0
  sed 's#^\./##' "$TMPD/rg.out" | LC_ALL=C sort -t: -k1,1 -k2,2n
}
# rg_count PATTERN NONTEST [globs...] -> prints "COUNT FILES FIRSTMATCH"; sets RG_RC
rg_count() {
  local out n files first
  out=$(rg_lines "$@")
  n=$(printf '%s\n' "$out" | grep -c .); files=$(printf '%s\n' "$out" | cut -d: -f1 | LC_ALL=C sort -u | grep -c .); first=$(printf '%s\n' "$out" | head -1)
  printf '%s %s %s' "$n" "$files" "$first"
}

# ------------------------------------------------------------------ git window facts
GIT_SIGNALS="jx-perf-commits jx-bug-fix-churn jx-regressions jx-release-overdue jx-release-imminent jx-docs-drift jx-unsafe-touched jx-port-in-progress jx-repo-sprawl jx-uncommitted-work jx-hang-or-deadlock jx-recurring-panics jx-flaky-tests jx-dependency-bump jx-upstream-sync-due jx-auth-loops jx-deploy-failures jx-payments-bugs jx-perf-complaints jx-security-concern jx-swarm-active jx-wasm-size-or-speed"
GL_RC=-1
if $IS_GIT && [ -n "$HEAD_FULL" ]; then
  tmo 60 git log $WINDOW --format='%h%x1f%an%x1f%cI%x1f%s' HEAD > "$TMPD/commits" 2> "$TMPD/gitlog.err"; GL_RC=$?
  [ "$GL_RC" = 0 ] || : > "$TMPD/commits"
fi
if [ "$GL_RC" = 0 ]; then
  N_WIN=$(grep -c . "$TMPD/commits")
  tmo 60 git log $WINDOW --format=%b HEAD > "$TMPD/bodies" 2>/dev/null || : > "$TMPD/bodies"
  tmo 60 git log $WINDOW --format='%x1e%h' --name-only HEAD > "$TMPD/names" 2>/dev/null || : > "$TMPD/names"
  ev_fact "commits in the $DAYS-day window" git "$HEAD_FULL" "$GITLOG --format='%h %an %cI %s' HEAD" "$N_WIN commits between $SINCE and $NOW; newest: $(head -3 "$TMPD/commits" | cut -d"$(printf '\037')" -f1,4 | tr '\037' ' ' | tr '\n' ';')"
  CHURN=$(grep -v '^\x1e' "$TMPD/names" | grep -v '^$' | awk -F/ '{print (NF>1?$1"/":$1)}' | LC_ALL=C sort | uniq -c | sort -k1,1nr -k2,2 | head -5 | awk '{printf "%s:%s ", $2, $1}')
  ev_fact "churn by top-level directory (files touched in window, top 5)" git "$HEAD_FULL" "$GITLOG --format= --name-only HEAD | cut -d/ -f1 | sort | uniq -c" "${CHURN:-no files touched}"
  # vocabulary densities over window subjects (+ bodies for co-author trailers)
  python3 - "$TMPD" "$N_WIN" <<'PY' > "$TMPD/vocab.kv"
import sys, re, os
tmpd, n = sys.argv[1], int(sys.argv[2])
rows = [l.rstrip('\n').split('\x1f') for l in open(os.path.join(tmpd, 'commits'), encoding='utf-8', errors='replace') if l.strip()]
subs = [(r[0], r[3].lower() if len(r) > 3 else '') for r in rows]
authors = sorted(set(r[1] for r in rows if len(r) > 1))
cats = {
  'fix': r'\b(fix|fixes|fixed|fixing|hotfix|bugfix|bug|repair|correct(s|ed)?)\b',
  'hotfix': r'\bhotfix\b', 'revert': r'\brevert(s|ed)?\b', 'regress': r'\bregress(ion|ions|ed)?\b',
  'flaky': r'\b(flaky|flake|flakiness|intermittent|deflake|retry (the )?test|retried)\b',
  'perf': r'\b(perf|performance|optimi[sz]e[sd]?|optimi[sz]ation|faster|speed[- ]?up|speedup|latency|throughput|hot ?path)\b',
  'wip': r'\bwip\b', 'port': r'\b(port(ed|ing)? (to|from|of)|parity|gauntlet|upstream sync)\b',
  'unsafe': r'\bunsafe\b', 'deadlock': r'\b(deadlock|livelock|hang|hangs|hanging|hung|timeout|timed out|stuck|lock contention)\b',
  'panic': r'\b(panic|panics|panicked|crash|crashes|segfault|stack overflow|unwrap(ped)? on (a )?none|abort)\b',
  'release': r'\b(release|releases|released|prepare (v|version )?[0-9]+\.[0-9]+|bump(ed)? version|chore\(release\))\b|^v?[0-9]+\.[0-9]+\.[0-9]+$',
  'bump': r'\b(bump|bumps|bumped|deps|dependabot|renovate|upgrade|upgrades|upgraded|cargo update|update dependencies|update deps)\b',
  'security': r'\b(security|secur|cve-[0-9]+|vulnerab|exploit|audit finding|hardening)\b',
  'auth': r'\b(auth|login|logout|oauth|sign[- ]?in|session token|token refresh|jwt|401|403)\b',
  'deploy': r'\b(deploy|deployment|deploys|vercel|hosting|cloudflare|railway|fly\.io|k8s|kubernetes|outage)\b',
  'payments': r'\b(webhook|billing|stripe|paypal|subscription|invoice|checkout|payment)\b',
  'wasm': r'\b(wasm|bundle size|wasm-opt|wasm size)\b', 'slow': r'\b(slow|slower|sluggish|latency|throughput|too long|bottleneck)\b',
}
out = {'n': n, 'authors': len(authors), 'code_commits': sum(1 for _ in rows)}
for k, pat in cats.items():
    rx = re.compile(pat)
    hits = [h for h, s in subs if rx.search(s)]
    out[k] = len(hits); out[k + '_shas'] = ' '.join(hits[:8])
bodies = open(os.path.join(tmpd, 'bodies'), encoding='utf-8', errors='replace').read()
out['agent_trailers'] = len(re.findall(r'(?i)co-authored-by:.*(claude|codex|gemini|gpt|copilot|cursor|agent)', bodies))
for k, v in sorted(out.items()): print('%s\t%s' % (k, v))
PY
  V="$TMPD/vocab.kv"; vc() { kv "$1" "$V"; }
  ev_fact "commit-message vocabulary in window" git "$HEAD_FULL" "$GITLOG --format=%s HEAD | python3 (regex categories)" "of $N_WIN commits: fix=$(vc fix) hotfix=$(vc hotfix) revert=$(vc revert) regress=$(vc regress) flaky=$(vc flaky) perf=$(vc perf) wip=$(vc wip) port/parity/gauntlet=$(vc port) unsafe=$(vc unsafe) deadlock/hang/timeout=$(vc deadlock) panic=$(vc panic) release=$(vc release) bump/upgrade=$(vc bump) security=$(vc security) auth=$(vc auth) deploy=$(vc deploy) payments=$(vc payments) wasm=$(vc wasm) slow=$(vc slow); authors=$(vc authors); agent co-author trailers=$(vc agent_trailers)"
  # vocab_signal SIGNAL CATEGORY MIN CONF "CLAIM"
  vocab_signal() {
    local sig="$1" cat="$2" min="$3" conf="$4" claim="$5" n; n=$(vc "$cat")
    if [ "$n" -ge "$min" ]; then ev_present "$sig" git "$(vc "${cat}_shas" | cut -d' ' -f1)" "$conf" "$claim" "$GITLOG --format='%h %s' HEAD | grep -Ei <$cat vocabulary>" "$n of $N_WIN window commits: $(vc "${cat}_shas")"
    else ev_absent "$sig" git "" "$conf" "no $claim" "$GITLOG --format='%h %s' HEAD | grep -Ei <$cat vocabulary>" "$n of $N_WIN window commits match (threshold $min)"; fi
  }
  vocab_signal jx-perf-commits perf 1 3 "perf/optimize vocabulary in recent commits"
  if [ "$N_WIN" -ge 4 ] && [ $(( $(vc fix) * 100 )) -ge $(( N_WIN * 40 )) ]; then ev_present jx-bug-fix-churn git "$(vc fix_shas | cut -d' ' -f1)" 3 "fix-like commits are >= 40% of the window" "$GITLOG --format='%h %s' HEAD | grep -Ei fix|hotfix|bug" "$(vc fix) of $N_WIN commits: $(vc fix_shas)"
  else ev_absent jx-bug-fix-churn git "" 3 "fix-like commits are not dominant" "$GITLOG --format='%h %s' HEAD | grep -Ei fix|hotfix|bug" "$(vc fix) of $N_WIN commits ($( [ "$N_WIN" -ge 4 ] || printf 'fewer than 4 commits in window; ')threshold 40%)"; fi
  REG=$(( $(vc revert) + $(vc regress) ))
  if [ "$REG" -ge 1 ]; then ev_present jx-regressions git "$(printf '%s %s' "$(vc revert_shas)" "$(vc regress_shas)" | tr ' ' '\n' | grep -v '^$' | head -1)" 3 "revert commits or regression vocabulary in window" "$GITLOG --format='%h %s' HEAD | grep -Ei revert|regress" "reverts: $(vc revert) [$(vc revert_shas)]; regression vocab: $(vc regress) [$(vc regress_shas)]"
  else ev_absent jx-regressions git "" 3 "no reverts or regression vocabulary in window" "$GITLOG --format='%h %s' HEAD | grep -Ei revert|regress" "0 of $N_WIN commits"; fi
  vocab_signal jx-port-in-progress port 1 3 "port/parity/gauntlet vocabulary in recent commits"
  vocab_signal jx-hang-or-deadlock deadlock 1 3 "hang/deadlock/timeout vocabulary in recent commits"
  if [ "$(vc panic)" -ge 2 ]; then vocab_signal jx-recurring-panics panic 2 3 "recurring panic/crash vocabulary in recent commits"
  else ev_absent jx-recurring-panics git "" 3 "panics/crashes do not recur in recent commits" "$GITLOG --format='%h %s' HEAD | grep -Ei panic|crash|segfault" "$(vc panic) of $N_WIN commits (threshold 2): $(vc panic_shas)"; fi
  vocab_signal jx-auth-loops auth 1 2 "auth/login/OAuth fix vocabulary in recent commits"
  vocab_signal jx-deploy-failures deploy 1 2 "deploy/hosting vocabulary in recent commits"
  vocab_signal jx-payments-bugs payments 1 2 "webhook/billing/subscription vocabulary in recent commits"
  vocab_signal jx-perf-complaints slow 1 2 "slowness/latency vocabulary in recent commits"
  vocab_signal jx-security-concern security 1 2 "security/vulnerability vocabulary in recent commits"
  vocab_signal jx-wasm-size-or-speed wasm 1 2 "wasm size/speed vocabulary in recent commits"
  # release overdue / imminent
  LAST_TAG=$(tmo 60 git describe --tags --abbrev=0 HEAD 2>/dev/null || true)
  if [ -n "$LAST_TAG" ]; then
    SINCE_TAG=$(tmo 60 git rev-list --count "$LAST_TAG..HEAD" 2>/dev/null || echo 0)
    ev_fact "distance from last tag to HEAD" git "$LAST_TAG" "git describe --tags --abbrev=0; git rev-list --count $LAST_TAG..HEAD" "$SINCE_TAG commits since $LAST_TAG"
    if [ "$SINCE_TAG" -ge 40 ]; then ev_present jx-release-overdue git "$LAST_TAG" 4 ">= 40 commits since the last tag" "git rev-list --count $LAST_TAG..HEAD" "$SINCE_TAG commits since $LAST_TAG"
    else ev_absent jx-release-overdue git "$LAST_TAG" 4 "fewer than 40 commits since the last tag" "git rev-list --count $LAST_TAG..HEAD" "$SINCE_TAG commits since $LAST_TAG"; fi
  else ev_absent jx-release-overdue git "" 3 "no tags, so release-overdue (commits since last tag) does not apply" "git describe --tags --abbrev=0" "no tag reachable from HEAD; $(tmo 60 git rev-list --count HEAD 2>/dev/null || echo '?') commits total"; fi
  REL7=$(tmo 60 git log --since="$SINCE7" --until="$NOW" --format='%h %s' HEAD 2>/dev/null | grep -Ei '\b(release[sd]?|prepare (v|version )?[0-9]+\.[0-9]+|bump(ed)? version|chore\(release\))\b|^[0-9a-f]+ v?[0-9]+\.[0-9]+\.[0-9]+$' | head -5)
  VBUMP=$(tmo 60 git log --since="$SINCE7" --until="$NOW" -p --format='%h' HEAD -- Cargo.toml package.json pyproject.toml 2>/dev/null | grep -E '^\+(version|"version")[[:space:]]*[:=]' | head -3)
  if [ -n "$REL7" ] || [ -n "$VBUMP" ]; then ev_present jx-release-imminent git "$(printf '%s\n' "$REL7" | head -1 | cut -d' ' -f1)" 3 "version bump or release vocabulary in the last 7 days" "git log --since=$SINCE7 --until=$NOW --format='%h %s' | grep -Ei release|bump version; git log -p -- Cargo.toml package.json pyproject.toml | grep '^+version'" "release commits: $(printf '%s' "$REL7" | tr '\n' ';'); version bumps: $(printf '%s' "$VBUMP" | tr '\n' ';')"
  else ev_absent jx-release-imminent git "" 3 "no version bump or release vocabulary in the last 7 days" "git log --since=$SINCE7 --until=$NOW --format='%h %s' | grep -Ei release|bump version; git log -p -- Cargo.toml package.json pyproject.toml | grep '^+version'" "0 release commits and 0 manifest version bumps since $SINCE7"; fi
  # docs drift: code commits since README / CHANGELOG were last touched
  DRIFT=""; DRIFT_MAX=0; DRIFT_LOC=""
  for doc in README.md CHANGELOG.md; do
    [ -f "$doc" ] || continue
    LASTD=$(tmo 60 git log -1 --format=%H -- "$doc" 2>/dev/null || true)
    if [ -n "$LASTD" ]; then c=$(tmo 60 git rev-list --count "$LASTD..HEAD" -- . ':!*.md' ':!*.mdx' ':!docs' ':!*.txt' 2>/dev/null || echo 0); DRIFT="$DRIFT $doc=$c(last touched $(git log -1 --format=%cs "$LASTD" 2>/dev/null))"; [ "$c" -gt "$DRIFT_MAX" ] && { DRIFT_MAX=$c; DRIFT_LOC="$doc"; }
    else DRIFT="$DRIFT $doc=uncommitted"; fi
  done
  if [ -z "$DRIFT" ]; then ev_absent jx-docs-drift git "" 3 "no README/CHANGELOG to drift (see docs-readme-missing)" "git log -1 -- README.md CHANGELOG.md" "neither README.md nor CHANGELOG.md at the target root"
  elif [ "$DRIFT_MAX" -ge 30 ]; then ev_present jx-docs-drift git "$(loc "$DRIFT_LOC")" 4 "README/CHANGELOG untouched while >= 30 code commits landed" "git rev-list --count <doc-last-commit>..HEAD -- . ':!*.md' ':!docs'" "code commits since last touch:$DRIFT"
  else ev_absent jx-docs-drift git "" 4 "README/CHANGELOG touched recently relative to code commits" "git rev-list --count <doc-last-commit>..HEAD -- . ':!*.md' ':!docs'" "code commits since last touch:$DRIFT (threshold 30)"; fi
  # unsafe touched in window (committed diff lines adding/removing unsafe, plus uncommitted)
  # Window diffs are taken cumulatively (newest commit before the window .. HEAD, plus the uncommitted diff): one diff
  # instead of a per-commit pickaxe, which is O(minutes) on large windows. Commits are then attributed by file.
  WIN_BASE=$(tmo 60 git rev-list -n1 --before="$SINCE" HEAD 2>/dev/null || true); [ -z "$WIN_BASE" ] && WIN_BASE=4b825dc642cb6eb9a060e54bf8d69288fbee4904
  window_diff_grep() { # window_diff_grep AWK_REGEX PATHSPEC... -> "COUNT<TAB>FILES" over added/removed lines
    local pat="$1"; shift
    { tmo 60 git diff "$WIN_BASE" HEAD -- "$@" 2>/dev/null; tmo 60 git diff HEAD -- "$@" 2>/dev/null; } | WDG_PAT="$pat" awk '
      BEGIN { pat = ENVIRON["WDG_PAT"] }
      /^\+\+\+ b\// { f = substr($0, 7); next }
      /^[-+]/ && !/^(\+\+\+|---)/ { if ($0 ~ pat) { n++; if (!(f in seen)) { seen[f] = 1; files = files (files == "" ? "" : " ") f } } }
      END { printf "%d\t%s\n", n, files }'
  }
  UNS_RES=$(window_diff_grep '(^|[^A-Za-z0-9_])unsafe([^A-Za-z0-9_]|$)' '*.rs'); UNS_N=$(printf '%s' "$UNS_RES" | cut -f1); UNS_FILES=$(printf '%s' "$UNS_RES" | cut -f2 | tr ' ' '\n' | head -6 | tr '\n' ' ')
  UNS_SHAS=""; [ -n "$UNS_FILES" ] && UNS_SHAS=$(tmo 60 git log $WINDOW --format=%h HEAD -- $UNS_FILES 2>/dev/null | head -8 | tr '\n' ' ')
  UNS_CMD="git diff $WIN_BASE HEAD -- '*.rs' | grep -E '^[-+].*unsafe' (base = newest commit before $SINCE); git diff HEAD -- '*.rs'; $GITLOG --format=%h -- <files>"
  if [ "${UNS_N:-0}" -gt 0 ]; then ev_present jx-unsafe-touched git "$(printf '%s' "$UNS_SHAS" | cut -d' ' -f1)" 4 "recent commits or uncommitted changes touch unsafe code" "$UNS_CMD" "$UNS_N added/removed lines mention unsafe in: $UNS_FILES; window commits touching those files: ${UNS_SHAS:-none (uncommitted only)}"
  else ev_absent jx-unsafe-touched git "" 4 "no unsafe lines changed in window" "$UNS_CMD" "0 added/removed lines mention 'unsafe' since $SINCE (committed or uncommitted)"; fi
  # sprawl: branches / stale branches / worktrees / stashes
  tmo 60 git for-each-ref --format='%(refname:short)%09%(committerdate:iso-strict)' refs/heads/ > "$TMPD/branches" 2>/dev/null || : > "$TMPD/branches"
  N_BR=$(grep -c . "$TMPD/branches"); N_STALE=$(python3 -c '
import sys, datetime as d
stale = sys.argv[2].replace("Z", "+00:00"); cutoff = d.datetime.fromisoformat(stale)
n = []
for line in open(sys.argv[1]):
    parts = line.rstrip("\n").split("\t")
    if len(parts) < 2 or not parts[1]: continue
    try:
        if d.datetime.fromisoformat(parts[1]) < cutoff: n.append(parts[0])
    except Exception: pass
print(len(n)); print(" ".join(sorted(n)[:8]))' "$TMPD/branches" "$STALE" 2>/dev/null); STALE_NAMES=$(printf '%s\n' "$N_STALE" | sed -n 2p); N_STALE=$(printf '%s\n' "$N_STALE" | head -1); N_STALE=${N_STALE:-0}
  N_WT=$(tmo 60 git worktree list --porcelain 2>/dev/null | grep -c '^worktree '); N_WT=$(( N_WT > 0 ? N_WT - 1 : 0 ))
  N_STASH=$(tmo 60 git stash list 2>/dev/null | grep -c .)
  ev_fact "branches, worktrees, and stashes" git "$HEAD_FULL" "git for-each-ref refs/heads/; git worktree list --porcelain; git stash list" "$N_BR local branches ($N_STALE with no commits since $STALE: $STALE_NAMES); $N_WT extra worktrees; $N_STASH stashes"
  if [ "$N_STALE" -ge 10 ] || [ "$N_STASH" -ge 3 ] || [ "$N_WT" -ge 2 ]; then ev_present jx-repo-sprawl git "$HEAD_FULL" 4 "many stale branches, stashes, or worktrees" "git for-each-ref refs/heads/; git worktree list; git stash list" "stale branches $N_STALE (>=10) / stashes $N_STASH (>=3) / extra worktrees $N_WT (>=2)"
  else ev_absent jx-repo-sprawl git "" 4 "repo is not sprawling" "git for-each-ref refs/heads/; git worktree list; git stash list" "stale branches $N_STALE (<10), stashes $N_STASH (<3), extra worktrees $N_WT (<2)"; fi
  # uncommitted work
  DIFF_LINES=$(tmo 60 git diff HEAD --numstat -- "${SCOPES[@]}" 2>/dev/null | awk '{a+=($1=="-"?0:$1); d+=($2=="-"?0:$2)} END{print a+d+0}')
  UNTRACKED=$(tmo 60 git ls-files --others --exclude-standard -- "${SCOPES[@]}" 2>/dev/null | head -200 | python3 -c '
import sys
n = 0
for p in [l.rstrip("\n") for l in sys.stdin if l.strip()]:
    try: n += open(p, "rb").read().count(b"\n")
    except Exception: pass
print(n)')
  TOTAL_UNC=$(( ${DIFF_LINES:-0} + ${UNTRACKED:-0} ))
  ev_fact "uncommitted changes" git "$HEAD_FULL" "git diff HEAD --numstat; git ls-files --others --exclude-standard | wc -l" "$DIFF_LINES changed lines in tracked files + $UNTRACKED lines in untracked files (first 200 files) = $TOTAL_UNC; on branch ${BRANCH:-<detached>}"
  if [ "$TOTAL_UNC" -ge 200 ]; then ev_present jx-uncommitted-work git "$HEAD_FULL" 4 "substantial uncommitted changes (>= 200 lines)" "git diff HEAD --numstat; git ls-files --others --exclude-standard" "$TOTAL_UNC uncommitted lines"
  else ev_absent jx-uncommitted-work git "" 4 "working tree has fewer than 200 uncommitted lines" "git diff HEAD --numstat; git ls-files --others --exclude-standard" "$TOTAL_UNC uncommitted lines"; fi
  # dependency bump: vocabulary or lockfile commits in window
  LOCKC=$(tmo 60 git log $WINDOW --format=%h HEAD -- Cargo.lock package-lock.json pnpm-lock.yaml yarn.lock bun.lock bun.lockb poetry.lock uv.lock go.sum Gemfile.lock 2>/dev/null | head -8 | tr '\n' ' ')
  if [ "$(vc bump)" -ge 1 ] || [ -n "$LOCKC" ]; then ev_present jx-dependency-bump git "$(printf '%s %s' "$(vc bump_shas)" "$LOCKC" | tr ' ' '\n' | grep -v '^$' | head -1)" 3 "dependency upgrades in progress" "$GITLOG --format='%h %s' | grep -Ei bump|upgrade|dependabot; $GITLOG --format=%h -- <lockfiles>" "bump vocabulary: $(vc bump) [$(vc bump_shas)]; lockfile commits: ${LOCKC:-none}"
  else ev_absent jx-dependency-bump git "" 3 "no dependency upgrades in window" "$GITLOG --format='%h %s' | grep -Ei bump|upgrade|dependabot; $GITLOG --format=%h -- <lockfiles>" "0 bump commits and 0 lockfile commits since $SINCE"; fi
  # flaky tests: vocabulary or newly added ignore/skip markers in window
  IGN_RES=$(window_diff_grep '#\[ignore|\.skip\(|(^|[^A-Za-z0-9_])xit\(|@pytest\.mark\.skip|t\.Skip\(' "${SCOPES[@]}"); IGN_N=$(printf '%s' "$IGN_RES" | cut -f1); IGN_FILES=$(printf '%s' "$IGN_RES" | cut -f2 | tr ' ' '\n' | head -6 | tr '\n' ' ')
  IGN=""; [ -n "$IGN_FILES" ] && IGN=$(tmo 60 git log $WINDOW --format=%h HEAD -- $IGN_FILES 2>/dev/null | head -8 | tr '\n' ' ')
  [ "${IGN_N:-0}" -gt 0 ] && [ -z "$IGN" ] && IGN="(uncommitted) $IGN_FILES"
  FLAKY_SLEEP=$(rg_count 'thread::sleep\(|time\.sleep\(|tokio::time::sleep\(|\bsleep\([0-9]|setTimeout\(|retry|retries' 0 $TEST_INC '*.rs' '*.py' '*.go' '*.ts' '*.js')
  if [ "$(vc flaky)" -ge 1 ] || [ -n "$IGN" ]; then ev_present jx-flaky-tests git "$(printf '%s %s' "$(vc flaky_shas)" "$IGN" | tr ' ' '\n' | grep -v '^$' | head -1)" 3 "flaky-test vocabulary or new ignore/skip markers in window" "$GITLOG --format='%h %s' | grep -Ei flaky|intermittent; $GITLOG -G'#\\[ignore|\\.skip\\(' --format=%h" "flaky vocab: $(vc flaky) [$(vc flaky_shas)]; commits touching ignore/skip markers: ${IGN:-none}; sleep/retry in test paths: $(printf '%s' "$FLAKY_SLEEP" | cut -d' ' -f1) lines"
  else ev_absent jx-flaky-tests git "" 3 "no flaky-test vocabulary or new skip markers in window" "$GITLOG --format='%h %s' | grep -Ei flaky|intermittent; $GITLOG -G'#\\[ignore|\\.skip\\(' --format=%h" "0 flaky commits, 0 commits touching ignore/skip markers since $SINCE; sleep/retry in test paths: $(printf '%s' "$FLAKY_SLEEP" | cut -d' ' -f1) lines (support only)"; fi
  # upstream sync (fork behind its upstream remote)
  if git remote get-url upstream >/dev/null 2>&1; then
    UPREF=""; for r in upstream/HEAD upstream/main upstream/master upstream/trunk upstream/develop; do git rev-parse --verify -q "$r" >/dev/null 2>&1 && { UPREF="$r"; break; }; done
    if [ -n "$UPREF" ]; then
      BEHIND=$(tmo 60 git rev-list --count "HEAD..$UPREF" 2>/dev/null || echo "")
      if [ -z "$BEHIND" ]; then ev_unknown jx-upstream-sync-due git "upstream distance unknown" "git rev-list --count HEAD..$UPREF" "git rev-list failed"
      elif [ "$BEHIND" -ge 50 ]; then ev_present jx-upstream-sync-due git "$(git rev-parse "$UPREF" 2>/dev/null)" 4 "fork is >= 50 commits behind upstream" "git rev-list --count HEAD..$UPREF" "$BEHIND commits behind $UPREF (local refs; no fetch performed)"
      else ev_absent jx-upstream-sync-due git "" 4 "fork is fewer than 50 commits behind upstream" "git rev-list --count HEAD..$UPREF" "$BEHIND commits behind $UPREF (local refs; no fetch performed)"; fi
    else ev_unknown jx-upstream-sync-due git "upstream distance unknown" "git rev-parse --verify upstream/{HEAD,main,master}" "an 'upstream' remote exists but no upstream/* ref is fetched locally (run git fetch upstream)"; fi
  else ev_absent jx-upstream-sync-due git "" 3 "no 'upstream' remote, so no fork sync is due" "git remote get-url upstream" "remotes: $(git remote 2>/dev/null | tr '\n' ' ')"; fi
  # swarm active: several authors, agent co-author trailers, or many agent-mail/beads-touching commits in window
  SWARM=""; [ "$(vc authors)" -ge 2 ] && SWARM="$(vc authors) distinct authors"
  [ "$(vc agent_trailers)" -ge 5 ] && SWARM="${SWARM:+$SWARM; }$(vc agent_trailers) agent co-author trailers"
  if [ -f .agent-mail-project-id ] && [ "$N_WIN" -ge 20 ]; then SWARM="${SWARM:+$SWARM; }.agent-mail-project-id with $N_WIN window commits"; fi
  if [ -n "$SWARM" ]; then ev_present jx-swarm-active git "$HEAD_FULL" 2 "multiple agents/authors active in window" "$GITLOG --format='%an%n%b' | sort -u; grep -ci co-authored-by" "$SWARM"
  else ev_absent jx-swarm-active git "" 2 "no multi-agent activity signature in window" "$GITLOG --format='%an%n%b' | sort -u; grep -ci co-authored-by" "$(vc authors) author(s), $(vc agent_trailers) agent trailers, $N_WIN commits"; fi
elif [ "$GL_RC" = -1 ]; then
  for s in $GIT_SIGNALS; do git_unknown "$s" "$s undetermined: no git history" "git log $WINDOW"; done
  git_unknown "" "commit window facts unavailable" "git log $WINDOW"
else
  # git log itself failed or timed out in a repo that has commits: every git-derived signal is
  # unknown (never absent) — a failed command is not evidence of a quiet window.
  for s in $GIT_SIGNALS; do ev_unknown "$s" git "$s undetermined: git log failed" "$GITLOG --format='%h %s' HEAD" "git log exited $GL_RC: $(head -c 160 "$TMPD/gitlog.err" 2>/dev/null | tr '\n' ' ')"; done
  ev_unknown "" git "commit window facts unavailable" "$GITLOG --format='%h %s' HEAD" "git log exited $GL_RC"
fi

# ------------------------------------------------------------------ GitHub (gh, timeout 30, only with a GitHub remote)
GH_SIGNALS="jx-open-pr-backlog jx-open-issue-backlog jx-failing-ci jx-issues-triage-due"
REMOTE=""; $IS_GIT && REMOTE=$(git remote get-url origin 2>/dev/null || true)
if ! printf '%s' "$REMOTE" | grep -q 'github\.com'; then
  for s in $GH_SIGNALS; do ev_unknown "$s" gh "$s undetermined: no GitHub remote" "git remote get-url origin" "origin is ${REMOTE:+not a GitHub URL}${REMOTE:-unset}; gh not queried"; done
elif ! command -v gh >/dev/null 2>&1; then
  for s in $GH_SIGNALS; do ev_unknown "$s" gh "$s undetermined: gh not installed" "gh pr list / gh issue list / gh run list" "gh CLI missing; GitHub remote present"; done
else
  gh_json() { # gh_json OUTFILE args... -> rc; stderr captured to OUTFILE.err
    local out="$1"; shift; tmo 30 gh "$@" > "$out" 2> "$out.err"; return $?
  }
  gh_json "$TMPD/prs" pr list --state open --limit 100 --json number,createdAt,title; PR_RC=$?
  gh_json "$TMPD/issues" issue list --state open --limit 100 --json number,createdAt,comments,title; IS_RC=$?
  gh_json "$TMPD/runs" run list --limit 20 --json status,conclusion,createdAt,name; RUN_RC=$?
  python3 - "$TMPD" "$NOW" "$PR_RC" "$IS_RC" "$RUN_RC" <<'PY' > "$TMPD/gh.kv"
import sys, json, os, datetime as d
tmpd, now, pr_rc, is_rc, run_rc = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5])
nowd = d.datetime.fromisoformat(now.replace('Z', '+00:00'))
def load(name, rc):
    if rc != 0: return None, 'exit %d: %s' % (rc, open(os.path.join(tmpd, name + '.err'), errors='replace').read().strip()[:200])
    try: return json.load(open(os.path.join(tmpd, name))), ''
    except Exception as e: return None, 'unparseable JSON: %s' % e
def age(s):
    try: return (nowd - d.datetime.fromisoformat(s.replace('Z', '+00:00'))).days
    except Exception: return 0
out = {}
prs, err = load('prs', pr_rc)
if prs is None: out['pr_err'] = err
else:
    old = sorted((p for p in prs if age(p.get('createdAt', '')) > 14), key=lambda p: p['number'])
    out['pr_open'] = len(prs); out['pr_old'] = len(old); out['pr_old_ids'] = ' '.join('#%d' % p['number'] for p in old[:8])
    out['pr_ids'] = ' '.join('#%d' % p['number'] for p in sorted(prs, key=lambda p: p['number'])[:8])
iss, err = load('issues', is_rc)
if iss is None: out['is_err'] = err
else:
    silent = sorted((i for i in iss if not i.get('comments') and age(i.get('createdAt', '')) > 14), key=lambda i: i['number'])
    out['is_open'] = len(iss); out['is_silent'] = len(silent); out['is_silent_ids'] = ' '.join('#%d' % i['number'] for i in silent[:8])
    out['is_ids'] = ' '.join('#%d' % i['number'] for i in sorted(iss, key=lambda i: i['number'])[:8])
runs, err = load('runs', run_rc)
if runs is None: out['run_err'] = err
else:
    done = [r for r in runs if r.get('status') == 'completed'][:10]
    failed = [r for r in done if r.get('conclusion') == 'failure']
    out['run_done'] = len(done); out['run_failed'] = len(failed); out['run_names'] = '; '.join(sorted(set('%s:%s' % (r.get('name', '?'), r.get('conclusion')) for r in failed))[:5])
for k, v in sorted(out.items()): print('%s\t%s' % (k, v))
PY
  G="$TMPD/gh.kv"; gv() { kv "$1" "$G"; }
  if [ -n "$(gv pr_err)" ]; then ev_unknown jx-open-pr-backlog gh "open PR backlog unknown" "timeout 30 gh pr list --state open --json number,createdAt" "$(gv pr_err)"
  else
    ev_fact "open pull requests" gh "" "timeout 30 gh pr list --state open --limit 100 --json number,createdAt" "$(gv pr_open) open; older than 14 days: $(gv pr_old) [$(gv pr_old_ids)]"
    if [ "$(gv pr_open)" -ge 3 ] || [ "$(gv pr_old)" -ge 1 ]; then ev_present jx-open-pr-backlog gh "$(gv pr_old_ids | cut -d' ' -f1)" 4 "open PR backlog (>= 3 open or any older than 14 days)" "timeout 30 gh pr list --state open --json number,createdAt" "$(gv pr_open) open [$(gv pr_ids)]; $(gv pr_old) older than 14 days [$(gv pr_old_ids)]"
    else ev_absent jx-open-pr-backlog gh "" 4 "no open PR backlog" "timeout 30 gh pr list --state open --json number,createdAt" "$(gv pr_open) open PRs, none older than 14 days"; fi
  fi
  if [ -n "$(gv is_err)" ]; then ev_unknown jx-open-issue-backlog gh "open issue backlog unknown" "timeout 30 gh issue list --state open --json number,createdAt,comments" "$(gv is_err)"
  else
    ev_fact "open issues" gh "" "timeout 30 gh issue list --state open --limit 100 --json number,createdAt,comments" "$(gv is_open) open; uncommented and older than 14 days: $(gv is_silent) [$(gv is_silent_ids)]"
    if [ "$(gv is_open)" -ge 5 ] || [ "$(gv is_silent)" -ge 1 ]; then ev_present jx-open-issue-backlog gh "$(gv is_silent_ids | cut -d' ' -f1)" 4 "open issue backlog (>= 5 open or unanswered > 14 days)" "timeout 30 gh issue list --state open --json number,createdAt,comments" "$(gv is_open) open [$(gv is_ids)]; $(gv is_silent) unanswered > 14 days [$(gv is_silent_ids)]"
    else ev_absent jx-open-issue-backlog gh "" 4 "no open issue backlog" "timeout 30 gh issue list --state open --json number,createdAt,comments" "$(gv is_open) open issues, none unanswered for 14 days"; fi
  fi
  if [ -n "$(gv run_err)" ]; then ev_unknown jx-failing-ci gh "CI run status unknown" "timeout 30 gh run list --limit 20 --json status,conclusion,createdAt" "$(gv run_err)"
  elif [ "$(gv run_failed)" -ge 3 ]; then ev_present jx-failing-ci gh "" 4 "red CI streak (>= 3 of the last 10 completed runs failed)" "timeout 30 gh run list --limit 20 --json status,conclusion,createdAt" "$(gv run_failed) of $(gv run_done) completed runs failed: $(gv run_names)"
  else ev_absent jx-failing-ci gh "" 4 "CI is not in a failing streak" "timeout 30 gh run list --limit 20 --json status,conclusion,createdAt" "$(gv run_failed) of $(gv run_done) completed runs failed (threshold 3)"; fi
  PR_OLD=$(gv pr_old); IS_SILENT=$(gv is_silent); TRIAGE=$(( ${PR_OLD:-0} + ${IS_SILENT:-0} ))
  if [ -n "$(gv pr_err)" ] && [ -n "$(gv is_err)" ]; then ev_unknown jx-issues-triage-due gh "triage state unknown" "gh pr list; gh issue list" "$(gv pr_err); $(gv is_err)"
  elif [ "$TRIAGE" -ge 1 ]; then ev_present jx-issues-triage-due gh "$(printf '%s %s' "$(gv is_silent_ids)" "$(gv pr_old_ids)" | tr ' ' '\n' | grep -v '^$' | head -1)" 3 "open issues/PRs on this repo need triage (unanswered > 14 days)" "gh pr list; gh issue list" "stale PRs: ${PR_OLD:-0} [$(gv pr_old_ids)]; unanswered issues: ${IS_SILENT:-0} [$(gv is_silent_ids)] (this repo only; cross-repo triage is not queried)"
  else ev_absent jx-issues-triage-due gh "" 3 "no stale issues/PRs on this repo" "gh pr list; gh issue list" "stale PRs: ${PR_OLD:-0}; unanswered issues: ${IS_SILENT:-0} (this repo only; cross-repo triage is not queried)"; fi
fi

# ------------------------------------------------------------------ beads (br/bv, read-only flags)
BEADS_SIGNALS="jx-beads-blocked jx-beads-many-open jx-beads-queue-dry jx-beads-stale-epics jx-beads-corrupt"
PLAN=$( (set +f; ls -- PLAN*.md ./*_PLAN.md ./*-plan.md ROADMAP* docs/plan*.md docs/PLAN*.md plans/*.md 2>/dev/null) | sed 's#^\./##' | LC_ALL=C sort | head -1)
BR_FLAGS="--no-auto-flush --no-auto-import"
if [ ! -d .beads ]; then
  for s in $BEADS_SIGNALS; do ev_absent "$s" beads "" 4 "$s not applicable: no .beads/" "ls -d .beads" "no .beads directory at the target root"; done
  if [ -n "$PLAN" ]; then ev_present jx-plan-no-beads beads "$(loc "$PLAN")" 4 "plan file exists but there is no .beads/" "ls PLAN*.md ROADMAP* docs/plan*; ls -d .beads" "plan: $PLAN; .beads: missing"
  else ev_absent jx-plan-no-beads beads "" 4 "no plan file and no beads" "ls PLAN*.md ROADMAP* docs/plan*; ls -d .beads" "no plan/roadmap file at root or docs/"; fi
elif ! command -v br >/dev/null 2>&1; then
  for s in $BEADS_SIGNALS jx-plan-no-beads; do ev_unknown "$s" beads "$s undetermined: br not installed" "br $BR_FLAGS list --status open --json" ".beads/ exists but the br CLI is missing"; done
else
  brj() { # brj OUTFILE args... ; JSON on stdout only when rc=0 and parseable
    local out="$1"; shift; tmo 30 br $BR_FLAGS "$@" > "$out" 2> "$out.err"; return $?
  }
  brj "$TMPD/b_open" list --status open --json; O_RC=$?
  brj "$TMPD/b_closed" list --status closed --json; C_RC=$?
  brj "$TMPD/b_ready" ready --json; R_RC=$?
  brj "$TMPD/b_blocked" blocked --json; B_RC=$?
  brj "$TMPD/b_doctor" doctor --json; D_RC=$?
  BV_T_RC=1; BV_I_RC=1
  if command -v bv >/dev/null 2>&1; then
    tmo 30 bv --robot-triage --no-cache > "$TMPD/bv_triage" 2> "$TMPD/bv_triage.err"; BV_T_RC=$?
    if is_timeout "$BV_T_RC"; then BV_I_RC=124; : > "$TMPD/bv_insights"; printf 'skipped: bv --robot-triage timed out after 30s' > "$TMPD/bv_insights.err"
    else tmo 30 bv --robot-insights --no-cache > "$TMPD/bv_insights" 2> "$TMPD/bv_insights.err"; BV_I_RC=$?; fi
  fi
  python3 - "$TMPD" "$O_RC" "$C_RC" "$R_RC" "$B_RC" "$D_RC" "$BV_T_RC" "$BV_I_RC" <<'PY' > "$TMPD/beads.kv"
import sys, json, os, glob, re
tmpd = sys.argv[1]; rcs = dict(zip(('open', 'closed', 'ready', 'blocked', 'doctor', 'triage', 'insights'), [int(x) for x in sys.argv[2:9]]))
files = {'open': 'b_open', 'closed': 'b_closed', 'ready': 'b_ready', 'blocked': 'b_blocked', 'doctor': 'b_doctor', 'triage': 'bv_triage', 'insights': 'bv_insights'}
def load(key):
    """Parse stdout as JSON whatever the exit code (br doctor exits non-zero with a JSON report); otherwise
    describe the failure by the JSON error codes/messages br prints, the timeout, or the raw stderr."""
    p = os.path.join(tmpd, files[key])
    err = open(p + '.err', errors='replace').read().strip() if os.path.exists(p + '.err') else ''
    txt = open(p, encoding='utf-8', errors='replace').read() if os.path.exists(p) else ''
    obj = None
    try:
        obj = json.loads(txt)
    except Exception:
        pass
    if isinstance(obj, dict) and 'error' in obj and not any(k in obj for k in ('issues', 'items', 'data', 'checks', 'triage', 'ok')):
        e = obj['error'] if isinstance(obj['error'], dict) else {'message': str(obj['error'])}
        return None, 'exit %d: %s - %s' % (rcs[key], e.get('code', 'error'), str(e.get('message', ''))[:160])
    if obj is not None: return obj, ''
    if key in ('triage', 'insights') and rcs[key] == 1 and not txt and not err: return None, 'bv not installed'
    if rcs[key] in (124, 142): return None, 'timed out after 30s'
    codes = re.findall(r'"code"\s*:\s*"([A-Za-z_]+)"', txt + err)
    msgs = re.findall(r'"message"\s*:\s*"([^"]{0,160})"', txt + err)
    return None, 'exit %d%s%s' % (rcs[key], (': ' + ', '.join(codes)) if codes else '', (' - ' + msgs[-1]) if msgs else ((': ' + err[:160]) if err else ''))
def rows(d):
    if isinstance(d, list): return d
    if isinstance(d, dict): return d.get('issues') or d.get('items') or d.get('data') or []
    return []
out = {}
src = 'br'
o, oe = load('open'); c, ce = load('closed')
allrows = None
if o is None or c is None:
    # fall back to the JSONL export (read-only) so the state is still derivable
    jl = sorted(glob.glob('.beads/*.jsonl'))
    jl = [p for p in jl if not p.endswith('.base.jsonl')] or jl
    if jl:
        try:
            allrows = [json.loads(l) for l in open(jl[0], encoding='utf-8', errors='replace') if l.strip()]
            src = 'jsonl:' + jl[0]
        except Exception as e:
            out['corrupt_jsonl'] = '%s: %s' % (jl[0], str(e)[:120])
    out['br_err'] = (oe or ce)[:220]
else:
    allrows = rows(o) + rows(c)
if allrows is None:
    out['fatal'] = 'br failed and no readable JSONL: %s' % out.get('br_err', '')
else:
    op = [r for r in allrows if r.get('status') not in ('closed', 'tombstone')]
    cl = [r for r in allrows if r.get('status') == 'closed']
    out['src'] = src; out['open'] = len(op); out['closed'] = len(cl)
    out['in_progress'] = sum(1 for r in op if r.get('status') == 'in_progress')
    ts = [r.get('updated_at') or r.get('updated') or '' for r in allrows]; ts = [t for t in ts if t]
    out['watermark'] = (max(ts) if ts else '') + '/' + str(len(allrows))
    # stale epics: open epics whose parent-child children are all closed (from dependencies on the children)
    status = {r.get('id'): r.get('status') for r in allrows}
    children = {}
    for r in allrows:
        for dep in (r.get('dependencies') or []):
            if isinstance(dep, dict) and dep.get('type') == 'parent-child' and dep.get('depends_on_id'):
                children.setdefault(dep['depends_on_id'], []).append(r.get('id'))
    epics = [r for r in op if r.get('issue_type') == 'epic' or r.get('type') == 'epic']
    has_dep_field = any('dependencies' in r for r in allrows)
    if not has_dep_field and epics and src == 'br':
        out['epic_shape'] = 'br list JSON carries no dependencies field; children not derivable'
    stale = sorted(e['id'] for e in epics if children.get(e['id']) and all(status.get(k) == 'closed' for k in children[e['id']]))
    childless = sorted(e['id'] for e in epics if not children.get(e['id']))
    out['epics_open'] = len(epics); out['epics_stale'] = len(stale); out['epics_stale_ids'] = ' '.join(stale[:8]); out['epics_childless'] = len(childless)
    r, re_ = load('ready')
    if r is None: out['ready_err'] = re_
    else: out['ready'] = len(rows(r))
    b, be = load('blocked')
    if b is None: out['blocked_err'] = be
    else:
        br_rows = rows(b); out['blocked'] = len(br_rows); out['blocked_ids'] = ' '.join(sorted(str(x.get('id')) for x in br_rows if isinstance(x, dict))[:8])
    t, te = load('triage')
    if t is None: out['triage_err'] = te
    else:
        tr = t.get('triage') if isinstance(t.get('triage'), dict) else t
        qr = tr.get('quick_ref') or {}; bl = tr.get('blockers_to_clear') or []
        out['triage_quick_ref'] = json.dumps({k: qr.get(k) for k in ('open_count', 'actionable_count', 'blocked_count', 'in_progress_count') if k in qr}, sort_keys=True)
        out['triage_blockers'] = len(bl); out['triage_blocker_ids'] = ' '.join(sorted(str(x.get('id', x)) for x in bl)[:8]) if isinstance(bl, list) else ''
    i, ie = load('insights')
    if i is None: out['insights_err'] = ie
    else:
        cy = i.get('Cycles') or i.get('cycles') or []
        out['cycles'] = len(cy) if isinstance(cy, list) else 0
d, de = load('doctor')
if d is None: out['doctor_err'] = de
else:
    bad = []
    for ch in (d.get('checks') or []):
        if isinstance(ch, dict) and ch.get('status') not in ('ok', 'pass', 'skipped', None): bad.append('%s=%s' % (ch.get('name'), ch.get('status')))
    out['doctor_ok'] = '1' if d.get('ok') is not False and not bad else '0'
    out['doctor_bad'] = '; '.join(bad[:6])
    out['doctor_health'] = str(d.get('workspace_health', ''))
for k, v in sorted(out.items()): print('%s\t%s' % (k, v))
PY
  B="$TMPD/beads.kv"; bvv() { kv "$1" "$B"; }
  BR_CMD="br $BR_FLAGS list --status open --json; br $BR_FLAGS list --status closed --json"
  if [ -n "$(bvv fatal)" ]; then
    for s in jx-beads-blocked jx-beads-many-open jx-beads-queue-dry jx-beads-stale-epics; do ev_unknown "$s" beads "$s undetermined: br failed" "$BR_CMD" "$(bvv fatal)"; done
    ev_unknown jx-plan-no-beads beads "plan-vs-beads undetermined" "$BR_CMD" "$(bvv fatal)"
  else
    SRC_NOTE=""; [ -n "$(bvv br_err)" ] && SRC_NOTE=" (br failed: $(bvv br_err); fell back to $(bvv src))"
    BCONF=4; [ -n "$(bvv br_err)" ] && BCONF=2
    ev_fact "beads watermark (max updated_at / issue count)" beads "" "$BR_CMD" "$(bvv watermark); open $(bvv open) (in_progress $(bvv in_progress)), closed $(bvv closed); source $(bvv src)$SRC_NOTE"
    if [ "$(bvv open)" -ge 20 ]; then ev_present jx-beads-many-open beads "" "$BCONF" ">= 20 open beads" "$BR_CMD" "$(bvv open) open beads$SRC_NOTE"
    else ev_absent jx-beads-many-open beads "" "$BCONF" "fewer than 20 open beads" "$BR_CMD" "$(bvv open) open beads$SRC_NOTE"; fi
    BLOCKED_N=$(bvv blocked); TB=$(bvv triage_blockers); CY=$(bvv cycles)
    if [ -n "$(bvv blocked_err)" ] && [ -z "$TB" ] && [ -z "$CY" ]; then ev_unknown jx-beads-blocked beads "blocked beads unknown" "br $BR_FLAGS blocked --json; bv --robot-triage --no-cache" "br blocked: $(bvv blocked_err); bv triage: $(bvv triage_err); bv insights: $(bvv insights_err)"
    elif [ "${BLOCKED_N:-0}" -gt 0 ] || [ "${TB:-0}" -gt 0 ] || [ "${CY:-0}" -gt 0 ]; then ev_present jx-beads-blocked beads "$(printf '%s %s' "$(bvv blocked_ids)" "$(bvv triage_blocker_ids)" | tr ' ' '\n' | grep -v '^$' | head -1)" 4 "blocked beads or dependency cycles" "br $BR_FLAGS blocked --json; bv --robot-triage --no-cache | jq .blockers_to_clear; bv --robot-insights | jq .Cycles" "br blocked: ${BLOCKED_N:-?} [$(bvv blocked_ids)]; bv blockers_to_clear: ${TB:-?} [$(bvv triage_blocker_ids)]; cycles: ${CY:-?}"
    else ev_absent jx-beads-blocked beads "" 4 "no blocked beads or cycles" "br $BR_FLAGS blocked --json; bv --robot-triage --no-cache | jq .blockers_to_clear; bv --robot-insights | jq .Cycles" "br blocked: ${BLOCKED_N:-?}; bv blockers_to_clear: ${TB:-n/a ($(bvv triage_err))}; cycles: ${CY:-n/a}"; fi
    if [ -n "$(bvv ready_err)" ]; then ev_unknown jx-beads-queue-dry beads "ready queue unknown" "br $BR_FLAGS ready --json" "$(bvv ready_err)"
    elif [ "$(bvv ready)" = 0 ] && [ "$(bvv open)" -gt 0 ]; then ev_present jx-beads-queue-dry beads "" 4 "no ready beads while work remains open" "br $BR_FLAGS ready --json" "0 ready, $(bvv open) open (in_progress $(bvv in_progress))"
    else ev_absent jx-beads-queue-dry beads "" 4 "ready queue is not dry" "br $BR_FLAGS ready --json" "$(bvv ready) ready, $(bvv open) open"; fi
    if [ -n "$(bvv epic_shape)" ]; then ev_unknown jx-beads-stale-epics beads "stale epics undetermined" "$BR_CMD | python3 (parent-child dependencies)" "$(bvv epic_shape); $(bvv epics_open) open epics"
    elif [ "$(bvv epics_stale)" -gt 0 ]; then ev_present jx-beads-stale-epics beads "$(bvv epics_stale_ids | cut -d' ' -f1)" "$BCONF" "open epics whose children are all closed" "$BR_CMD | python3 (parent-child dependencies)" "$(bvv epics_stale) of $(bvv epics_open) open epics: $(bvv epics_stale_ids)$SRC_NOTE"
    else ev_absent jx-beads-stale-epics beads "" "$BCONF" "no open epic has all children closed" "$BR_CMD | python3 (parent-child dependencies)" "$(bvv epics_open) open epics ($(bvv epics_childless) without children)$SRC_NOTE"; fi
    if [ -n "$PLAN" ] && [ "$(( $(bvv open) + $(bvv closed) ))" = 0 ]; then ev_present jx-plan-no-beads beads "$(loc "$PLAN")" 4 "plan file exists but beads are empty" "ls PLAN*.md ROADMAP* docs/plan*; $BR_CMD" "plan: $PLAN; 0 issues"
    else ev_absent jx-plan-no-beads beads "" 4 "plan and beads are consistent" "ls PLAN*.md ROADMAP* docs/plan*; $BR_CMD" "plan: ${PLAN:-none}; issues: $(( $(bvv open) + $(bvv closed) ))"; fi
  fi
  if [ -n "$(bvv doctor_err)" ] && [ -z "$(bvv corrupt_jsonl)" ] && [ -z "$(bvv br_err)" ]; then ev_unknown jx-beads-corrupt beads "beads integrity unknown" "br $BR_FLAGS doctor --json" "$(bvv doctor_err)"
  elif [ -n "$(bvv corrupt_jsonl)" ] || [ "$(bvv doctor_ok)" = 0 ] || printf '%s' "$(bvv br_err)" | grep -qE 'SCHEMA_MISMATCH|corrupt|malformed|drift'; then ev_present jx-beads-corrupt beads "$(loc .beads)" 3 "br doctor / br list report corruption, drift, or schema mismatch" "br $BR_FLAGS doctor --json; $BR_CMD" "doctor ok=$(bvv doctor_ok) health=$(bvv doctor_health) findings: $(bvv doctor_bad); br error: $(bvv br_err | cut -c1-160); jsonl: $(bvv corrupt_jsonl)"
  else ev_absent jx-beads-corrupt beads "$(loc .beads)" 4 "beads store is healthy" "br $BR_FLAGS doctor --json" "doctor ok=$(bvv doctor_ok) health=$(bvv doctor_health)"; fi
fi

# ------------------------------------------------------------------ code smells (rg over non-generated source)
# non-test code LOC for densities: git ls-files (else find) filtered by the same exclusions, counted in one python pass
if $IS_GIT; then tmo 60 git ls-files -z --cached --others --exclude-standard -- "${SCOPES[@]}" > "$TMPD/all0" 2>/dev/null; LOC_RC=$?
else tmo 60 find "${SCOPES[@]}" -type f -not -path '*/.git/*' -not -path '*/node_modules/*' -not -path '*/target/*' -not -path '*/vendor/*' -not -path '*/dist/*' -not -path '*/build/*' -print0 > "$TMPD/all0" 2>/dev/null; LOC_RC=$?; fi
python3 - "$TMPD" <<'PY' > "$TMPD/loc.kv"
import sys, os, re
tmpd = sys.argv[1]
raw = open(os.path.join(tmpd, 'all0'), 'rb').read().split(b'\0')
paths = sorted(set(p.decode('utf-8', 'surrogateescape') for p in raw if p))
paths = [p[2:] if p.startswith('./') else p for p in paths]
EXCL = re.compile(r'(^|/)(target|node_modules|vendor|dist|build|\.git|third_party|upstream|legacy[^/]*|\.next|__pycache__|\.venv|venv|coverage|\.beads|\.doctor)/|\.generated\.|\.min\.(js|css)$|\.pb\.go$|_pb2\.py$')
TEST = re.compile(r'(^|/)(tests?|specs?|__tests__|e2e|benches|bench|fuzz|testdata|fixtures|__snapshots__)/|(^|/)(test_[^/]*\.py|[^/]*_test\.[a-z]+|[^/]*\.(test|spec)\.[cm]?[jt]sx?|[^/]*_tests?\.rs|tests?\.rs)$')
CODE = set('rs py ts tsx js jsx mjs cjs go c cc cpp cxx h hpp hh zig swift kt kts java rb sh bash zsh cu cuh metal wgsl cl cs ex exs lua dart vue svelte astro php scala hs ml'.split())
code = rust = test = files = 0
for p in paths:
    if EXCL.search(p): continue
    ext = p.rsplit('.', 1)[-1].lower() if '.' in p.rsplit('/', 1)[-1] else ''
    if ext not in CODE: continue
    if len(paths) > 20000: continue
    try: n = open(p, 'rb').read().count(b'\n')
    except Exception: continue
    files += 1
    if TEST.search(p): test += n
    else:
        code += n
        if ext == 'rs': rust += n
print('files\t%d' % files); print('code_loc\t%d' % code); print('rust_loc\t%d' % rust); print('test_loc\t%d' % test); print('capped\t%s' % ('1' if len(paths) > 20000 else '0'))
PY
L="$TMPD/loc.kv"; CODE_LOC=$(kv code_loc "$L"); RUST_LOC=$(kv rust_loc "$L"); CAPPED=$(kv capped "$L")
per_kloc() { python3 -c 'import sys; n=int(sys.argv[1]); loc=int(sys.argv[2]); print("%.1f" % (n*1000.0/loc) if loc else "n/a")' "$1" "$2"; }
ge() { python3 -c 'import sys; a=sys.argv[1]; sys.exit(0 if a!="n/a" and float(a)>=float(sys.argv[2]) else 1)' "$1" "$2"; }
ev_fact "non-test code LOC for smell densities" file "" "git ls-files | python3 (count newlines; generated/vendored and test paths excluded)" "$CODE_LOC non-test code LOC ($RUST_LOC Rust) in $(kv files "$L") code files; test LOC $(kv test_loc "$L")${CAPPED:+; capped: $CAPPED}"
# density_signal SIGNAL NONTEST THRESHOLD_PER_KLOC LOC "NOUN" "PATTERN" [globs...]
density_signal() {
  local sig="$1" nontest="$2" thr="$3" loc_base="$4" noun="$5" pat="$6"; shift 6
  local res n files first dens
  res=$(rg_count "$pat" "$nontest" "$@"); local rc=$RG_RC
  n=${res%% *}; files=$(printf '%s' "$res" | cut -d' ' -f2); first=$(printf '%s' "$res" | cut -d' ' -f3-)
  if is_timeout "$rc" || [ "$rc" = 2 ]; then ev_unknown "$sig" file "$noun density unknown" "$RG_CMD" "rg exit $rc: $(head -c 200 "$TMPD/rg.err")"; return; fi
  if [ "$CAPPED" = 1 ] || [ "$loc_base" = 0 ]; then ev_unknown "$sig" file "$noun density unknown (no LOC base)" "$RG_CMD" "$n matches but LOC not counted (capped or zero)"; return; fi
  dens=$(per_kloc "$n" "$loc_base")
  if ge "$dens" "$thr"; then ev_present "$sig" file "$(loc_of_match "$first")" 3 "$noun density high (>= $thr per kLOC)" "$RG_CMD" "$n matches in $files files = $dens per kLOC over $loc_base LOC; e.g. $(printf '%s' "$first" | cut -d: -f1,2): $(snippet "$first")"
  else ev_absent "$sig" file "" 3 "$noun density below $thr per kLOC" "$RG_CMD" "$n matches in $files files = $dens per kLOC over $loc_base LOC"; fi
}
density_signal jx-todo-density-high 0 5 "$CODE_LOC" "TODO/FIXME/HACK/XXX" '\b(TODO|FIXME|HACK|XXX)\b' $CODE_GLOBS
if [ "$RUST_LOC" -gt 0 ]; then density_signal jx-unwrap-density-high 1 8 "$RUST_LOC" "unwrap()/expect() in non-test Rust" '\.unwrap\(\)|\.expect\(' '*.rs'
elif [ "$CAPPED" = 1 ] || { [ "${LOC_RC:-0}" != 0 ] && [ "$CODE_LOC" = 0 ]; }; then ev_unknown jx-unwrap-density-high file "unwrap density unknown (no LOC base)" "rg '\.unwrap\(\)|\.expect\(' -g '*.rs'" "Rust LOC not counted (file list capped at 20000 or inventory command failed)"
else ev_absent jx-unwrap-density-high file "" 3 "no Rust code, so no unwrap density" "rg '\.unwrap\(\)|\.expect\(' -g '*.rs'" "0 non-test Rust LOC"; fi
IGN_RES=$(rg_count '#\[ignore(\]|[[:space:]]*=)|@pytest\.mark\.skip|@unittest\.skip|\.skip\(|\bxit\(|\bxdescribe\(|\bt\.Skip\(' 0 '*.rs' '*.py' '*.go' '*.ts' '*.tsx' '*.js'); IGN_RC=$RG_RC
ev_fact "ignored/skipped test markers" file "" "$RG_CMD" "$( is_timeout "$IGN_RC" || [ "$IGN_RC" = 2 ] && printf 'scan failed (exit %s)' "$IGN_RC" || printf '%s markers in %s files' "${IGN_RES%% *}" "$(printf '%s' "$IGN_RES" | cut -d' ' -f2)")"
DEAD=$(rg_count 'allow\((dead_code|unused)|#!\[allow\(unused' 1 '*.rs'); DEAD_RC=$RG_RC; DEAD_CMD="$RG_CMD"; DEAD_N=${DEAD%% *}
COMM=$(rg_count '^[[:space:]]*//[[:space:]]*(let|fn|if|for|while|return|use|impl|struct|pub|match|const|println!|self\.)\b|^[[:space:]]*#[[:space:]]*(def|class|return|import|if|for|print\()\b|^[[:space:]]*//[[:space:]]*(const|let|var|function|return|import|export)\b' 1 $CODE_GLOBS); COMM_RC=$RG_RC; COMM_N=${COMM%% *}
DEAD_GROW=""
if $IS_GIT && [ -n "$HEAD_FULL" ]; then
  DG_FILES=$(window_diff_grep 'allow\((dead_code|unused)' '*.rs' | cut -f2 | tr ' ' '\n' | head -6 | tr '\n' ' ')
  [ -n "$DG_FILES" ] && DEAD_GROW=$(tmo 60 git log $WINDOW --format=%h HEAD -- $DG_FILES 2>/dev/null | head -5 | tr '\n' ' ')
  [ -n "$DG_FILES" ] && [ -z "$DEAD_GROW" ] && DEAD_GROW="(uncommitted) $DG_FILES"
fi
if is_timeout "$DEAD_RC" || [ "$DEAD_RC" = 2 ] || is_timeout "$COMM_RC" || [ "$COMM_RC" = 2 ]; then ev_unknown jx-dead-code-sprawl file "dead-code scan failed" "$DEAD_CMD" "rg exit $DEAD_RC/$COMM_RC"
elif [ "${DEAD_N:-0}" -ge 5 ] || [ "${COMM_N:-0}" -ge 50 ] || { [ "${DEAD_N:-0}" -ge 1 ] && [ -n "$DEAD_GROW" ]; }; then ev_present jx-dead-code-sprawl file "$(loc_of_match "$(printf '%s' "$DEAD" | cut -d' ' -f3-)")" 3 "allow(dead_code)/commented-out code sprawl" "$DEAD_CMD; rg '^\s*//\s*(let|fn|if|...)'; $GITLOG -G'allow\\(dead_code' --format=%h" "allow(dead_code|unused): $DEAD_N; commented-out code lines: $COMM_N; window commits touching allow(dead_code): ${DEAD_GROW:-none}"
else ev_absent jx-dead-code-sprawl file "" 3 "no dead-code sprawl" "$DEAD_CMD; rg '^\s*//\s*(let|fn|if|...)'; $GITLOG -G'allow\\(dead_code' --format=%h" "allow(dead_code|unused): ${DEAD_N:-0} (<5); commented-out code lines: ${COMM_N:-0} (<50); window commits touching allow(dead_code): ${DEAD_GROW:-none}"; fi
MOCK=$(rg_count 'todo!\(|unimplemented!\(|panic!\("not (yet )?implemented|NotImplementedError|raise NotImplemented|throw new Error\(["'"'"'](not implemented|TODO|unimplemented)|TODO: implement|(//|#)[[:space:]]*(stub|placeholder)( implementation| impl)?[[:space:]]*$|placeholder (implementation|impl)\b|return (Ok\(\(\)\)|null|None|\{\})[[:space:]]*;?[[:space:]]*(//|#)[[:space:]]*(TODO|stub|placeholder)' 1 $CODE_GLOBS); MOCK_RC=$RG_RC; MOCK_N=${MOCK%% *}
if is_timeout "$MOCK_RC" || [ "$MOCK_RC" = 2 ]; then ev_unknown jx-mock-suspicion file "stub/placeholder scan failed" "$RG_CMD" "rg exit $MOCK_RC"
elif [ "${MOCK_N:-0}" -ge 3 ]; then ev_present jx-mock-suspicion file "$(loc_of_match "$(printf '%s' "$MOCK" | cut -d' ' -f3-)")" 2 "stubs/placeholders/todo!() in non-test code" "$RG_CMD" "$MOCK_N matches in $(printf '%s' "$MOCK" | cut -d' ' -f2) files; e.g. $(printf '%s' "$MOCK" | cut -d' ' -f3- | cut -d: -f1,2): $(snippet "$(printf '%s' "$MOCK" | cut -d' ' -f3-)")"
else ev_absent jx-mock-suspicion file "" 2 "few or no stubs/placeholders in non-test code" "$RG_CMD" "${MOCK_N:-0} matches (threshold 3)"; fi

# ------------------------------------------------------------------ finalize
python3 - "$TMPD/records" "$KIND" "$ID_PREFIX" "$NOW" "$REPO_HEAD" "$TMPD/out.json" <<'PY'
import sys, json, re
recs_path, kind, prefix, now, head, out_path = sys.argv[1:7]
SECRET = re.compile(r'((sk|pk|rk)_(live|test)_[A-Za-z0-9]{8,}|ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|AKIA[0-9A-Z]{16}|xox[baprs]-[A-Za-z0-9-]{10,}|-----BEGIN [A-Z ]*PRIVATE KEY-----|eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,})')
records, n = [], 0
for line in open(recs_path, encoding='utf-8', errors='replace'):
    line = line.rstrip('\n')
    if not line: continue
    f = line.split('\x1f')
    if len(f) < 9: f += [''] * (9 - len(f))
    if len(f) > 9: f = f[:8] + ['\x1f'.join(f[8:])]
    state, polarity, src, locator, conf, signals, claim, command, detail = f
    n += 1
    eid = 'ev-%s%04d' % (prefix, n)
    if state == 'present' and not locator:
        locator = 'juncture-signals.sh:' + eid
    if state == 'absent-with-positive-evidence' and not command:
        command = 'juncture-signals.sh positive-absence detector for ' + (signals or 'narrative fact')
    if state == 'unknown' and not detail:
        detail = claim
    records.append({
        'id': eid, 'claim': claim if len(claim) >= 3 else (claim + ' (n/a)'), 'kind': kind, 'polarity': polarity, 'state': state,
        'source_type': src, 'locator': locator or None, 'observed_at': now, 'command': command or None, 'repo_head': head or None,
        'origin_host': None, 'confidence': int(conf or 0), 'signals': [s for s in signals.split(',') if s],
        'detail': SECRET.sub('<redacted>', detail)[:1200] if detail else None,
    })
with open(out_path, 'w', encoding='utf-8') as fh:
    fh.write(json.dumps(records, indent=2, sort_keys=True, ensure_ascii=False) + '\n')
c = {}
for r in records: c[r['state']] = c.get(r['state'], 0) + 1
sys.stderr.write('%s-signals: %d records (present=%d absent=%d unknown=%d)\n' % (kind, len(records), c.get('present', 0), c.get('absent-with-positive-evidence', 0), c.get('unknown', 0)))
PY
if ! python3 "$SCRIPT_DIR/skillsel_common.py" validate-json "$SCHEMA" "$TMPD/out.json" >/dev/null; then
  echo "juncture-signals: output failed schema validation" >&2; python3 "$SCRIPT_DIR/skillsel_common.py" validate-json "$SCHEMA" "$TMPD/out.json" >&2; exit 1
fi
if [ "$OUT" = "-" ]; then cat "$TMPD/out.json"; else cp "$TMPD/out.json" "$OUT" && echo "juncture-signals: wrote $OUT" >&2; fi
exit 0
