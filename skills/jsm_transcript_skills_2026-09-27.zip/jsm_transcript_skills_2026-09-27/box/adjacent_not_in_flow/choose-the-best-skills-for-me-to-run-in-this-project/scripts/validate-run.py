#!/usr/bin/env python3
"""Validate a recommendation run: schemas + the candidate-ledger invariants.

  validate-run.py --run RUN.json --evidence EVIDENCE.json --catalog CATALOG.json
                  --run-config CONFIG.json --already-done DONE.json --gaps GAPS.json
                  --overrides OVERRIDES.json --activations ACTIVATIONS.json
                  --recipe-candidates RECIPES.json
                  [--map MAP] [--aliases ALIASES] [--constants CONSTANTS] [--recipes RECIPES]

Exit 0 when valid. Exit 1 and print every violation otherwise. A violation blocks artifact
writing: the orchestrator repairs the inputs and re-scores; it never writes artifacts from
an invalid run.
"""
from __future__ import annotations

import argparse
import importlib.util
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import skillsel_common as slib  # noqa: E402


def load_scorer():
    path = Path(__file__).resolve().parent / "score-recommendations.py"
    spec = importlib.util.spec_from_file_location("skill_selection_scorer_for_validation", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def check(run, evidence, catalog, smap, aliases, consts, recipes, already=None,
          overrides=None, recipe_candidates=None, supplied_activations=None,
          gaps=None, run_config=None, expected_input_hashes=None) -> list[str]:
    v: list[str] = []
    already = already or {}
    overrides = overrides or {}
    scorer = load_scorer()
    # ---- schemas
    v += [f"run schema: {e}" for e in slib.validate_against(run, slib.load_json(slib.SCHEMA_DIR / "recommendation-run.schema.json"), slib.SCHEMA_DIR)]
    ev_schema = slib.load_json(slib.SCHEMA_DIR / "evidence.schema.json")
    for i, e in enumerate(evidence):
        v += [f"evidence[{i}] schema: {x}" for x in slib.validate_against(e, ev_schema, slib.SCHEMA_DIR)]
    cat_schema = slib.load_json(slib.SCHEMA_DIR / "catalog-entry.schema.json")
    for i, c in enumerate(catalog["skills"]):
        v += [f"catalog[{i}] schema: {x}" for x in slib.validate_against(c, cat_schema, slib.SCHEMA_DIR)]
    try:
        active_evidence = slib.active_evidence(evidence)
    except ValueError as exc:
        v.append(f"evidence corrections: {exc}")
        active_evidence = []

    names = [c["canonical_name"] for c in catalog["skills"]]
    name_set = set(names)
    if len(names) != len(name_set):
        v.append("catalog: duplicate canonical names")
    if gaps is not None and run.get("gaps") != gaps:
        v.append("run gaps do not match the required Phase 5 gaps input")
    if run_config is not None:
        for field in ("target", "fingerprint", "sources", "catalog_drift"):
            if field == "catalog_drift":
                expected_value = run_config.get(field, {
                    "new": [], "renamed": [], "retired": [],
                    "provisional": sorted(c["canonical_name"] for c in catalog["skills"]
                                          if c.get("provisional_mapping")),
                })
            else:
                expected_value = run_config.get(field, {} if field == "sources" else None)
            if run.get(field) != expected_value:
                v.append(f"run {field} does not match run-config")
        if run.get("run_id") != run_config.get("run_id") or run.get("generated_at") != run_config.get("generated_at"):
            v.append("run identity/timestamp do not match run-config")
    if expected_input_hashes is not None:
        for field, expected_hash in expected_input_hashes.items():
            if run.get("inputs", {}).get(field) != expected_hash:
                v.append(f"inputs.{field} does not match supplied file bytes")
    alias_map = aliases.get("aliases", {})
    for old, new in alias_map.items():
        if new not in name_set and new not in smap["skills"]:
            v.append(f"alias {old} -> {new}: target is not a current canonical name")
        if old in name_set:
            v.append(f"alias {old} still appears as a canonical catalog name")
    for n in names:
        if n in alias_map:
            v.append(f"catalog name {n} is a retired alias; resolve to {alias_map[n]}")

    ledger = run.get("ledger", [])
    ledger_names = [r["canonical_name"] for r in ledger]
    # ---- ledger invariants
    if len(ledger) != len(names):
        v.append(f"ledger row count {len(ledger)} != normalized catalog count {len(names)}")
    dup = {n for n in ledger_names if ledger_names.count(n) > 1}
    if dup:
        v.append(f"ledger has duplicate rows: {sorted(dup)}")
    missing = name_set - set(ledger_names)
    extra = set(ledger_names) - name_set
    if missing:
        v.append(f"catalog skills with no ledger row: {sorted(missing)}")
    if extra:
        v.append(f"ledger rows for skills not in the catalog: {sorted(extra)}")

    ev_ids = {e["id"] for e in evidence}
    active_ids = {e["id"] for e in active_evidence}
    for r in ledger:
        for eid in r.get("evidence_ids", []):
            if eid not in ev_ids:
                v.append(f"{r['canonical_name']}: evidence id {eid} not in the evidence set")
            elif eid not in active_ids:
                v.append(f"{r['canonical_name']}: superseded evidence id {eid} cannot support the current run")
    for c in run.get("campaigns", []):
        for eid in c.get("evidence_ids", []):
            if eid not in ev_ids:
                v.append(f"{c['id']}: evidence id {eid} not in the evidence set")
            elif eid not in active_ids:
                v.append(f"{c['id']}: superseded evidence id {eid} cannot support the current run")
        for m in c["sequence"]:
            if m["skill"] not in name_set:
                v.append(f"{c['id']}: member {m['skill']} not in the normalized catalog")
        if c["anchor"] not in name_set:
            v.append(f"{c['id']}: anchor {c['anchor']} not in the normalized catalog")
        member_names = [m["skill"] for m in c["sequence"]]
        if len(member_names) != len(set(member_names)):
            v.append(f"{c['id']}: duplicate campaign members")
        if any(r["candidate"] in set(member_names) for r in c.get("runners_up", [])):
            v.append(f"{c['id']}: runner-up is already retained in the campaign")
        runner_names = [r["candidate"] for r in c.get("runners_up", [])]
        if len(runner_names) != len(set(runner_names)):
            v.append(f"{c['id']}: duplicate runners-up")
    if len(run.get("campaigns", [])) > consts["portfolio"]["max_campaigns"]:
        v.append("too many campaigns")
    campaign_ids = [c["id"] for c in run.get("campaigns", [])]
    if len(campaign_ids) != len(set(campaign_ids)):
        v.append("duplicate campaign ids")

    by_name = {r["canonical_name"]: r for r in ledger}
    camp_by = {c["id"]: c for c in run.get("campaigns", [])}

    # ---- recompute every scoring dimension and portfolio decision from bound inputs
    catalog_by = {c["canonical_name"]: c for c in catalog["skills"]}
    try:
        scorer.validate_catalog_retirement(
            catalog, run_config if run_config is not None
            else {"catalog_drift": run.get("catalog_drift", {})},
        )
        scorer.validate_override_provenance(overrides, evidence)
        signals = scorer.merged_signals(smap, overrides)
        activations = scorer.activate(evidence, signals)
        scorer.check_supplied_activations(supplied_activations, activations, signals)
        allowed_recipes = scorer.allowed_recipe_ids(
            recipe_candidates, evidence, recipes["recipes"], activations
        )
        scorer.validate_gap_provenance(run.get("gaps", []), evidence, signals, names)
        retired_names = set(run.get("catalog_drift", {}).get("retired", []))
        entries = {
            n: scorer.mapping_for(n, smap, overrides, catalog_by[n].get("provisional_mapping"))
            for n in names
        }
        expected = {
            n: scorer.score_skill(n, catalog_by[n], entries[n], activations, signals, already,
                                  consts, run["generated_at"], retired=n in retired_names)
            for n in names
        }
        eligible = sorted(
            [n for n in names if scorer.run_now_eligible(expected[n], consts)],
            key=lambda n: scorer.sort_key(n, expected[n]),
        )
        expected_campaigns, expected_rejected = scorer.build_campaigns(
            eligible, expected, entries, catalog_by, recipes["recipes"], already,
            activations, consts, allowed_recipes,
        )
    except (KeyError, TypeError, ValueError) as exc:
        v.append(f"bound-input recomputation failed: {exc}")
        expected = {}
        expected_campaigns = []
        expected_rejected = {}
        entries = {}
        activations = {}

    expected_roles = {}
    for campaign in expected_campaigns:
        for member in campaign["sequence"]:
            expected_roles[member["skill"]] = (campaign["id"], member["role"])

    for name, result in expected.items():
        row = by_name.get(name)
        if row is None:
            continue
        expected_positive = sorted({
            spec["signal"] + ("" if spec.get("when", "present") == "present" else " (absent)")
            for spec in result["firing"]
        })
        expected_negative = sorted({
            spec["signal"] + ("" if spec.get("when", "present") == "present" else " (absent)")
            for spec in result["anti_firing"]
        })
        exact_fields = {
            "applicability": result["applicable"],
            "applicability_basis": result["basis"],
            "positive_signals": expected_positive,
            "anti_signals": expected_negative,
            "already_done_state": result["done_state"],
            "suppression_gate": result["gate"],
            "scores": result["scores"],
            "anchors": {"profile": result["profile_anchor_keys"], "juncture": result["juncture_anchor_keys"]},
        }
        for field, wanted in exact_fields.items():
            if row.get(field) != wanted:
                v.append(f"{name}: {field} does not match bound-input recomputation")

        campaign_id, role = expected_roles.get(name, (None, None))
        scores = result["scores"]
        tiers = consts["tiers"]
        promotion = None
        if not result["applicable"]:
            disposition = "not_applicable"
            tier_reason = "catalog_retired" if result["basis"] == "catalog-retired" else "gate_absent"
        elif campaign_id:
            disposition = "run_now"
            tier_reason = "run_now_rule" if role == "anchor" else f"campaign_{role}"
        elif result["gate"]:
            disposition = "keep_handy" if scores["total"] >= tiers["keep_handy"]["min_score"] else "considered_not_now"
            tier_reason = f"suppressed:{result['gate']}"
        elif name in expected_rejected:
            disposition, tier_reason = "run_soon", expected_rejected[name][0]
        elif scores["total"] >= tiers["run_soon"]["min_score"] and scores["J"] >= tiers["run_soon"]["min_J"]:
            disposition, tier_reason = "run_soon", "run_soon_rule"
        elif scores["total"] >= tiers["keep_handy"]["min_score"]:
            disposition, tier_reason = "keep_handy", "keep_handy_rule"
            pending = sorted(
                (spec for spec in entries[name].get("positive_signals", [])
                 if not scorer.fires(spec, activations)),
                key=lambda spec: (-spec["weight"], spec["signal"]),
            )
            promotion = pending[0]["signal"] if pending else None
        else:
            disposition = "considered_not_now"
            tier_reason = "gate_unknown" if result["basis"] == "gate-unknown" else "score_below_12"
        for field, wanted in {
            "disposition": disposition, "tier_reason": tier_reason,
            "campaign_id": campaign_id, "campaign_role": role,
            "promotion_trigger": promotion,
        }.items():
            if row.get(field) != wanted:
                v.append(f"{name}: {field} {row.get(field)!r} != recomputed {wanted!r}")

    if len(run.get("campaigns", [])) != len(expected_campaigns):
        v.append("campaign count does not match independent portfolio recomputation")
    for actual, wanted in zip(run.get("campaigns", []), expected_campaigns):
        recipe_id = wanted["recipe"]["id"] if wanted["recipe"] else None
        expected_core = {
            "id": wanted["id"], "anchor": wanted["anchor"],
            "sequence": wanted["sequence"], "effort": wanted["effort"],
            "recipe_id": recipe_id,
        }
        for field, value in expected_core.items():
            if actual.get(field) != value:
                v.append(f"{actual.get('id', 'campaign')}: {field} does not match portfolio recomputation")
        if actual.get("kickoff_prompt") != scorer.kickoff_for(wanted, entries):
            v.append(f"{actual.get('id', 'campaign')}: kickoff prompt describes a different sequence")
        if actual.get("install_command") != scorer.install_line(wanted, catalog_by):
            v.append(f"{actual.get('id', 'campaign')}: install command does not match retained members")

    for r in ledger:
        n, s = r["canonical_name"], r["scores"]
        # score arithmetic must match the contract
        w = consts["weights"]
        expect = w["J"] * s["J"] + w["A"] * s["A"] + w["E"] * s["E"] + w["C"] * s["C"] + w["R"] * s["R"] + w["D"] * s["D"]
        if s["total"] != expect:
            v.append(f"{n}: total {s['total']} != contract {expect}")
        if r["disposition"] in ("run_now", "run_soon") and r.get("suppression_gate"):
            v.append(f"{n}: disposition {r['disposition']} under suppression gate {r['suppression_gate']}")
        if r["disposition"] == "not_applicable" and r["applicability"]:
            v.append(f"{n}: not_applicable but applicability=true")
        if r["disposition"] != "not_applicable" and not r["applicability"]:
            v.append(f"{n}: applicability=false but disposition {r['disposition']}")
        if r["disposition"] == "run_now":
            cid = r.get("campaign_id")
            if not cid or cid not in camp_by:
                v.append(f"{n}: run_now without a campaign")
                continue
            camp = camp_by[cid]
            member = next((m for m in camp["sequence"] if m["skill"] == n), None)
            if member is None:
                v.append(f"{n}: run_now but not a member of {cid}")
                continue
            if member["role"] != r.get("campaign_role"):
                v.append(f"{n}: campaign_role {r.get('campaign_role')} != sequence role {member['role']}")
            if r["campaign_role"] == "anchor":
                if camp["anchor"] != n:
                    v.append(f"{n}: anchor row but {cid} anchors {camp['anchor']}")
                t = consts["tiers"]
                hyg = smap["skills"].get(n, {}).get("baseline_hygiene")
                anchors = r.get("anchors", {"profile": [], "juncture": []})
                rn = t["run_now"]
                if s["total"] < rn["min_score"] or s["J"] < rn["min_J"] or s["E"] < rn["min_E"]:
                    v.append(f"{n}: anchor fails the RUN NOW score/J/E rule")
                prof, junc = anchors.get("profile", []), anchors.get("juncture", [])
                hygiene_route = bool(hyg) and not junc
                if hygiene_route:
                    if len(prof) < t["run_now_baseline_hygiene"]["min_profile_anchors"]:
                        v.append(f"{n}: baseline-hygiene anchor needs >= 2 profile anchors")
                else:
                    if len(set(prof) | set(junc)) < rn["min_anchors"] or not prof or not junc:
                        v.append(f"{n}: anchor lacks >= 2 independent anchors with both profile and juncture kinds")
                if r["prerequisite_status"] == "unsatisfied":
                    v.append(f"{n}: anchor has unsatisfied prerequisites outside its campaign")
            else:
                entry = smap["skills"].get(camp["anchor"]) or {}
                declared = {p["skill"] for p in entry.get("prerequisites", [])} | set(entry.get("pairs", []))
                recipe = next((rc for rc in recipes["recipes"] if rc["id"] == camp.get("recipe_id")), None)
                if recipe:
                    declared |= {m["skill"] for m in recipe["sequence"]}
                if n not in declared:
                    v.append(f"{n}: run_now member of {cid} but not a declared prerequisite/pair of {camp['anchor']}")
        # keep_handy rows explain promotion in `reason`. promotion_trigger names a specific
        # un-fired positive signal when one exists, but is legitimately null (schema allows
        # it) when every positive signal already fires — e.g. a skill with no juncture-kind
        # positive signals whose profile signals all match yet whose score stays below the
        # RUN SOON bar. Nothing is left to wait for, so no trigger is required here.

    # ---- campaign structure, prerequisite order, and aggregate effort
    for c in run.get("campaigns", []):
        roles = [m["role"] for m in c["sequence"]]
        if sum(1 for x in roles if x == "anchor") != 1:
            v.append(f"{c['id']}: must have exactly one anchor")
        else:
            anchor_member = next(m for m in c["sequence"] if m["role"] == "anchor")
            if anchor_member["skill"] != c["anchor"]:
                v.append(f"{c['id']}: declared anchor does not match anchor-role member")
        positions = {m["skill"]: i for i, m in enumerate(c["sequence"])}
        for member in c["sequence"]:
            for prerequisite in (entries.get(member["skill"]) or {}).get("prerequisites", []):
                skill = prerequisite["skill"]
                satisfied = (already.get(skill) or {}).get("state") in ("completed_successfully", "superseded") \
                    or any(scorer.state_of(activations, signal) == scorer.PRESENT
                           for signal in prerequisite.get("satisfied_by_signals", []))
                if not satisfied and (skill not in positions or positions[skill] >= positions[member["skill"]]):
                    v.append(f"{c['id']}: prerequisite {skill} does not precede dependent {member['skill']}")
        effort = sum((expected.get(name) or {"scores": {"C": 0}})["scores"]["C"] for name in positions)
        if c.get("effort") != effort:
            v.append(f"{c['id']}: effort {c.get('effort')} != sum of member C values {effort}")
        index = run.get("campaigns", []).index(c)
        limit = consts["portfolio"]["first_campaign_max_effort"] if index == 0 else consts["portfolio"]["other_campaign_max_effort"]
        if c.get("effort", 0) > limit:
            v.append(f"{c['id']}: effort {c.get('effort')} exceeds campaign limit {limit}")

    # ---- gaps name no existing skill
    token_re = re.compile(r"(^|[^a-z0-9-])/?(" + "|".join(sorted(map(re.escape, name_set), key=len, reverse=True)) + r")([^a-z0-9-]|$)") if name_set else None
    for g in run.get("gaps", []):
        if not g.get("catalog_query", "").strip():
            v.append(f"{g.get('id', 'gap')}: missing exact catalog_query provenance")
        if g.get("names_existing_skill"):
            v.append(f"{g['id']}: names existing skill {g['names_existing_skill']} (that is a match, not a gap)")
        if token_re and token_re.search(g.get("description", "").lower()):
            m = token_re.search(g["description"].lower())
            v.append(f"{g['id']}: description mentions catalog skill {m.group(2)}")
        for eid in g.get("evidence_ids", []):
            if eid not in ev_ids:
                v.append(f"{g['id']}: evidence id {eid} not in the evidence set")
            elif eid not in active_ids:
                v.append(f"{g['id']}: superseded evidence id {eid} cannot support the current run")

    # ---- tiers agree with the ledger
    for tier, members in run.get("tiers", {}).items():
        for n in members:
            if n not in by_name:
                v.append(f"tiers.{tier}: {n} has no ledger row")
            elif by_name[n]["disposition"] != tier:
                v.append(f"tiers.{tier}: {n} ledger disposition is {by_name[n]['disposition']}")
    counted = sum(len(m) for m in run.get("tiers", {}).values())
    if counted != len(ledger):
        v.append(f"tiers list {counted} names but the ledger has {len(ledger)} rows")
    flattened = [name for members in run.get("tiers", {}).values() for name in members]
    if len(flattened) != len(set(flattened)):
        v.append("a skill appears in more than one tier")
    if set(flattened) != set(ledger_names):
        v.append("tier partition does not exactly equal the ledger names")
    return v


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--run", required=True)
    ap.add_argument("--evidence", required=True)
    ap.add_argument("--catalog", required=True)
    ap.add_argument("--map", default=str(slib.DATA_DIR / "signal-to-skill-map.json"))
    ap.add_argument("--aliases", default=str(slib.DATA_DIR / "aliases.json"))
    ap.add_argument("--constants", default=str(slib.DATA_DIR / "scoring-constants.json"))
    ap.add_argument("--recipes", default=str(slib.DATA_DIR / "combo-recipes.json"))
    ap.add_argument("--run-config", required=True)
    ap.add_argument("--already-done", required=True)
    ap.add_argument("--gaps", required=True)
    ap.add_argument("--overrides", required=True)
    ap.add_argument("--recipe-candidates", required=True)
    ap.add_argument("--activations", required=True)
    ap.add_argument("--previous-run")
    a = ap.parse_args(argv)
    previous_hash = (slib.sha256_file(a.previous_run)
                     if a.previous_run and Path(a.previous_run).exists() else None)
    expected_hashes = {
        "evidence_sha256": slib.sha256_file(a.evidence),
        "catalog_sha256": slib.sha256_file(a.catalog),
        "signal_map_sha256": slib.sha256_file(a.map),
        "recipes_sha256": slib.sha256_file(a.recipes),
        "constants_sha256": slib.sha256_file(a.constants),
        "already_done_sha256": slib.sha256_file(a.already_done),
        "run_config_sha256": slib.sha256_file(a.run_config),
        "gaps_sha256": slib.sha256_file(a.gaps),
        "overrides_sha256": slib.sha256_file(a.overrides),
        "recipe_candidates_sha256": slib.sha256_file(a.recipe_candidates),
        "activations_sha256": slib.sha256_file(a.activations),
        "previous_run_sha256": previous_hash,
    }
    violations = check(
        slib.load_json(a.run), slib.load_json(a.evidence), slib.load_json(a.catalog),
        slib.load_json(a.map), slib.load_json(a.aliases), slib.load_json(a.constants),
        slib.load_json(a.recipes), slib.load_json(a.already_done),
        slib.load_json(a.overrides), slib.load_json(a.recipe_candidates),
        slib.load_json(a.activations), slib.load_json(a.gaps),
        slib.load_json(a.run_config), expected_hashes,
    )
    for x in violations:
        print("VIOLATION: " + x)
    print("run valid" if not violations else f"{len(violations)} violation(s)")
    return 0 if not violations else 1


if __name__ == "__main__":
    sys.exit(main())
