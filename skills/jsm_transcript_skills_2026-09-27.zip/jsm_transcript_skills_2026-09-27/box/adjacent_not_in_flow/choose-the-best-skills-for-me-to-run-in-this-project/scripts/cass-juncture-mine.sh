#!/usr/bin/env bash
# cass-juncture-mine.sh — session-history JUNCTURE miner for the skill-selection package.
#
# Usage: bash cass-juncture-mine.sh --target DIR [--days N] [--wide-days N] --out FILE
#          [--already-out FILE] [--catalog FILE] [--hosts "h1 h2"]
#   --days N        recent window in days (default 14), ending at the pinned clock.
#   --wide-days N   fallback window (default 60) used when the narrow window has < 5 hits.
#   --catalog FILE  catalog snapshot supplying the skill names for the invocation scan
#                   (default: ../references/data/catalog-snapshot.json).
#   --hosts "h1 h2" remote cass hosts (space-separated). An EMPTY string means "local only":
#                   remote mining is skipped deliberately (recorded as a fact, not an unknown).
#                   When the flag is absent, hosts come from $SKILL_SELECTION_CASS_HOSTS, else
#                   from `cass sources list --json`; nothing configured => one unknown record.
#   --already-out F companion skill-invocation tally (default: --out with .json -> .already.json).
#
# Output: --out is a JSON array of evidence records (references/schemas/evidence.schema.json)
#   with ids ev-c0001.. in emission order, kind=juncture, source_type=cass. --already-out is
#   {"<canonical>": {"mention_count": N, "refs": [...], "hosts": [...]}} for the orchestrator's
#   already-done state machine. Every locator is "source_path:line@origin_host" (origin_host
#   "local" for local hits). Every record's command field is the exact cass invocation.
#
# Behavior: cass absent => ONE summary unknown record listing every cass-derived signal from
#   signal-to-skill-map.json, empty already-file, exit 0. cass is never run bare (it is a TUI);
#   every invocation is a --json/--robot form under `timeout 60`. A timeout or failure yields
#   state=unknown records, never absence; an absence claim about a battery is only made after
#   the workspace was confirmed to have indexed sessions via the workspace aggregate. A remote
#   host that fails or times out yields ONE unknown record naming the host and the error.
#   Remote hosts run the error-class batteries only (never the per-skill scan), in parallel.
#   Workspace path mapping: the same project may live under different roots on different
#   machines, so remote queries are scoped by the target's basename (never by the local path);
#   locally both the full target path and the basename-matched workspace aggregate are tried.
#
# Read-only toward everything except --out/--already-out; nothing else is created or deleted.
# Exit codes: 0 = a schema-valid array was written; 1 = bad arguments, missing helper, or the
#   output failed schema validation. Individual probe failures never abort the run.
# Determinism: same cass index + same SKILL_SELECTION_NOW => byte-identical output (windows come
#   from the pinned clock via --since/--until, scans are sorted, ids are sequential). The global
#   wall-clock deadline (~240s local, 120s per remote host) only degrades to unknown records.
# Portability: bash 3.2+ (no associative arrays/mapfile), timeout/gtimeout/perl-alarm, python3
#   (stdlib only). External deps: bash, python3; optional cass, ssh, git.
set -uo pipefail
set -f

TARGET=""; OUT=""; ALREADY_OUT=""; DAYS=14; WIDE_DAYS=60; CATALOG=""; HOSTS=""; HOSTS_GIVEN=0
while [ $# -gt 0 ]; do
  case "$1" in
    --target) TARGET="$2"; shift 2;;
    --days) DAYS="$2"; shift 2;;
    --wide-days) WIDE_DAYS="$2"; shift 2;;
    --out) OUT="$2"; shift 2;;
    --already-out) ALREADY_OUT="$2"; shift 2;;
    --catalog) CATALOG="$2"; shift 2;;
    --hosts) HOSTS="$2"; HOSTS_GIVEN=1; shift 2;;
    -h|--help) sed -n '2,40p' "$0"; exit 0;;
    *) echo "unknown arg: $1" >&2; exit 1;;
  esac
done
[ -n "$TARGET" ] || { echo "--target DIR is required" >&2; exit 1; }
[ -n "$OUT" ] && [ "$OUT" != "-" ] || { echo "--out FILE is required (stdout is not supported: two files are written)" >&2; exit 1; }
case "$DAYS" in ''|*[!0-9]*) echo "--days must be a positive integer" >&2; exit 1;; esac
case "$WIDE_DAYS" in ''|*[!0-9]*) echo "--wide-days must be a positive integer" >&2; exit 1;; esac
SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)
SCHEMA="$SCRIPT_DIR/../references/schemas/evidence.schema.json"
MAP="$SCRIPT_DIR/../references/data/signal-to-skill-map.json"
ALIASES="$SCRIPT_DIR/../references/data/aliases.json"
[ -n "$CATALOG" ] || CATALOG="$SCRIPT_DIR/../references/data/catalog-snapshot.json"
TARGET=$(cd "$TARGET" 2>/dev/null && pwd -P) || { echo "target not found: $TARGET" >&2; exit 1; }
[ -f "$TARGET/AGENTS.md" ] && grep -Eqi 'NO FILE DELETION|NEVER (ALLOWED TO )?DELETE' "$TARGET/AGENTS.md" && export SKILL_SELECTION_KEEP_TEMP=1
BASE=$(basename "$TARGET")
case "$OUT" in /*) ;; *) OUT="$PWD/$OUT";; esac
if [ -z "$ALREADY_OUT" ]; then
  case "$OUT" in *.json) ALREADY_OUT="${OUT%.json}.already.json";; *) ALREADY_OUT="$OUT.already.json";; esac
fi
case "$ALREADY_OUT" in /*) ;; *) ALREADY_OUT="$PWD/$ALREADY_OUT";; esac
[ -f "$CATALOG" ] || { echo "catalog not found: $CATALOG" >&2; exit 1; }
[ -f "$MAP" ] || { echo "signal map not found: $MAP" >&2; exit 1; }
NOW=$(python3 "$SCRIPT_DIR/skillsel_common.py" now) || { echo "python3 helper failed" >&2; exit 1; }
shift_days() { python3 -c 'import sys,datetime as d; s=sys.argv[1].replace("Z","+00:00"); print((d.datetime.fromisoformat(s)-d.timedelta(days=int(sys.argv[2]))).strftime("%Y-%m-%dT%H:%M:%SZ"))' "$NOW" "$1"; }
SINCE=$(shift_days "$DAYS"); WIDE_SINCE=$(shift_days "$WIDE_DAYS")
REPO_HEAD=""
command -v git >/dev/null 2>&1 && REPO_HEAD=$(git -C "$TARGET" rev-parse HEAD 2>/dev/null || true)

TMPD=$(mktemp -d "${TMPDIR:-/tmp}/skillsel-cassmine.XXXXXX") || { echo "mktemp failed" >&2; exit 1; }
cleanup() {
  if [ "${SKILL_SELECTION_KEEP_TEMP:-0}" = 1 ]; then
    echo "cass-juncture-mine: kept temporary workspace $TMPD" >&2
    return
  fi
  (set +f; rm -f "$TMPD"/* 2>/dev/null); rmdir "$TMPD" 2>/dev/null
}
trap cleanup EXIT
REC="$TMPD/records"; : > "$REC"

# ------------------------------------------------------------------ helpers
TMO_BIN=""
if command -v timeout >/dev/null 2>&1; then TMO_BIN=timeout; elif command -v gtimeout >/dev/null 2>&1; then TMO_BIN=gtimeout; fi
tmo() { # tmo SECONDS cmd args...  (124/142 = timed out)
  local s="$1"; shift
  if [ -n "$TMO_BIN" ]; then "$TMO_BIN" "$s" "$@"
  elif command -v perl >/dev/null 2>&1; then perl -e 'alarm shift; exec @ARGV' "$s" "$@"
  else "$@"; fi
}
is_timeout() { [ "$1" = 124 ] || [ "$1" = 142 ]; }

# emit STATE POLARITY SRC LOCATOR CONF SIGNALS CLAIM COMMAND HOST DETAIL (one line, US-separated)
emit() {
  printf '%s\037%s\037%s\037%s\037%s\037%s\037%s\037%s\037%s\037%s\n' \
    "$1" "$2" "$3" "$4" "$5" "$6" "$7" "$8" "$9" "$(printf '%s' "${10}" | tr '\n\r\037' '   ')" >> "$REC"
}
ev_present() { emit present positive cass "$2" "$3" "$1" "$4" "$5" "$6" "$7"; }                     # signals loc conf claim cmd host detail
ev_absent()  { emit absent-with-positive-evidence negative cass "$2" "$3" "$1" "$4" "$5" "$6" "$7"; }
ev_unknown() { emit unknown positive cass "" 0 "$1" "$2" "$3" "$4" "$5"; }                          # signals claim cmd host detail
ev_fact()    { emit present positive cass "$2" 4 "" "$1" "$3" "$4" "$5"; }                          # claim loc cmd host detail

# parse a `cass search --json` result: line 1 "COUNT TOTAL", then "path<TAB>line<TAB>content"
cat > "$TMPD/parse_hits.py" <<'PY'
import json, sys
try:
    d = json.load(open(sys.argv[1], encoding="utf-8"))
except Exception as e:
    print("-1 -1"); print("parse error: %s" % e); sys.exit(0)
hits = d.get("hits") or []
print("%d %s" % (len(hits), d.get("total_matches", len(hits))))
for h in hits:
    c = (h.get("content") or h.get("snippet") or "").replace("\t", " ").replace("\n", " ")
    c = "".join(ch for ch in c if ch >= " ")[:110]
    print("%s\t%s\t%s" % (h.get("source_path") or "?", h.get("line_number") or 0, c))
PY

DEADLINE=240   # global local wall-clock budget (seconds); past it, remaining probes are unknown
past_deadline() { [ "$SECONDS" -ge "$DEADLINE" ]; }

finalize() { # write OUT from $REC, validate, exit
  python3 - "$REC" "$NOW" "$REPO_HEAD" "$MAP" "$TMPD/out.json" <<'PY'
import json, re, sys
recs_path, now, head, map_path, out_path = sys.argv[1:6]
SECRET = re.compile(r'((sk|pk|rk)_(live|test)_[A-Za-z0-9]{8,}|ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|AKIA[0-9A-Z]{16}|xox[baprs]-[A-Za-z0-9-]{10,}|-----BEGIN [A-Z ]*PRIVATE KEY-----|eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,})')
known = set(json.load(open(map_path, encoding="utf-8")).get("signals", {}))
records, n = [], 0
for line in open(recs_path, encoding="utf-8", errors="replace"):
    line = line.rstrip("\n")
    if not line:
        continue
    f = line.split("\x1f")
    if len(f) < 10: f += [""] * (10 - len(f))
    if len(f) > 10: f = f[:9] + ["\x1f".join(f[9:])]
    state, polarity, src, locator, conf, signals, claim, command, host, detail = f
    sigs = [s for s in signals.split(",") if s]
    bad = [s for s in sigs if s not in known]
    if bad:
        sys.stderr.write("cass-juncture-mine: dropping unmapped signal id(s): %s\n" % ",".join(bad))
        sigs = [s for s in sigs if s in known]
    n += 1
    eid = "ev-c%04d" % n
    if state == "present" and not locator:
        locator = "cass-juncture-mine.sh:" + eid
    if state == "absent-with-positive-evidence" and not command:
        command = "cass-juncture-mine.sh positive-absence detector for " + (signals or "narrative fact")
    if state == "unknown" and not detail:
        detail = claim
    records.append({
        "id": eid, "claim": claim if len(claim) >= 3 else (claim + " (n/a)"),
        "kind": "juncture", "polarity": polarity, "state": state, "source_type": src,
        "locator": SECRET.sub("<redacted>", locator) or None, "observed_at": now,
        "command": command or None, "repo_head": head or None, "origin_host": host or None,
        "confidence": int(conf or 0), "signals": sigs,
        "detail": SECRET.sub("<redacted>", detail)[:1200] if detail else None,
    })
with open(out_path, "w", encoding="utf-8") as fh:
    fh.write(json.dumps(records, indent=2, sort_keys=True, ensure_ascii=False) + "\n")
c = {}
for r in records: c[r["state"]] = c.get(r["state"], 0) + 1
sys.stderr.write("cass-juncture-mine: %d records (present=%d absent=%d unknown=%d)\n"
                 % (len(records), c.get("present", 0), c.get("absent-with-positive-evidence", 0), c.get("unknown", 0)))
PY
  if ! python3 "$SCRIPT_DIR/skillsel_common.py" validate-json "$SCHEMA" "$TMPD/out.json" >/dev/null; then
    echo "cass-juncture-mine: output failed schema validation" >&2
    python3 "$SCRIPT_DIR/skillsel_common.py" validate-json "$SCHEMA" "$TMPD/out.json" >&2; exit 1
  fi
  cp "$TMPD/out.json" "$OUT" && echo "cass-juncture-mine: wrote $OUT" >&2
  exit 0
}

# every cass-derived signal id (detector mentions this script), sorted
CASS_SIGNALS=$(python3 -c '
import json, sys
m = json.load(open(sys.argv[1], encoding="utf-8"))
ids = sorted(k for k, v in m.get("signals", {}).items() if "cass-juncture-mine.sh" in str(v.get("detector", "")))
print(",".join(ids))' "$MAP") || CASS_SIGNALS=""

# ------------------------------------------------------------- cass absent
if ! command -v cass >/dev/null 2>&1; then
  ev_unknown "$CASS_SIGNALS" "cass unavailable: every session-mining signal is unknown" "command -v cass" "" \
    "cass not on PATH; signals: $(printf '%s' "$CASS_SIGNALS" | tr ',' ' ')"
  printf '{}\n' > "$ALREADY_OUT"
  finalize
fi

# ------------------------------------------------- battery table (signal|remote?|q1|q2|q3)
# remote? = R means the battery also runs on remote hosts (error classes only).
BATTERIES="jx-recurring-panics|R|panicked at|segfault|panic backtrace
jx-hang-or-deadlock|R|deadlock|hung forever|timed out waiting
jx-flaky-tests|R|flaky test|intermittent test failure|test flake
jx-perf-complaints|R|too slow|performance regression|latency spike
jx-payments-bugs|R|webhook failed|billing bug|subscription error
jx-auth-loops|R|auth failed|login loop|oauth error
jx-deploy-failures|R|deploy failed|deployment error|hosting broken
jx-machine-unresponsive|R|OOM killed|out of memory|system unresponsive
jx-slow-builds|L|slow build|compile time too long|build takes forever
jx-user-frustration|L|this is ridiculous|still broken|so frustrating
jx-design-questions|L|what should we build next|how should we architect|design question
jx-agents-deleted-things|L|rm -rf|git reset --hard|accidentally deleted
jx-cli-ergonomics-complaints|L|confusing error message|unclear CLI output|help text wrong
jx-contested-decision|L|revert that change|on second thought|changed my mind
jx-context-loss|L|context compacted|as I already said|explaining this again
jx-dependency-bump|L|bump the dependency|upgrade to the new version|cargo update
jx-going-public|L|make the repo public|open source this|announce the release
jx-large-refactor-discussed|L|split this module|large refactor|restructure the codebase
jx-mock-suspicion|L|tests pass but broken|mocked out|placeholder implementation
jx-ocr-accuracy|L|OCR accuracy|misrecognized text|OCR errors
jx-port-in-progress|L|port to rust|parity gauntlet|porting progress
jx-release-imminent|L|cut a release|release prep|version bump
jx-security-concern|L|security vulnerability|CVE|security audit finding
jx-swarm-active|L|agent swarm|ntm session|agent mail
jx-ux-complaints|L|UI looks bad|polish the UI|confusing UX
jx-wasm-size-or-speed|L|wasm bundle size|wasm too slow|wasm size
jx-ceremony-smell|L|status report instead of code|process ceremony|report with no code
jx-big-change-no-plan|L|rewrite everything|huge change without a plan|just start over"
BATTERY_SIGNALS=$(printf '%s\n' "$BATTERIES" | cut -d'|' -f1 | tr '\n' ',' | sed 's/,$//')

# --------------------------------------------------------------- index health
HEALTH_CMD="cass health --json"
HSTATE=unknown
# NOTE: cass health exits nonzero when unhealthy but still prints JSON; parse stdout first
tmo 60 cass health --json > "$TMPD/health.json" 2> "$TMPD/health.err"; HC=$?
if is_timeout $HC || ! python3 -c 'import json,sys; json.load(open(sys.argv[1]))' "$TMPD/health.json" 2>/dev/null; then
  ev_unknown jx-cass-index-stale "cass index health unknown" "$HEALTH_CMD" local \
    "$( is_timeout $HC && echo 'timed out after 60s' || printf 'exit %s: %s' "$HC" "$(head -c 200 "$TMPD/health.err")" )"
else
  python3 -c '
import json, sys
try: d = json.load(open(sys.argv[1], encoding="utf-8"))
except Exception as e: print("err"); print("health JSON parse error: %s" % e); sys.exit(0)
print("ok" if d.get("healthy") else "stale")
print("%s | %s" % (d.get("status"), (d.get("recommended_action") or "")[:180]))' "$TMPD/health.json" > "$TMPD/health.state"
  HSTATE=$(head -1 "$TMPD/health.state"); HDET=$(sed -n 2p "$TMPD/health.state")
  case "$HSTATE" in
    ok)    ev_absent jx-cass-index-stale "" 3 "cass index healthy" "$HEALTH_CMD" local "$HDET";;
    stale) ev_present jx-cass-index-stale "" 3 "cass index stale or missing" "$HEALTH_CMD" local "$HDET";;
    *)     ev_unknown jx-cass-index-stale "cass index health unknown" "$HEALTH_CMD" local "$HDET";;
  esac
fi

# ------------------------------------------------------- workspace resolution
AGG_CMD="cass search \"$BASE\" --aggregate workspace --limit 1 --json"
tmo 60 cass search "$BASE" --aggregate workspace --limit 1 --json > "$TMPD/agg.json" 2> "$TMPD/agg.err"; AC=$?
WSKEY=""; WSCOUNT=0; AGG_OK=0
# exit 0 with unparseable output (e.g. truncated JSON) must stay AGG_OK=0: an absence
# claim about prior sessions may only rest on an aggregate that actually parsed.
if [ $AC -eq 0 ] && python3 -c 'import json,sys; json.load(open(sys.argv[1], encoding="utf-8"))' "$TMPD/agg.json" 2>/dev/null; then
  AGG_OK=1
  WSLINE=$(python3 -c '
import json, os, sys
target, base = sys.argv[2], sys.argv[3]
try: d = json.load(open(sys.argv[1], encoding="utf-8"))
except Exception: sys.exit(0)
buckets = ((d.get("aggregations") or {}).get("workspace") or {}).get("buckets") or []
exact = [b for b in buckets if b.get("key") == target]
named = sorted((b for b in buckets if os.path.basename(str(b.get("key", "")).rstrip("/")) == base),
               key=lambda b: (-int(b.get("count", 0)), str(b.get("key"))))
pick = (exact or named or [None])[0]
if pick: print("%s\t%s" % (pick["key"], pick.get("count", 0)))' "$TMPD/agg.json" "$TARGET" "$BASE")
  if [ -n "$WSLINE" ]; then WSKEY=$(printf '%s' "$WSLINE" | cut -f1); WSCOUNT=$(printf '%s' "$WSLINE" | cut -f2); fi
fi
# also try the full target path directly (the aggregate can miss low-scoring workspaces)
if [ -z "$WSKEY" ] && [ $AGG_OK -eq 1 ]; then
  if tmo 60 cass search "$BASE" --workspace "$TARGET" --limit 1 --fields minimal --json > "$TMPD/wsprobe.json" 2>/dev/null; then
    PN=$(python3 "$TMPD/parse_hits.py" "$TMPD/wsprobe.json" | head -1 | cut -d' ' -f1)
    [ "${PN:-0}" -gt 0 ] 2>/dev/null && { WSKEY="$TARGET"; WSCOUNT="$PN"; }
  fi
fi
WS_CONFIRMED=0; [ -n "$WSKEY" ] && [ "${WSCOUNT:-0}" -gt 0 ] 2>/dev/null && WS_CONFIRMED=1

if [ $AGG_OK -eq 0 ]; then
  ev_unknown jx-onboarding "prior-session count unknown (workspace aggregate failed)" "$AGG_CMD" local \
    "$( if is_timeout $AC; then echo 'timed out after 60s'; elif [ $AC -eq 0 ]; then echo 'cass exited 0 but printed unparseable JSON'; else printf 'exit %s: %s' "$AC" "$(head -c 200 "$TMPD/agg.err")"; fi )"
elif [ $WS_CONFIRMED -eq 1 ]; then
  ev_absent jx-onboarding "" 2 "prior sessions exist for this project ($WSCOUNT indexed hits in workspace)" "$AGG_CMD" local "workspace $WSKEY"
  ev_fact "cass workspace resolved for target" "" "$AGG_CMD" local "workspace $WSKEY ($WSCOUNT hits for query '$BASE')"
elif [ "$HSTATE" != ok ]; then
  ev_unknown jx-onboarding "prior-session absence cannot be established from an unhealthy cass index" "$AGG_CMD" local \
    "workspace aggregate has no matching bucket, but cass health is $HSTATE"
else
  ev_present jx-onboarding "" 2 "no prior sessions indexed for this project" "$AGG_CMD" local \
    "no workspace bucket matches $TARGET or basename '$BASE' (confirmed by the workspace aggregate)"
fi

# ------------------------------------------------------------ local batteries
# run_local_batteries SINCE_ISO -> per-battery files $TMPD/bat.<signal>.{hits,err,cmd}; echoes total hit count
run_local_batteries() {
  local since="$1" total=0 sig rmt rest terms t cmd rc line n
  while IFS= read -r line; do
    sig=${line%%|*}; rest=${line#*|}; rmt=${rest%%|*}; terms=${rest#*|}
    : > "$TMPD/bat.$sig.hits"; : > "$TMPD/bat.$sig.err"; : > "$TMPD/bat.$sig.cmd"
    if past_deadline; then echo "global deadline (${DEADLINE}s) exceeded before this battery ran" > "$TMPD/bat.$sig.err"; continue; fi
    OLDIFS=$IFS; IFS='|'; set -- $terms; IFS=$OLDIFS
    for t in "$@"; do
      cmd="cass search \"$t\" --workspace \"$WSKEY\" --since $since --until $NOW --json --fields source_path,line_number,content --max-content-length 110 --limit 8"
      [ -s "$TMPD/bat.$sig.cmd" ] || printf '%s' "$cmd" > "$TMPD/bat.$sig.cmd"
      tmo 60 cass search "$t" --workspace "$WSKEY" --since "$since" --until "$NOW" --json \
        --fields source_path,line_number,content --max-content-length 110 --limit 8 \
        < /dev/null > "$TMPD/q.json" 2> "$TMPD/q.err"; rc=$?
      if [ $rc -ne 0 ]; then
        printf '%s: %s\n' "$t" "$( is_timeout $rc && echo 'timed out after 60s' || printf 'exit %s: %s' "$rc" "$(head -c 120 "$TMPD/q.err")" )" >> "$TMPD/bat.$sig.err"
      else
        # parse_hits signals unparseable JSON with a "-1 -1" count line; that is a probe
        # FAILURE (goes to .err -> state=unknown), never a hit line.
        python3 "$TMPD/parse_hits.py" "$TMPD/q.json" > "$TMPD/q.parsed"
        if [ "$(head -1 "$TMPD/q.parsed" | cut -d' ' -f1)" = "-1" ]; then
          printf '%s: %s\n' "$t" "$(sed -n 2p "$TMPD/q.parsed" | head -c 120)" >> "$TMPD/bat.$sig.err"
        else
          sed '1d' "$TMPD/q.parsed" >> "$TMPD/bat.$sig.hits"
        fi
      fi
    done
    LC_ALL=C sort -u "$TMPD/bat.$sig.hits" -o "$TMPD/bat.$sig.hits"
    n=$(grep -c . "$TMPD/bat.$sig.hits" 2>/dev/null || true); total=$((total + ${n:-0}))
  done <<EOF_BAT
$BATTERIES
EOF_BAT
  echo "$total"
}

WINDOW_SINCE="$SINCE"; WINDOW_LABEL="${DAYS}d"
if [ $WS_CONFIRMED -eq 1 ]; then
  TOTAL=$(run_local_batteries "$SINCE" | tail -1)
  if [ "${TOTAL:-0}" -lt 5 ] && [ "$WIDE_DAYS" -gt "$DAYS" ]; then
    WINDOW_SINCE="$WIDE_SINCE"; WINDOW_LABEL="${WIDE_DAYS}d (widened: ${TOTAL:-0} hits in ${DAYS}d)"
    TOTAL=$(run_local_batteries "$WIDE_SINCE" | tail -1)
  fi
  while IFS= read -r line; do
    sig=${line%%|*}
    CMD=$(cat "$TMPD/bat.$sig.cmd" 2>/dev/null || true)
    N=$(grep -c . "$TMPD/bat.$sig.hits" 2>/dev/null || true); N=${N:-0}
    if [ -s "$TMPD/bat.$sig.err" ] && [ "$N" -eq 0 ]; then
      ev_unknown "$sig" "session mining for $sig failed" "$CMD" local "$(head -3 "$TMPD/bat.$sig.err" | tr '\n' '; ')"
    elif [ "$N" -gt 0 ]; then
      FIRST=$(head -1 "$TMPD/bat.$sig.hits")
      LOC="$(printf '%s' "$FIRST" | cut -f1):$(printf '%s' "$FIRST" | cut -f2)@local"
      CONF=2; [ "$N" -ge 3 ] && CONF=3
      DET=$(head -3 "$TMPD/bat.$sig.hits" | awk -F'\t' '{printf "%s:%s: %s; ", $1, $2, $3}')
      ev_present "$sig" "$LOC" "$CONF" "recent sessions match the $sig battery ($N hits, window $WINDOW_LABEL)" "$CMD" local "$DET"
    else
      ev_absent "$sig" "" 2 "no recent session matches for the $sig battery (window $WINDOW_LABEL)" "$CMD" local \
        "0 hits in confirmed workspace $WSKEY"
    fi
  done <<EOF_BAT2
$BATTERIES
EOF_BAT2

  # jx-history-underused: sessions exist, but do recent sessions consult cass history?
  HU_CMD="cass search \"cass search\" --workspace \"$WSKEY\" --since $WINDOW_SINCE --until $NOW --json --fields minimal --limit 8"
  if past_deadline; then
    ev_unknown jx-history-underused "history-usage probe skipped" "$HU_CMD" local "global deadline (${DEADLINE}s) exceeded"
  else
    tmo 60 cass search "cass search" --workspace "$WSKEY" --since "$WINDOW_SINCE" --until "$NOW" --json --fields minimal --limit 8 \
      > "$TMPD/hu.json" 2> "$TMPD/hu.err"; RC=$?
    if [ $RC -ne 0 ]; then
      ev_unknown jx-history-underused "history-usage probe failed" "$HU_CMD" local \
        "$( is_timeout $RC && echo 'timed out after 60s' || printf 'exit %s: %s' "$RC" "$(head -c 200 "$TMPD/hu.err")" )"
    else
      HN=$(python3 "$TMPD/parse_hits.py" "$TMPD/hu.json" | head -1 | cut -d' ' -f1)
      if [ "${HN:-0}" -lt 0 ] 2>/dev/null; then
        # parse_hits' "-1" sentinel: cass exited 0 but printed unparseable JSON
        ev_unknown jx-history-underused "history-usage probe failed" "$HU_CMD" local \
          "cass exited 0 but printed unparseable JSON: $(python3 "$TMPD/parse_hits.py" "$TMPD/hu.json" | sed -n 2p | head -c 160)"
      elif [ "${HN:-0}" -eq 0 ]; then
        ev_present jx-history-underused "" 2 "sessions exist but recent sessions do not consult cass history" "$HU_CMD" local \
          "workspace $WSKEY has indexed sessions; 0 'cass search' mentions in window $WINDOW_LABEL"
      else
        HF=$(python3 "$TMPD/parse_hits.py" "$TMPD/hu.json" | sed -n 2p)
        ev_absent jx-history-underused "$(printf '%s' "$HF" | cut -f1):$(printf '%s' "$HF" | cut -f2)@local" 2 \
          "recent sessions do consult cass history" "$HU_CMD" local "$HN mention(s) of 'cass search' in window $WINDOW_LABEL"
      fi
    fi
  fi
else
  UNK_SIGS="$BATTERY_SIGNALS,jx-history-underused"
  ev_unknown "$UNK_SIGS" "session batteries unknown: no confirmed cass workspace for this project" "$AGG_CMD" local \
    "no workspace bucket matched $TARGET or '$BASE'; battery absence claims require a confirmed workspace"
fi

# ------------------------------------------------------- skill-invocation scan
: > "$TMPD/already.tsv"
if [ $WS_CONFIRMED -eq 1 ]; then
  python3 -c '
import json, sys
cat = json.load(open(sys.argv[1], encoding="utf-8"))
al = json.load(open(sys.argv[2], encoding="utf-8")).get("aliases", {})
names = sorted({s["canonical_name"] for s in cat.get("skills", [])})
for n in names: print("%s\t%s" % (n, n))
for a in sorted(al):
    print("%s\t%s" % (a, al[a]))' "$CATALOG" "$ALIASES" > "$TMPD/scan.names" || : > "$TMPD/scan.names"
  SCAN_STOPPED=""
  while IFS=$'\t' read -r NAME CANON; do
    [ -n "$NAME" ] || continue
    if past_deadline; then SCAN_STOPPED=1; break; fi
    tmo 60 cass search "$NAME" --workspace "$WSKEY" --since "$WINDOW_SINCE" --until "$NOW" --json --fields minimal --limit 12 \
      < /dev/null > "$TMPD/sk.json" 2>/dev/null; RC=$?
    [ $RC -eq 0 ] || continue   # a failed per-name probe is silently skipped (summary signals unaffected)
    python3 "$TMPD/parse_hits.py" "$TMPD/sk.json" | awk -F'\t' -v name="$NAME" -v canon="$CANON" \
      'NR==1{split($0,a," "); n=a[1]; next} n>0 {print canon "\t" name "\t" $1 ":" $2 "@local"}' >> "$TMPD/already.tsv"
  done < "$TMPD/scan.names"
  [ -n "$SCAN_STOPPED" ] && echo "cass-juncture-mine: skill scan stopped at global deadline (${DEADLINE}s)" >&2
fi
# build already.json + one present record per mentioned skill
python3 - "$TMPD/already.tsv" "$ALREADY_OUT" "$WSKEY" "$WINDOW_SINCE" "$NOW" <<'PY' > "$TMPD/already.rec"
import json, sys
tsv, out, wskey, since, now = sys.argv[1:6]
tally = {}
for line in open(tsv, encoding="utf-8", errors="replace"):
    parts = line.rstrip("\n").split("\t")
    if len(parts) != 3:
        continue
    canon, name, ref = parts
    t = tally.setdefault(canon, {"mention_count": 0, "refs": [], "hosts": [], "aliases": set()})
    t["mention_count"] += 1
    if ref not in t["refs"]:
        t["refs"].append(ref)
    if "local" not in t["hosts"]:
        t["hosts"].append("local")
    if name != canon:
        t["aliases"].add(name)
obj = {k: {"mention_count": v["mention_count"], "refs": v["refs"][:12], "hosts": v["hosts"]}
       for k, v in tally.items()}
with open(out, "w", encoding="utf-8") as fh:
    fh.write(json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False) + "\n")
for canon in sorted(tally):
    t = tally[canon]
    refs = "; ".join(t["refs"][:3])
    via = (" (via former alias %s)" % ", ".join(sorted(t["aliases"]))) if t["aliases"] else ""
    cmd = 'cass search "%s" --workspace "%s" --since %s --until %s --json --fields minimal --limit 12' % (canon, wskey, since, now)
    detail = "%d mention(s); %s%s" % (t["mention_count"], refs, via)
    print("\x1f".join([canon, t["refs"][0] if t["refs"] else "", cmd, detail]))
PY
while IFS=$'\037' read -r CANON LOC CMD DET; do
  [ -n "$CANON" ] || continue
  emit present positive cass "$LOC" 2 "" "skill $CANON invoked/mentioned in sessions" "$CMD" local "$DET"
done < "$TMPD/already.rec"
[ -f "$ALREADY_OUT" ] || printf '{}\n' > "$ALREADY_OUT"

# ------------------------------------------------------------------- remote
if [ $HOSTS_GIVEN -eq 0 ]; then HOSTS="${SKILL_SELECTION_CASS_HOSTS:-}"; fi
if [ $HOSTS_GIVEN -eq 0 ] && [ -z "$HOSTS" ]; then
  tmo 60 cass sources list --json > "$TMPD/sources.json" 2>/dev/null && \
    HOSTS=$(python3 -c '
import json, sys
try: d = json.load(open(sys.argv[1], encoding="utf-8"))
except Exception: sys.exit(0)
print(" ".join(sorted(s.get("name", "") for s in d.get("sources", []) if s.get("name"))))' "$TMPD/sources.json")
fi
if [ $HOSTS_GIVEN -eq 1 ] && [ -z "$(printf '%s' "$HOSTS" | tr -d ' ')" ]; then
  ev_fact "remote session mining skipped: --hosts empty (local only)" "" "" local "caller requested local-only mining"
elif [ -z "$(printf '%s' "$HOSTS" | tr -d ' ')" ]; then
  ev_unknown "$BATTERY_SIGNALS" "remote sources unknown: none configured" "cass sources list --json" "" \
    "no --hosts, \$SKILL_SELECTION_CASS_HOSTS empty, and cass sources list returned no sources"
else
  HOST_BUDGET=120
  i=0
  for H in $HOSTS; do
    i=$((i + 1))
    # A host token is passed to ssh in argument position: a leading dash would be parsed
    # as an ssh option (-oProxyCommand=... executes a local command), so only plain
    # ssh destinations ([user@]host of letters/digits/._-) are accepted; anything else
    # is recorded as one unknown, never executed.
    case "$H" in
      -*|*[!A-Za-z0-9._@-]*)
        ev_unknown "$BATTERY_SIGNALS" "remote host name rejected (not a plain ssh destination)" \
          "ssh -o ConnectTimeout=5 -o BatchMode=yes <host> 'cass search ... --json'" "$H" \
          "host token rejected before ssh: allowed characters are letters, digits, . _ - @, with no leading dash"
        continue;;
    esac
    (
      REC="$TMPD/host.$i.rec"; : > "$REC"
      HSTART=$SECONDS; FAILED=""
      HITS_TOTAL=0
      while IFS= read -r line; do
        sig=${line%%|*}; rest=${line#*|}; rmt=${rest%%|*}; terms=${rest#*|}
        [ "$rmt" = "R" ] || continue
        [ -n "$FAILED" ] && continue
        if [ $((SECONDS - HSTART)) -ge $HOST_BUDGET ]; then FAILED="per-host budget (${HOST_BUDGET}s) exceeded"; continue; fi
        QUERY="$BASE $(printf '%s' "$terms" | tr '|' ' ')"
        RCMD="ssh -o ConnectTimeout=5 -o BatchMode=yes $H 'IFS= read -r q && cass search \"\$q\" --json --fields minimal --limit 20 --days $DAYS' <<< \"$QUERY\""
        tmo 60 ssh -o ConnectTimeout=5 -o BatchMode=yes "$H" \
          'IFS= read -r q && cass search "$q" --json --fields minimal --limit 20 --days '"$DAYS" \
          <<< "$QUERY" > "$TMPD/host.$i.json" 2> "$TMPD/host.$i.err"; RC=$?
        if [ $RC -ne 0 ]; then
          FAILED="$( is_timeout $RC && echo "timed out after 60s (battery $sig)" || printf 'ssh/cass exit %s (battery %s): %s' "$RC" "$sig" "$(head -c 160 "$TMPD/host.$i.err" | tr '\n' ' ')" )"
          continue
        fi
        N=$(python3 "$TMPD/parse_hits.py" "$TMPD/host.$i.json" | head -1 | cut -d' ' -f1)
        if [ "${N:-0}" -gt 0 ]; then
          HITS_TOTAL=$((HITS_TOTAL + N))
          FIRST=$(python3 "$TMPD/parse_hits.py" "$TMPD/host.$i.json" | sed -n 2p)
          LOC="$(printf '%s' "$FIRST" | cut -f1):$(printf '%s' "$FIRST" | cut -f2)@$H"
          DET=$(python3 "$TMPD/parse_hits.py" "$TMPD/host.$i.json" | sed '1d' | head -3 | awk -F'\t' -v h="$H" '{printf "%s:%s@%s; ", $1, $2, h}')
          ev_present "$sig" "$LOC" 2 "sessions on $H match the $sig battery ($N hits, last ${DAYS}d)" "$RCMD" "$H" "$DET"
        fi
      done <<EOF_RBAT
$BATTERIES
EOF_RBAT
      if [ -n "$FAILED" ]; then
        ev_unknown "$BATTERY_SIGNALS" "remote host $H unavailable for session mining" \
          "ssh -o ConnectTimeout=5 -o BatchMode=yes $H 'cass search ... --json'" "$H" "$FAILED"
      elif [ "$HITS_TOTAL" -eq 0 ]; then
        ev_unknown "" "no error-battery matches on $H (workspace mapping unconfirmed on that host)" \
          "ssh -o ConnectTimeout=5 -o BatchMode=yes $H 'cass search ... --json'" "$H" \
          "0 hits for basename-scoped queries; the project may live under a different root there"
      fi
    ) &
  done
  wait
  j=1
  while [ $j -le $i ]; do
    [ -f "$TMPD/host.$j.rec" ] && cat "$TMPD/host.$j.rec" >> "$REC"
    j=$((j + 1))
  done
fi

finalize
