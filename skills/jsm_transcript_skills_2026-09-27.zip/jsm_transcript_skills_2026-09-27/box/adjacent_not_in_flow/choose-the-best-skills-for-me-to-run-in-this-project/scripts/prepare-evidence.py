#!/usr/bin/env python3
"""Build the canonical evidence set, reloading durable profile facts on reuse.

Full-profile runs pass every detector file via repeated ``--current`` arguments.
Reuse runs additionally pass ``--profile-reused --analysis-doc FILE``; profile facts
are then taken from the analysis document's embedded canonical block, while current
juncture facts replace stale juncture facts. This makes the reuse branch executable
without retaining a temporary workspace from the previous run.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import skillsel_common as slib  # noqa: E402

PROFILE_RE = re.compile(r"<!-- skill-selection:profile-evidence:v1\n(.*?)\n-->", re.S)


def embedded_profile(path: Path) -> list[dict]:
    match = PROFILE_RE.search(path.read_text(encoding="utf-8"))
    if not match:
        raise ValueError(f"{path}: missing skill-selection:profile-evidence:v1 block")
    rows = json.loads(match.group(1))
    if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
        raise ValueError(f"{path}: profile evidence block must be a JSON array of objects")
    if any(row.get("kind") != "profile" for row in rows):
        raise ValueError(f"{path}: profile evidence block contains non-profile records")
    return rows


def prepare(current_paths: list[str], analysis_doc: str | None, reused: bool) -> list[dict]:
    current: list[dict] = []
    for path in current_paths:
        rows = slib.load_json(path)
        if not isinstance(rows, list):
            raise ValueError(f"{path}: evidence input must be an array")
        current.extend(rows)
    if reused:
        if not analysis_doc:
            raise ValueError("--profile-reused requires --analysis-doc")
        rows = embedded_profile(Path(analysis_doc)) + [r for r in current if r.get("kind") != "profile"]
    else:
        rows = current
        if not any(r.get("kind") == "profile" for r in rows):
            raise ValueError("full-profile evidence contains no profile records")
    slib.active_evidence(rows)
    return sorted(rows, key=lambda r: r["id"])


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--current", action="append", default=[], required=True)
    ap.add_argument("--analysis-doc")
    ap.add_argument("--profile-reused", action="store_true")
    ap.add_argument("--out", required=True)
    args = ap.parse_args(argv)
    try:
        rows = prepare(args.current, args.analysis_doc, args.profile_reused)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"prepare-evidence: {exc}", file=sys.stderr)
        return 2
    slib.write_json(args.out, rows)
    print(f"prepared {len(rows)} evidence records")
    return 0


if __name__ == "__main__":
    sys.exit(main())
