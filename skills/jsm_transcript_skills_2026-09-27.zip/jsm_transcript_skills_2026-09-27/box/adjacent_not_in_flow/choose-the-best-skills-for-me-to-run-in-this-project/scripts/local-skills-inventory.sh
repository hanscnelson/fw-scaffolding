#!/usr/bin/env bash
# local-skills-inventory.sh — enumerate every locally installed skill as catalog entries.
#
# Usage: bash local-skills-inventory.sh [--target DIR] [--map FILE] --out FILE
#
# Output: a JSON array of catalog-entry objects (references/schemas/catalog-entry.schema.json),
#   deduped by canonical name (aliases.json canonicalizes former names), sorted by
#   canonical_name, written to --out (or stdout when --out is "-").
#
# Directory enumeration order (= dedupe precedence; the FIRST copy of a name wins):
#   1. target-project-local: <target>/.claude/skills and <target>/.agents/skills (--target only)
#   2. the running harness's user dir: $CLAUDE_CONFIG_DIR/skills (else $HOME/.claude/skills)
#      when a CLAUDECODE/CLAUDE_CODE* env var is present; $CODEX_HOME/skills when CODEX_HOME
#      is present. Codex plugin cache trees are searched recursively for skill roots. When no
#      harness is detectable, jsm's .values.skills_dir is the primary.
#   3. every directory from `jsm config show --json`: .values.skills_dir then
#      .values.skills.{claude_dir,codex_dir,gemini_dir,cursor_dir,openclaw_dir,hermes_dir}
#      (nulls skipped)
#   4. $HOME/.agents/skills
#   No-jsm fallback: when `jsm` is absent, step 3 is replaced by the literal list
#   $HOME/.claude/skills $HOME/.codex/skills $HOME/.gemini/skills $HOME/.cursor/skills
#   $HOME/.agents/skills.
#   Later copies of a name whose content hash differs from the winner's are recorded in the
#   winner's `skew` array; byte-identical copies are ignored.
#
# Entry fields: canonical_name, catalog_sources ["local"], installed true, resolved_path,
#   description/use_when/tags/detect_rules from SKILL.md front matter, category null, packs [],
#   empty related groups, provisional_mapping true unless an explicit map entry exists,
#   updated_at null, content_hash = sha256 of every sorted relative path and every file's bytes.
#
# Read-only toward everything except --out. Exit codes: 0 = a schema-valid array was written;
#   1 = bad arguments, missing helper, or the output failed schema validation.
# Determinism: same skill trees => byte-identical output (sorted names, stable hash, no clock).
# Portability: bash 3.2+, python3 (stdlib only); optional jsm (queried with timeout 30).
set -uo pipefail

TARGET=""; OUT=""; MAP=""
while [ $# -gt 0 ]; do
  case "$1" in
    --target) TARGET="$2"; shift 2;;
    --out) OUT="$2"; shift 2;;
    --map) MAP="$2"; shift 2;;
    -h|--help) sed -n '2,33p' "$0"; exit 0;;
    *) echo "unknown arg: $1" >&2; exit 1;;
  esac
done
[ -n "$OUT" ] || { echo "--out FILE is required (use - for stdout)" >&2; exit 1; }
SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)
ALIASES="$SCRIPT_DIR/../references/data/aliases.json"
[ -n "$MAP" ] || MAP="$SCRIPT_DIR/../references/data/signal-to-skill-map.json"
if [ -n "$TARGET" ]; then
  TARGET=$(cd "$TARGET" 2>/dev/null && pwd -P) || { echo "target not found: $TARGET" >&2; exit 1; }
fi
[ -n "$TARGET" ] && [ -f "$TARGET/AGENTS.md" ] && grep -Eqi 'NO FILE DELETION|NEVER (ALLOWED TO )?DELETE' "$TARGET/AGENTS.md" && export SKILL_SELECTION_KEEP_TEMP=1
if [ "$OUT" != "-" ]; then case "$OUT" in /*) ;; *) OUT="$PWD/$OUT";; esac; fi

TMPD=$(mktemp -d "${TMPDIR:-/tmp}/skillsel-inventory.XXXXXX") || { echo "mktemp failed" >&2; exit 1; }
cleanup() {
  if [ "${SKILL_SELECTION_KEEP_TEMP:-0}" = 1 ]; then
    echo "local-skills-inventory: kept temporary workspace $TMPD" >&2
    return
  fi
  rm -f "$TMPD"/* 2>/dev/null; rmdir "$TMPD" 2>/dev/null
}
trap cleanup EXIT
TMO_BIN=""
if command -v timeout >/dev/null 2>&1; then TMO_BIN=timeout; elif command -v gtimeout >/dev/null 2>&1; then TMO_BIN=gtimeout; fi
tmo() { local s="$1"; shift
  if [ -n "$TMO_BIN" ]; then "$TMO_BIN" "$s" "$@"
  elif command -v perl >/dev/null 2>&1; then perl -e 'alarm shift; exec @ARGV' "$s" "$@"
  else "$@"; fi
}

# ------------------------------------------------- candidate dirs, in precedence order
DIRS="$TMPD/dirs"; : > "$DIRS"
add_dir() { [ -n "${1:-}" ] && [ "$1" != "null" ] && printf '%s\n' "$1" >> "$DIRS"; }

# 1. target-project-local
if [ -n "$TARGET" ]; then
  add_dir "$TARGET/.claude/skills"
  add_dir "$TARGET/.agents/skills"
fi

# 2. the running harness's user dir
HARNESS_DETECTED=0
if [ -n "${CLAUDECODE:-}" ] || env | grep -q '^CLAUDE_CODE' 2>/dev/null; then
  HARNESS_DETECTED=1
  add_dir "${CLAUDE_CONFIG_DIR:-$HOME/.claude}/skills"
fi
if [ -n "${CODEX_HOME:-}" ]; then
  HARNESS_DETECTED=1
  add_dir "$CODEX_HOME/skills"
fi
# Codex plugin bundles are also skill roots and may be nested below provider/site/version.
CODEX_PLUGIN_ROOT="${CODEX_HOME:-$HOME/.codex}/plugins/cache"
if [ -d "$CODEX_PLUGIN_ROOT" ]; then
  find "$CODEX_PLUGIN_ROOT" -type d -name skills -print 2>/dev/null | LC_ALL=C sort >> "$DIRS"
fi

# 3. jsm-managed dirs (or the no-jsm literal fallback list)
if command -v jsm >/dev/null 2>&1 && tmo 30 jsm config show --json > "$TMPD/jsm.json" 2>/dev/null; then
  # skills_dir first: it is the primary when the harness is undetectable
  python3 -c '
import json, sys
try: v = json.load(open(sys.argv[1], encoding="utf-8")).get("values", {})
except Exception: sys.exit(0)
dirs = [v.get("skills_dir")]
sk = v.get("skills") or {}
for k in ("claude_dir", "codex_dir", "gemini_dir", "cursor_dir", "openclaw_dir", "hermes_dir"):
    dirs.append(sk.get(k))
for d in dirs:
    if d: print(d)' "$TMPD/jsm.json" >> "$DIRS"
else
  for d in "$HOME/.claude/skills" "$HOME/.codex/skills" "$HOME/.gemini/skills" "$HOME/.cursor/skills" "$HOME/.agents/skills"; do
    add_dir "$d"
  done
fi

# 4. ~/.agents/skills last
add_dir "$HOME/.agents/skills"
: "$HARNESS_DETECTED"   # informational; when 0, jsm skills_dir leads step 3 and is the primary

# ---------------------------------------------- walk, hash, dedupe, validate (python)
python3 - "$DIRS" "$ALIASES" "$MAP" "$SCRIPT_DIR" "$TMPD/out.json" <<'PY'
import hashlib, json, os, sys
dirs_file, aliases_path, map_path, script_dir, out_path = sys.argv[1:6]
sys.path.insert(0, script_dir)
import skillsel_common as slib

aliases = {}
try:
    aliases = slib.load_json(aliases_path).get("aliases", {})
except Exception:
    pass
try:
    mapped_skills = set(slib.load_json(map_path).get("skills", {}))
except Exception:
    mapped_skills = set()

seen_real = set()
ordered_dirs = []
for line in open(dirs_file, encoding="utf-8"):
    d = line.strip()
    if not d or not os.path.isdir(d):
        continue
    real = os.path.realpath(d)
    if real in seen_real:
        continue
    seen_real.add(real)
    ordered_dirs.append(real)

def content_hash(skill_dir):
    """sha256 over every sorted relative path and every file byte."""
    files = []
    for root, dnames, fnames in os.walk(skill_dir):
        dnames[:] = sorted(x for x in dnames if x not in (".git", "__pycache__"))
        for f in fnames:
            if f == ".DS_Store" or f.startswith("._"):
                continue
            files.append(os.path.relpath(os.path.join(root, f), skill_dir))
    h = hashlib.sha256()
    for rel in sorted(files):
        encoded = rel.replace(os.sep, "/").encode("utf-8")
        try:
            data = open(os.path.join(skill_dir, rel), "rb").read()
        except OSError:
            data = b""
        h.update(len(encoded).to_bytes(8, "big")); h.update(encoded)
        h.update(len(data).to_bytes(8, "big")); h.update(data)
    return "sha256:" + h.hexdigest()

def as_str_list(v):
    if isinstance(v, list):
        return [str(x) for x in v if isinstance(x, (str, int, float))]
    if isinstance(v, str) and v.strip():
        return [t.strip() for t in v.split(",") if t.strip()]
    return []

def valid_detect_rules(v):
    out = []
    if isinstance(v, list):
        for r in v:
            if isinstance(r, dict) and isinstance(r.get("pattern"), str) \
               and r.get("engine") in ("frankensearch", "ast-grep"):
                out.append(r)
    return out

entries = {}   # canonical_name -> entry
order = {}     # canonical_name -> discovery index of the winner (for reporting only)
idx = 0
for d in ordered_dirs:
    try:
        children = sorted(os.listdir(d))
    except OSError:
        continue
    for child in children:
        if child.startswith("."):
            continue
        sd = os.path.join(d, child)
        smd = os.path.join(sd, "SKILL.md")
        if not os.path.isdir(sd) or not os.path.isfile(smd):
            continue
        idx += 1
        try:
            fm = slib.parse_frontmatter(open(smd, encoding="utf-8", errors="replace").read())
        except Exception:
            fm = {}
        name = fm.get("name") if isinstance(fm.get("name"), str) and fm.get("name") else child
        name = name.strip().lower()
        canonical = aliases.get(name, name)
        chash = content_hash(sd)
        if canonical in entries:
            e = entries[canonical]
            if chash != e["content_hash"]:
                e.setdefault("skew", []).append({"path": sd, "content_sha256": chash})
            continue
        desc = fm.get("description") if isinstance(fm.get("description"), str) else ""
        tags = as_str_list(fm.get("compatibilityTags") or fm.get("compatibility_tags") or fm.get("tags"))
        entries[canonical] = {
            "canonical_name": canonical,
            "catalog_sources": ["local"],
            "installed": True,
            "resolved_path": sd,
            "skew": [],
            "description": desc or "",
            "use_when": slib.extract_use_when(desc or ""),
            "tags": sorted(set(tags)),
            "category": None,
            "packs": [],
            "related": {"pairs_with": [], "alternative_to": [], "extends": [], "prerequisite": []},
            "detect_rules": valid_detect_rules(fm.get("detect")),
            "provisional_mapping": canonical not in mapped_skills,
            "updated_at": None,
            "content_hash": chash,
        }
        order[canonical] = idx

rows = [entries[k] for k in sorted(entries)]
with open(out_path, "w", encoding="utf-8") as fh:
    fh.write(slib.canonical_json(rows))

schema_path = os.path.join(script_dir, "..", "references", "schemas", "catalog-entry.schema.json")
errs = []
schema = slib.load_json(schema_path)
base = os.path.dirname(os.path.abspath(schema_path))
from pathlib import Path
for i, row in enumerate(rows):
    errs.extend(slib.validate_against(row, schema, Path(base), "$[%d]" % i))
if errs:
    for e in errs:
        sys.stderr.write(e + "\n")
    sys.stderr.write("local-skills-inventory: output failed schema validation\n")
    sys.exit(1)
skew_n = sum(len(e["skew"]) for e in rows)
sys.stderr.write("local-skills-inventory: %d skills across %d dirs (%d skewed copies)\n"
                 % (len(rows), len(ordered_dirs), skew_n))
PY
RC=$?
[ $RC -eq 0 ] || exit 1
if [ "$OUT" = "-" ]; then cat "$TMPD/out.json"; else cp "$TMPD/out.json" "$OUT" && echo "local-skills-inventory: wrote $OUT" >&2; fi
exit 0
