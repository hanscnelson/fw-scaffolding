#!/usr/bin/env bash
# profile-project.sh — deterministic PROFILE detector for the skill-selection package.
#
# Usage: bash profile-project.sh --target DIR [--scope PATH[,PATH...]] --out FILE [--max-files N]
#
# Output: a JSON array of evidence records (references/schemas/evidence.schema.json) with ids
#   ev-p0001.. in emission order, written to --out (or stdout when --out is "-"), plus a one-line
#   summary on stderr. Every record is one of present | absent-with-positive-evidence | unknown.
#   A missing tool, a timeout, or a failed command yields unknown (never absent) with the error
#   text in `detail`. Absence claims about code kinds are only made after generated/vendored
#   paths were identified and excluded (the code-generated-or-vendored-excluded record).
#
# Read-only toward the target: nothing under --target is created, modified, or deleted.
# Exit codes: 0 = a schema-valid array was written; 1 = bad arguments, target/helper missing,
#   the file inventory failed or timed out (the substrate for every absence claim — the caller
#   records the phase as unknown), or the output failed schema validation. Individual detector
#   failures never abort the run.
#
# Determinism: same tree + same SKILL_SELECTION_NOW => byte-identical output (sorted scans,
#   sequential ids, observed_at = pinned clock, no temp names in the output).
# Portability: bash 3.2+ (no associative arrays/mapfile), BSD or GNU find/sed/stat, rg with a
#   grep -rE fallback, shasum -a 256 with a sha256sum fallback, timeout/gtimeout/perl-alarm.
# External deps: bash, git, rg (optional), python3 (stdlib only), optional gh/cargo/npm.
set -uo pipefail
set -f   # no pathname expansion: glob strings like '*.rs' and 'legacy*' are passed to rg/grep literally

TARGET="."; SCOPE="."; OUT=""; MAX_FILES=20000
while [ $# -gt 0 ]; do
  case "$1" in
    --target) TARGET="$2"; shift 2;;
    --scope) SCOPE="$2"; shift 2;;
    --out) OUT="$2"; shift 2;;
    --max-files) MAX_FILES="$2"; shift 2;;
    -h|--help) sed -n '2,23p' "$0"; exit 0;;
    *) echo "unknown arg: $1" >&2; exit 1;;
  esac
done
[ -n "$OUT" ] || { echo "--out FILE is required (use - for stdout)" >&2; exit 1; }
SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)
SCHEMA="$SCRIPT_DIR/../references/schemas/evidence.schema.json"
TARGET=$(cd "$TARGET" 2>/dev/null && pwd -P) || { echo "target not found: $TARGET" >&2; exit 1; }
[ -f "$TARGET/AGENTS.md" ] && grep -Eqi 'NO FILE DELETION|NEVER (ALLOWED TO )?DELETE' "$TARGET/AGENTS.md" && export SKILL_SELECTION_KEEP_TEMP=1
if [ "$OUT" != "-" ]; then case "$OUT" in /*) ;; *) OUT="$PWD/$OUT";; esac; fi
NOW=$(python3 "$SCRIPT_DIR/skillsel_common.py" now) || { echo "python3 helper failed" >&2; exit 1; }
KIND=profile; ID_PREFIX=p

# --scope: comma-separated paths relative to the target ("." = whole target).
SCOPES=(); IFS=',' read -r -a SCOPES_RAW <<< "$SCOPE"
for s in "${SCOPES_RAW[@]}"; do
  s="${s%/}"; [ -z "$s" ] && s="."; case "$s" in ./*) s="${s#./}";; esac; [ -z "$s" ] && s="."
  SCOPES+=("$s")
done
[ "${#SCOPES[@]}" -gt 0 ] || SCOPES=(.)

TMPD=$(mktemp -d "${TMPDIR:-/tmp}/skillsel-profile.XXXXXX") || { echo "mktemp failed" >&2; exit 1; }
cleanup() {
  if [ "${SKILL_SELECTION_KEEP_TEMP:-0}" = 1 ]; then
    echo "profile-project: kept temporary workspace $TMPD" >&2
    return
  fi
  (set +f; rm -f "$TMPD"/* 2>/dev/null); rmdir "$TMPD" 2>/dev/null
}
trap cleanup EXIT
: > "$TMPD/records"; : > "$TMPD/states"
cd "$TARGET" || exit 1

# ------------------------------------------------------------------ helpers
TMO_BIN=""
if command -v timeout >/dev/null 2>&1; then TMO_BIN=timeout; elif command -v gtimeout >/dev/null 2>&1; then TMO_BIN=gtimeout; fi
tmo() { # tmo SECONDS cmd args...  (124/142 = timed out)
  local s="$1"; shift
  if [ -n "$TMO_BIN" ]; then "$TMO_BIN" "$s" "$@"
  elif command -v perl >/dev/null 2>&1; then perl -e 'alarm shift; exec @ARGV' "$s" "$@"
  else "$@"; fi
}
is_timeout() { [ "$1" = 124 ] || [ "$1" = 142 ]; }
sha_file() { if command -v shasum >/dev/null 2>&1; then shasum -a 256 "$1" | cut -d' ' -f1; else sha256sum "$1" | cut -d' ' -f1; fi; }
HAVE_RG=0; command -v rg >/dev/null 2>&1 && HAVE_RG=1
HAVE_GIT=0; command -v git >/dev/null 2>&1 && HAVE_GIT=1

IS_GIT=false; HEAD_FULL=""; SHA=worktree; REPO_HEAD=""; BRANCH=""
if [ $HAVE_GIT = 1 ] && git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  IS_GIT=true
  HEAD_FULL=$(git rev-parse HEAD 2>/dev/null || true)
  if [ -n "$HEAD_FULL" ]; then SHA=$(git rev-parse --short HEAD 2>/dev/null || echo worktree); REPO_HEAD="$HEAD_FULL"; fi
  BRANCH=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || true)
fi

# Record accumulator: one record per line, fields separated by US (0x1f); the finalizer assigns ids.
# emit STATE POLARITY SOURCE LOCATOR CONF SIGNALS CLAIM COMMAND DETAIL
emit() {
  printf '%s\037%s\037%s\037%s\037%s\037%s\037%s\037%s\037%s\n' "$1" "$2" "$3" "$4" "$5" "$6" "$7" "$8" "$(printf '%s' "$9" | tr '\n\r\037' '   ')" >> "$TMPD/records"
  local s; for s in $(printf '%s' "$6" | tr ',' ' '); do printf '%s\t%s\t%s\n' "$s" "$1" "$4" >> "$TMPD/states"; done
}
ev_present() { emit present positive "$2" "$3" "$4" "$1" "$5" "$6" "$7"; }                     # signals src loc conf claim cmd detail
ev_absent()  { emit absent-with-positive-evidence negative "$2" "$3" "$4" "$1" "$5" "$6" "$7"; }
ev_unknown() { emit unknown positive "$2" "" 0 "$1" "$3" "$4" "$5"; }                             # signals src claim cmd detail
ev_fact()    { emit present positive "$2" "$3" 4 "" "$1" "$4" "$5"; }                            # claim src loc cmd detail
sig_state()  { awk -F'\t' -v s="$1" '$1==s{st=$2} END{print (st==""?"unknown":st)}' "$TMPD/states"; }
sig_loc()    { awk -F'\t' -v s="$1" '$1==s{l=$3} END{print l}' "$TMPD/states"; }
loc() { if [ -n "${2:-}" ]; then printf '%s@%s:%s' "$1" "$SHA" "$2"; else printf '%s@%s' "$1" "$SHA"; fi; }
loc_of_match() { # "path:line:text" -> path@sha:line
  local p l; p=$(printf '%s' "$1" | cut -d: -f1); l=$(printf '%s' "$1" | cut -d: -f2); loc "$p" "$l"
}
snippet() { printf '%s' "$1" | cut -d: -f3- | tr -d '\000-\010\013-\037' | cut -c1-110; }
first_existing() { # first_existing NAME... -> relative path of the first that exists in root or a scope root
  local s n
  for s in . "${SCOPES[@]}"; do for n in "$@"; do
    if [ "$s" = "." ]; then [ -e "$n" ] && { printf '%s' "$n"; return 0; }; else [ -e "$s/$n" ] && { printf '%s' "$s/$n"; return 0; }; fi
  done; done; return 1
}
kv() { awk -F'\t' -v k="$1" '$1==k{print substr($0, length(k)+2)}' "$2"; }
days_since() { python3 -c 'import sys,datetime as d
def p(s):
    s=s.strip()
    if s.endswith("Z"): s=s[:-1]+"+00:00"
    x=d.datetime.fromisoformat(s)
    return x if x.tzinfo else x.replace(tzinfo=d.timezone.utc)
print(int((p(sys.argv[2])-p(sys.argv[1])).total_seconds()//86400))' "$1" "$NOW" 2>/dev/null || echo ""; }

# ---------------------------------------------------- generated/vendored exclusions
EXCL_DIRS="target node_modules vendor dist build .git third_party upstream legacy* .next __pycache__ .venv venv coverage .beads .doctor"
EXCL_FILES="*.generated.* *.min.js *.min.css *.pb.go *_pb2.py Cargo.lock package-lock.json pnpm-lock.yaml yarn.lock bun.lockb bun.lock poetry.lock uv.lock go.sum Gemfile.lock composer.lock"
TEST_DIRS="tests test spec specs __tests__ e2e benches bench fuzz testdata fixtures __snapshots__"
TEST_FILES="*_test.* *.test.* *.spec.* test_*.py *_tests.rs tests.rs test.rs"
LINGUIST=""
for s in . "${SCOPES[@]}"; do
  f="$s/.gitattributes"; [ "$s" = "." ] && f=".gitattributes"
  [ -f "$f" ] && LINGUIST="$LINGUIST $(grep -E 'linguist-(generated|vendored)(=true)?([[:space:]]|$)' "$f" 2>/dev/null | grep -v '^#' | awk '{print $1}' | tr '\n' ' ')"
done
LINGUIST=$(printf '%s' "$LINGUIST" | tr ' ' '\n' | grep -v '^$' | LC_ALL=C sort -u | tr '\n' ' ')
RG_EXCL=(); for d in $EXCL_DIRS; do RG_EXCL+=(-g "!$d/"); done; for f in $EXCL_FILES; do RG_EXCL+=(-g "!$f"); done
for f in $LINGUIST; do RG_EXCL+=(-g "!$f"); done
RG_TEST=(); for d in $TEST_DIRS; do RG_TEST+=(-g "!$d/"); done; for f in $TEST_FILES; do RG_TEST+=(-g "!$f"); done
CODE_GLOBS='*.rs *.py *.ts *.tsx *.js *.jsx *.mjs *.cjs *.go *.c *.cc *.cpp *.cxx *.h *.hpp *.hh *.zig *.swift *.kt *.kts *.java *.rb *.sh *.bash *.zsh *.cu *.cuh *.metal *.wgsl *.cl *.cs *.ex *.exs *.lua *.dart *.vue *.svelte *.astro *.php *.scala *.hs *.ml'
EXCL_NOTE="generated/vendored paths excluded (see code-generated-or-vendored-excluded)"

# rg_lines PATTERN NONTEST [include globs...] -> sorted "path:line:text"; sets RG_RC (0 hit, 1 none, 2 error, 124 timeout)
RG_RC=1; RG_CMD=""
rg_lines() {
  local pat="$1" nontest="$2"; shift 2
  local inc=() x; for x in "$@"; do inc+=(-g "$x"); done
  local tst=(); [ "$nontest" = 1 ] && tst=("${RG_TEST[@]}")
  RG_CMD="rg -n --hidden -e '$pat'${1:+ -g '$*'} <generated/vendored exclusions>${nontest:+ <test-path exclusions>} -- ${SCOPES[*]}"
  if [ $HAVE_RG = 1 ]; then
    tmo 60 rg -n --no-messages --no-require-git --hidden --max-columns 200 --max-columns-preview -e "$pat" \
      ${inc[@]+"${inc[@]}"} "${RG_EXCL[@]}" ${tst[@]+"${tst[@]}"} -- "${SCOPES[@]}" > "$TMPD/rg.out" 2> "$TMPD/rg.err"; RG_RC=$?
  else
    RG_CMD="grep -rEn (rg fallback) -e '$pat' ... -- ${SCOPES[*]}"
    local ex=() d; for d in $EXCL_DIRS; do ex+=(--exclude-dir="$d"); done; for d in $EXCL_FILES $LINGUIST; do ex+=(--exclude="$d"); done
    if [ "$nontest" = 1 ]; then for d in $TEST_DIRS; do ex+=(--exclude-dir="$d"); done; for d in $TEST_FILES; do ex+=(--exclude="$d"); done; fi
    local gi=(); for x in "$@"; do gi+=(--include="${x##*/}"); done
    tmo 60 grep -rEn ${gi[@]+"${gi[@]}"} "${ex[@]}" -e "$pat" -- "${SCOPES[@]}" > "$TMPD/rg.out" 2> "$TMPD/rg.err"; RG_RC=$?
    [ "$RG_RC" -gt 2 ] && ! is_timeout "$RG_RC" && RG_RC=2
  fi
  [ "$RG_RC" = 2 ] && [ -s "$TMPD/rg.out" ] && RG_RC=0
  sed 's#^\./##' "$TMPD/rg.out" | LC_ALL=C sort -t: -k1,1 -k2,2n
}
# scan_signal SIGNAL NONTEST CONF MIN "NOUN PHRASE" "PATTERN" [include globs...]  (default globs = code files)
scan_signal() {
  local sig="$1" nontest="$2" conf="$3" min="$4" noun="$5" pat="$6"; shift 6
  local out n files first
  if [ $# -gt 0 ]; then out=$(rg_lines "$pat" "$nontest" "$@"); else out=$(rg_lines "$pat" "$nontest" $CODE_GLOBS); fi
  local rc=$RG_RC
  if is_timeout "$rc"; then ev_unknown "$sig" file "$noun: scan timed out" "$RG_CMD" "timeout after 60s"; return; fi
  if [ "$rc" = 2 ]; then ev_unknown "$sig" file "$noun: scan failed" "$RG_CMD" "$(head -c 300 "$TMPD/rg.err")"; return; fi
  n=$(printf '%s\n' "$out" | grep -c . ); files=$(printf '%s\n' "$out" | cut -d: -f1 | LC_ALL=C sort -u | grep -c .)
  if [ "$n" -ge "$min" ] && [ "$n" -gt 0 ]; then
    first=$(printf '%s\n' "$out" | head -1)
    ev_present "$sig" file "$(loc_of_match "$first")" "$conf" "$noun present" "$RG_CMD" "$n matches in $files files ($EXCL_NOTE${nontest:+; test paths excluded}); e.g. $(printf '%s' "$first" | cut -d: -f1,2): $(snippet "$first")"
  else
    ev_absent "$sig" file "" "$conf" "$noun absent" "$RG_CMD" "$n matches (threshold $min) $EXCL_NOTE${nontest:+; test paths excluded}"
  fi
}

# ------------------------------------------------------------------ inventory
# File list: git ls-files (tracked + untracked-not-ignored) when git, else find. Paths are relative to the target.
INV_CMD=""
if $IS_GIT; then
  INV_CMD="git ls-files -z --cached --others --exclude-standard -- ${SCOPES[*]}"
  tmo 60 git ls-files -z --cached --others --exclude-standard -- "${SCOPES[@]}" > "$TMPD/all0" 2>/dev/null; INV_RC=$?
else
  INV_CMD="find ${SCOPES[*]} -type f (excluding .git/node_modules/target/vendor/dist/build/third_party)"
  tmo 60 find "${SCOPES[@]}" -type f -not -path '*/.git/*' -not -path '*/node_modules/*' -not -path '*/target/*' \
    -not -path '*/vendor/*' -not -path '*/dist/*' -not -path '*/build/*' -not -path '*/third_party/*' -print0 > "$TMPD/all0" 2>/dev/null; INV_RC=$?
fi
# Inventory is the substrate for every absence claim below. A failed-and-empty git listing is
# retried with find; a still-empty failure or a timeout (truncated listing) aborts with exit 1
# rather than fabricating absent-with-positive-evidence records from a missing inventory.
if $IS_GIT && [ "${INV_RC:-1}" != 0 ] && [ ! -s "$TMPD/all0" ]; then
  INV_CMD="find ${SCOPES[*]} -type f (git ls-files failed: exit $INV_RC)"
  tmo 60 find "${SCOPES[@]}" -type f -not -path '*/.git/*' -not -path '*/node_modules/*' -not -path '*/target/*' \
    -not -path '*/vendor/*' -not -path '*/dist/*' -not -path '*/build/*' -not -path '*/third_party/*' -print0 > "$TMPD/all0" 2>/dev/null; INV_RC=$?
fi
if is_timeout "${INV_RC:-0}" || { [ "${INV_RC:-1}" != 0 ] && [ ! -s "$TMPD/all0" ]; }; then
  echo "profile-project: file inventory failed (exit ${INV_RC:-?}); refusing to emit absence claims without an inventory — record this phase as unknown" >&2
  exit 1
fi
printf '%s\n' $LINGUIST > "$TMPD/linguist"
python3 - "$TMPD" "$MAX_FILES" <<'PY'
import sys, os, re, json
tmpd, max_files = sys.argv[1], int(sys.argv[2])
raw = open(os.path.join(tmpd, 'all0'), 'rb').read().split(b'\0')
paths = sorted(set(p.decode('utf-8', 'surrogateescape') for p in raw if p))
paths = [p[2:] if p.startswith('./') else p for p in paths]
EXCL_DIR = re.compile(r'(^|/)(target|node_modules|vendor|dist|build|\.git|third_party|upstream|legacy[^/]*|\.next|__pycache__|\.venv|venv|coverage|\.beads|\.doctor)/')
EXCL_FILE = re.compile(r'(\.generated\.|\.min\.(js|css)$|\.pb\.go$|_pb2\.py$|(^|/)(Cargo\.lock|package-lock\.json|pnpm-lock\.yaml|yarn\.lock|bun\.lockb|bun\.lock|poetry\.lock|uv\.lock|go\.sum|Gemfile\.lock|composer\.lock)$)')
TEST_RE = re.compile(r'(^|/)(tests?|specs?|__tests__|e2e|benches|bench|fuzz|testdata|fixtures|__snapshots__)/|(^|/)(test_[^/]*\.py|[^/]*_test\.[a-z]+|[^/]*\.(test|spec)\.[cm]?[jt]sx?|[^/]*_tests?\.rs|tests?\.rs)$')
CODE_EXT = set('rs py ts tsx js jsx mjs cjs go c cc cpp cxx h hpp hh zig swift kt kts java rb sh bash zsh sql cu cuh metal wgsl cl cs ex exs lua dart vue svelte astro php scala hs ml'.split())
def glob_re(g):
    g = g.strip().lstrip('/')
    anchored = '/' in g.rstrip('/')
    out = ''
    i = 0
    while i < len(g):
        c = g[i]
        if g.startswith('**', i): out += '.*'; i += 2; continue
        if c == '*': out += '[^/]*'
        elif c == '?': out += '[^/]'
        else: out += re.escape(c)
        i += 1
    return re.compile(('^' if anchored else '(^|.*/)') + out + '(/.*)?$')
ling = [glob_re(l) for l in open(os.path.join(tmpd, 'linguist')).read().split('\n') if l.strip()]
kept, excluded, hits = [], [], {}
for p in paths:
    m = EXCL_DIR.search(p)
    if m: excluded.append(p); hits[m.group(2)] = hits.get(m.group(2), 0) + 1; continue
    if EXCL_FILE.search(p): excluded.append(p); hits['generated-file-pattern'] = hits.get('generated-file-pattern', 0) + 1; continue
    if any(r.match(p) for r in ling): excluded.append(p); hits['linguist-generated'] = hits.get('linguist-generated', 0) + 1; continue
    kept.append(p)
open(os.path.join(tmpd, 'files.txt'), 'w').write('\n'.join(kept) + ('\n' if kept else ''))
open(os.path.join(tmpd, 'all.txt'), 'w').write('\n'.join(paths) + ('\n' if paths else ''))
counted = len(kept) <= max_files
by_ext, lines_of, code_loc, rust_nontest, test_loc, test_files, docs_md, docs_lines = {}, {}, 0, 0, 0, 0, 0, 0
if counted:
    for p in kept:
        try:
            with open(p, 'rb') as f: n = f.read().count(b'\n')
        except Exception: continue
        ext = p.rsplit('.', 1)[1].lower() if '.' in p.rsplit('/', 1)[-1] else '(none)'
        e = by_ext.setdefault(ext, [0, 0]); e[0] += 1; e[1] += n
        lines_of[p] = n
        is_test = bool(TEST_RE.search(p))
        if ext in CODE_EXT:
            if is_test: test_loc += n; test_files += 1
            else:
                code_loc += n
                if ext == 'rs': rust_nontest += n
        if ext in ('md', 'mdx') and re.match(r'(^|.*/)docs?/', p): docs_md += 1; docs_lines += n
top_ext = sorted(by_ext.items(), key=lambda kv: (-kv[1][1], kv[0]))[:12]
code_files = sorted(((lines_of[p], p) for p in lines_of if p.rsplit('.', 1)[-1].lower() in CODE_EXT and not TEST_RE.search(p)), key=lambda t: (-t[0], t[1]))
mono = [(n, p) for n, p in code_files if n > 3000 or (code_loc >= 20000 and n >= 1500 and n > 0.05 * code_loc)]
roots = {}
for p in paths:
    head = p.split('/', 1)[0]; roots[head] = roots.get(head, 0) + (1 if '/' in p else 0)
dirs = sorted(k for k, v in roots.items() if v > 0); files = sorted(k for k, v in roots.items() if v == 0)
out = {
    'total_all': len(paths), 'total_kept': len(kept), 'excluded_count': len(excluded),
    'excluded_hits': '; '.join('%s:%d' % (k, v) for k, v in sorted(hits.items())) or 'none matched',
    'counted': '1' if counted else '0', 'code_loc': code_loc, 'rust_nontest_loc': rust_nontest, 'test_loc': test_loc, 'test_files': test_files,
    'ext_summary': '; '.join('%s: %d files / %d lines' % (k, v[0], v[1]) for k, v in top_ext) or 'no files',
    'top_files': '; '.join('%s:%d' % (p, n) for n, p in code_files[:5]),
    'monolith': '; '.join('%s:%d' % (p, n) for n, p in mono[:3]), 'monolith_count': len(mono),
    'ipynb': sum(1 for p in kept if p.endswith('.ipynb')), 'skill_md': sum(1 for p in kept if p.endswith('/SKILL.md') or p == 'SKILL.md'),
    'sh_files': by_ext.get('sh', [0, 0])[0] + by_ext.get('bash', [0, 0])[0],
    'docs_md': docs_md, 'docs_lines': docs_lines,
    'layout_dirs': ', '.join(dirs[:40]), 'layout_files': ', '.join(files[:40]),
    'ext_json': json.dumps({k: v for k, v in by_ext.items()}, sort_keys=True),
}
with open(os.path.join(tmpd, 'inv.kv'), 'w') as f:
    for k, v in sorted(out.items()): f.write('%s\t%s\n' % (k, v))
PY
INV="$TMPD/inv.kv"; FILES="$TMPD/files.txt"; ALL="$TMPD/all.txt"
TOTAL_ALL=$(kv total_all "$INV"); TOTAL_KEPT=$(kv total_kept "$INV"); COUNTED=$(kv counted "$INV")
CODE_LOC=$(kv code_loc "$INV"); RUST_LOC=$(kv rust_nontest_loc "$INV")
files_matching() { grep -E -- "$1" "$FILES" | LC_ALL=C sort; }   # regex over kept inventory paths
any_file() { grep -qE -- "$1" "$FILES"; }
count_files() { grep -cE -- "$1" "$FILES"; }

if [ "${INV_RC:-1}" != 0 ] && [ "$TOTAL_ALL" = 0 ]; then
  ev_unknown "code-generated-or-vendored-excluded" file "file inventory failed" "$INV_CMD" "inventory command exited $INV_RC"
else
  ev_present "code-generated-or-vendored-excluded" file "" 4 "generated and vendored paths identified and excluded from code scans" "$INV_CMD" \
    "$TOTAL_ALL files inventoried, $TOTAL_KEPT kept, $(kv excluded_count "$INV") excluded ($(kv excluded_hits "$INV")); exclusions: dirs $(printf '%s' "$EXCL_DIRS" | tr ' ' ','); file patterns $(printf '%s' "$EXCL_FILES" | tr ' ' ','); .gitattributes linguist-generated/vendored: ${LINGUIST:-none}"
fi
ev_fact "top-level layout of the target" file "" "$INV_CMD" "dirs: $(kv layout_dirs "$INV"); files: $(kv layout_files "$INV")"
if [ "$COUNTED" = 1 ]; then
  ev_fact "line counts per extension (kept files, newline count)" file "" "$INV_CMD | python3 (count newlines per file)" "$(kv ext_summary "$INV"); non-test code LOC=$CODE_LOC (rust non-test $RUST_LOC); test LOC=$(kv test_loc "$INV") in $(kv test_files "$INV") test files"
  ev_fact "largest non-test source files" file "" "$INV_CMD | python3 (count newlines per file)" "$(kv top_files "$INV")"
else
  ev_unknown "" file "line counts per extension not computed" "$INV_CMD" "$TOTAL_KEPT files exceed --max-files $MAX_FILES; line-count facts skipped"
fi

# ------------------------------------------------------------------ manifests
# One python pass over every non-vendored manifest: writes man.kv (facts) and per-ecosystem dependency lists.
grep -E '(^|/)(Cargo\.toml|Cargo\.lock|package\.json|pyproject\.toml|requirements[^/]*\.txt|setup\.py|go\.mod|Gemfile|build\.zig|build\.zig\.zon|pnpm-workspace\.yaml|go\.work|lerna\.json|turbo\.json|nx\.json|package-lock\.json|pnpm-lock\.yaml|yarn\.lock|bun\.lockb|bun\.lock|poetry\.lock|uv\.lock|go\.sum|Gemfile\.lock|CMakeLists\.txt|Makefile|justfile|Justfile|tsconfig\.json|wrangler\.(toml|json|jsonc)|vercel\.json|next\.config\.[a-z]+|playwright\.config\.[a-z]+|mkdocs\.yml|book\.toml|docusaurus\.config\.[a-z]+|dist-workspace\.toml|\.goreleaser\.ya?ml|cliff\.toml|Trunk\.toml|manifest\.json)$' "$ALL" \
  | grep -vE '(^|/)(target|node_modules|vendor|dist|build|\.git|third_party|\.next|__pycache__|\.venv|venv|coverage)/' | LC_ALL=C sort > "$TMPD/manifests.txt"
python3 - "$TMPD" <<'PY'
import sys, os, re, json, glob
tmpd = sys.argv[1]
man = [l.strip() for l in open(os.path.join(tmpd, 'manifests.txt')) if l.strip()]
try:
    import tomllib
except Exception:
    tomllib = None
def toml_lite(text):
    """Tolerant line-based TOML subset for manifests (tables, arrays of tables, strings, bools, arrays, inline tables)."""
    root, cur = {}, None
    text = re.sub(r'"""[\s\S]*?"""', '""', text)
    lines = text.split('\n'); i = 0
    def val(s):
        s = s.strip()
        if s.startswith('"'): return re.sub(r'^"|"(\s*#.*)?$', '', s)
        if s.startswith("'"): return re.sub(r"^'|'(\s*#.*)?$", '', s)
        if s in ('true', 'false'): return s == 'true'
        if s.startswith('['): return re.findall(r'"([^"]*)"|\'([^\']*)\'', s) and [a or b for a, b in re.findall(r'"([^"]*)"|\'([^\']*)\'', s)] or []
        if s.startswith('{'):
            d = {}
            for k, v in re.findall(r'([A-Za-z0-9_.-]+)\s*=\s*("(?:[^"\\]|\\.)*"|\'[^\']*\'|\[[^\]]*\]|true|false|[0-9][0-9.]*)', s): d[k] = val(v)
            return d
        return re.sub(r'\s*#.*$', '', s)
    cur = root
    while i < len(lines):
        line = lines[i].strip(); i += 1
        if not line or line.startswith('#'): continue
        m = re.match(r'^\[\[([^\]]+)\]\]', line)
        if m:
            node = root
            parts = [p.strip().strip('"\'') for p in re.split(r'\.(?=(?:[^"]*"[^"]*")*[^"]*$)', m.group(1))]
            for p in parts[:-1]: node = node.setdefault(p, {}) if isinstance(node.get(p, {}), dict) else node[p][-1]
            cur = {}; node.setdefault(parts[-1], []).append(cur); continue
        m = re.match(r'^\[([^\]]+)\]', line)
        if m:
            node = root
            parts = [p.strip().strip('"\'') for p in re.split(r'\.(?=(?:[^"]*"[^"]*")*[^"]*$)', m.group(1))]
            for p in parts:
                nxt = node.get(p)
                if isinstance(nxt, list): node = nxt[-1]
                elif isinstance(nxt, dict): node = nxt
                else: node[p] = {}; node = node[p]
            cur = node; continue
        m = re.match(r'^([A-Za-z0-9_."\'-]+)\s*=\s*(.*)$', line)
        if not m: continue
        key, rest = m.group(1).strip('"\''), m.group(2)
        if rest.lstrip().startswith('[') and rest.count('[') > rest.count(']'):
            while i < len(lines) and rest.count('[') > rest.count(']'): rest += ' ' + lines[i].strip(); i += 1
        if rest.lstrip().startswith('{') and rest.count('{') > rest.count('}'):
            while i < len(lines) and rest.count('{') > rest.count('}'): rest += ' ' + lines[i].strip(); i += 1
        cur[key] = val(rest)
    return root
def load_toml(path):
    txt = open(path, encoding='utf-8', errors='replace').read()
    if tomllib:
        try: return tomllib.loads(txt)
        except Exception: pass
    try: return toml_lite(txt)
    except Exception: return {}
def load_json(path):
    try: return json.load(open(path, encoding='utf-8', errors='replace'))
    except Exception: return {}
def root_crate_name(cargo, names):
    """The crate a registry lookup should use: the root [package], else the workspace member whose name
    prefixes the most other members (fsqlite over fsqlite-core), else the first member."""
    if not names: return ''
    if cargo and cargo[0] == 'Cargo.toml':
        pkg = (load_toml('Cargo.toml').get('package') or {}).get('name')
        if isinstance(pkg, str): return pkg
    base = os.path.basename(os.getcwd()).lower().replace('_', '-')
    for n in names:
        if n.lower().replace('_', '-') == base: return n
    return min(names, key=lambda n: (-sum(1 for o in names if o.startswith(n)), len(n), n))
facts, lists = {}, {'cargo': set(), 'cargo_dev': set(), 'npm': set(), 'npm_dev': set(), 'py': set(), 'go': set(), 'gem': set(), 'lock_cargo': set()}
cargo = [m for m in man if m.endswith('Cargo.toml')]
members, names, bins, libs, cdylib, publish_false, gitpath, pins, feats_max, optional, prof, buildrs, sys_crates, homepage, wasm_cfg = [], [], [], [], [], [], [], [], 0, 0, [], [], [], [], []
dep_counts = {}
for m in cargo:
    t = load_toml(m); d = os.path.dirname(m)
    pkg = t.get('package') or {}
    name = pkg.get('name') if isinstance(pkg.get('name'), str) else None
    if name: names.append(name)
    ws = t.get('workspace') or {}
    for g in (ws.get('members') or []):
        if isinstance(g, str):
            for hit in sorted(glob.glob(os.path.join(d, g) if d else g)):
                if os.path.isfile(os.path.join(hit, 'Cargo.toml')): members.append(hit)
    deps = {}
    for sect in ('dependencies', 'build-dependencies'):
        deps.update(t.get(sect) or {})
    for _, tt in (t.get('target') or {}).items():
        if isinstance(tt, dict): deps.update(tt.get('dependencies') or {})
    deps.update(ws.get('dependencies') or {})
    dev = t.get('dev-dependencies') or {}
    for k, v in list(deps.items()) + list(dev.items()):
        lst = lists['cargo'] if k in deps else lists['cargo_dev']
        nm = v.get('package', k) if isinstance(v, dict) else k
        lst.add(nm)
        if isinstance(v, dict) and ('git' in v or 'path' in v): gitpath.append((nm, '%s(%s)' % (k, 'git' if 'git' in v else 'path')))
        ver = v.get('version') if isinstance(v, dict) else v
        if isinstance(ver, str) and ver.strip().startswith('='): pins.append('%s%s' % (k, ver))
        if isinstance(v, dict) and v.get('optional') is True: optional += 1
        if nm.endswith('-sys') and nm not in ('js-sys', 'web-sys', 'windows-sys', 'libfuzzer-sys', 'wasi-sys'): sys_crates.append(nm)
    if name: dep_counts[name] = len(deps)
    feats_max = max(feats_max, len(t.get('features') or {}))
    if 'lib' in t or os.path.isfile(os.path.join(d, 'src', 'lib.rs')): libs.append(name or m)
    ct = (t.get('lib') or {}).get('crate-type') or []
    if 'cdylib' in ct: cdylib.append(name or m)
    bl = t.get('bin') or []
    if bl or os.path.isfile(os.path.join(d, 'src', 'main.rs')) or os.path.isdir(os.path.join(d, 'src', 'bin')):
        bins.extend([b.get('name') for b in bl if isinstance(b, dict) and b.get('name')] or [name or m])
    if pkg.get('publish') is False or pkg.get('publish') == []: publish_false.append(name or m)
    pr = ((t.get('profile') or {}).get('release') or {})
    for k in ('lto', 'codegen-units', 'opt-level', 'panic', 'strip', 'debug'):
        if k in pr: prof.append('%s=%s' % (k, pr[k]))
    if os.path.isfile(os.path.join(d, 'build.rs')): buildrs.append(os.path.join(d, 'build.rs') if d else 'build.rs')
    if isinstance(pkg.get('homepage'), str): homepage.append(pkg['homepage'])
for cfg in ('.cargo/config.toml', '.cargo/config'):
    if os.path.isfile(cfg):
        txt = open(cfg, errors='replace').read()
        if 'target-cpu' in txt: prof.append('.cargo/config target-cpu')
        if 'wasm32' in txt: wasm_cfg.append(cfg)
for lk in [m for m in man if m.endswith('Cargo.lock')]:
    for nm in re.findall(r'^name = "([^"]+)"', open(lk, errors='replace').read(), re.M): lists['lock_cargo'].add(nm)
gitpath = [g for nm, g in gitpath if nm not in set(names)]   # path deps on this workspace's own crates are not unusual
brs = []
for b in buildrs:
    txt = open(b, errors='replace').read()
    if re.search(r'\b(cc::|bindgen|cmake::|pkg_config|napi_build|cxx_build)', txt): brs.append(b)
facts.update({'cargo.count': len(cargo), 'cargo.names': ';'.join(sorted(set(names))), 'cargo.members': ';'.join(sorted(set(members))),
    'cargo.member_count': len(set(members)), 'cargo.libs': ';'.join(sorted(set(str(x) for x in libs))), 'cargo.bins': ';'.join(sorted(set(str(x) for x in bins))),
    'cargo.cdylib': ';'.join(sorted(set(cdylib))), 'cargo.publish_false': ';'.join(sorted(set(publish_false))), 'cargo.gitpath': ';'.join(sorted(set(gitpath))),
    'cargo.pins': ';'.join(sorted(set(pins))), 'cargo.features_max': feats_max, 'cargo.optional': optional, 'cargo.profile': ';'.join(sorted(set(prof))),
    'cargo.build_rs_native': ';'.join(sorted(set(brs))), 'cargo.sys_crates': ';'.join(sorted(set(sys_crates))), 'cargo.homepage': ';'.join(sorted(set(homepage))),
    'cargo.wasm_cfg': ';'.join(wasm_cfg), 'cargo.dep_max': max(dep_counts.values()) if dep_counts else 0,
    'cargo.dep_counts': ';'.join('%s=%d' % (k, v) for k, v in sorted(dep_counts.items())), 'cargo.root_name': root_crate_name(cargo, names)})
# npm
npm = [m for m in man if m.endswith('package.json') and not m.endswith('package-lock.json')]
nnames, private, nbin, nws, ngit, nhome, ndep = [], [], [], [], [], [], {}
for m in npm:
    j = load_json(m)
    if not isinstance(j, dict): continue
    nm = j.get('name') if isinstance(j.get('name'), str) else None
    if nm: nnames.append(nm)
    if j.get('private') is True: private.append(nm or m)
    if j.get('bin'): nbin.append(nm or m)
    if j.get('workspaces'): nws.append(m)
    if isinstance(j.get('homepage'), str): nhome.append(j['homepage'])
    for sect, lst in (('dependencies', 'npm'), ('peerDependencies', 'npm'), ('devDependencies', 'npm_dev')):
        for k, v in (j.get(sect) or {}).items():
            lists[lst].add(k)
            if isinstance(v, str) and re.match(r'^(git\+|github:|file:|link:|https?://|git://)', v): ngit.append('%s(%s)' % (k, v.split(':')[0]))
    if nm: ndep[nm] = len(j.get('dependencies') or {})
root_pkg = load_json('package.json') if os.path.isfile('package.json') else {}
facts.update({'npm.count': len(npm), 'npm.names': ';'.join(sorted(set(nnames))), 'npm.private': ';'.join(sorted(set(private))), 'npm.bin': ';'.join(sorted(set(nbin))),
    'npm.workspaces': ';'.join(sorted(set(nws))), 'npm.gitdeps': ';'.join(sorted(set(ngit))), 'npm.homepage': ';'.join(sorted(set(nhome))),
    'npm.dep_max': max(ndep.values()) if ndep else 0, 'npm.dep_counts': ';'.join('%s=%d' % (k, v) for k, v in sorted(ndep.items())),
    'npm.root_name': root_pkg.get('name', '') if isinstance(root_pkg, dict) else '', 'npm.root_private': '1' if isinstance(root_pkg, dict) and root_pkg.get('private') is True else '0',
    'npm.main': ';'.join(sorted(m for m in npm if any(k in (load_json(m) or {}) for k in ('main', 'exports', 'module', 'types'))))})
# python
py = [m for m in man if m.endswith('pyproject.toml')]
pyname, pyscripts, pydeps_count = '', [], 0
for m in py:
    t = load_toml(m); proj = t.get('project') or {}; poetry = (t.get('tool') or {}).get('poetry') or {}
    pyname = pyname or (proj.get('name') if isinstance(proj.get('name'), str) else '') or (poetry.get('name') if isinstance(poetry.get('name'), str) else '')
    if proj.get('scripts') or poetry.get('scripts'): pyscripts.append(m)
    deps = [d for d in (proj.get('dependencies') or []) if isinstance(d, str)] + list((poetry.get('dependencies') or {}).keys())
    for grp in (proj.get('optional-dependencies') or {}).values(): deps += [d for d in grp if isinstance(d, str)]
    for d in deps:
        n = re.split(r'[\s\[<>=!~;@]', d.strip())[0].lower()
        if n and n != 'python': lists['py'].add(n)
    pydeps_count = max(pydeps_count, len(proj.get('dependencies') or []) + len(poetry.get('dependencies') or {}))
for m in [x for x in man if re.search(r'(^|/)requirements[^/]*\.txt$', x)]:
    for line in open(m, errors='replace'):
        line = line.strip()
        if line and not line.startswith(('#', '-')):
            n = re.split(r'[\s\[<>=!~;@]', line)[0].lower()
            if n: lists['py'].add(n)
facts.update({'py.count': len(py) + len([x for x in man if re.search(r'(^|/)(requirements[^/]*\.txt|setup\.py)$', x)]), 'py.name': pyname, 'py.scripts': ';'.join(pyscripts), 'py.dep_max': max(pydeps_count, len(lists['py']) if not py else 0),
    'py.pyproject': ';'.join(py)})
# go / gem / zig / others
gomods = [m for m in man if m.endswith('go.mod')]
gomod = ''
for m in gomods:
    txt = open(m, errors='replace').read()
    mm = re.search(r'^module\s+(\S+)', txt, re.M); gomod = gomod or (mm.group(1) if mm else '')
    for dep in re.findall(r'^\s*([A-Za-z0-9._/-]+\.[a-z]+/[A-Za-z0-9._/-]+)\s+v[0-9]', txt, re.M): lists['go'].add(dep)
for m in [x for x in man if x.endswith('Gemfile')]:
    for g in re.findall(r'^\s*gem\s+[\'"]([^\'"]+)', open(m, errors='replace').read(), re.M): lists['gem'].add(g)
facts.update({'go.count': len(gomods), 'go.module': gomod, 'go.dep_count': len(lists['go']), 'gem.count': len([x for x in man if x.endswith('Gemfile')]),
    'zig.count': len([x for x in man if x.endswith(('build.zig', 'build.zig.zon'))]), 'cmake.count': len([x for x in man if x.endswith('CMakeLists.txt')]),
    'make.count': len([x for x in man if x.endswith(('Makefile', 'justfile', 'Justfile'))]), 'tsconfig.count': len([x for x in man if x.endswith('tsconfig.json')]),
    'ws.files': ';'.join(sorted(x for x in man if re.search(r'(^|/)(pnpm-workspace\.yaml|go\.work|lerna\.json|turbo\.json|nx\.json)$', x))),
    'lock.files': ';'.join(sorted(x for x in man if re.search(r'(^|/)(Cargo\.lock|package-lock\.json|pnpm-lock\.yaml|yarn\.lock|bun\.lockb|bun\.lock|poetry\.lock|uv\.lock|go\.sum|Gemfile\.lock)$', x))),
    'cfg.files': ';'.join(sorted(x for x in man if re.search(r'(^|/)(wrangler\.(toml|json|jsonc)|vercel\.json|next\.config\.[a-z]+|playwright\.config\.[a-z]+|mkdocs\.yml|book\.toml|docusaurus\.config\.[a-z]+|dist-workspace\.toml|\.goreleaser\.ya?ml|cliff\.toml|Trunk\.toml|manifest\.json)$', x))),
    'manifest.dirs': len(set(os.path.dirname(m) for m in man if re.search(r'(^|/)(Cargo\.toml|package\.json|pyproject\.toml|go\.mod)$', m)))})
with open(os.path.join(tmpd, 'man.kv'), 'w') as f:
    for k, v in sorted(facts.items()): f.write('%s\t%s\n' % (k, v))
for k, v in lists.items():
    open(os.path.join(tmpd, 'deps.' + k), 'w').write('\n'.join(sorted(v)) + ('\n' if v else ''))
PY
MAN="$TMPD/man.kv"
mk() { kv "$1" "$MAN"; }
# dep_has ECOSYSTEMS(space list of cargo cargo_dev npm npm_dev py go gem lock_cargo) REGEX -> 0 if any dependency name matches; DEP_HIT = matches
DEP_HIT=""
dep_has() {
  local eco="$1" re="$2" e hits=""
  for e in $eco; do [ -f "$TMPD/deps.$e" ] && hits="$hits $(grep -E -- "$re" "$TMPD/deps.$e" | tr '\n' ' ')"; done
  DEP_HIT=$(printf '%s' "$hits" | tr ' ' '\n' | grep -v '^$' | LC_ALL=C sort -u | head -8 | tr '\n' ' ' | sed 's/ $//')
  [ -n "$DEP_HIT" ]
}
manifest_loc() { local f; f=$(first_existing "$@") || return 1; loc "$f"; }

# ------------------------------------------------------ manifest facts (signals: [])
while IFS= read -r m; do
  [ -z "$m" ] && continue
  case "$m" in *Cargo.toml|*package.json|*pyproject.toml|*go.mod|*Gemfile|*build.zig.zon|*Cargo.lock|*package-lock.json|*pnpm-lock.yaml|*yarn.lock|*poetry.lock|*uv.lock|*go.sum|*Gemfile.lock|*bun.lock|*bun.lockb) ;; *) continue;; esac
  ev_fact "manifest $m digest sha256:$(sha_file "$m")" file "$(loc "$m")" "shasum -a 256 $m" "$(wc -l < "$m" | tr -d ' ') lines"
done < "$TMPD/manifests.txt"
[ "$(mk cargo.count)" -gt 0 ] && ev_fact "cargo crates and dependency counts" file "$(manifest_loc Cargo.toml)" "python3 (parse Cargo.toml)" "crates: $(mk cargo.names | tr ';' ' '); direct deps per crate: $(mk cargo.dep_counts | tr ';' ' '); dev deps: $(grep -c . "$TMPD/deps.cargo_dev"); features max $(mk cargo.features_max); optional deps $(mk cargo.optional)"
[ "$(mk cargo.member_count)" -gt 0 ] && ev_fact "cargo workspace members" file "$(manifest_loc Cargo.toml)" "python3 (parse [workspace].members globs)" "$(mk cargo.member_count) members: $(mk cargo.members | tr ';' ' ')"
[ "$(mk npm.count)" -gt 0 ] && ev_fact "npm packages and dependency counts" file "$(manifest_loc package.json)" "python3 (parse package.json)" "packages: $(mk npm.names | tr ';' ' '); deps per package: $(mk npm.dep_counts | tr ';' ' '); devDeps: $(grep -c . "$TMPD/deps.npm_dev")${NPM_WS:+; workspaces}"
[ "$(mk py.count)" -gt 0 ] && ev_fact "python packaging and dependency count" file "$(manifest_loc pyproject.toml requirements.txt setup.py)" "python3 (parse pyproject/requirements)" "name: $(mk py.name); distinct deps: $(grep -c . "$TMPD/deps.py")"
[ "$(mk go.count)" -gt 0 ] && ev_fact "go module and dependency count" file "$(manifest_loc go.mod)" "python3 (parse go.mod)" "module: $(mk go.module); requires: $(mk go.dep_count)"

# ------------------------------------------------------------------ languages
ext_lines() { python3 -c 'import json,sys; d=json.loads(sys.argv[1]); print(sum(d.get(e,[0,0])[1] for e in sys.argv[2].split()), sum(d.get(e,[0,0])[0] for e in sys.argv[2].split()))' "$(kv ext_json "$INV")" "$1" 2>/dev/null || echo "0 0"; }
TOTAL_CODE=$(python3 -c 'import json,sys; d=json.loads(sys.argv[1]); print(sum(v[1] for k,v in d.items() if k in set("rs py ts tsx js jsx mjs cjs go c cc cpp cxx h hpp hh zig swift kt kts java rb sh bash zsh sql cu cuh metal wgsl cl cs ex exs lua dart vue svelte astro php scala hs ml".split())))' "$(kv ext_json "$INV")" 2>/dev/null || echo 0)
# lang_signal SIGNAL "LANG" "EXTS" MANIFEST_PATH_OR_EMPTY [min_share%]
lang_signal() {
  local sig="$1" name="$2" exts="$3" manifest="$4" share="${5:-15}" ln fl pct=0
  read -r ln fl <<< "$(ext_lines "$exts")"
  [ "$TOTAL_CODE" -gt 0 ] && pct=$(( ln * 100 / TOTAL_CODE ))
  if [ -n "$manifest" ]; then
    ev_present "$sig" file "$(loc "$manifest")" 4 "$name is a primary language (manifest present)" "ls $manifest; line counts by extension" "$manifest present; $fl files / $ln lines ($pct% of code LOC)"
  elif [ "$COUNTED" != 1 ]; then
    ev_unknown "$sig" file "$name primary-language status unknown" "line counts by extension" "no manifest and line counting skipped (--max-files)"
  elif [ "$pct" -ge "$share" ] && [ "$fl" -ge 3 ]; then
    ev_present "$sig" file "" 3 "$name is a primary language (by line share)" "line counts by extension" "$fl files / $ln lines ($pct% of code LOC, threshold $share%)"
  else
    ev_absent "$sig" file "" 3 "$name is not a primary language" "manifest lookup + line counts by extension" "no manifest; $fl files / $ln lines ($pct% of code LOC, threshold $share%)"
  fi
}
lang_signal lang-rust Rust "rs" "$(first_existing Cargo.toml || true)"
lang_signal lang-typescript TypeScript "ts tsx" "$(first_existing tsconfig.json || true)"
JS_MAN=""; [ "$(mk npm.count)" -gt 0 ] && [ "$(mk tsconfig.count)" = 0 ] && JS_MAN=$(first_existing package.json || true)
lang_signal lang-javascript JavaScript "js jsx mjs cjs" "$JS_MAN" 25
lang_signal lang-python Python "py" "$(first_existing pyproject.toml requirements.txt setup.py || true)"
lang_signal lang-go Go "go" "$(first_existing go.mod || true)"
lang_signal lang-c-cpp "C/C++" "c cc cpp cxx h hpp hh" "$(first_existing CMakeLists.txt || true)" 20
lang_signal lang-zig Zig "zig" "$(first_existing build.zig || true)"
lang_signal lang-swift-kotlin-java "Swift/Kotlin/Java" "swift kt kts java" "" 15
SH_FILES=$(kv sh_files "$INV"); read -r SH_LN _ <<< "$(ext_lines "sh bash zsh")"
SH_PCT=0; [ "$TOTAL_CODE" -gt 0 ] && SH_PCT=$(( SH_LN * 100 / TOTAL_CODE ))
if [ "$SH_FILES" -ge 1 ] && { [ "$SH_PCT" -ge 10 ] || [ "$(kv ext_summary "$INV" | cut -d: -f1)" = sh ]; }; then
  ev_present lang-shell file "$(files_matching '\.(sh|bash)$' | head -1 | xargs -I{} printf '%s' "$(loc "{}")")" 3 "shell scripts are a significant part of the deliverable" "line counts by extension" "$SH_FILES shell files / $SH_LN lines of $TOTAL_CODE code LOC"
else
  ev_absent lang-shell file "" 3 "shell scripts are not a significant part of the deliverable" "line counts by extension" "$SH_FILES shell files / $SH_LN lines of $TOTAL_CODE code LOC ($SH_PCT%; threshold 10% or shell is the largest language)"
fi

# ------------------------------------------------------------------ build / deps
CARGO_LOC=$(manifest_loc Cargo.toml || true)
if [ "$(mk cargo.count)" -gt 0 ]; then
  if [ "$(mk cargo.member_count)" -gt 0 ]; then ev_present build-cargo-workspace file "$CARGO_LOC" 4 "Cargo workspace with members" "python3 (parse [workspace].members)" "$(mk cargo.member_count) members: $(mk cargo.members | tr ';' ' ')"
  else ev_absent build-cargo-workspace file "$CARGO_LOC" 4 "no Cargo workspace members" "python3 (parse [workspace].members)" "no [workspace] members in $(mk cargo.count) Cargo.toml"; fi
  if [ -n "$(mk cargo.profile)" ]; then ev_present cargo-profile-tuned file "$CARGO_LOC" 4 "release profile tuned" "python3 (parse [profile.release], .cargo/config)" "$(mk cargo.profile | tr ';' ' ')"
  else ev_absent cargo-profile-tuned file "$CARGO_LOC" 4 "no release profile tuning" "python3 (parse [profile.release], .cargo/config)" "no lto/codegen-units/opt-level/panic/strip keys and no target-cpu in .cargo/config"; fi
  if [ "$(mk cargo.features_max)" -ge 5 ] || [ "$(mk cargo.optional)" -ge 3 ]; then ev_present cargo-features-heavy file "$CARGO_LOC" 4 "many cargo features or optional deps" "python3 (parse [features])" "features max $(mk cargo.features_max) (>=5) / optional deps $(mk cargo.optional) (>=3)"
  else ev_absent cargo-features-heavy file "$CARGO_LOC" 4 "few cargo features" "python3 (parse [features])" "features max $(mk cargo.features_max); optional deps $(mk cargo.optional)"; fi
else
  for s in build-cargo-workspace cargo-profile-tuned cargo-features-heavy; do ev_absent "$s" file "" 4 "$s not applicable: no Cargo.toml" "ls Cargo.toml" "no Cargo.toml in inventory"; done
fi
NATIVE=""
[ -n "$(mk cargo.build_rs_native)" ] && NATIVE="build.rs uses cc/bindgen/cmake: $(mk cargo.build_rs_native | tr ';' ' ')"
[ -n "$(mk cargo.sys_crates)" ] && NATIVE="$NATIVE; -sys crates: $(mk cargo.sys_crates | tr ';' ' ')"
if any_file '(^|/)binding\.gyp$'; then NATIVE="$NATIVE; binding.gyp (node-gyp)"; fi
if dep_has "npm npm_dev py" '^(node-gyp|node-addon-api|napi|cffi|pybind11|maturin|nanobind)$'; then NATIVE="$NATIVE; deps: $DEP_HIT"; fi
NATIVE=${NATIVE#; }
if [ -n "$NATIVE" ]; then ev_present native-ffi-deps file "${CARGO_LOC:-$(manifest_loc package.json pyproject.toml || true)}" 4 "native/FFI dependencies" "python3 (parse manifests, build.rs)" "$NATIVE"
else ev_absent native-ffi-deps file "" 4 "no native/FFI dependencies" "python3 (parse manifests, build.rs, binding.gyp)" "no cc/bindgen/cmake build.rs, no -sys crates, no node-gyp/cffi/pybind11 deps"; fi
PINS="$(mk cargo.gitpath | tr ';' ' ') $(mk cargo.pins | tr ';' ' ') $(mk npm.gitdeps | tr ';' ' ')"; PINS=$(printf '%s' "$PINS" | tr -s ' ' | sed 's/^ //; s/ $//')
if [ -n "$PINS" ]; then ev_present unusual-pins file "${CARGO_LOC:-$(manifest_loc package.json || true)}" 4 "git/path dependencies or exact pins" "python3 (parse manifests)" "$PINS"
else ev_absent unusual-pins file "" 4 "no git/path dependencies or exact pins" "python3 (parse manifests)" "no git/path deps or '=' pins in Cargo.toml; no git/file/link deps in package.json"; fi
DEP_MAX=$(mk cargo.dep_max); [ "$(mk npm.dep_max)" -gt "$DEP_MAX" ] && DEP_MAX=$(mk npm.dep_max); [ "$(mk py.dep_max)" -gt "$DEP_MAX" ] && DEP_MAX=$(mk py.dep_max); [ "$(mk go.dep_count)" -gt "$DEP_MAX" ] && DEP_MAX=$(mk go.dep_count)
WEBFW=""; dep_has "cargo npm py go gem" '^(next|nuxt|@remix-run/react|@angular/core|django|flask|fastapi|rails|actix-web|axum|rocket|warp|express|fastify|koa|hono|@nestjs/core|gin|echo|fiber|phoenix)$' && WEBFW="$DEP_HIT"
if [ "$(mk manifest.dirs)" = 0 ]; then
  ev_absent framework-heavy file "" 3 "no dependency manifest, so no framework dependency graph" "python3 (parse manifests)" "no Cargo.toml/package.json/pyproject.toml/go.mod"
  ev_unknown hand-rolled file "hand-rolled status unknown without a manifest" "python3 (parse manifests)" "no dependency manifest to count"
elif { [ -n "$WEBFW" ] && [ "$DEP_MAX" -ge 15 ]; } || [ "$DEP_MAX" -ge 40 ]; then
  ev_present framework-heavy file "$(manifest_loc Cargo.toml package.json pyproject.toml go.mod || true)" 3 "dependency graph dominated by frameworks" "python3 (count direct deps; framework dep present)" "max direct deps $DEP_MAX${WEBFW:+; framework: $WEBFW} (rule: framework dep AND >= 15 deps, or >= 40 deps)"
  ev_absent hand-rolled file "" 3 "not hand-rolled" "python3 (count direct deps)" "max direct deps $DEP_MAX (> 10)"
elif [ "$DEP_MAX" -le 10 ] && [ -z "$WEBFW" ]; then
  ev_absent framework-heavy file "" 3 "not framework-heavy" "python3 (count direct deps)" "max direct deps $DEP_MAX; no framework dependency"
  ev_present hand-rolled file "$(manifest_loc Cargo.toml package.json pyproject.toml go.mod || true)" 3 "few dependencies; mechanisms implemented in-tree" "python3 (count direct deps)" "max direct deps $DEP_MAX (<= 10); no framework dependency"
else
  ev_absent framework-heavy file "" 3 "not framework-heavy" "python3 (count direct deps)" "max direct deps $DEP_MAX${WEBFW:+; framework: $WEBFW} (rule: framework dep AND >= 15 deps, or >= 40 deps)"
  ev_absent hand-rolled file "" 2 "not hand-rolled by dependency count" "python3 (count direct deps)" "max direct deps $DEP_MAX (> 10)${WEBFW:+; framework: $WEBFW}"
fi
# fw_dep SIGNAL "ECOS" REGEX "LABEL" [FILE_REGEX]  -> dependency-name match, else file-pattern match, else absent
fw_dep() {
  local sig="$1" eco="$2" re="$3" label="$4" fre="${5:-}" f
  if dep_has "$eco" "$re"; then ev_present "$sig" file "$(manifest_loc Cargo.toml package.json pyproject.toml go.mod Gemfile || true)" 4 "$label dependency present" "python3 (parse manifests) | grep -E '$re'" "matched: $DEP_HIT"
  elif [ -n "$fre" ] && f=$(files_matching "$fre" | head -1) && [ -n "$f" ]; then ev_present "$sig" file "$(loc "$f")" 4 "$label config present" "grep -E '$fre' <inventory>" "$f"
  else ev_absent "$sig" file "" 4 "no $label dependency or config" "python3 (parse manifests) | grep -E '$re'${fre:+; grep -E '$fre' <inventory>}" "no dependency matched /$re/${fre:+ and no file matched /$fre/}"; fi
}
fw_dep fw-nextjs "npm npm_dev" '^next$' "Next.js" '(^|/)next\.config\.[a-z]+$'
fw_dep fw-supabase "npm npm_dev py cargo" '^(@supabase/.*|supabase|supabase-py|postgrest)$' "Supabase" '(^|/)supabase/config\.toml$'
fw_dep fw-vercel "npm npm_dev" '^(vercel|@vercel/.*)$' "Vercel" '(^|/)vercel\.json$'
[ -d .vercel ] && [ "$(sig_state fw-vercel)" != present ] && ev_present fw-vercel file "$(loc .vercel)" 4 "Vercel project link present" "ls -d .vercel" ".vercel/ directory exists (gitignored)"
fw_dep fw-cloudflare-workers "npm npm_dev" '^(wrangler|@cloudflare/workers-types)$' "Cloudflare Workers" '(^|/)wrangler\.(toml|json|jsonc)$'
fw_dep fw-tanstack "npm npm_dev" '^@tanstack/.*' "TanStack"
fw_dep fw-stripe "npm npm_dev py cargo go gem" '^(stripe|@stripe/.*|async-stripe|stripe-rust|stripe-go|github\.com/stripe/stripe-go.*)$' "Stripe"
fw_dep fw-paypal "npm npm_dev py cargo go gem" '^(@paypal/.*|paypal.*|paypalrestsdk|paypal-checkout-serversdk)$' "PayPal"
fw_dep fw-snowflake "npm npm_dev py cargo go" '^(snowflake-connector-python|snowflake-sqlalchemy|snowflake-sdk|snowflake-snowpark-python|fsnow|franken_snowflake|gosnowflake|github\.com/snowflakedb/.*)$' "Snowflake"
if dep_has "npm npm_dev py" '^(react-ga4|@next/third-parties|google-analytics-data|@google-analytics/.*)$'; then ev_present fw-ga4 file "$(manifest_loc package.json pyproject.toml || true)" 4 "GA4 dependency present" "python3 (parse manifests) | grep -E ga4 deps" "matched: $DEP_HIT"
else scan_signal fw-ga4 0 3 1 "GA4/gtag/GTM integration" 'gtag\(|googletagmanager\.com|GTM-[A-Z0-9]{5,}|G-[A-Z0-9]{8,}' '*.ts' '*.tsx' '*.js' '*.jsx' '*.html' '*.astro' '*.vue' '*.svelte'; fi
fw_dep fw-playwright "npm npm_dev py" '^(@playwright/test|playwright)$' "Playwright" '(^|/)playwright\.config\.[a-z]+$'
fw_dep fw-drizzle-prisma "npm npm_dev" '^(drizzle-orm|drizzle-kit|prisma|@prisma/client)$' "Drizzle/Prisma" '(^|/)(drizzle\.config\.[a-z]+|prisma/schema\.prisma)$'
fw_dep fw-tokio "cargo" '^(tokio|async-std|smol)$' "async runtime"
fw_dep fw-charm-bubbletea "go" '^github\.com/charmbracelet/(bubbletea|lipgloss|bubbles|gum|huh|glamour)$' "charmbracelet"
fw_dep fw-threejs "npm npm_dev" '^(three|@react-three/.*|@types/three)$' "three.js"
fw_dep fw-nextra "npm npm_dev" '^(nextra|nextra-theme-docs)$' "Nextra"
if f=$(files_matching '^\.github/workflows/[^/]+\.ya?ml$' | head -1) && [ -n "$f" ]; then ev_present fw-gh-actions file "$(loc "$f")" 4 "GitHub Actions workflows present" "ls .github/workflows/*.yml" "$(count_files '^\.github/workflows/[^/]+\.ya?ml$') workflow files"
else ev_absent fw-gh-actions file "" 4 "no GitHub Actions workflows" "ls .github/workflows/*.yml" "no .github/workflows/*.yml in inventory"; fi
# dep-<franken crate> from Cargo.toml + Cargo.lock names, excluding this workspace's own crates
own_re="^($(mk cargo.names | sed 's/[][\.*^$]/\\&/g; s/;/|/g'))$"; [ "$own_re" = '^()$' ] && own_re='^$'
franken_dep() {
  local sig="$1" re="$2" label="$3" hits
  hits=$(cat "$TMPD/deps.cargo" "$TMPD/deps.cargo_dev" "$TMPD/deps.lock_cargo" 2>/dev/null | grep -E -- "$re" | grep -vE -- "$own_re" | LC_ALL=C sort -u | tr '\n' ' ')
  if [ -n "$hits" ]; then ev_present "$sig" file "$(manifest_loc Cargo.toml Cargo.lock || true)" 4 "depends on $label" "grep -E '$re' <Cargo.toml deps + Cargo.lock names>" "$hits"
  else ev_absent "$sig" file "" 4 "no dependency on $label" "grep -E '$re' <Cargo.toml deps + Cargo.lock names>" "no crate matched /$re/ ($(grep -c . "$TMPD/deps.cargo") direct deps, $(grep -c . "$TMPD/deps.lock_cargo") lock entries)"; fi
}
franken_dep dep-frankensqlite '^(fsqlite|frankensqlite|franken_sqlite)' "the fsqlite crates"
franken_dep dep-asupersync '^asupersync' "the asupersync crate"
franken_dep dep-frankensearch '^frankensearch' "frankensearch crates"
franken_dep dep-frankentui '^(ftui|frankentui)' "frankentui/ftui crates"

# ------------------------------------------------------------------ identity
# proj-is-* data table: signal|name prefixes (a package/crate named exactly <prefix> or <prefix>-x / <prefix>_x).
PROJ_IDENTITY_TABLE='proj-is-asupersync|asupersync
proj-is-brenner-bot|brenner_bot brenner-bot brennerbot
proj-is-franken-ocr|franken_ocr franken-ocr focr
proj-is-franken-snowflake|franken_snowflake franken-snowflake fsnow
proj-is-franken-tts|franken_tts franken-tts frankentts ftts
proj-is-franken-whisper|franken_whisper franken-whisper frankenwhisper
proj-is-frankensqlite|fsqlite frankensqlite franken_sqlite
proj-is-frankentui|frankentui ftui
proj-is-pi-agent|pi-agent pi_agent pi-agent-rust
proj-uses-frankenterm|frankenterm franken_term franken-term'
ALL_NAMES="$(mk cargo.names | tr ';' ' ') $(mk npm.names | tr ';' ' ') $(mk py.name) $(mk go.module | sed 's#.*/##')"
printf '%s\n' "$PROJ_IDENTITY_TABLE" | while IFS='|' read -r sig prefixes; do
  hit=""
  for n in $ALL_NAMES; do for p in $prefixes; do case "$n" in "$p"|"$p"-*|"$p"_*) hit="$hit $n";; esac; done; done
  if [ -n "$hit" ]; then ev_present "$sig" file "$(manifest_loc Cargo.toml package.json pyproject.toml go.mod || true)" 4 "target is the named project (package name match)" "python3 (manifest names) vs identity table" "matched:${hit}"
  else ev_absent "$sig" file "" 4 "target is not the named project" "python3 (manifest names) vs identity table" "no package named ${prefixes// /|} among: ${ALL_NAMES:-<none>}"; fi
done
# frankensuite site: an npm site package whose name carries the franken* brand, or a README/site that says so.
if printf '%s' "$(mk npm.names)" | tr ';' '\n' | grep -qiE '^franken.*(site|web|www|com|dev|docs)|frankensuite'; then
  ev_present proj-is-frankensuite-site file "$(manifest_loc package.json)" 3 "target is a FrankenSuite project website" "python3 (package.json names)" "package: $(mk npm.names | tr ';' '\n' | grep -iE '^franken.*(site|web|www|com|dev|docs)|frankensuite' | head -1)"
else
  ev_absent proj-is-frankensuite-site file "" 3 "target is not a FrankenSuite project website" "python3 (package.json names)" "no npm package named franken*(site|web|www|com|dev|docs) or *frankensuite*"
fi
# library / cli
LIB=""; [ -n "$(mk cargo.libs)" ] && LIB="rust lib crates: $(mk cargo.libs | tr ';' ' ')"
[ -n "$(mk npm.main)" ] && [ -z "$(mk npm.bin)" ] && [ "$(mk npm.root_private)" != 1 ] && LIB="$LIB; npm main/exports: $(mk npm.main | tr ';' ' ')"
[ -n "$(mk py.pyproject)" ] && [ -z "$(mk py.scripts)" ] && LIB="$LIB; pyproject without [project.scripts]"
LIB=${LIB#; }
if [ -n "$LIB" ]; then ev_present proj-library file "$(manifest_loc Cargo.toml package.json pyproject.toml || true)" 4 "ships a library as a primary deliverable" "python3 (parse manifests: [lib]/src/lib.rs, main/exports, pyproject)" "$LIB"
else ev_absent proj-library file "" 4 "does not ship a library deliverable" "python3 (parse manifests: [lib]/src/lib.rs, main/exports, pyproject)" "no lib.rs/[lib], no npm main/exports without bin, no pyproject library"; fi
CLI=""; [ -n "$(mk cargo.bins)" ] && CLI="rust bins: $(mk cargo.bins | tr ';' ' ')"
[ -n "$(mk npm.bin)" ] && CLI="$CLI; npm bin: $(mk npm.bin | tr ';' ' ')"
[ -n "$(mk py.scripts)" ] && CLI="$CLI; pyproject scripts"
dep_has "cargo npm py go" '^(clap|argh|structopt|bpaf|lexopt|pico-args|commander|yargs|oclif|@oclif/core|click|typer|argparse|docopt|github\.com/spf13/cobra|github\.com/urfave/cli.*)$' && CLI="$CLI; cli deps: $DEP_HIT"
CLI=${CLI#; }
if [ -n "$CLI" ]; then ev_present proj-cli file "$(manifest_loc Cargo.toml package.json pyproject.toml go.mod || true)" 4 "ships a command-line binary" "python3 (parse manifests: [[bin]]/main.rs, package.json bin, project.scripts, cli deps)" "$CLI"
elif [ "$(mk go.count)" -gt 0 ] && out=$(rg_lines '^package main$' 0 '*.go') && [ -n "$out" ]; then ev_present proj-cli file "$(loc_of_match "$(printf '%s\n' "$out" | head -1)")" 3 "ships a command-line binary (go package main)" "$RG_CMD" "$(printf '%s\n' "$out" | grep -c .) package main files"
else ev_absent proj-cli file "" 4 "does not ship a command-line binary" "python3 (parse manifests) + rg 'package main'" "no bin targets, no package.json bin, no project.scripts, no CLI framework dependency"; fi
# tui
if dep_has "cargo npm py go" '^(ratatui|crossterm|tui|cursive|termion|termwiz|frankentui|ftui.*|github\.com/charmbracelet/bubbletea|github\.com/gdamore/tcell.*|github\.com/rivo/tview|textual|blessed|ink|prompt_toolkit|urwid)$'; then
  ev_present proj-tui file "$(manifest_loc Cargo.toml package.json pyproject.toml go.mod || true)" 4 "renders a terminal UI" "python3 (parse manifests) | grep -E tui deps" "matched: $DEP_HIT"
else ev_absent proj-tui file "" 4 "does not render a terminal UI" "python3 (parse manifests) | grep -E tui deps" "no ratatui/crossterm/cursive/frankentui/bubbletea/tcell/textual/blessed/ink dependency"; fi
# daemon
if f=$(files_matching '\.(service|plist)$' | grep -vE '(^|/)(node_modules|vendor)/' | head -1) && [ -n "$f" ]; then
  ev_present proj-daemon file "$(loc "$f")" 4 "long-running service/daemon (unit file)" "grep -E '\.(service|plist)$' <inventory>" "$f"
else scan_signal proj-daemon 1 2 1 "long-running daemon/serve entry point" '\b(Daemon|Serve|daemonize|serve_forever|ListenAndServe|TcpListener::bind|Server::bind|HttpServer::new|app\.listen\(|axum::serve|"daemon"|"serve")\b'; fi
# web app / saas
WEB=""; [ -n "$WEBFW" ] && WEB="web framework deps: $WEBFW"
[ "$(sig_state fw-nextjs)" = present ] && WEB="${WEB:+$WEB; }next.js"
if [ -n "$WEB" ]; then ev_present proj-web-app file "$(manifest_loc package.json Cargo.toml pyproject.toml go.mod || true)" 4 "serves HTTP pages/APIs to browsers" "python3 (parse manifests) | grep -E web framework deps" "$WEB"
else scan_signal proj-web-app 1 2 1 "HTTP route handlers" '\b(Router::new\(\)|\.route\("|app\.(get|post|use)\(|@app\.(get|post|route)\(|http\.HandleFunc\(|createServer\(|export (default )?async function (GET|POST)|NextResponse)\b' '*.rs' '*.py' '*.go' '*.ts' '*.tsx' '*.js' '*.jsx'; fi
AUTH=""; dep_has "npm npm_dev py cargo go gem" '^(next-auth|@auth/.*|@clerk/.*|@supabase/(ssr|auth-helpers.*|supabase-js)|lucia|passport|jose|jsonwebtoken|firebase-admin|@workos-inc/.*|authlib|django-allauth|devise|oauth2|openidconnect|@kinde-oss/.*|better-auth)$' && AUTH="$DEP_HIT"
PAY=""; { [ "$(sig_state fw-stripe)" = present ] || [ "$(sig_state fw-paypal)" = present ]; } && PAY="stripe/paypal dependency"
dep_has "npm npm_dev py cargo go" '^(@paddle/.*|@lemonsqueezy/.*|lemonsqueezy|paddle|polar-sh|@polar-sh/.*)$' && PAY="${PAY:+$PAY; }$DEP_HIT"
if [ "$(sig_state proj-web-app)" = present ] && [ -n "$PAY" ]; then ev_present proj-saas file "$(manifest_loc package.json Cargo.toml pyproject.toml || true)" 4 "web app with billing/subscriptions" "python3 (parse manifests): web framework + payments dependency" "$WEB; payments: $PAY${AUTH:+; auth: $AUTH}"
elif [ "$(sig_state proj-web-app)" = present ] && [ -n "$AUTH" ]; then ev_present proj-saas file "$(manifest_loc package.json Cargo.toml pyproject.toml || true)" 2 "web app with accounts (auth provider, no payments dependency)" "python3 (parse manifests): web framework + auth dependency" "$WEB; auth: $AUTH; no payments dependency"
elif [ "$(sig_state proj-web-app)" = unknown ]; then ev_unknown proj-saas file "SaaS status unknown (web-app status unknown)" "python3 (parse manifests)" "web-app detection did not complete"
else ev_absent proj-saas file "" 4 "not a SaaS web app" "python3 (parse manifests): web framework + auth/payments dependency" "web app: $(sig_state proj-web-app); auth deps: ${AUTH:-none}; payments deps: ${PAY:-none}"; fi
# mcp server
if dep_has "npm npm_dev py cargo go" '^(@modelcontextprotocol/sdk|mcp|fastmcp|rmcp|mcp-sdk|rust-mcp-sdk|mcp-server|github\.com/mark3labs/mcp-go|github\.com/modelcontextprotocol/.*)$'; then
  ev_present proj-mcp-server file "$(manifest_loc package.json pyproject.toml Cargo.toml go.mod || true)" 4 "implements an MCP server (SDK dependency)" "python3 (parse manifests) | grep -E mcp sdk" "matched: $DEP_HIT"
else scan_signal proj-mcp-server 1 3 1 "MCP server implementation" '\b(McpServer|FastMCP|ListToolsRequestSchema|CallToolRequestSchema|StdioServerTransport|rmcp::|mcp\.server|@mcp\.tool)\b'; fi
# browser extension
if out=$(rg_lines '"manifest_version"[[:space:]]*:' 0 'manifest.json') && [ -n "$out" ]; then
  f=$(printf '%s\n' "$out" | head -1 | cut -d: -f1)
  if grep -qE '"(background|content_scripts|browser_action|action|permissions)"' "$f" 2>/dev/null; then ev_present proj-browser-extension file "$(loc "$f")" 4 "browser extension manifest" "rg '\"manifest_version\"' -g manifest.json + grep background/content_scripts" "$f"
  else ev_absent proj-browser-extension file "$(loc "$f")" 3 "manifest.json is not a browser-extension manifest" "rg '\"manifest_version\"' -g manifest.json + grep background/content_scripts" "$f lacks background/content_scripts/action keys"; fi
elif is_timeout "$RG_RC" || [ "$RG_RC" = 2 ]; then ev_unknown proj-browser-extension file "browser-extension scan failed" "$RG_CMD" "$(head -c 200 "$TMPD/rg.err")"
else ev_absent proj-browser-extension file "" 4 "no browser extension manifest" "rg '\"manifest_version\"' -g manifest.json" "no manifest.json with manifest_version $EXCL_NOTE"; fi
# wasm target
WASM=""; dep_has "cargo cargo_dev npm npm_dev" '^(wasm-bindgen|wasm-pack|js-sys|web-sys|wasm-bindgen-futures|trunk|@wasm-tool/.*|vite-plugin-wasm|wasm-opt)$' && WASM="deps: $DEP_HIT"
[ -n "$(mk cargo.wasm_cfg)" ] && WASM="${WASM:+$WASM; }.cargo/config targets wasm32"
any_file '(^|/)Trunk\.toml$' && WASM="${WASM:+$WASM; }Trunk.toml"
[ -n "$(mk cargo.cdylib)" ] && [ -n "$WASM" ] && WASM="$WASM; cdylib: $(mk cargo.cdylib | tr ';' ' ')"
if [ -n "$WASM" ]; then ev_present proj-wasm-target file "$(manifest_loc Cargo.toml package.json || true)" 4 "builds for wasm32" "python3 (parse manifests, .cargo/config, Trunk.toml)" "$WASM"
else scan_signal proj-wasm-target 0 3 1 "wasm32 build target references" 'wasm32-unknown-unknown|wasm32-wasip?[0-9]?|wasm-pack build|--target[= ]wasm32' '*.yml' '*.yaml' '*.toml' 'Makefile' 'justfile' '*.sh' '*.json'; fi
# mobile
if f=$(files_matching '(\.xcodeproj/|\.xcworkspace/|(^|/)android/app/build\.gradle(\.kts)?$|(^|/)AndroidManifest\.xml$|(^|/)ios/Podfile$|(^|/)capacitor\.config\.[a-z]+$|(^|/)app\.json$)' | head -1) && [ -n "$f" ]; then
  ev_present proj-mobile file "$(loc "$f")" 4 "iOS/Android target" "grep -E xcodeproj|build.gradle|AndroidManifest|Podfile|capacitor.config <inventory>" "$f"
elif dep_has "npm npm_dev" '^(react-native|expo|@capacitor/core|@ionic/.*|nativescript)$'; then ev_present proj-mobile file "$(manifest_loc package.json)" 4 "mobile framework dependency" "python3 (parse package.json)" "matched: $DEP_HIT"
else ev_absent proj-mobile file "" 4 "no iOS/Android target" "grep -E xcodeproj|gradle|AndroidManifest|Podfile|capacitor <inventory>; python3 (parse package.json)" "no Xcode/gradle/manifest/Podfile files and no react-native/expo/capacitor dependency"; fi
# data pipeline
if dep_has "py npm cargo go" '^(apache-airflow|airflow|dagster|prefect|luigi|pyspark|dbt-core|dbt|kedro|mage-ai|polars|pandas|snowflake-connector-python|fsnow)$' && [ "$(sig_state proj-web-app)" != present ]; then
  ev_present proj-data-pipeline file "$(manifest_loc pyproject.toml requirements.txt package.json Cargo.toml || true)" 3 "batch/ETL data pipeline dependencies" "python3 (parse manifests) | grep -E pipeline deps" "matched: $DEP_HIT"
elif f=$(files_matching '(^|/)(dags|pipelines|etl)/[^/]+\.(py|sql)$|(^|/)dbt_project\.yml$' | head -1) && [ -n "$f" ]; then ev_present proj-data-pipeline file "$(loc "$f")" 3 "pipeline/DAG source layout" "grep -E 'dags|pipelines|etl|dbt_project' <inventory>" "$f"
else scan_signal proj-data-pipeline 1 2 2 "ETL/DAG code" '\b(@dag|@task|DAG\(|SparkSession|COPY INTO|MERGE INTO|read_parquet|to_parquet|scan_parquet|LazyFrame)\b' '*.py' '*.sql' '*.rs'; fi
# ml inference
if any_file '\.(safetensors|gguf|onnx|pt|pth|ckpt|tflite|mlmodel)$'; then f=$(files_matching '\.(safetensors|gguf|onnx|pt|pth|ckpt|tflite|mlmodel)$' | head -1)
  ev_present proj-ml-inference file "$(loc "$f")" 4 "model weight files in tree" "grep -E weights <inventory>" "$(count_files '\.(safetensors|gguf|onnx|pt|pth|ckpt|tflite|mlmodel)$') weight files, e.g. $f"
elif dep_has "py cargo npm go" '^(torch|onnxruntime|ort|candle-core|candle-nn|candle|burn|tch|tract-onnx|tract|llama-cpp-2|llama_cpp|ggml|safetensors|tokenizers|transformers|onnxruntime-node|@xenova/transformers|@huggingface/transformers|whisper-rs|ctranslate2|mlx|coremltools|gguf)$'; then
  ev_present proj-ml-inference file "$(manifest_loc pyproject.toml Cargo.toml package.json || true)" 4 "model inference dependencies" "python3 (parse manifests) | grep -E inference deps" "matched: $DEP_HIT"
else scan_signal proj-ml-inference 1 2 2 "model inference code" '\b(safetensors|gguf|quantiz|dequantiz|load_weights|from_pretrained|onnx|kv_cache|logits)\b'; fi
# research code
PACKAGED=0; [ "$(mk manifest.dirs)" -gt 0 ] && PACKAGED=1
if { [ "$(kv ipynb "$INV")" -gt 0 ] || any_file '^(papers?|experiments?|notebooks?)/'; } && [ $PACKAGED = 0 ]; then
  ev_present proj-research-code file "$(loc "$(files_matching '\.ipynb$|^(papers?|experiments?|notebooks?)/' | head -1)")" 3 "research/experiment code without packaging" "grep -E ipynb|papers/|experiments/ <inventory>; manifest count" "$(kv ipynb "$INV") notebooks; no packaging manifest"
else ev_absent proj-research-code file "" 3 "not research/experiment code" "grep -E ipynb|papers/|experiments/ <inventory>; manifest count" "$(kv ipynb "$INV") notebooks; papers/experiments dirs: $(any_file '^(papers?|experiments?|notebooks?)/' && echo yes || echo no); packaged: $PACKAGED"; fi
# monorepo
MONO=""; [ "$(mk cargo.member_count)" -ge 2 ] && MONO="cargo workspace with $(mk cargo.member_count) members"
[ -n "$(mk npm.workspaces)" ] && MONO="${MONO:+$MONO; }npm workspaces ($(mk npm.workspaces | tr ';' ' '))"
[ -n "$(mk ws.files)" ] && MONO="${MONO:+$MONO; }$(mk ws.files | tr ';' ' ')"
[ "$(mk manifest.dirs)" -ge 3 ] && MONO="${MONO:+$MONO; }$(mk manifest.dirs) manifest directories"
if [ -n "$MONO" ]; then ev_present proj-monorepo file "$(manifest_loc Cargo.toml package.json pnpm-workspace.yaml go.work || true)" 4 "several deliverables in one repo" "python3 (parse manifests: workspace members, workspaces, manifest dirs)" "$MONO"
else ev_absent proj-monorepo file "" 4 "single deliverable repo" "python3 (parse manifests: workspace members, workspaces, manifest dirs)" "cargo members $(mk cargo.member_count); npm workspaces none; manifest dirs $(mk manifest.dirs)"; fi
# docs site / marketing site / skills repo
DOCSITE=""; { [ "$(sig_state fw-nextra)" = present ]; } && DOCSITE="nextra"
dep_has "npm npm_dev py" '^(@docusaurus/core|vitepress|astro|@astrojs/starlight|mkdocs|mkdocs-material|sphinx|docsify)$' && DOCSITE="${DOCSITE:+$DOCSITE; }$DEP_HIT"
f=$(files_matching '(^|/)(mkdocs\.yml|book\.toml|docusaurus\.config\.[a-z]+|docs/conf\.py|\.vitepress/config\.[a-z]+|astro\.config\.[a-z]+)$' | head -1); [ -n "$f" ] && DOCSITE="${DOCSITE:+$DOCSITE; }$f"
if [ -n "$DOCSITE" ]; then ev_present proj-docs-site file "${f:+$(loc "$f")}" 4 "documentation site exists" "python3 (parse manifests) + grep -E mkdocs.yml|book.toml|docusaurus.config <inventory>" "$DOCSITE"
else ev_absent proj-docs-site file "" 4 "no documentation site" "python3 (parse manifests) + grep -E mkdocs.yml|book.toml|docusaurus.config|.vitepress <inventory>" "no nextra/docusaurus/vitepress/starlight/mkdocs/mdBook/sphinx config"; fi
SITE_DIR=$(files_matching '^(site|website|www|landing|marketing)/(index\.html|package\.json|src/|app/|pages/)' | head -1 | cut -d/ -f1)
HOMEPAGE="$(mk cargo.homepage | tr ';' ' ') $(mk npm.homepage | tr ';' ' ')"; HOMEPAGE=$(printf '%s' "$HOMEPAGE" | tr ' ' '\n' | grep -vE '^$|github\.com|gitlab\.com|crates\.io|npmjs\.com|pypi\.org' | tr '\n' ' ' | sed 's/ $//')
if [ -n "$SITE_DIR" ]; then ev_present proj-marketing-site file "$(loc "$SITE_DIR")" 3 "marketing/landing site directory in repo" "grep -E '^(site|website|www|landing|marketing)/' <inventory>" "$SITE_DIR/"
elif [ -n "$HOMEPAGE" ]; then ev_present proj-marketing-site file "$(manifest_loc Cargo.toml package.json || true)" 2 "project declares a homepage URL" "python3 (manifest homepage fields)" "$HOMEPAGE"
else ev_absent proj-marketing-site file "" 3 "no marketing/landing site in repo" "grep -E '^(site|website|www|landing|marketing)/' <inventory>; manifest homepage" "no site/website/www/landing dir and no homepage field"; fi
SKILLS=$(kv skill_md "$INV")
if [ "$SKILLS" -ge 2 ]; then ev_present proj-skills-repo file "$(loc "$(files_matching '(^|/)SKILL\.md$' | head -1)")" 4 "repo is a collection of SKILL.md packages" "grep -c SKILL.md <inventory>" "$SKILLS SKILL.md files"
else ev_absent proj-skills-repo file "" 4 "repo is not a skills collection" "grep -c SKILL.md <inventory>" "$SKILLS SKILL.md files (threshold 2)"; fi

# ------------------------------------------------------------------ code kinds (rg over non-generated source)
scan_signal code-concurrency-primitives 1 3 1 "concurrency primitives in non-test code" '\b(Mutex|RwLock|Condvar|Semaphore|Atomic(Usize|U64|U32|Bool|I64|Ptr)|parking_lot|tokio::sync|std::sync::mpsc|crossbeam|flume|mpsc::channel|sync\.(Mutex|RWMutex|WaitGroup)|threading\.(Lock|RLock|Semaphore)|asyncio\.(Lock|Semaphore)|std::(mutex|atomic|condition_variable))\b'
# async-holding-lock: a std/parking_lot guard (.lock()/.read()/.write() without .await on that line) within 10 lines of an .await in the same fn, or block_on inside an async fn
AHL_CMD="rg -l '\.await' -g '*.rs' ∩ rg -l '\.(lock|read|write)\(' | python3 (±10-line window in one fn; block_on inside async fn)"
if [ "$(sig_state lang-rust)" = present ] || any_file '\.rs$'; then
  rg_lines '\.await' 1 '*.rs' | cut -d: -f1 | LC_ALL=C sort -u > "$TMPD/ahl_a"; rc1=$RG_RC
  rg_lines '\.(lock|read|write)\(\)' 1 '*.rs' | cut -d: -f1 | LC_ALL=C sort -u > "$TMPD/ahl_b"; rc2=$RG_RC
  if is_timeout "$rc1" || is_timeout "$rc2" || [ "$rc1" = 2 ] || [ "$rc2" = 2 ]; then ev_unknown code-async-holding-lock file "async-holding-lock scan failed" "$AHL_CMD" "rg exit $rc1/$rc2: $(head -c 200 "$TMPD/rg.err")"
  else
    LC_ALL=C comm -12 "$TMPD/ahl_a" "$TMPD/ahl_b" | python3 -c '
import sys, re
hits = []
for path in [l.strip() for l in sys.stdin if l.strip()]:
    try: lines = open(path, encoding="utf-8", errors="replace").read().split("\n")
    except Exception: continue
    fn_start = {}; cur = 0; is_async = False
    for i, l in enumerate(lines):
        if re.match(r"^\s*(pub(\([^)]*\))?\s+)?(async\s+)?(unsafe\s+)?fn\s", l): cur = i; is_async = bool(re.search(r"\basync\s+fn\b", l))
        fn_start[i] = (cur, is_async)
        if is_async and "block_on(" in l: hits.append("%s:%d: block_on inside async fn" % (path, i + 1))
    guard = [i for i, l in enumerate(lines) if re.search(r"\.(lock|read|write)\(\)", l) and ".await" not in l and not l.strip().startswith("//")]
    awaits = [i for i, l in enumerate(lines) if ".await" in l]
    for g in guard:
        for a in awaits:
            if 0 < a - g <= 10 and fn_start[g][0] == fn_start[a][0]:
                hits.append("%s:%d: guard at line %d, .await at line %d" % (path, g + 1, g + 1, a + 1)); break
hits.sort()
print(len(hits)); print("\n".join(hits[:3]))' > "$TMPD/ahl_out"
    n=$(head -1 "$TMPD/ahl_out"); n=${n:-0}
    if [ "$n" -gt 0 ]; then first=$(sed -n 2p "$TMPD/ahl_out"); ev_present code-async-holding-lock file "$(loc_of_match "$first")" 2 "await while a sync lock guard is live (heuristic)" "$AHL_CMD" "$n suspect sites; e.g. $(sed -n '2,4p' "$TMPD/ahl_out" | tr '\n' ';')"
    else ev_absent code-async-holding-lock file "" 2 "no await-holding-lock pattern (heuristic)" "$AHL_CMD" "$(grep -c . "$TMPD/ahl_a") files with .await, $(grep -c . "$TMPD/ahl_b") with sync guards, 0 overlapping windows; test paths excluded"; fi
  fi
else ev_absent code-async-holding-lock file "" 2 "no Rust sources, so no await-holding-lock pattern" "$AHL_CMD" "no .rs files in inventory"; fi
scan_signal code-lock-free 1 3 1 "lock-free/atomic-ordering code" 'Ordering::(Acquire|Release|AcqRel|SeqCst|Relaxed)|crossbeam_epoch|crossbeam::epoch|compare_exchange|fetch_(add|sub|or|and)\(|atomic\.(Add|Load|Store|CompareAndSwap)[A-Za-z0-9]*\(|\block[- ]?free\b|memory_order_'
# unsafe: count in non-test, non-generated Rust
UNSAFE_OUT=$(rg_lines '^[^/]*\bunsafe[[:space:]]*(\{|fn\b|impl\b|trait\b|extern\b)' 1 '*.rs'); UNSAFE_RC=$RG_RC; UNSAFE_CMD="$RG_CMD"
UNSAFE_N=$(printf '%s\n' "$UNSAFE_OUT" | grep -c .)
if is_timeout "$UNSAFE_RC" || [ "$UNSAFE_RC" = 2 ]; then
  ev_unknown code-unsafe-any file "unsafe scan failed" "$UNSAFE_CMD" "rg exit $UNSAFE_RC: $(head -c 200 "$TMPD/rg.err")"
  ev_unknown code-unsafe-heavy file "unsafe density unknown" "$UNSAFE_CMD" "rg exit $UNSAFE_RC"
elif [ "$UNSAFE_N" -gt 0 ]; then
  first=$(printf '%s\n' "$UNSAFE_OUT" | head -1); UF=$(printf '%s\n' "$UNSAFE_OUT" | cut -d: -f1 | LC_ALL=C sort -u | grep -c .)
  ev_present code-unsafe-any file "$(loc_of_match "$first")" 4 "unsafe blocks/fns in non-generated non-test Rust" "$UNSAFE_CMD" "$UNSAFE_N unsafe sites in $UF files; e.g. $(printf '%s' "$first" | cut -d: -f1,2): $(snippet "$first")"
  HEAVY=0; [ "$UNSAFE_N" -ge 5 ] && HEAVY=1; [ "$RUST_LOC" -gt 0 ] && [ $(( UNSAFE_N * 500 )) -ge "$RUST_LOC" ] && HEAVY=1
  if [ "$COUNTED" != 1 ] && [ "$UNSAFE_N" -lt 5 ]; then ev_unknown code-unsafe-heavy file "unsafe density unknown (line counting skipped)" "$UNSAFE_CMD" "$UNSAFE_N sites; LOC not counted (--max-files)"
  elif [ $HEAVY = 1 ]; then ev_present code-unsafe-heavy file "$(loc_of_match "$first")" 4 "unsafe-heavy Rust" "$UNSAFE_CMD" "$UNSAFE_N unsafe sites vs $RUST_LOC non-test Rust LOC (threshold >=5 or >=1 per 500 LOC)"
  else ev_absent code-unsafe-heavy file "" 4 "unsafe present but not heavy" "$UNSAFE_CMD" "$UNSAFE_N unsafe sites vs $RUST_LOC non-test Rust LOC (threshold >=5 or >=1 per 500 LOC)"; fi
else
  ev_absent code-unsafe-any file "" 4 "no unsafe in non-generated non-test Rust" "$UNSAFE_CMD" "0 unsafe sites $EXCL_NOTE; test paths excluded; inline #[cfg(test)] modules are still scanned"
  ev_absent code-unsafe-heavy file "" 4 "no unsafe, so not unsafe-heavy" "$UNSAFE_CMD" "0 unsafe sites"
fi
scan_signal code-ffi-boundary 1 3 1 "FFI boundary (extern C / bindgen / N-API / cffi)" 'extern "C"|#\[no_mangle\]|\bbindgen::|cbindgen|#\[napi|napi::|\bcffi\b|ctypes\.(CDLL|cdll|c_)|import "C"|#\[pyfunction\]|#\[pymodule\]|\bjni::|extern crate libc|napi_create_'
scan_signal code-wasm-bindgen 1 4 1 "wasm-bindgen/js-sys/web-sys usage" '#\[wasm_bindgen|wasm_bindgen::|\bjs_sys::|\bweb_sys::' '*.rs'
scan_signal code-simd-hot-loops 1 3 1 "SIMD intrinsics or explicit hot-path vectorization" '(core|std)::arch::|_mm(256|512)?_[a-z0-9_]+\(|\bv(add|mul|ld1|st1|dot)q_|#\[target_feature|std::simd|portable_simd|__m(128|256|512)i?\b|#pragma omp simd|\bwide::|#\[inline\(always\)\]'
BENCH=""; any_file '(^|/)benches/[^/]+\.(rs|go|py|ts|js)$' && BENCH="benches/ directory"
dep_has "cargo cargo_dev py npm_dev go" '^(criterion|divan|iai|iai-callgrind|pytest-benchmark|benchmark|tinybench|vitest|github\.com/.*/benchstat)$' && BENCH="${BENCH:+$BENCH; }deps: $DEP_HIT"
if out=$(rg_lines '\bhyperfine\b|#\[bench\]|testing\.B\b|\bBenchmark[A-Z][A-Za-z0-9_]*\(b \*testing\.B' 0 '*.sh' '*.rs' '*.go' 'Makefile' 'justfile' '*.yml' '*.yaml') && [ -n "$out" ]; then BENCH="${BENCH:+$BENCH; }$(printf '%s\n' "$out" | grep -c .) bench markers (e.g. $(printf '%s\n' "$out" | head -1 | cut -d: -f1,2))"; fi
BENCH_LOC=$(files_matching '(^|/)benches/' | head -1); [ -z "$BENCH_LOC" ] && [ -n "${out:-}" ] && BENCH_LOC=$(printf '%s\n' "$out" | head -1 | cut -d: -f1); [ -z "$BENCH_LOC" ] && BENCH_LOC=$(first_existing Cargo.toml package.json pyproject.toml go.mod || true)
if [ -n "$BENCH" ]; then ev_present bench-harness-present file "$(loc "$BENCH_LOC")" 4 "benchmark harness present" "grep benches/ <inventory>; python3 (parse manifests); rg hyperfine|#[bench]|testing.B" "$BENCH"
else ev_absent bench-harness-present file "" 4 "no benchmark harness" "grep benches/ <inventory>; python3 (parse manifests); rg hyperfine|#[bench]|testing.B" "no benches/ dir, no criterion/divan/iai/pytest-benchmark dependency, no hyperfine/#[bench]/testing.B markers"; fi
scan_signal code-parser 1 3 2 "hand-written parser/lexer/decoder" '\bfn (parse|lex|tokenize|decode)[A-Za-z0-9_]*\(|impl FromStr for|\bfn from_str\(|\b(nom|winnow|pest|logos|chumsky|lalrpop|tree_sitter)::|\b(struct|class|type) (Parser|Lexer|Tokenizer|Scanner)\b|\bdef (parse|tokenize|lex)[A-Za-z0-9_]*\(|\bfunc (parse|lex|tokenize)[A-Za-z0-9_]*\(|func \([a-z]+ \*?(Parser|Lexer)\)'
scan_signal code-binary-format 1 3 2 "binary format read/write" 'from_(le|be)_bytes|to_(le|be)_bytes|\bbyteorder::|read_u(16|32|64)|(Little|Big)Endian|\bMAGIC(_NUMBER|_BYTES)?\b|magic_number|struct\.(pack|unpack)\(|binary\.(Read|Write|LittleEndian|BigEndian)|encoding/binary|\bzerocopy::|\bbytemuck::|\bhtonl\(|nom::number'
scan_signal code-storage-engine 1 3 2 "storage engine internals (WAL/MVCC/B-tree/page cache/fsync)" '\bWAL\b|write_ahead|\bMVCC\b|\bB[-+]?[Tt]ree\b|\bBTreePage|page_cache|PageCache|\bfsync\b|sync_all\(\)|fdatasync|\bLSM\b|SSTable|memtable|\bPager\b|struct Page\b|checkpoint\('
scan_signal code-network-protocol 1 3 2 "custom wire protocol/transport" '\b(framing|Frame::|Codec|Decoder for|Encoder for|handshake|Handshake|quinn::|QUIC|UdpSocket|tokio_util::codec|LengthDelimited|fountain|RaptorQ|raptorq|WireFormat|PROTOCOL_VERSION|wire_version)\b'
scan_signal code-crypto-auth 1 3 2 "cryptography or authentication code" '\b(ring::|rustls|ed25519|Ed25519|hmac::|Hmac<|sha2::|Sha256::|argon2|bcrypt|jsonwebtoken|jwt\.(sign|verify|decode)|OAuth2?|oauth2|PKCE|pkce|passport\.|NextAuth|getServerSession|clerk|lucia|jose|crypto\.subtle|openssl::|aes_gcm|AesGcm|ChaCha20|x25519|secp256k1|verify_signature|sign_message|signature\.verify|Bearer )'
scan_signal code-payments-billing 1 3 3 "billing logic (subscriptions, invoices, checkout, entitlements)" '\b(Stripe|stripe::|stripe\.(webhooks|checkout|customers|subscriptions|paymentIntents|prices|products|invoices)|PayPal|paypal|Paddle|lemonsqueezy|checkout\.sessions|PaymentIntent|payment_intent|Invoice|invoice_id|entitlement|billing_portal|price_id|subscription_id|Subscription(Status|Tier|Plan))\b'
scan_signal code-webhooks 1 3 1 "inbound webhook handlers" '\b(webhook|Webhook|constructEvent|verify_webhook|X-Hub-Signature|Stripe-Signature|stripe-signature|svix|webhooks\.constructEvent)\b'
scan_signal code-arena-self-referential 1 3 2 "arena/slab/self-referential structures" '\bPin<|Pin::new|pin_project|PhantomPinned|NonNull<|\*mut |\*const |\b(Arena|arena|slab::|Slab<|SlotMap|generational_arena|typed_arena|bumpalo|petgraph|NodeIndex|struct NodeId)\b'
if any_file '\.(cu|cuh|metal|wgsl|cl)$'; then f=$(files_matching '\.(cu|cuh|metal|wgsl|cl)$' | head -1); ev_present code-gpu-cuda file "$(loc "$f")" 4 "GPU kernel sources" "grep -E '\.(cu|cuh|metal|wgsl|cl)$' <inventory>" "$(count_files '\.(cu|cuh|metal|wgsl|cl)$') kernel files, e.g. $f"
else scan_signal code-gpu-cuda 1 3 1 "CUDA/Metal/wgpu kernels" '\b(__global__|cudaMalloc|cudaMemcpy|cublas|cuBLAS|cust::|cudarc|wgpu::|MTLDevice|metal::Device|kernel void|vulkano::|\bash::vk|opencl|OpenCL|ComputePipeline)\b'; fi
scan_signal code-ml-kernels 1 3 2 "matmul/attention/quantization kernels implemented in-tree" '\b(fn|def|func) (matmul|gemm|sgemm|attention|softmax|rms_?norm|layer_?norm|rope|quantize|dequantize|q4_0|q8_0|kv_cache)[A-Za-z0-9_]*\(|\b(vdotq|_dpbusd|vpdpbusd|VNNI|SDOT|udot)\b'
scan_signal code-tui-renderer 1 3 2 "bespoke terminal renderer/layout engine" 'struct (Cell|CellBuffer|ScreenBuffer|Grid|Surface|Viewport)\b|\\x1b\[|\\u\{1b\}\[|\\033\[|EnterAlternateScreen|alternate_screen|\bfn (render|draw|flush|present|diff)\(|\b(termwiz|vte|vt100|crossterm|ratatui|termion)::' '*.rs' '*.go' '*.py' '*.ts' '*.zig' '*.c'
# cli subcommands: max variants of a clap Subcommand enum, or builder/cobra/argparse/click/commander counts
CLI_CMD="rg -l 'Subcommand|Command::new|AddCommand|add_parser|\.command\(' | python3 (count clap enum variants / builder calls)"
rg_lines 'derive\([^)]*Subcommand|\.subcommand\(|Command::new\(|\bAddCommand\(|add_parser\(|@[a-z_]+\.command\(|\.command\(["'"'"']' 1 '*.rs' '*.go' '*.py' '*.ts' '*.js' | cut -d: -f1 | LC_ALL=C sort -u > "$TMPD/cli_files"; CLI_RC=$RG_RC
if is_timeout "$CLI_RC" || [ "$CLI_RC" = 2 ]; then ev_unknown code-cli-subcommands file "subcommand scan failed" "$CLI_CMD" "rg exit $CLI_RC"
else
  python3 - "$TMPD/cli_files" <<'PY' > "$TMPD/cli_out"
import sys, re
best, where, parts = 0, "", []
for path in [l.strip() for l in open(sys.argv[1]) if l.strip()]:
    try: txt = open(path, encoding="utf-8", errors="replace").read()
    except Exception: continue
    if path.endswith(".rs"):
        for m in re.finditer(r"#\[derive\([^)]*\bSubcommand\b[^)]*\)\][\s\S]*?\benum\s+(\w+)\s*\{", txt):
            depth, i, variants = 1, m.end(), 0
            body_start = i
            while i < len(txt) and depth > 0:
                if txt[i] == "{": depth += 1
                elif txt[i] == "}": depth -= 1
                i += 1
            body = txt[body_start:i - 1]
            d = 0
            for line in body.split("\n"):
                s = line.strip()
                if d == 0 and re.match(r"^[A-Z]\w*\s*(\{|\(|,|$|//)", s): variants += 1
                d += line.count("{") + line.count("(") - line.count("}") - line.count(")")
            parts.append("%s enum %s: %d variants" % (path, m.group(1), variants))
            if variants > best: best, where = variants, path
        n = len(re.findall(r"\.subcommand\(\s*Command::new\(", txt))
        if n: parts.append("%s: %d builder subcommands" % (path, n))
        if n > best: best, where = n, path
    else:
        n = len(re.findall(r"\bAddCommand\(|add_parser\(|@[a-z_]+\.command\(|\.command\([\"']", txt))
        if n: parts.append("%s: %d subcommand registrations" % (path, n))
        if n > best: best, where = n, path
print(best); print(where); print("; ".join(sorted(parts)[:6]))
PY
  CLI_N=$(sed -n 1p "$TMPD/cli_out"); CLI_N=${CLI_N:-0}; CLI_WHERE=$(sed -n 2p "$TMPD/cli_out")
  if [ "$CLI_N" -ge 5 ]; then ev_present code-cli-subcommands file "$(loc "$CLI_WHERE")" 3 "multi-subcommand CLI surface (>= 5 subcommands)" "$CLI_CMD" "max $CLI_N subcommands; $(sed -n 3p "$TMPD/cli_out")"
  else ev_absent code-cli-subcommands file "" 3 "fewer than 5 subcommands" "$CLI_CMD" "max $CLI_N subcommands across $(grep -c . "$TMPD/cli_files") candidate files; $(sed -n 3p "$TMPD/cli_out")"; fi
fi
scan_signal code-json-robot-mode 1 3 1 "CLI --json/--robot output mode" '--json\b|--robot\b|--format[= ]json|--output[= ]json|OutputFormat::Json|"json" =>' '*.rs' '*.go' '*.py' '*.ts' '*.js' '*.md'
scan_signal code-doctor-command 1 3 1 "doctor/diagnose subcommand" '"doctor"|\bDoctor\b|\bdoctor\(|"diagnose"|\bDiagnose\b|"health-check"|"healthcheck"|"check-health"' '*.rs' '*.go' '*.py' '*.ts' '*.js'
if f=$(files_matching '(^|/)(install|installer|install-[a-z]+)\.(sh|ps1)$|^scripts/install[^/]*\.sh$' | head -1) && [ -n "$f" ]; then ev_present code-installer-script file "$(loc "$f")" 4 "installer script present" "grep -E 'install.*\.(sh|ps1)$' <inventory>" "$f"
else scan_signal code-installer-script 0 3 1 "curl-pipe-shell installer" 'curl [^|]*\| *(sudo )?(sh|bash)\b|irm [^|]*\| *iex' '*.md' '*.sh' '*.html' '*.mdx'; fi
REL=""; f=$(files_matching '^\.github/workflows/[^/]*(release|publish|deploy)[^/]*\.ya?ml$' | head -1); [ -n "$f" ] && REL="$f"
f2=$(files_matching '(^|/)(dist-workspace\.toml|\.goreleaser\.ya?ml|release-please-config\.json|\.releaserc[^/]*|cliff\.toml|release\.sh|scripts/release[^/]*)$' | head -1); [ -n "$f2" ] && REL="${REL:+$REL; }$f2"
dep_has "npm_dev npm" '^(semantic-release|release-it|changesets|@changesets/cli|np)$' && REL="${REL:+$REL; }deps: $DEP_HIT"
grep -q 'workspace.metadata.dist\|\[workspace\.metadata\.dist\]' Cargo.toml 2>/dev/null && REL="${REL:+$REL; }cargo-dist metadata"
if [ -n "$REL" ]; then ev_present code-release-workflow file "$(loc "${f:-${f2:-Cargo.toml}}")" 4 "release automation present" "grep -E release|publish workflow|goreleaser|cargo-dist|semantic-release <inventory/manifests>" "$REL"
else ev_absent code-release-workflow file "" 4 "no release automation" "grep -E release|publish workflow|goreleaser|cargo-dist|semantic-release <inventory/manifests>" "no release/publish workflow, goreleaser, cargo-dist, release-please, cliff, semantic-release, or release script"; fi
scan_signal code-mcp-tools 1 3 1 "MCP tool definitions in-tree" '@mcp\.tool|@server\.tool|server\.(tool|registerTool)\(|\.tool\([[:space:]]*"|#\[tool\(|ListToolsRequestSchema|CallToolRequestSchema|"tools/call"|"tools/list"|rmcp::|FastMCP\('
SWARM=""; [ -d .beads ] && SWARM=".beads/"; [ -f .agent-mail-project-id ] && SWARM="${SWARM:+$SWARM; }.agent-mail-project-id"
f=$(files_matching '(^|/)(\.ntm/|ntm\.toml|\.ntm\.toml|\.ntm\.ya?ml|swarm[^/]*\.(md|toml|ya?ml|json))' | head -1); [ -n "$f" ] && SWARM="${SWARM:+$SWARM; }$f"
if [ -n "$SWARM" ]; then ev_present code-agent-swarm-scaffolding file "$(loc "${f:-${SWARM%%;*}}")" 4 "agent swarm scaffolding present" "ls .beads .agent-mail-project-id; grep -E ntm|swarm <inventory>" "$SWARM"
else scan_signal code-agent-swarm-scaffolding 0 2 2 "swarm orchestration docs" '\b(agent swarm|Agent Mail|agent-mail|ntm (spawn|send|status)|swarm orchestration|MCP Agent Mail)\b' 'AGENTS.md' 'CLAUDE.md' '*.md'; fi
scan_signal code-numeric-transforms 1 3 3 "numerical/transform code with algebraic relations" '\b(fft|FFT|convolve|Convolution|eigen(value|vector)|determinant|transpose|quantile|percentile|z_?score|std_dev|stddev|variance|covariance|kurtosis|interpolat[a-z]*|dijkstra|Dijkstra|topological_sort|shortest_path|pagerank|PageRank|betweenness|centrality|voronoi|delaunay|bezier|Quaternion|quaternion|kalman|Kalman|welford|Welford|histogram|Histogram|entropy|sigmoid|spline|Spline|reed_solomon|ReedSolomon|galois|fountain|raptorq|cosine_similarity|dot_product|cross_product|normalize_vec|matmul)\b'
scan_signal code-codegen-renderer 1 3 2 "renderer/code generator/exporter producing durable artifacts" '\b(Renderer|CodeGen|Codegen|Emitter|Exporter|TemplateEngine)\b|\bfn (render|render_to_[a-z]+|to_html|to_svg|to_pdf|to_png|generate_code|emit|export_[a-z]+|write_to)\(|\b(tera|askama|handlebars|minijinja|printpdf|resvg|tiny_skia)::|\bdef (render|to_html|to_svg|generate_code)\('
SPEC=""; f=$(files_matching '(^|/)(SPEC[^/]*\.md|spec/[^/]+|conformance/[^/]+|PARITY[^/]*\.md|oracle[^/]*/)' | head -1); [ -n "$f" ] && SPEC="$f"
if [ -n "$SPEC" ]; then ev_present code-spec-reimplementation file "$(loc "$SPEC")" 3 "spec/oracle-driven reimplementation (spec or conformance files)" "grep -E 'SPEC|spec/|conformance/|PARITY|oracle' <inventory>" "$SPEC"
else scan_signal code-spec-reimplementation 0 2 2 "spec/oracle reimplementation vocabulary" '\b(RFC ?[0-9]{3,5}|conformance|reference implementation|byte-for-byte|bit-identical|parity (matrix|harness|test|suite)|against (the )?(upstream|original|reference) (implementation|oracle|sqlite|rsync))\b' '*.md' '*.rs' '*.py' '*.go' '*.ts' '*.zig' '*.c'; fi
PORT=""; f=$(grep -E -- '(^|/)(upstream|legacy[^/]*|reference|orig|original)/.*\.(c|cc|cpp|h|py|zig|go|js|ts)$|(^|/)(PORT(ING)?[^/]*|PARITY[^/]*)\.md$' "$ALL" | grep -vE '(^|/)(node_modules|vendor|target)/' | LC_ALL=C sort | head -1); [ -n "$f" ] && PORT="$f"
if [ -n "$PORT" ]; then ev_present code-port-of-other-language file "$(loc "$PORT")" 3 "port of another language (upstream/parity files)" "grep -E 'upstream/|reference/|PORT|PARITY' <inventory>" "$PORT"
else scan_signal code-port-of-other-language 0 2 2 "port-of-other-language vocabulary" '\b(ported from|port of the|(C|C\+\+|Python|Zig|Go|JavaScript|TypeScript) (implementation|version|original|source) (was|is|has been) ported|faithful port|1:1 port|line-by-line port|upstream commit|parity with (the )?(C|Python|Go|Zig|upstream|original))\b' '*.md' '*.rs' '*.zig' '*.go'; fi
if dep_has "cargo npm py go gem" '^(rusqlite|sqlx|fsqlite|fsqlite-.*|libsql|turso|diesel|sea-orm|better-sqlite3|sqlite3|sqlite|aiosqlite|sqlite-utils|modernc\.org/sqlite|github\.com/mattn/go-sqlite3|sqlalchemy|drizzle-orm)$' && { printf '%s' "$DEP_HIT" | grep -qvE '^(sqlx|sqlalchemy|diesel|sea-orm|drizzle-orm)$' || grep -rqiE 'sqlite' --include=Cargo.toml --include=package.json --include=pyproject.toml --include='*.config.*' . 2>/dev/null; }; then
  ev_present code-sqlite-persistence file "$(manifest_loc Cargo.toml package.json pyproject.toml go.mod || true)" 4 "persists state in SQLite (dependency)" "python3 (parse manifests) | grep -E sqlite deps" "matched: $DEP_HIT"
else scan_signal code-sqlite-persistence 1 3 1 "SQLite persistence code" '\b(rusqlite::|sqlite3\.connect\(|better-sqlite3|Connection::open\(|PRAGMA journal_mode|sqlite:///|\.db"\)|fsqlite::)'; fi
if dep_has "cargo npm py go" '^(tantivy|frankensearch|frankensearch-.*|meilisearch.*|typesense|fastembed|hnsw|hnsw_rs|usearch|faiss|faiss-cpu|lancedb|qdrant-client|instant-distance|bm25|rank-bm25|flexsearch|lunr|minisearch|fuse\.js|github\.com/blevesearch/bleve.*)$'; then
  ev_present code-search-index file "$(manifest_loc Cargo.toml package.json pyproject.toml go.mod || true)" 4 "implements or embeds a search index (dependency)" "python3 (parse manifests) | grep -E search deps" "matched: $DEP_HIT"
else scan_signal code-search-index 1 3 2 "search index implementation" '\b(BM25|bm25|InvertedIndex|inverted_index|fts5|FTS5|hnsw|Hnsw|VectorIndex|TwoTierSearcher|IndexBuilder|EmbedderStack|cosine_similarity|reciprocal_rank|rrf_fuse|TermFrequency|posting_list|PostingList)\b'; fi

# ------------------------------------------------------------------ tests
TEST_INC='**/tests/** **/test/** **/spec/** **/specs/** **/__tests__/** **/e2e/** *_test.* *.test.* *.spec.* test_*.py *_tests.rs tests.rs'
scan_signal tests-unit 0 4 1 "unit tests" '#\[(tokio::)?test\]|#\[cfg\(test\)\]|^[[:space:]]*def test_[a-z0-9_]*\(|^func Test[A-Z][A-Za-z0-9_]*\(|^[[:space:]]*(it|test|describe)\(["'"'"'`]|@pytest\.|unittest\.TestCase|@Test\b|XCTestCase|#\[test_case|#\[rstest|#\[cfg\(test\)\]' '*.rs' '*.py' '*.go' '*.ts' '*.tsx' '*.js' '*.jsx' '*.zig' '*.swift' '*.kt' '*.java'
if any_file '(^|/)tests/[^/]+\.(rs|py|go|ts|js|sh)$|(^|/)(integration|integration_tests|it)/[^/]+\.(rs|py|go|ts|js)$|_integration_test\.[a-z]+$'; then f=$(files_matching '(^|/)tests/[^/]+\.(rs|py|go|ts|js|sh)$|(^|/)(integration|integration_tests|it)/[^/]+\.(rs|py|go|ts|js)$|_integration_test\.[a-z]+$' | head -1)
  ev_present tests-integration file "$(loc "$f")" 4 "integration tests present" "grep -E 'tests/|integration/' <inventory>" "$(count_files '(^|/)tests/[^/]+\.(rs|py|go|ts|js|sh)$|(^|/)(integration|integration_tests|it)/[^/]+\.(rs|py|go|ts|js)$|_integration_test\.[a-z]+$') files, e.g. $f"
else scan_signal tests-integration 0 3 1 "integration test markers" '@pytest\.mark\.integration|//go:build integration|#\[cfg\(feature = "integration|describe\("integration|integration_test' $TEST_INC; fi
if any_file '(^|/)(e2e|end-to-end|end_to_end)/[^/]+|\.e2e\.[a-z]+$|(^|/)cypress/'; then f=$(files_matching '(^|/)(e2e|end-to-end|end_to_end)/[^/]+|\.e2e\.[a-z]+$|(^|/)cypress/' | head -1)
  ev_present tests-e2e file "$(loc "$f")" 4 "end-to-end tests present" "grep -E 'e2e/|.e2e.|cypress/' <inventory>" "$(count_files '(^|/)(e2e|end-to-end|end_to_end)/[^/]+|\.e2e\.[a-z]+$|(^|/)cypress/') files, e.g. $f"
elif [ "$(sig_state fw-playwright)" = present ] && any_file '(^|/)(tests?|specs?|e2e)/[^/]+\.(spec|test|e2e)\.(ts|tsx|js|jsx)$'; then
  f=$(files_matching '(^|/)(tests?|specs?|e2e)/[^/]+\.(spec|test|e2e)\.(ts|tsx|js|jsx)$' | head -1)
  ev_present tests-e2e file "$(loc "$f")" 4 "end-to-end tests (Playwright test file present)" "grep Playwright test files <inventory>" "$f"
else scan_signal tests-e2e 0 3 1 "end-to-end test drivers (real binaries or browsers invoked)" '\bassert_cmd::|cargo_bin\(|Command::cargo_bin|\bcypress\b|page\.goto\(|subprocess\.(run|check_output)\(\[?"?(cargo|\./|target/)|execa\(|spawnSync\(' $TEST_INC; fi
if dep_has "cargo_dev cargo py npm_dev npm go" '^(proptest|quickcheck|arbitrary|test-strategy|hypothesis|fast-check|pgregory\.net/rapid|github\.com/leanovate/gopter|@fast-check/.*)$'; then ev_present tests-property file "$(manifest_loc Cargo.toml pyproject.toml package.json go.mod || true)" 4 "property-based testing dependency" "python3 (parse manifests) | grep -E proptest|quickcheck|hypothesis|fast-check" "matched: $DEP_HIT"
else scan_signal tests-property 0 3 1 "property tests" 'proptest!|#\[quickcheck\]|@given\(|fc\.(assert|property)\(|rapid\.Check\(|gopter\.' '*.rs' '*.py' '*.ts' '*.js' '*.go'; fi
if any_file '(^|/)fuzz/fuzz_targets/[^/]+\.rs$|(^|/)fuzz/Cargo\.toml$|_fuzz_test\.go$|(^|/)fuzz(ers)?/[^/]+\.(py|c|cc|zig)$'; then f=$(files_matching '(^|/)fuzz/fuzz_targets/[^/]+\.rs$|(^|/)fuzz/Cargo\.toml$|_fuzz_test\.go$|(^|/)fuzz(ers)?/[^/]+\.(py|c|cc|zig)$' | head -1)
  ev_present tests-fuzz-targets file "$(loc "$f")" 4 "fuzz targets present" "grep -E 'fuzz/fuzz_targets|fuzz/Cargo.toml|_fuzz_test.go' <inventory>" "$(count_files '(^|/)fuzz/fuzz_targets/[^/]+\.rs$|(^|/)fuzz/Cargo\.toml$|_fuzz_test\.go$|(^|/)fuzz(ers)?/[^/]+\.(py|c|cc|zig)$') files, e.g. $f"
else scan_signal tests-fuzz-targets 0 3 1 "fuzz harness code" 'fuzz_target!|LLVMFuzzerTestOneInput|^func Fuzz[A-Z][A-Za-z0-9_]*\(f \*testing\.F|\batheris\b|honggfuzz|afl::fuzz|cargo[- ]fuzz' '*.rs' '*.go' '*.py' '*.c' '*.cc' '*.toml' '*.yml' '*.yaml'; fi
if dep_has "cargo_dev cargo npm_dev py go" '^(insta|expect-test|goldie|github\.com/sebdah/goldie.*|cupaloy|syrupy|pytest-snapshot|snapshottest|jest-image-snapshot)$' || any_file '(^|/)(__snapshots__|snapshots|golden|testdata)/[^/]+\.(snap|golden|json|txt|html|svg|out|png)$|\.golden$|\.snap$'; then
  f=$(files_matching '(^|/)(__snapshots__|snapshots|golden|testdata)/[^/]+|\.golden$|\.snap$' | head -1)
  ev_present tests-golden file "$(loc "${f:-$(first_existing Cargo.toml package.json pyproject.toml || true)}")" 4 "golden/snapshot tests present" "python3 (parse manifests) | grep insta|expect-test|goldie|syrupy; grep -E '__snapshots__|golden/|.snap$' <inventory>" "deps: ${DEP_HIT:-none}; files: ${f:-none} ($(count_files '(^|/)(__snapshots__|snapshots|golden|testdata)/[^/]+|\.golden$|\.snap$') matched)"
else scan_signal tests-golden 0 3 1 "golden/snapshot assertions" 'assert_(debug_|json_|yaml_|display_)?snapshot!|toMatch(Inline)?Snapshot\(|expect!\[|expect_file!|assertSnapshot|golden\.Assert|snapshot\.assert_match' '*.rs' '*.py' '*.ts' '*.tsx' '*.js' '*.go' '*.swift'; fi
scan_signal tests-metamorphic 0 3 1 "metamorphic relation tests" '\b(metamorphic|Metamorphic|relation_test|invariance_test|test_mr_|fn mr_|MR[0-9]+\b|metamorphic_relation)\b' '*.rs' '*.py' '*.ts' '*.js' '*.go' '*.zig'
if any_file '(^|/)(conformance|parity|compat|compliance)(_tests?)?/[^/]+'; then f=$(files_matching '(^|/)(conformance|parity|compat|compliance)(_tests?)?/[^/]+' | head -1)
  ev_present tests-conformance file "$(loc "$f")" 4 "conformance/parity harness directory" "grep -E 'conformance/|parity/|compat/' <inventory>" "$(count_files '(^|/)(conformance|parity|compat|compliance)(_tests?)?/[^/]+') files, e.g. $f"
else scan_signal tests-conformance 0 3 1 "conformance/parity/oracle tests" '\b(conformance|Conformance|parity_matrix|parity_test|oracle_test|OracleTest|against_upstream|compare_with_(c|python|upstream|reference)|reference_impl|golden_master|differential_test)\b' '*.rs' '*.py' '*.ts' '*.js' '*.go' '*.sh' '*.zig'; fi
if dep_has "cargo_dev cargo" '^(loom|shuttle)$'; then ev_present tests-loom-shuttle file "$(manifest_loc Cargo.toml)" 4 "loom/shuttle model checking dependency" "python3 (parse Cargo.toml) | grep -E loom|shuttle" "matched: $DEP_HIT"
else scan_signal tests-loom-shuttle 0 3 1 "loom/shuttle interleaving models" '\bloom::|#\[cfg\(loom\)\]|\bshuttle::(check|thread)' '*.rs'; fi
scan_signal tests-miri 0 4 1 "Miri runs configured" '\b(cargo (\+nightly )?miri|MIRIFLAGS|cargo careful)\b' '*.yml' '*.yaml' '*.sh' 'Makefile' 'justfile' 'Justfile' '*.toml' 'AGENTS.md' 'CLAUDE.md' '*.ps1'
scan_signal tests-sanitizer 0 4 1 "sanitizer or dynamic memory-tool runs configured" '\b(-Zsanitizer=|-fsanitize=|sanitizer=(address|thread|memory)|ASAN|TSAN|valgrind)\b' '*.yml' '*.yaml' '*.sh' 'Makefile' 'justfile' 'Justfile' '*.toml' 'AGENTS.md' 'CLAUDE.md' '*.ps1'
if dep_has "cargo_dev cargo py npm_dev npm go" '^(mockall|mockito|wiremock|httpmock|faux|mocktopus|unimock|pytest-mock|responses|respx|requests-mock|msw|sinon|jest-mock|vitest-mock-extended|nock|github\.com/golang/mock|go\.uber\.org/mock|github\.com/vektra/mockery.*|github\.com/stretchr/testify)$'; then
  ev_present tests-use-mocks file "$(manifest_loc Cargo.toml pyproject.toml package.json go.mod || true)" 4 "mocking dependency present" "python3 (parse manifests) | grep -E mock deps" "matched: $DEP_HIT"
else scan_signal tests-use-mocks 0 3 1 "mocks/fakes in tests" '#\[automock\]|mock!\s*\{|\bmockall::|\bmockito::|\bwiremock::|jest\.mock\(|vi\.mock\(|sinon\.(stub|mock|fake)|setupServer\(|unittest\.mock|from mock import|@patch\(|MagicMock\(|monkeypatch\.|gomock\.|mockery|\bFake[A-Z][A-Za-z]+(Client|Service|Repo|Store|Db)\b|\bStub[A-Z][A-Za-z]+\b' '*.rs' '*.py' '*.ts' '*.tsx' '*.js' '*.go'; fi
scan_signal tests-real-services 0 3 1 "tests hitting real services" '\b(testcontainers|Testcontainers|DATABASE_URL|POSTGRES_URL|SUPABASE_URL|REDIS_URL|docker[ -]compose|localhost:(5432|6379|3306|27017|54321)|pg_isready)\b' $TEST_INC '.github/workflows/*.yml' '.github/workflows/*.yaml'
scan_signal tests-flaky-markers 0 3 1 "flaky-test markers (ignore/skip/retry/sleep in tests)" '#\[ignore(\]|[[:space:]]*=)|@pytest\.mark\.skip|@unittest\.skip|\.skip\(|\bxit\(|\bxdescribe\(|\bt\.Skip\(|#\[flaky\]|\bflaky\b|retry_count|\.retries\(|thread::sleep\(|time\.sleep\(|tokio::time::sleep\(|\bsleep\([0-9]' $TEST_INC
# tests-none aggregate: any present kind settles it as absent ("tests exist") no matter
# what the other scans did; unknown blocks only the positive no-tests claim.
TESTS_PRESENT=""; TESTS_UNKNOWN=0
for s in tests-unit tests-integration tests-e2e tests-property tests-fuzz-targets tests-golden tests-conformance; do
  st=$(sig_state "$s")
  [ "$st" = present ] && TESTS_PRESENT="$TESTS_PRESENT$s "
  [ "$st" = unknown ] && TESTS_UNKNOWN=1
done
if [ -n "$TESTS_PRESENT" ]; then ev_absent tests-none file "" 4 "tests exist" "aggregate of tests-* records" "present: $TESTS_PRESENT"
elif [ "$TESTS_UNKNOWN" = 1 ]; then ev_unknown tests-none file "test presence could not be fully determined" "aggregate of tests-* records" "at least one tests-* scan is unknown and no test kind is present"
else ev_present tests-none file "" 4 "no tests of any kind found" "aggregate of tests-* records" "unit/integration/e2e/property/fuzz/golden/conformance all absent-with-positive-evidence; $(kv test_files "$INV") test-path files in inventory"; fi
CI_FILES=$(files_matching '^(\.github/workflows/[^/]+\.ya?ml|\.gitlab-ci\.yml|\.circleci/config\.yml|Jenkinsfile|\.buildkite/[^/]+|azure-pipelines\.yml|\.travis\.yml|\.woodpecker\.ya?ml|bitbucket-pipelines\.yml|\.drone\.yml)$')
if [ -n "$CI_FILES" ]; then
  out=$(rg_lines 'clippy[^\n]*-D[[:space:]]*warnings|-D[[:space:]]*warnings[^\n]*clippy|RUSTFLAGS[^\n]*-D[[:space:]]*warnings|\bubs\b|\beslint\b|\bmypy\b|\bsemgrep\b|\bruff\b|\bpyright\b|golangci-lint|staticcheck|\bshellcheck\b|\bbiome\b|cargo deny|cargo audit' 0 '.github/workflows/*.yml' '.github/workflows/*.yaml' '.gitlab-ci.yml' '.circleci/config.yml' 'Jenkinsfile' '.buildkite/*' 'azure-pipelines.yml' '.travis.yml' '.woodpecker.yml' 'bitbucket-pipelines.yml' '.drone.yml')
  if is_timeout "$RG_RC" || [ "$RG_RC" = 2 ]; then ev_unknown tests-static-analysis-gate file "static-analysis gate scan failed" "$RG_CMD" "rg exit $RG_RC"
  elif [ -n "$out" ]; then first=$(printf '%s\n' "$out" | head -1); ev_present tests-static-analysis-gate file "$(loc_of_match "$first")" 4 "CI runs a static-analysis gate" "$RG_CMD" "$(printf '%s\n' "$out" | grep -c .) matches; e.g. $(printf '%s' "$first" | cut -d: -f1,2): $(snippet "$first")"
  else ev_absent tests-static-analysis-gate file "$(loc "$(printf '%s\n' "$CI_FILES" | head -1)")" 4 "CI has no static-analysis gate" "$RG_CMD" "$(printf '%s\n' "$CI_FILES" | grep -c .) CI files mention no clippy -D warnings/ubs/eslint/mypy/semgrep/ruff/golangci-lint"; fi
else ev_absent tests-static-analysis-gate file "" 4 "no CI config, so no static-analysis gate" "grep -E CI config paths <inventory>" "no .github/workflows, .gitlab-ci.yml, .circleci, Jenkinsfile, buildkite, azure, travis, drone config"; fi

# ------------------------------------------------------------------ derived gaps (present only when both parts are known)
gap() { # gap SIGNAL "CODE_SIGNALS(any present)" "TEST_SIGNALS(all absent)" "CLAIM"
  local sig="$1" codes="$2" tests="$3" claim="$4" c t cs ts code_hit="" test_absent=1 unk="" locs=""
  for c in $codes; do cs=$(sig_state "$c"); [ "$cs" = present ] && code_hit="$c"; [ "$cs" = unknown ] && unk="$unk $c"; locs="$locs $c=$(sig_state "$c")@$(sig_loc "$c")"; done
  for t in $tests; do ts=$(sig_state "$t"); [ "$ts" = present ] && test_absent=0; [ "$ts" = unknown ] && unk="$unk $t"; locs="$locs $t=$(sig_state "$t")@$(sig_loc "$t")"; done
  locs=${locs# }
  local code_unknown=0 test_unknown=0
  for c in $codes; do [ "$(sig_state "$c")" = unknown ] && code_unknown=1; done
  for t in $tests; do [ "$(sig_state "$t")" = unknown ] && test_unknown=1; done
  local how="derived: ($codes present) AND ($tests absent-with-positive-evidence)"
  if [ -n "$code_hit" ] && [ $test_absent = 0 ]; then ev_absent "$sig" file "" 3 "no gap: $claim" "$how" "a covering test kind is present; underlying: $locs"
  elif [ -n "$code_hit" ] && [ $test_unknown = 1 ]; then ev_unknown "$sig" file "$claim: undetermined" "$how" "unknown inputs:$unk; underlying: $locs"
  elif [ -n "$code_hit" ]; then ev_present "$sig" file "$(sig_loc "$code_hit")" 3 "$claim" "$how" "underlying: $locs"
  elif [ $code_unknown = 1 ]; then ev_unknown "$sig" file "$claim: undetermined" "$how" "unknown inputs:$unk; underlying: $locs"
  else ev_absent "$sig" file "" 3 "no gap: $claim" "$how" "the code kind is absent; underlying: $locs"; fi
}
gap gap-parser-no-fuzz "code-parser code-binary-format" "tests-fuzz-targets" "parser/binary-format code with no fuzz target"
gap gap-concurrency-no-model "code-concurrency-primitives" "tests-loom-shuttle tests-sanitizer" "concurrency primitives with no loom/shuttle model and no sanitizer run"
# webhook replay / idempotency tests are an ad-hoc test kind (not a vocabulary signal)
# NOTE: rg -g include globs are a UNION, so test-path globs and extension globs must not be
# passed together (that would scan every *.ts/*.rs file in the tree, not just test paths).
# Scan test paths only, then narrow to code files by extension.
rg_lines '\b(replay|idempoten[a-z]*|constructEvent|webhook)\b' 0 $TEST_INC > "$TMPD/wr.out"; WR_RC=$RG_RC
WR=$(grep -E '^[^:]+\.(rs|py|ts|tsx|js|jsx|go):' "$TMPD/wr.out" | grep -c .)
if { [ "$(sig_state code-webhooks)" = present ] || [ "$(sig_state code-payments-billing)" = present ]; }; then
  if is_timeout "$WR_RC" || [ "$WR_RC" = 2 ]; then ev_unknown gap-payments-no-webhook-replay file "webhook replay test scan failed" "$RG_CMD" "rg exit $WR_RC"
  elif [ "$WR" = 0 ]; then ev_present gap-payments-no-webhook-replay file "$(sig_loc code-webhooks)" 3 "webhook/billing code with no webhook replay or idempotency test" "$RG_CMD" "0 replay/idempotency/webhook matches under test paths; underlying: code-webhooks=$(sig_state code-webhooks)@$(sig_loc code-webhooks) code-payments-billing=$(sig_state code-payments-billing)@$(sig_loc code-payments-billing)"
  else ev_absent gap-payments-no-webhook-replay file "" 3 "webhook replay/idempotency tests exist" "$RG_CMD" "$WR matches under test paths"; fi
elif [ "$(sig_state code-webhooks)" = unknown ] && [ "$(sig_state code-payments-billing)" = unknown ]; then ev_unknown gap-payments-no-webhook-replay file "webhook gap undetermined" "derived" "code-webhooks and code-payments-billing unknown"
else ev_absent gap-payments-no-webhook-replay file "" 3 "no webhook/billing code, so no replay gap" "derived" "code-webhooks=$(sig_state code-webhooks) code-payments-billing=$(sig_state code-payments-billing)"; fi
rg_lines '(--json|--robot|assert_json_snapshot|json[a-z_]*snapshot|snapshot[a-z_]*json)' 0 $TEST_INC > "$TMPD/js.out"; JS_RC=$RG_RC
JS=$(grep -E '^[^:]+\.(rs|py|ts|tsx|js|jsx|go):' "$TMPD/js.out" | grep -c .)
if [ "$(sig_state code-json-robot-mode)" = present ]; then
  if is_timeout "$JS_RC" || [ "$JS_RC" = 2 ]; then ev_unknown gap-cli-no-json-snapshot file "json snapshot test scan failed" "$RG_CMD" "rg exit $JS_RC"
  elif [ "$JS" = 0 ]; then ev_present gap-cli-no-json-snapshot file "$(sig_loc code-json-robot-mode)" 3 "CLI --json output with no snapshot/golden test of it" "$RG_CMD" "0 --json/json-snapshot matches under test paths; tests-golden=$(sig_state tests-golden)@$(sig_loc tests-golden); code-json-robot-mode@$(sig_loc code-json-robot-mode)"
  else ev_absent gap-cli-no-json-snapshot file "" 3 "json output is exercised by tests" "$RG_CMD" "$JS matches under test paths"; fi
elif [ "$(sig_state code-json-robot-mode)" = unknown ]; then ev_unknown gap-cli-no-json-snapshot file "json snapshot gap undetermined" "derived" "code-json-robot-mode unknown"
else ev_absent gap-cli-no-json-snapshot file "" 3 "no --json mode, so no snapshot gap" "derived" "code-json-robot-mode=$(sig_state code-json-robot-mode)"; fi
gap gap-webapp-no-e2e "proj-web-app" "tests-e2e" "web app with no e2e/browser tests"
gap gap-numeric-no-metamorphic "code-numeric-transforms" "tests-metamorphic tests-property" "numeric/transform code with no metamorphic or property tests"
gap gap-renderer-no-golden "code-codegen-renderer" "tests-golden" "renderer/codegen output with no golden tests"
gap gap-spec-no-conformance "code-spec-reimplementation code-port-of-other-language" "tests-conformance" "spec reimplementation or port with no conformance harness"
gap gap-mocks-without-real-e2e "tests-use-mocks" "tests-real-services" "tests mock services with no real-service test"
gap gap-unsafe-no-miri "code-unsafe-any" "tests-miri tests-sanitizer" "unsafe code with no Miri or sanitizer run"

# ------------------------------------------------------------------ git facts (maturity, tags, changelog)
TAG_COUNT=""; NEWEST_TAG=""; NEWEST_TAG_DATE=""; COMMITS=""; FIRST_DATE=""; LAST_DATE=""; RECENT90=""
if $IS_GIT && [ -n "$HEAD_FULL" ]; then
  COMMITS=$(tmo 60 git rev-list --count HEAD 2>/dev/null || true)
  LAST_DATE=$(tmo 60 git log -1 --format=%cI HEAD 2>/dev/null || true)
  FIRST_DATE=$(tmo 60 git log --reverse --format=%cI --max-parents=0 HEAD 2>/dev/null | head -1)
  SINCE90=$(python3 -c 'import sys,datetime as d; s=sys.argv[1].replace("Z","+00:00"); print((d.datetime.fromisoformat(s)-d.timedelta(days=90)).strftime("%Y-%m-%dT%H:%M:%SZ"))' "$NOW")
  RECENT90=$(tmo 60 git rev-list --count --since="$SINCE90" --until="$NOW" HEAD 2>/dev/null || echo 0)
  tmo 60 git tag -l --sort=-creatordate > "$TMPD/tags" 2>/dev/null || : > "$TMPD/tags"
  grep -E '^v?[0-9]+(\.[0-9]+)+' "$TMPD/tags" > "$TMPD/vtags"; [ -s "$TMPD/vtags" ] || cp "$TMPD/tags" "$TMPD/vtags"
  TAG_COUNT=$(grep -c . "$TMPD/vtags"); NEWEST_TAG=$(head -1 "$TMPD/vtags")
  [ -n "$NEWEST_TAG" ] && NEWEST_TAG_DATE=$(tmo 60 git log -1 --format=%cI "$NEWEST_TAG" 2>/dev/null || true)
  REMOTE_URL=$(git remote get-url origin 2>/dev/null | sed -E 's#(://)[^/@]+@#\1<redacted>@#' || true)
  ev_fact "git HEAD and branch" git "$HEAD_FULL" "git rev-parse HEAD; git rev-parse --abbrev-ref HEAD" "HEAD $HEAD_FULL on branch ${BRANCH:-<detached>}; origin: ${REMOTE_URL:-<none>}"
  ev_fact "commit count and repository age" git "$HEAD_FULL" "git rev-list --count HEAD; git log --format=%cI" "$COMMITS commits; first $FIRST_DATE; last $LAST_DATE; age $(days_since "$FIRST_DATE") days; $RECENT90 commits in the last 90 days (as of $NOW)"
  ev_fact "version tags (newest 5)" git "${NEWEST_TAG:-$HEAD_FULL}" "git tag -l --sort=-creatordate" "$TAG_COUNT version-like tags; newest: $(head -5 "$TMPD/vtags" | tr '\n' ' ')${NEWEST_TAG_DATE:+(newest tagged $NEWEST_TAG_DATE)}"
  if [ "$TAG_COUNT" -gt 0 ]; then ev_present release-tags-present git "$NEWEST_TAG" 4 "version tags exist" "git tag -l --sort=-creatordate" "$TAG_COUNT tags, newest $NEWEST_TAG ($NEWEST_TAG_DATE)"; ev_absent releases-none git "" 4 "releases exist (tags)" "git tag -l" "$TAG_COUNT tags"
  else ev_absent release-tags-present git "" 4 "no version tags" "git tag -l --sort=-creatordate" "0 tags"; ev_present releases-none git "$HEAD_FULL" 4 "no version tags and no releases" "git tag -l" "0 tags (GitHub releases not queried; tags are the release marker)"; fi
  tmo 60 git log -60 --format=%s HEAD > "$TMPD/subjects" 2>/dev/null || : > "$TMPD/subjects"
  tmo 60 git log --format=%ct --max-count=3000 HEAD > "$TMPD/ctimes" 2>/dev/null || : > "$TMPD/ctimes"
  python3 - "$TMPD" "$NOW" "$COMMITS" "$TAG_COUNT" "$RECENT90" "$FIRST_DATE" <<'PY' > "$TMPD/maturity"
import sys, re, datetime as d, os
tmpd, now, commits, tags, recent90, first = sys.argv[1], sys.argv[2], int(sys.argv[3] or 0), int(sys.argv[4] or 0), int(sys.argv[5] or 0), sys.argv[6]
nowd = d.datetime.fromisoformat(now.replace("Z", "+00:00"))
age = (nowd - d.datetime.fromisoformat(first.replace("Z", "+00:00"))).days if first else 0
subj = [l.strip().lower() for l in open(os.path.join(tmpd, "subjects")) if l.strip()][:50]
n = max(len(subj), 1)
fix = sum(1 for s in subj if re.search(r"\b(fix|fixes|fixed|hotfix|bugfix|bug|test|tests|regress|stabili[sz]e|flaky|repair|correct)\b", s))
feat = sum(1 for s in subj if re.search(r"\b(feat|feature|add|adds|added|implement|implements|introduce|new|support|wire|build out|scaffold)\b", s))
bump = sum(1 for s in subj if re.search(r"\b(bump|deps|dependabot|renovate|upgrade|chore|update dependencies|version)\b", s))
ts = sorted(int(l) for l in open(os.path.join(tmpd, "ctimes")) if l.strip())
gap_days, gap_end = 0, None
for a, b in zip(ts, ts[1:]):
    g = (b - a) / 86400.0
    if g > gap_days: gap_days, gap_end = g, b
revived = gap_days > 90 and gap_end is not None and (nowd.timestamp() - gap_end) / 86400.0 <= 90
base = "active-buildout"
if (commits < 50 or age < 30) and tags == 0: base = "greenfield"
elif recent90 < 10 and feat / n < 0.3: base = "maintenance"
elif fix / n >= 0.5 and feat / n < 0.25: base = "stabilization"
why = "commits=%d age=%dd tags=%d recent90=%d last50: fix-like=%d feat-like=%d bump-like=%d; max gap=%.0fd%s" % (commits, age, tags, recent90, fix, feat, bump, gap_days, (" ending " + d.datetime.fromtimestamp(gap_end, d.timezone.utc).strftime("%Y-%m-%d")) if gap_end else "")
for s in ("greenfield", "active-buildout", "stabilization", "maintenance"):
    print("%s\t%s\t%s" % ("maturity-" + s, "present" if s == base else "absent", why))
print("%s\t%s\t%s" % ("maturity-revived", "present" if revived else "absent", why))
PY
  while IFS=$'\t' read -r msig mst mwhy; do
    if [ "$mst" = present ]; then ev_present "$msig" git "$HEAD_FULL" 3 "${msig#maturity-} maturity" "git rev-list --count; git log -50 --format=%s; git log --format=%ct" "$mwhy"
    else ev_absent "$msig" git "" 3 "not ${msig#maturity-} maturity" "git rev-list --count; git log -50 --format=%s; git log --format=%ct" "$mwhy"; fi
  done < "$TMPD/maturity"
else
  for s in maturity-greenfield maturity-active-buildout maturity-stabilization maturity-maintenance maturity-revived release-tags-present releases-none; do
    ev_unknown "$s" git "$s unknown: not a git repository" "git rev-parse --is-inside-work-tree" "$( $IS_GIT && echo "git repository without commits" || echo "not a git repository" )"
  done
fi

# ------------------------------------------------------------------ docs / process
if f=$(first_existing AGENTS.md CLAUDE.md); then ev_present docs-agents-md file "$(loc "$f")" 4 "agent instructions file present" "ls AGENTS.md CLAUDE.md" "$f ($(wc -l < "$f" | tr -d ' ') lines)"
else ev_absent docs-agents-md file "" 4 "no AGENTS.md or CLAUDE.md" "ls AGENTS.md CLAUDE.md" "neither file at the target root or scope roots"; fi
README=$(first_existing README.md README.rst README.txt README readme.md || true)
if [ -z "$README" ]; then
  ev_present docs-readme-missing file "" 4 "README missing" "ls README*" "no README.md/README.rst/README.txt/README at root"
  ev_absent docs-readme-weak file "" 4 "README weakness not assessable: no README" "ls README*" "README missing (see docs-readme-missing)"
else
  ev_absent docs-readme-missing file "$(loc "$README")" 4 "README exists" "ls README*" "$README"
  RL=$(wc -l < "$README" | tr -d ' '); RH=$(grep -ciE '^#+ .*(install|usage|getting started|quick ?start|how to (use|run)|setup)' "$README"); RT=$(grep -ciE '^# (project title|my project|template)|^TODO: (write|fill)|lorem ipsum|this is a template' "$README")
  if [ "$RL" -lt 60 ] || [ "$RH" = 0 ] || [ "$RT" -gt 0 ]; then ev_present docs-readme-weak file "$(loc "$README")" 4 "README is weak" "wc -l; grep -iE '^#+ .*(install|usage|getting started)'" "$RL lines (< 60?); $RH install/usage headings; $RT template phrases"
  else ev_absent docs-readme-weak file "$(loc "$README")" 4 "README is substantial" "wc -l; grep -iE '^#+ .*(install|usage|getting started)'" "$RL lines; $RH install/usage headings; $RT template phrases"; fi
fi
CHANGELOG=$(first_existing CHANGELOG.md CHANGELOG CHANGES.md HISTORY.md RELEASES.md changelog.md || true)
if [ -z "$CHANGELOG" ]; then
  if [ -n "$TAG_COUNT" ] && [ "$TAG_COUNT" -gt 0 ]; then ev_present docs-changelog-missing file "" 4 "no CHANGELOG although the project has tags" "ls CHANGELOG*; git tag -l" "$TAG_COUNT tags, newest $NEWEST_TAG; no CHANGELOG.md/CHANGES.md/HISTORY.md/RELEASES.md"
  elif [ -n "$TAG_COUNT" ]; then ev_absent docs-changelog-missing file "" 4 "no CHANGELOG but also no tags (not a gap)" "ls CHANGELOG*; git tag -l" "0 tags; changelog absence is not counted"
  else ev_unknown docs-changelog-missing file "changelog gap undetermined" "ls CHANGELOG*; git tag -l" "no CHANGELOG and tag state unknown (not a git repository)"; fi
  ev_absent docs-changelog-stale-vs-tags file "" 4 "no CHANGELOG to be stale" "ls CHANGELOG*" "no changelog file"
  ev_absent docs-changelog-fresh file "" 4 "no CHANGELOG to be fresh" "ls CHANGELOG*" "no changelog file"
else
  ev_absent docs-changelog-missing file "$(loc "$CHANGELOG")" 4 "CHANGELOG exists" "ls CHANGELOG*" "$CHANGELOG"
  if [ -n "$NEWEST_TAG" ]; then
    CL_DATE=$(tmo 60 git log -1 --format=%cI -- "$CHANGELOG" 2>/dev/null || true)
    TAGSTR=$(printf '%s' "$NEWEST_TAG" | sed -E 's/^v//'); MENTIONS=$(grep -cF -- "$TAGSTR" "$CHANGELOG")
    NEWER=0; [ -n "$CL_DATE" ] && [ -n "$NEWEST_TAG_DATE" ] && [ "$(python3 -c 'import sys,datetime as d; f=lambda s: d.datetime.fromisoformat(s.replace("Z","+00:00")); print(1 if f(sys.argv[1])>=f(sys.argv[2]) else 0)' "$CL_DATE" "$NEWEST_TAG_DATE")" = 1 ] && NEWER=1
    if [ "$MENTIONS" -gt 0 ] || [ $NEWER = 1 ]; then
      ev_absent docs-changelog-stale-vs-tags file "$(loc "$CHANGELOG")" 4 "CHANGELOG is current with the newest tag" "git log -1 --format=%cI -- $CHANGELOG; grep -F '$TAGSTR' $CHANGELOG" "newest tag $NEWEST_TAG ($NEWEST_TAG_DATE); changelog last commit ${CL_DATE:-uncommitted}; mentions tag: $MENTIONS"
      ev_present docs-changelog-fresh file "$(loc "$CHANGELOG")" 4 "CHANGELOG mentions the latest tag or was touched after it" "git log -1 --format=%cI -- $CHANGELOG; grep -F '$TAGSTR' $CHANGELOG" "newest tag $NEWEST_TAG ($NEWEST_TAG_DATE); changelog last commit ${CL_DATE:-uncommitted}; mentions tag: $MENTIONS"
    else
      ev_present docs-changelog-stale-vs-tags file "$(loc "$CHANGELOG")" 4 "CHANGELOG last touched before the newest tag and does not mention it" "git log -1 --format=%cI -- $CHANGELOG; grep -F '$TAGSTR' $CHANGELOG" "newest tag $NEWEST_TAG ($NEWEST_TAG_DATE); changelog last commit ${CL_DATE:-never}; mentions tag: 0"
      ev_absent docs-changelog-fresh file "$(loc "$CHANGELOG")" 4 "CHANGELOG is not fresh" "git log -1 --format=%cI -- $CHANGELOG; grep -F '$TAGSTR' $CHANGELOG" "stale vs $NEWEST_TAG"
    fi
  elif [ -n "$TAG_COUNT" ]; then
    ev_absent docs-changelog-stale-vs-tags file "$(loc "$CHANGELOG")" 4 "no tags, so the CHANGELOG cannot be stale vs tags" "git tag -l" "0 tags"
    ev_absent docs-changelog-fresh file "$(loc "$CHANGELOG")" 3 "no tags to be fresh against" "git tag -l" "0 tags; changelog exists ($(wc -l < "$CHANGELOG" | tr -d ' ') lines)"
  else
    ev_unknown docs-changelog-stale-vs-tags file "changelog staleness unknown" "git tag -l" "not a git repository"
    ev_unknown docs-changelog-fresh file "changelog freshness unknown" "git tag -l" "not a git repository"
  fi
fi
file_signal() { # file_signal SIGNAL "LABEL" REGEX "CMD-DESC"
  local f; f=$(files_matching "$3" | head -1)
  if [ -n "$f" ]; then ev_present "$1" file "$(loc "$f")" 4 "$2 present" "$4" "$(count_files "$3") files, e.g. $f"
  else ev_absent "$1" file "" 4 "no $2" "$4" "no inventory path matched /$3/"; fi
}
file_signal docs-plan-file "plan/roadmap/spec file" '(^|/)(PLAN[^/]*\.md|[^/]*[_-](PLAN|plan)\.md|ROADMAP[^/]*|docs?/plans?[^/]*\.md|docs?/plans?/[^/]+\.md|plans?/[^/]+\.md|TODO\.md)$' "grep -E 'PLAN|ROADMAP|docs/plan|plans/' <inventory>"
file_signal docs-adrs "ADRs/design records" '(^|/)(docs?/)?(adrs?|decisions|design(-docs)?|rfcs?)/[^/]+\.(md|mdx)$|(^|/)ADR-[0-9]+[^/]*\.md$|\.adr\.md$' "grep -E 'adr/|decisions/|design/|rfcs/' <inventory>"
file_signal docs-contributing "CONTRIBUTING.md" '^(\.github/)?CONTRIBUTING(\.md|\.rst)?$' "ls CONTRIBUTING.md .github/CONTRIBUTING.md"
file_signal docs-security-md "SECURITY.md" '^(\.github/)?SECURITY(\.md|\.rst)?$' "ls SECURITY.md .github/SECURITY.md"
file_signal docs-license "LICENSE file" '^(LICENSE|LICENCE|COPYING|UNLICENSE)([.-][A-Za-z0-9.]+)?$' "ls LICENSE*"
if [ -d .beads ]; then ev_present beads-present file "$(loc .beads)" 4 ".beads/ directory exists" "ls -d .beads" "$(find .beads -mindepth 1 -maxdepth 1 2>/dev/null | grep -c .) entries"; ev_absent beads-absent file "$(loc .beads)" 4 "beads present" "ls -d .beads" ".beads/ exists"
else ev_absent beads-present file "" 4 "no .beads/ directory" "ls -d .beads" "no .beads at target root"; ev_present beads-absent file "" 4 "no .beads/ directory" "ls -d .beads" "no .beads at target root"; fi
if [ -f .agent-mail-project-id ]; then ev_present agent-mail-project file "$(loc .agent-mail-project-id)" 4 ".agent-mail-project-id present" "ls .agent-mail-project-id" "file present"
else ev_absent agent-mail-project file "" 4 "no .agent-mail-project-id" "ls .agent-mail-project-id" "no file at target root"; fi
if [ -n "$CI_FILES" ]; then ev_present ci-config file "$(loc "$(printf '%s\n' "$CI_FILES" | head -1)")" 4 "CI configuration exists" "grep -E CI config paths <inventory>" "$(printf '%s\n' "$CI_FILES" | grep -c .) files: $(printf '%s\n' "$CI_FILES" | head -5 | tr '\n' ' ')"; ev_absent ci-none file "" 4 "CI configured" "grep -E CI config paths <inventory>" "$(printf '%s\n' "$CI_FILES" | grep -c .) CI files"
else ev_absent ci-config file "" 4 "no CI configuration" "grep -E CI config paths <inventory>" "no workflows/gitlab-ci/circleci/Jenkinsfile/buildkite/azure/travis/drone"; ev_present ci-none file "" 4 "no CI configuration found" "grep -E CI config paths <inventory>" "no known CI config path in inventory"; fi
file_signal issue-templates ".github issue templates" '^\.github/(ISSUE_TEMPLATE/[^/]+|ISSUE_TEMPLATE\.md|PULL_REQUEST_TEMPLATE(\.md|/[^/]+))$' "ls .github/ISSUE_TEMPLATE"

# ------------------------------------------------------------------ delivery
# published-registry: crates.io via cargo search, npm via npm view, PyPI via python3 urllib (each with a timeout).
PUB_STATE=""; PUB_DETAIL=""; PUB_CMD=""; PUB_SRC=tool-output
CRATE=$(mk cargo.root_name); NPM_NAME=$(mk npm.root_name); PY_NAME=$(mk py.name)
if [ -n "$CRATE" ] && ! printf '%s' "$(mk cargo.publish_false)" | tr ';' '\n' | grep -qxF -- "$CRATE"; then
  PUB_CMD="timeout 30 cargo search --limit 1 $CRATE"
  if command -v cargo >/dev/null 2>&1; then
    out=$(tmo 30 cargo search --limit 1 "$CRATE" 2>"$TMPD/pub.err"); rc=$?
    if [ $rc = 0 ] && printf '%s\n' "$out" | grep -qE "^$(printf '%s' "$CRATE" | sed 's/[][\.*^$-]/\\&/g') = \""; then PUB_STATE=present; PUB_DETAIL="crates.io: $(printf '%s\n' "$out" | head -1 | cut -d'#' -f1 | sed 's/ *$//')"
    elif [ $rc = 0 ]; then PUB_STATE=absent; PUB_DETAIL="crates.io has no crate named $CRATE (first hit: $(printf '%s\n' "$out" | head -1 | cut -d' ' -f1))"
    else PUB_STATE=unknown; PUB_DETAIL="cargo search exit $rc: $(head -c 200 "$TMPD/pub.err" | tr '\n' ' ')"; fi
  else PUB_STATE=unknown; PUB_DETAIL="cargo not installed; crates.io lookup for $CRATE skipped"; fi
elif [ -n "$NPM_NAME" ] && [ "$(mk npm.root_private)" != 1 ]; then
  PUB_CMD="timeout 30 npm view $NPM_NAME version"
  if command -v npm >/dev/null 2>&1; then
    out=$(tmo 30 npm view "$NPM_NAME" version 2>"$TMPD/pub.err"); rc=$?
    if [ $rc = 0 ] && [ -n "$out" ]; then PUB_STATE=present; PUB_DETAIL="npm: $NPM_NAME@$(printf '%s' "$out" | tail -1)"
    elif grep -q 'E404' "$TMPD/pub.err"; then PUB_STATE=absent; PUB_DETAIL="npm registry has no package named $NPM_NAME (E404)"
    else PUB_STATE=unknown; PUB_DETAIL="npm view exit $rc: $(head -c 200 "$TMPD/pub.err" | tr '\n' ' ')"; fi
  else PUB_STATE=unknown; PUB_DETAIL="npm not installed; registry lookup for $NPM_NAME skipped"; fi
elif [ -n "$PY_NAME" ]; then
  PUB_CMD="python3 urllib GET https://pypi.org/pypi/$PY_NAME/json (timeout 30)"
  out=$(tmo 35 python3 -c 'import sys,urllib.request,urllib.error
try:
    r=urllib.request.urlopen("https://pypi.org/pypi/%s/json" % sys.argv[1], timeout=30); print("present", r.status)
except urllib.error.HTTPError as e:
    print("absent" if e.code==404 else "unknown", e.code)
except Exception as e:
    print("unknown", str(e)[:120])' "$PY_NAME" 2>&1); PUB_STATE=${out%% *}; PUB_DETAIL="pypi $PY_NAME: ${out#* }"
  case "$PUB_STATE" in present|absent|unknown) ;; *) PUB_STATE=unknown; PUB_DETAIL="pypi lookup failed: $out";; esac
elif [ -n "$CRATE" ] || [ "$(mk npm.root_private)" = 1 ]; then PUB_STATE=absent; PUB_SRC="file"; PUB_CMD="python3 (parse manifests: publish=false / private=true)"; PUB_DETAIL="publish disabled in manifest (cargo publish=false: $(mk cargo.publish_false | tr ';' ' '); npm private: $(mk npm.root_private))"
else PUB_STATE=absent; PUB_SRC="file"; PUB_CMD="python3 (parse manifests)"; PUB_DETAIL="no publishable package metadata (no root crate name, npm name, or pyproject name)"; fi
case "$PUB_STATE" in
  present) ev_present published-registry "$PUB_SRC" "$(manifest_loc Cargo.toml package.json pyproject.toml || true)" 4 "published to a package registry" "$PUB_CMD" "$PUB_DETAIL";;
  absent) ev_absent published-registry "$PUB_SRC" "" 3 "not published to a package registry" "$PUB_CMD" "$PUB_DETAIL";;
  *) ev_unknown published-registry "$PUB_SRC" "registry publication unknown" "$PUB_CMD" "$PUB_DETAIL";;
esac
# public-facing: gh repo view (timeout 30) when gh + GitHub remote; else registry hints.
REMOTE=""; $IS_GIT && REMOTE=$(git remote get-url origin 2>/dev/null || true)
if printf '%s' "$REMOTE" | grep -q 'github\.com'; then
  if command -v gh >/dev/null 2>&1; then
    out=$(tmo 30 gh repo view --json isPrivate,nameWithOwner 2>"$TMPD/gh.err"); rc=$?
    PRIV=$(printf '%s' "$out" | python3 -c 'import json,sys
try: d=json.load(sys.stdin); print("true" if d.get("isPrivate") else "false", d.get("nameWithOwner",""))
except Exception: print("err")' 2>/dev/null)
    case "$PRIV" in
      "false "*) ev_present public-facing gh "" 4 "GitHub remote is public" "timeout 30 gh repo view --json isPrivate" "isPrivate=false for ${PRIV#false }${PUB_STATE:+; registry: $PUB_STATE}";;
      "true "*) if [ "$PUB_STATE" = present ]; then ev_present public-facing tool-output "" 3 "published to a registry although the GitHub remote is private" "$PUB_CMD" "$PUB_DETAIL; gh isPrivate=true"; else ev_absent public-facing gh "" 4 "GitHub remote is private" "timeout 30 gh repo view --json isPrivate" "isPrivate=true for ${PRIV#true }; registry: $PUB_STATE"; fi;;
      *) ev_unknown public-facing gh "GitHub visibility unknown" "timeout 30 gh repo view --json isPrivate" "gh exit $rc: $(head -c 200 "$TMPD/gh.err" | tr '\n' ' ')";;
    esac
  elif [ "$PUB_STATE" = present ]; then ev_present public-facing tool-output "" 3 "published to a registry (gh unavailable for remote visibility)" "$PUB_CMD" "$PUB_DETAIL"
  else ev_unknown public-facing gh "GitHub visibility unknown" "gh repo view --json isPrivate" "gh not installed; GitHub remote exists; registry: $PUB_STATE"; fi
elif [ "$PUB_STATE" = present ]; then ev_present public-facing tool-output "" 3 "published to a registry" "$PUB_CMD" "$PUB_DETAIL"
elif [ "$PUB_STATE" = unknown ]; then ev_unknown public-facing tool-output "public-facing status unknown" "$PUB_CMD" "no GitHub remote; registry lookup: $PUB_DETAIL"
else ev_absent public-facing git "" 2 "no public remote or registry publication" "git remote get-url origin; registry lookup" "origin: ${REMOTE:+non-GitHub}${REMOTE:-none}; registry: $PUB_DETAIL"; fi
# installer / doctor / json gaps for CLIs
if [ "$(sig_state proj-cli)" = present ] && [ "$(sig_state release-tags-present)" = present ] && [ "$(sig_state code-installer-script)" = absent-with-positive-evidence ]; then ev_present installer-missing-for-cli file "$(sig_loc proj-cli)" 3 "CLI with releases but no installer script" "derived: proj-cli AND release-tags-present AND NOT code-installer-script" "proj-cli@$(sig_loc proj-cli); tags: $NEWEST_TAG; installer: absent"
elif [ "$(sig_state proj-cli)" = unknown ] || [ "$(sig_state release-tags-present)" = unknown ] || [ "$(sig_state code-installer-script)" = unknown ]; then ev_unknown installer-missing-for-cli file "installer gap undetermined" "derived: proj-cli AND release-tags-present AND NOT code-installer-script" "proj-cli=$(sig_state proj-cli) release-tags-present=$(sig_state release-tags-present) code-installer-script=$(sig_state code-installer-script)"
else ev_absent installer-missing-for-cli file "" 3 "no installer gap" "derived: proj-cli AND release-tags-present AND NOT code-installer-script" "proj-cli=$(sig_state proj-cli) release-tags-present=$(sig_state release-tags-present) code-installer-script=$(sig_state code-installer-script)"; fi
if [ "$(sig_state code-installer-script)" = present ]; then
  INST=$(files_matching '(^|/)(install|installer|install-[a-z]+)\.sh$|^scripts/install[^/]*\.sh$' | head -1)
  if [ -n "$INST" ]; then
    LACK=""; grep -qiE 'sha256|checksum|shasum|sha256sum' "$INST" || LACK="checksum"; grep -qE 'uname|OSTYPE|platform|\barch\b|x86_64|aarch64|arm64' "$INST" || LACK="$LACK version-pin-less-platform-detection"; grep -qE 'VERSION=|--version|v[0-9]+\.[0-9]+|tag' "$INST" || LACK="$LACK version-pin"; grep -qiE 'uninstall' "$INST" || LACK="$LACK uninstall"
    LACK=$(printf '%s' "$LACK" | sed 's/version-pin-less-platform-detection/platform-detection/; s/^ //')
    if [ -n "$LACK" ]; then ev_present installer-weak file "$(loc "$INST")" 4 "installer lacks safety features" "grep -iE sha256|checksum; grep -E uname|OSTYPE|arch; grep -E VERSION=|--version; grep -i uninstall $INST" "missing: $LACK"
    else ev_absent installer-weak file "$(loc "$INST")" 4 "installer has checksum, platform detection, version pin, and uninstall" "grep -iE sha256|checksum; grep -E uname|OSTYPE|arch; grep -E VERSION=|--version; grep -i uninstall $INST" "all four present in $INST"; fi
  else ev_unknown installer-weak file "installer quality not assessed" "grep install.sh" "installer detected only via curl-pipe docs; no install.sh in tree to inspect"; fi
elif [ "$(sig_state code-installer-script)" = unknown ]; then ev_unknown installer-weak file "installer quality unknown" "derived" "code-installer-script unknown"
else ev_absent installer-weak file "" 4 "no installer to be weak" "derived" "code-installer-script absent"; fi
derived_missing() { # derived_missing SIGNAL BASE FEATURE "CLAIM"
  local sig="$1" base="$2" feat="$3" claim="$4"
  if [ "$(sig_state "$base")" = present ] && [ "$(sig_state "$feat")" = absent-with-positive-evidence ]; then ev_present "$sig" file "$(sig_loc "$base")" 3 "$claim" "derived: $base present AND $feat absent" "$base@$(sig_loc "$base"); $feat absent"
  elif [ "$(sig_state "$base")" = unknown ] || { [ "$(sig_state "$base")" = present ] && [ "$(sig_state "$feat")" = unknown ]; }; then ev_unknown "$sig" file "$claim: undetermined" "derived: $base present AND $feat absent" "$base=$(sig_state "$base") $feat=$(sig_state "$feat")"
  else ev_absent "$sig" file "" 3 "no gap: $claim" "derived: $base present AND $feat absent" "$base=$(sig_state "$base") $feat=$(sig_state "$feat")"; fi
}
derived_missing doctor-missing-for-cli code-cli-subcommands code-doctor-command "multi-subcommand CLI with no doctor/diagnose command"
derived_missing json-mode-missing-for-cli code-cli-subcommands code-json-robot-mode "multi-subcommand CLI with no --json/--robot mode"
DOCS_MD=$(kv docs_md "$INV"); DOCS_LN=$(kv docs_lines "$INV")
if [ "$(sig_state public-facing)" = present ] && { [ "$DOCS_MD" -ge 5 ] || [ "$DOCS_LN" -ge 500 ]; } && [ "$(sig_state proj-docs-site)" = absent-with-positive-evidence ]; then ev_present docs-site-missing file "$(loc "$(files_matching '(^|/)docs?/[^/]+\.mdx?$' | head -1)")" 3 "public project with substantial docs/ but no docs site" "derived: public-facing AND docs/ >= 5 md files or 500 lines AND NOT proj-docs-site" "$DOCS_MD docs markdown files / $DOCS_LN lines; proj-docs-site absent"
elif [ "$(sig_state public-facing)" = unknown ] && { [ "$DOCS_MD" -ge 5 ] || [ "$DOCS_LN" -ge 500 ]; } && [ "$(sig_state proj-docs-site)" != present ]; then ev_unknown docs-site-missing file "docs-site gap undetermined" "derived: public-facing AND docs/ substantial AND NOT proj-docs-site" "public-facing unknown; $DOCS_MD docs files / $DOCS_LN lines"
else ev_absent docs-site-missing file "" 3 "no docs-site gap" "derived: public-facing AND docs/ substantial AND NOT proj-docs-site" "public-facing=$(sig_state public-facing); docs/ $DOCS_MD md files / $DOCS_LN lines (threshold 5 files or 500 lines); proj-docs-site=$(sig_state proj-docs-site)"; fi
SITE_SRC=$(files_matching '\.(html|tsx|jsx|astro|vue|svelte|mdx)$|(^|/)(next\.config\.[a-z]+|opengraph-image\.[a-z]+|og\.[a-z]+)$' | grep -c .)
if [ "$SITE_SRC" -gt 0 ] || [ "$(sig_state public-facing)" = present ]; then
  out=$(rg_lines 'og:image|openGraph|opengraph-image|twitter:image|og-image|ogImage' 0 '*.html' '*.tsx' '*.jsx' '*.ts' '*.js' '*.astro' '*.vue' '*.svelte' '*.mdx' '*.md' '*.toml' '*.yml' '*.yaml' '*.json'); og_rc=$RG_RC
  OGF=$(files_matching '^\.github/[^/]*(social|preview|og|banner)[^/]*\.(png|jpe?g|svg|webp)$|(^|/)(public|static|assets)/[^/]*(og|opengraph|social|twitter-card)[^/]*\.(png|jpe?g|svg|webp)$' | head -1)
  if is_timeout "$og_rc" || [ "$og_rc" = 2 ]; then ev_unknown og-image-missing file "og:image scan failed" "$RG_CMD" "rg exit $og_rc"
  elif [ -n "$out" ] || [ -n "$OGF" ]; then
    if [ -n "$OGF" ]; then OG_LOC=$(loc "$OGF"); else OG_LOC=$(loc_of_match "$(printf '%s\n' "$out" | head -1)"); fi
    ev_absent og-image-missing file "$OG_LOC" 4 "social preview image is configured" "$RG_CMD; grep social/og images <inventory>" "$(printf '%s\n' "$out" | grep -c .) og:image references; image file: ${OGF:-none}"
  else ev_present og-image-missing file "" 2 "public repo/site with no social preview image" "$RG_CMD; grep social/og images <inventory>" "0 og:image/openGraph references in $SITE_SRC site sources; no .github social image or public/og*.png (GitHub's web-UI social preview cannot be checked from the tree)"; fi
elif [ "$(sig_state public-facing)" = unknown ]; then ev_unknown og-image-missing file "og-image gap undetermined" "derived" "no site sources and public-facing unknown"
else ev_absent og-image-missing file "" 3 "not public and no site sources, so no og:image gap" "derived" "public-facing=$(sig_state public-facing); site sources: 0"; fi
# deps-outdated: newest commit (or mtime) of each lockfile vs the pinned clock
LOCKS=$(mk lock.files | tr ';' '\n' | grep -v '^$'); AGES=""; OLD=0; OLDF=""
if [ -n "$LOCKS" ]; then
  while IFS= read -r lk; do
    d=""; $IS_GIT && d=$(tmo 60 git log -1 --format=%cI -- "$lk" 2>/dev/null || true)
    if [ -z "$d" ]; then d=$( { stat -f '%Sm' -t '%Y-%m-%dT%H:%M:%SZ' "$lk" 2>/dev/null || date -u -r "$(stat -c '%Y' "$lk" 2>/dev/null)" '+%Y-%m-%dT%H:%M:%SZ' 2>/dev/null; } ); fi
    a=$(days_since "$d"); AGES="$AGES $lk=${a:-?}d"; [ -n "$a" ] && [ "$a" -gt 180 ] && { OLD=1; OLDF=${OLDF:-$lk}; }
  done <<EOF_LOCKS
$LOCKS
EOF_LOCKS
  if [ $OLD = 1 ]; then ev_present deps-outdated file "$(loc "$OLDF")" 1 "dependency freshness review due; lockfile age does not prove dependencies are outdated" "git log -1 --format=%cI -- <lockfile> (else mtime) vs $NOW" "ages:$AGES; no package-manager outdated query was run"
  else ev_absent deps-outdated file "" 1 "lockfiles updated within 180 days; dependency freshness remains unverified" "git log -1 --format=%cI -- <lockfile> (else mtime) vs $NOW" "ages:$AGES; no package-manager outdated query was run"; fi
else ev_unknown deps-outdated file "dependency staleness not assessable" "python3 (parse manifests: lockfiles)" "no lockfile in inventory (no outdated-check tool is run)"; fi
if [ "$COUNTED" != 1 ]; then ev_unknown monolith-file file "monolith detection skipped" "line counts" "line counting skipped (--max-files $MAX_FILES)"
elif [ "$(kv monolith_count "$INV")" -gt 0 ]; then ev_present monolith-file file "$(loc "$(kv monolith "$INV" | cut -d: -f1)")" 4 "source file exceeds 3000 lines (or 5% of code LOC)" "python3 (count newlines per non-test code file)" "$(kv monolith_count "$INV") files; top 3: $(kv monolith "$INV")"
else ev_absent monolith-file file "" 4 "no monolith source file" "python3 (count newlines per non-test code file)" "largest: $(kv top_files "$INV" | cut -d';' -f1-3); code LOC $CODE_LOC"; fi
# media (find over the tree; media are often gitignored)
MEDIA_CMD="find <scopes> -type f -iname '*.<ext>' (excluding .git/node_modules/target/vendor)"
media_find() { tmo 60 find "${SCOPES[@]}" -type f -not -path '*/.git/*' -not -path '*/node_modules/*' -not -path '*/target/*' -not -path '*/vendor/*' \( "$@" \) 2>/dev/null | sed 's#^\./##' | LC_ALL=C sort; }
VID=$(media_find -iname '*.mp4' -o -iname '*.mov' -o -iname '*.mkv' -o -iname '*.webm' -o -iname '*.avi' -o -iname '*.m4v'); VRC=$?
AUD=$(media_find -iname '*.m4a' -o -iname '*.mp3' -o -iname '*.wav' -o -iname '*.flac' -o -iname '*.aac' -o -iname '*.ogg'); ARC=$?
if is_timeout "$VRC"; then ev_unknown media-video-files-present file "video scan timed out" "$MEDIA_CMD" "find exceeded 60s"
elif [ -n "$VID" ]; then ev_present media-video-files-present file "$(loc "$(printf '%s\n' "$VID" | head -1)")" 4 "video files in the target" "$MEDIA_CMD" "$(printf '%s\n' "$VID" | grep -c .) files, e.g. $(printf '%s\n' "$VID" | head -3 | tr '\n' ' ')"
else ev_absent media-video-files-present file "" 4 "no video files" "$MEDIA_CMD" "0 mp4/mov/mkv/webm/avi/m4v files"; fi
if is_timeout "$ARC"; then ev_unknown media-audio-files-present file "audio scan timed out" "$MEDIA_CMD" "find exceeded 60s"
elif [ -n "$AUD" ]; then ev_present media-audio-files-present file "$(loc "$(printf '%s\n' "$AUD" | head -1)")" 4 "audio files in the target" "$MEDIA_CMD" "$(printf '%s\n' "$AUD" | grep -c .) files, e.g. $(printf '%s\n' "$AUD" | head -3 | tr '\n' ' ')"
else ev_absent media-audio-files-present file "" 4 "no audio files" "$MEDIA_CMD" "0 m4a/mp3/wav/flac/aac/ogg files"; fi
IPH=$(printf '%s\n' "$VID" | grep -cE '(^|/)IMG_[0-9]{3,5}\.(MOV|mov|MP4|mp4)$|\.MOV$')
if [ -n "$VID" ] && [ "$IPH" -ge 2 ]; then ev_present iphone-takes-present file "$(loc "$(printf '%s\n' "$VID" | grep -E '(^|/)IMG_[0-9]{3,5}\.(MOV|mov|MP4|mp4)$|\.MOV$' | head -1)")" 2 "multiple iPhone video takes present" "$MEDIA_CMD | grep -E 'IMG_[0-9]+\.(MOV|mp4)|\.MOV$'" "$IPH iPhone-named takes"
elif is_timeout "$VRC"; then ev_unknown iphone-takes-present file "iPhone takes unknown" "$MEDIA_CMD" "video scan timed out"
else ev_absent iphone-takes-present file "" 2 "no multiple iPhone takes" "$MEDIA_CMD | grep -E 'IMG_[0-9]+\.(MOV|mp4)|\.MOV$'" "$IPH iPhone-named video files (threshold 2)"; fi
SCR=$(printf '%s\n' "$VID" | grep -ciE 'screen|recording|screencast|capture|obs|demo|\.mkv$')
if [ -n "$VID" ] && [ "$SCR" -ge 1 ]; then ev_present screencast-present file "$(loc "$(printf '%s\n' "$VID" | grep -iE 'screen|recording|screencast|capture|obs|demo|\.mkv$' | head -1)")" 2 "screen recordings present" "$MEDIA_CMD | grep -iE 'screen|recording|capture|obs|demo|.mkv'" "$SCR screencast-named videos"
elif is_timeout "$VRC"; then ev_unknown screencast-present file "screencast presence unknown" "$MEDIA_CMD" "video scan timed out"
else ev_absent screencast-present file "" 2 "no screen recordings" "$MEDIA_CMD | grep -iE 'screen|recording|capture|obs|demo|.mkv'" "0 screencast-named videos among $(printf '%s\n' "$VID" | grep -c .)"; fi
SLACK=$(media_find -name 'channels.json' -o -name 'users.json' -o -iname '*slack*export*' -o -iname '*slack*.zip' -o -iname 'mattermost*import*.jsonl' -o -iname 'bulk-import*.jsonl'); SRC_RC=$?
SLACK_DIRS=$(printf '%s\n' "$SLACK" | grep -E '(^|/)(channels|users)\.json$' | xargs -I{} dirname {} 2>/dev/null | LC_ALL=C sort | uniq -d)
if is_timeout "$SRC_RC"; then ev_unknown slack-export-present file "slack export scan timed out" "$MEDIA_CMD" "find exceeded 60s"
elif [ -n "$SLACK_DIRS" ] || printf '%s\n' "$SLACK" | grep -qiE 'slack|mattermost|bulk-import'; then ev_present slack-export-present file "$(loc "$(printf '%s\n' "${SLACK_DIRS:-$SLACK}" | head -1)")" 3 "Slack export or Mattermost import bundle present" "find channels.json+users.json | *slack*export* | mattermost*import*.jsonl" "$(printf '%s\n' "${SLACK_DIRS:-$SLACK}" | head -3 | tr '\n' ' ')"
else ev_absent slack-export-present file "" 3 "no Slack export or Mattermost import bundle" "find channels.json+users.json | *slack*export* | mattermost*import*.jsonl" "no directory with both channels.json and users.json; no slack/mattermost bundle names"; fi
# mac-mini-remote-browser is deliberately not emitted: nothing in a project tree identifies a remote browser-automation host.

# ------------------------------------------------------------------ finalize
python3 - "$TMPD/records" "$KIND" "$ID_PREFIX" "$NOW" "$REPO_HEAD" "$TMPD/out.json" <<'PY'
import sys, json, re
recs_path, kind, prefix, now, head, out_path = sys.argv[1:7]
SECRET = re.compile(r'((sk|pk|rk)_(live|test)_[A-Za-z0-9]{8,}|ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|AKIA[0-9A-Z]{16}|xox[baprs]-[A-Za-z0-9-]{10,}|-----BEGIN [A-Z ]*PRIVATE KEY-----|eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,})')
records, n = [], 0
for line in open(recs_path, encoding='utf-8', errors='replace'):
    line = line.rstrip('\n')
    if not line: continue
    f = line.split('\x1f')
    if len(f) < 9: f += [''] * (9 - len(f))
    if len(f) > 9: f = f[:8] + ['\x1f'.join(f[8:])]
    state, polarity, src, locator, conf, signals, claim, command, detail = f
    n += 1
    eid = 'ev-%s%04d' % (prefix, n)
    if state == 'present' and not locator:
        locator = 'profile-project.sh:' + eid
    if state == 'absent-with-positive-evidence' and not command:
        command = 'profile-project.sh positive-absence detector for ' + (signals or 'narrative fact')
    if state == 'unknown' and not detail:
        detail = claim
    records.append({
        'id': eid, 'claim': claim if len(claim) >= 3 else (claim + ' (n/a)'), 'kind': kind, 'polarity': polarity, 'state': state,
        'source_type': src, 'locator': locator or None, 'observed_at': now, 'command': command or None, 'repo_head': head or None,
        'origin_host': None, 'confidence': int(conf or 0), 'signals': [s for s in signals.split(',') if s],
        'detail': SECRET.sub('<redacted>', detail)[:1200] if detail else None,
    })
with open(out_path, 'w', encoding='utf-8') as fh:
    fh.write(json.dumps(records, indent=2, sort_keys=True, ensure_ascii=False) + '\n')
c = {}
for r in records: c[r['state']] = c.get(r['state'], 0) + 1
sys.stderr.write('%s-project: %d records (present=%d absent=%d unknown=%d)\n' % (kind, len(records), c.get('present', 0), c.get('absent-with-positive-evidence', 0), c.get('unknown', 0)))
PY
if ! python3 "$SCRIPT_DIR/skillsel_common.py" validate-json "$SCHEMA" "$TMPD/out.json" >/dev/null; then
  echo "profile-project: output failed schema validation" >&2; python3 "$SCRIPT_DIR/skillsel_common.py" validate-json "$SCHEMA" "$TMPD/out.json" >&2; exit 1
fi
if [ "$OUT" = "-" ]; then cat "$TMPD/out.json"; else cp "$TMPD/out.json" "$OUT" && echo "profile-project: wrote $OUT" >&2; fi
exit 0
