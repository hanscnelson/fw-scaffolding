#!/usr/bin/env python3
"""Self-contained package validator for this skill.

  python3 validate-skill.py [PKG_DIR]      (defaults to the package this file lives in)

Checks (exit 1 on any ERROR):
  1. SKILL.md frontmatter: starts with ---, name matches the directory, description
     present, third-person, contains "Use when", <= 1024 chars (warn > 200).
  2. SKILL.md body line budget (target < 200 body lines; ERROR > 500) and a Reference
     Index / TOC when > 100 lines.
  3. Every relative markdown link and every `references/...`, `scripts/...`, `assets/...`
     path mentioned in SKILL.md and references/*.md resolves to a file.
  4. No absolute home paths (/Users/<name>/, /home/<name>/) in any shipped text file.
  5. Shipped JSON validates: catalog-snapshot entries against catalog-entry.schema.json;
     signal-to-skill-map structure (every referenced signal defined; prerequisites/pairs
     name catalog skills; weights/cost/risk in range; map covers every snapshot skill);
     combo-recipes reference catalog skills and defined trigger signals; scoring-constants
     shape; aliases resolve to catalog names.
  6. Generated views (CATALOG-SNAPSHOT.md, SIGNAL-TO-SKILL-MAP.md, COMBO-RECIPES.md)
     match a re-render from the current JSON (ignoring the generated_at line).
  7. Scripts have shebangs; no file exceeds 1MB.
  8. If `jsm validate` is on PATH it is run and its verdict reported (informational:
     its file-count limit and this package's size are reported honestly, not hidden).

This validator is self-contained by design — it must not reference any private
authoring skill. PyYAML is optional (frontmatter parsing uses skillsel_common).
"""
from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import skillsel_common as slib  # noqa: E402

ERRORS: list[str] = []
WARNINGS: list[str] = []


def err(msg):
    ERRORS.append(msg)


def warn(msg):
    WARNINGS.append(msg)


def check_frontmatter(pkg: Path):
    skill_md = pkg / "SKILL.md"
    if not skill_md.exists():
        err("SKILL.md missing")
        return ""
    text = skill_md.read_text(encoding="utf-8")
    if not text.startswith("---\n"):
        err("SKILL.md must start with '---' (no leading blank line)")
    fm = slib.parse_frontmatter(text)
    name = fm.get("name", "")
    desc = fm.get("description", "")
    if name != pkg.name:
        err(f"frontmatter name {name!r} != directory name {pkg.name!r}")
    if not re.match(r"^[a-z0-9-]+$", name or "x_"):
        err("frontmatter name must be lowercase letters, numbers, hyphens")
    if len(name) > 64:
        err(f"frontmatter name exceeds 64 chars ({len(name)})")
    if not desc:
        err("frontmatter description missing")
    else:
        if "use when" not in desc.lower():
            err("description missing a 'Use when …' trigger clause")
        if len(desc) > 1024:
            err(f"description exceeds 1024 chars ({len(desc)})")
        elif len(desc) > 200:
            warn(f"description is {len(desc)} chars (recommend < 200)")
        if desc.lower().startswith(("i ", "i can", "you ")):
            err("description must be third person")
    m = re.match(r"^---\n.*?\n---\n?(.*)$", text, re.S)
    body = m.group(1) if m else text
    lines = body.count("\n")
    if lines > 500:
        err(f"SKILL.md body has {lines} lines (> 500)")
    elif lines > 200:
        warn(f"SKILL.md body has {lines} lines (target < 200)")
    if lines > 100 and "Reference Index" not in body and "Table of Contents" not in body:
        warn("SKILL.md > 100 lines without a Reference Index")
    return text


LINK_RE = re.compile(r"\[[^\]]*\]\((?!https?://|#|mailto:)([^)\s]+)\)")
PATH_RE = re.compile(r"(?<![\w/.-])((?:references|scripts|assets|subagents|tests)/[A-Za-z0-9_./-]+)")


def strip_code(text: str) -> str:
    return re.sub(r"```.*?```", "", text, flags=re.S)


def check_paths(pkg: Path):
    docs = [pkg / "SKILL.md", pkg / "SELF-TEST.md"] + sorted((pkg / "references").glob("*.md"))
    for doc in docs:
        if not doc.exists():
            continue
        text = doc.read_text(encoding="utf-8")
        base = doc.parent
        for link in LINK_RE.findall(strip_code(text)):
            link = link.split("#")[0]
            if not link:
                continue
            if not (base / link).exists() and not (pkg / link).exists():
                err(f"{doc.name}: broken link {link}")
        for p in PATH_RE.findall(strip_code(text)):
            p = p.rstrip(".,;:")
            if p.endswith("/") or "<" in p or "*" in p:
                continue
            if not (pkg / p).exists() and not (base / p).exists():
                # tolerate template/example paths that name a placeholder file
                if re.search(r"(NN|XX|<|\.\.\.)", p):
                    continue
                warn(f"{doc.name}: path {p} does not resolve")


HOME_RE = re.compile(r"(/Users/[A-Za-z0-9_.-]+/|/home/[A-Za-z0-9_.-]+/)")


def check_portability(pkg: Path):
    for f in sorted(pkg.rglob("*")):
        if not f.is_file() or f.suffix in (".png", ".webp", ".jpg"):
            continue
        try:
            text = f.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue
        if f.stat().st_size > 1_048_576:
            err(f"{f.relative_to(pkg)}: exceeds 1MB")
        for mth in HOME_RE.findall(text):
            err(f"{f.relative_to(pkg)}: absolute home path {mth!r}")
        if f.suffix in (".sh", ".py") and f.parent.name in ("scripts", "tests") and not text.startswith("#!"):
            warn(f"{f.relative_to(pkg)}: script missing shebang")


def check_data(pkg: Path):
    data = pkg / "references" / "data"
    schemas = pkg / "references" / "schemas"
    try:
        snap = slib.load_json(data / "catalog-snapshot.json")
        smap = slib.load_json(data / "signal-to-skill-map.json")
        recipes = slib.load_json(data / "combo-recipes.json")
        consts = slib.load_json(data / "scoring-constants.json")
        aliases = slib.load_json(data / "aliases.json")
    except Exception as e:  # noqa: BLE001
        err(f"shipped JSON unreadable: {e}")
        return
    cat_schema = slib.load_json(schemas / "catalog-entry.schema.json")
    for e in snap["skills"]:
        for x in slib.validate_against(e, cat_schema, schemas, e.get("canonical_name", "?")):
            err(f"catalog-snapshot: {x}")
    names = {e["canonical_name"] for e in snap["skills"]}
    sigs = smap["signals"]
    for sid, meta in sigs.items():
        if meta.get("kind") not in ("profile", "juncture"):
            err(f"signal {sid}: bad kind")
    missing = names - set(smap["skills"])
    extra = set(smap["skills"]) - names
    if missing:
        err(f"signal map missing catalog skills: {sorted(missing)}")
    if extra:
        err(f"signal map has non-catalog skills: {sorted(extra)}")
    for n, e in smap["skills"].items():
        for g in e.get("domain_gate", []):
            if g not in sigs:
                err(f"{n}: gate signal {g} undefined")
        for p in e.get("positive_signals", []):
            if p["signal"] not in sigs:
                err(f"{n}: positive signal {p['signal']} undefined")
            if not 1 <= p.get("weight", 0) <= 4:
                err(f"{n}: weight out of range for {p['signal']}")
        for a in e.get("anti_signals", []):
            if a["signal"] not in sigs:
                err(f"{n}: anti signal {a['signal']} undefined")
        for pr in e.get("prerequisites", []):
            if pr["skill"] not in names:
                err(f"{n}: prerequisite {pr['skill']} not in catalog")
            for s in pr.get("satisfied_by_signals", []):
                if s not in sigs:
                    err(f"{n}: prerequisite signal {s} undefined")
        for pair in e.get("pairs", []):
            if pair not in names:
                err(f"{n}: pair {pair} not in catalog")
        hyg = e.get("baseline_hygiene")
        if hyg and hyg["gap_signal"] not in sigs:
            err(f"{n}: hygiene signal {hyg['gap_signal']} undefined")
        for dim in ("cost", "risk", "accretive_base"):
            if not 0 <= e.get(dim, 0) <= 4:
                err(f"{n}: {dim} out of range")
    for r in recipes["recipes"]:
        if r["anchor"] not in names:
            err(f"recipe {r['id']}: anchor {r['anchor']} not in catalog")
        if not any(m["skill"] == r["anchor"] and m["role"] == "anchor" for m in r["sequence"]):
            err(f"recipe {r['id']}: sequence lacks the anchor with role=anchor")
        for m in r["sequence"]:
            if m["skill"] not in names:
                err(f"recipe {r['id']}: member {m['skill']} not in catalog")
        for t in r["triggers"]:
            if t not in sigs:
                err(f"recipe {r['id']}: trigger {t} undefined")
        ru = r.get("runner_up")
        if ru and ru["candidate"] not in names:
            err(f"recipe {r['id']}: runner-up {ru['candidate']} not in catalog")
    for k in ("weights", "tiers", "already_done_D", "suppression", "portfolio"):
        if k not in consts:
            err(f"scoring-constants missing {k}")
    for old, new in aliases.get("aliases", {}).items():
        if new not in names:
            err(f"alias {old} -> {new}: target not in catalog")
        if old in names:
            err(f"alias {old} is still a catalog name")
    if smap["harmonized_against"]["source_listing_sha256"] != snap["harmonized_against"]["source_listing_sha256"]:
        err("signal map harmonized_against differs from catalog snapshot (refresh the map)")


def check_generated_views(pkg: Path):
    sys.path.insert(0, str(pkg / "scripts"))
    try:
        import render_reference_views  # noqa: F401  (hyphen name workaround below)
    except ImportError:
        import importlib.util

        spec = importlib.util.spec_from_file_location(
            "rrv", pkg / "scripts" / "render-reference-views.py"
        )
        rrv = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(rrv)
        rendered = rrv.render_all(write=False)
    else:  # pragma: no cover
        rendered = render_reference_views.render_all(write=False)

    def normalize(t: str) -> str:
        return "\n".join(l for l in t.splitlines() if not l.startswith("<!-- generated_at:"))

    for dst, body in rendered.items():
        path = pkg / "references" / dst
        if not path.exists():
            err(f"generated view missing: references/{dst} (run render-reference-views.py)")
            continue
        if normalize(path.read_text(encoding="utf-8")) != normalize(body):
            err(f"generated view drift: references/{dst} does not match its JSON source")


def delegate_external_validator(pkg: Path):
    import shutil

    if not shutil.which("jsm"):
        print("[info] jsm not on PATH; skipping jsm validate delegation")
        return
    try:
        r = subprocess.run(
            ["jsm", "validate", str(pkg), "--json"],
            capture_output=True, text=True, timeout=120, check=False,
        )
        print(f"[info] jsm validate exit={r.returncode} (verdict reported, not gating): "
              + (r.stdout.strip().splitlines()[0] if r.stdout.strip() else r.stderr.strip()[:200]))
    except Exception as e:  # noqa: BLE001
        print(f"[info] jsm validate could not run: {e}")


def main() -> int:
    pkg = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else slib.PKG_ROOT
    check_frontmatter(pkg)
    check_paths(pkg)
    check_portability(pkg)
    check_data(pkg)
    check_generated_views(pkg)
    delegate_external_validator(pkg)
    for w in WARNINGS:
        print(f"WARN  {w}")
    for e in ERRORS:
        print(f"ERROR {e}")
    print(f"{'VALID' if not ERRORS else 'INVALID'}: {len(ERRORS)} error(s), {len(WARNINGS)} warning(s)")
    return 0 if not ERRORS else 1


if __name__ == "__main__":
    sys.exit(main())
