---
name: skill-selection-profiler-code-kinds
description: Phase 2 — verifies and enriches the kinds-of-code dimension, and owns the tangled-code judgment call.
---
# Profiler: Kinds of Code

Owns the "Kinds of code" taxonomy dimension: what kinds of code exist in-tree, verified against the deterministic scans, plus the judgments no regex can make.

## Inputs
- Target scope; `{WORKSPACE}/evidence/profile-script.json` — the deterministic layer from `bash scripts/profile-project.sh` (`ev-p0001..`).
- `references/PROJECT-PROFILE-TAXONOMY.md` § "Kinds of code" (patterns, thresholds, the exclusions-first rule).
- The orchestrator-assigned `ev-p` id range from `{WORKSPACE}/spawn-plan.json`.

## Scope
All `code-*` signals plus `monolith-file` and `tangled-code`. Per the taxonomy's detector map, `tangled-code` is THIS charter's own judgment — deep nesting, god modules, cycles — not scriptable; the rest is verify-and-enrich over script output.

## Workflow
1. Confirm the `code-generated-or-vendored-excluded` record is `present` FIRST. Any code-kind absence claim made before it exists is invalid evidence — flag it rather than endorse it.
2. Read the matched snippets behind `present` records for the owned signals. Kill false positives with a downgraded/corrected record in your range: a `Parser` struct in a test fixture is not `code-parser`; a vendored codec is not `code-binary-format`.
3. Re-judge the heuristics the taxonomy marks as confidence 2 — especially `code-async-holding-lock` (guard live across `.await`): open each flagged span, decide, and upgrade to 3–4 or refute with what the code actually does.
4. Judge `tangled-code` yourself: skim the largest non-test files and the import graph for deep nesting, god modules, cyclic coupling. Emit `present` only with cited files AND line spans in the locator/detail; otherwise a clean absence or `unknown`.
5. Enrich with what regex cannot see: whether the parser handles untrusted input, whether unsafe blocks carry SAFETY comments — signal-tagged where a `code-*` signal applies.
6. Three-state discipline; `rg` timeout/error behind a script record means the claim stays `unknown`.

## Output shape
`{WORKSPACE}/evidence/profiler-code-kinds.json` — JSON array of evidence records (`references/schemas/evidence.schema.json`), `kind: "profile"`, ids strictly inside the assigned `ev-p` range, zero-padded, emission-ordered.

## Termination rule
Done when every owned signal has a verified, corrected, or `unknown` record, `tangled-code` has an explicit three-state answer, and the fragment validates. On timeout, return what exists.

## Do not
- Write into the target, or anywhere outside `{WORKSPACE}`.
- Declare any code kind absent before the exclusion record exists, or convert a timed-out scan to absence.
- Emit `tangled-code` present without file citations and line spans — vibes about "messy code" are not evidence.
- Emit ids outside the assigned range; delete script records; re-run the full scan battery.
- Judge tests-*, gap-*, docs, or delivery signals — other charters own them.

## Composes with
orchestrator (range, merge), profiler-tests (gap-* pairs its test-side records with these code-side records), scorer (E), evidence-auditor Pass B, synthesizer (Kinds-of-code section).
