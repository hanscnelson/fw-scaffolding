---
name: skill-selection-profiler-build-and-deps
description: Phase 2 — verifies and enriches the languages, build, toolchains, and dependency dimension of the profile.
---
# Profiler: Build & Dependencies

Owns the "Languages, build, toolchains" taxonomy dimension: languages, workspace layout, frameworks, dependency oddities — verifying what the deterministic detectors flagged.

## Inputs
- Target scope; `{WORKSPACE}/evidence/profile-script.json` — the deterministic layer from `bash scripts/profile-project.sh` (`ev-p0001..`).
- `references/PROJECT-PROFILE-TAXONOMY.md` § "Languages, build, toolchains".
- The orchestrator-assigned `ev-p` id range from `{WORKSPACE}/spawn-plan.json`.

## Scope
`lang-*`, `build-cargo-workspace`, `cargo-profile-tuned`, `cargo-features-heavy`, `native-ffi-deps`, `unusual-pins`, `framework-heavy`, `hand-rolled`, `fw-*`, `dep-*`, `deps-outdated`. This charter is the taxonomy's named verifier of dependency oddities.

## Workflow
1. Read the script's records for the owned signals; VERIFY and ENRICH — never re-run its scans wholesale.
2. Open the manifests and lockfiles behind `unusual-pins`, `native-ffi-deps`, `cargo-profile-tuned`, and `dep-*` claims: is the `=` pin deliberate (a comment, a workaround) or drift? Is the git dependency a private fork? Record what the file actually says, with locators.
3. Sanity-check line-share `lang-*` claims (threshold 15%, JS 25%, C/C++ 20%, shell 10%) by opening a few counted files — vendored or generated code that slipped the exclusions downgrades the claim.
4. Judge what scripts cannot: whether the dependency posture is `framework-heavy` in spirit (a thin wrapper over one framework) or `hand-rolled` despite a long dep list; note toolchain pins (rust-toolchain.toml, .nvmrc, mise/asdf files) as narrative records.
5. `deps-outdated` rests on lockfile age — corroborate with the manifest before endorsing; a pinned-by-policy repo is not "outdated".
6. Three-state discipline: unanswered questions are `unknown` with the error text; absence claims state the completed search in `detail`.

## Output shape
`{WORKSPACE}/evidence/profiler-build-and-deps.json` — JSON array of evidence records (`references/schemas/evidence.schema.json`), `kind: "profile"`, ids strictly inside the assigned `ev-p` range, zero-padded, emission-ordered.

## Termination rule
Done when every owned signal has a verified, corrected, or `unknown` record and the fragment validates. On timeout, return what exists — a missing signal record is a contract violation, an `unknown` one is not.

## Do not
- Write into the target, or anywhere outside `{WORKSPACE}`; never run installs, `cargo update`, or lockfile-touching commands.
- Emit ids outside the assigned range; delete or rewrite script records.
- Treat a parse failure or missing manifest as absence — that is `unknown`.
- Judge test, docs, or delivery signals — their owners handle those dimensions.

## Composes with
orchestrator (range, merge), profiler-code-kinds (shares the exclusion record), scorer (E), evidence-auditor Pass B (locator replay), synthesizer (Languages/build section).
