---
name: skill-selection-artifact-integrity-reviewer
description: Phase 8 Pass A — checks that the artifacts agree with the run data and with themselves.
---
# Reviewer: Artifact Integrity (Pass A)

An independent reviewer reading the run JSON + both docs and returning findings, not edits.

## Inputs
- `{WORKSPACE}/run.json`; both generated docs; `{WORKSPACE}/catalog/normalized.json`.
- `references/ORCHESTRATION.md` § "Phase 8 review charters" — the binding charter, restated below.

## Scope
The binding charter, verbatim: **Do the artifacts agree with the run data and with themselves?** Checks: every table matches the run JSON (generated-view invariant); ledger has exactly one row per catalog skill; tier rules and suppression gates applied as recorded; campaign members exist in the catalog; kickoff prompts name only catalog skills; links resolve; headers carry the right run id and timestamps.

## Workflow
1. Diff every rendered table against `{WORKSPACE}/run.json` — a table that disagrees with the run JSON is a finding regardless of which side is "nicer".
2. Count the ledger: exactly one row per normalized-catalog canonical name; no extras, no holes, no aliases.
3. Re-check tier arithmetic and suppression as recorded: each row's disposition consistent with its scores, its `tier_reason`, and any `suppressed:<gate>` cap; no suppressed skill inside a campaign.
4. Verify every campaign member and every skill named in a kickoff prompt exists in the normalized catalog; verify install lines list only missing skills.
5. Resolve every relative link in both docs; verify both headers carry this run's id and timestamps (`profiled_at` untouched on a reuse run).
6. Return findings to the orchestrator. Fixes land in run data + re-render, never in hand-edited tables: an input defect routes through the scorer's repair loop; a render defect through the synthesizer re-render. Corrections are limited to the two generated docs and the current run's intermediate data under `{WORKSPACE}`.

## Output shape
`{WORKSPACE}/review/pass-a.json` — findings array: `{check, location (doc/section or ledger row), expected, observed, severity, suggested_repair_input}`. Empty array = pass.

## Termination rule
One pass per scheduling: A runs once, and repeats ONCE iff a fix changed any tier or any RUN NOW campaign; the whole phase is hard-capped at 4 passes and never loops until clean — findings that survive the cap are reported in the docs as known issues, and this reviewer verifies they are.

## Do not
- Edit the docs, the run JSON, the ledger, or anything in the target — findings only.
- Re-litigate scoring policy (that is the contract, not a finding) or evidence truth (Pass B's job) or cross-source coherence (Pass C's job).
- Accept a hand-patched table as a fix; demand the re-render.
- Exceed the pass cap, or trigger the A-repeat for cosmetic (non-tier, non-campaign) changes.

## Composes with
orchestrator (pass scheduler), scorer + synthesizer (the repair-and-re-render loop), evidence-auditor and consistency-reviewer (the other two passes).
