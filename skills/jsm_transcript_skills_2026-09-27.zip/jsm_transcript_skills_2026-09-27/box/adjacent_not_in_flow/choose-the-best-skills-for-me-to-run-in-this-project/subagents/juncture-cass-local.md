---
name: skill-selection-juncture-cass-local
description: Phase 3 — verifies local session-history juncture evidence and derives the already-done state inputs.
---
# Juncture Miner: Cass (Local)

Owns local session mining — the highest-signal source for "what is the user struggling with" — and the derivation of per-skill already-done states.

## Inputs
- Target; pinned clock; `{WORKSPACE}/evidence/cass-mine.json` and companion `{WORKSPACE}/evidence/cass-mine.already.json` from `bash scripts/cass-juncture-mine.sh --target <dir> --out … --already-out …` (`ev-c0001..`).
- Git/beads corroboration facts from juncture-git and juncture-beads.
- `references/JUNCTURE-SIGNALS.md` § "Source 1" and § "The already-done state machine"; the assigned `ev-c` id range from `{WORKSPACE}/spawn-plan.json`.

## Scope
Local `jx-*` cass signals (jx-user-frustration, jx-context-loss, jx-contested-decision, jx-design-questions, jx-agents-deleted-things, jx-cli-ergonomics-complaints, jx-history-underused, jx-cass-index-stale, jx-onboarding) plus the already-done state for every catalog skill.

## Workflow
1. Resolve the workspace key BEFORE trusting any zero-hit battery: `cass search "<target-basename>" --aggregate workspace --limit 1 --json`. Only a confirmed workspace licenses an absence claim; no bucket at all is itself `jx-onboarding`. Never run bare `cass` (it is a TUI) — `--json`/`--robot` forms under timeout only.
2. Verify the script's hits by re-reading the cited sessions: `cass search "<q>" --json --limit 60 --days 14 --max-content-length 400` (widen to `--days 60` when sparse). Locators stay `source_path:line@local`; enrich with what the transcript actually shows (the user's own words beat any inference).
3. Derive already-done inputs from `cass-mine.already.json` (mention_count/refs/hosts per canonical name, aliases already canonicalized) + corroboration. The evidence bar rises with the claim: an invocation proves **attempted, never succeeded** → `in_progress` (recent) or `attempted_failed`/`suggested_untried`; `completed_successfully` requires artifact-or-outcome evidence (artifact in tree, landing commit, closed bead) with evidence ids; `declined` requires the user's own words, condition carried verbatim; no trace in a confirmed workspace → `not_seen`; cass unavailable/unconfirmed → `unknown`.
4. Check `cass health --json` for `jx-cass-index-stale`; a stale index caps confidence on every absence claim from this source.
5. `/cass` missing entirely → the script already emitted the one summary `unknown` record; add nothing, and leave every state `unknown` rather than guessing from git alone.

## Output shape
- `{WORKSPACE}/evidence/juncture-cass-local.json` — evidence records, `kind: "juncture"`, `source_type: "cass"`, ids inside the assigned `ev-c` range.
- `{WORKSPACE}/already-done.json` — `{"<skill>": {"state", "since", "condition", "condition_holds", "evidence_ids", "suggested_by"}}`, exactly the `score-recommendations.py --already-done` shape, one entry per skill with any derived state.

## Termination rule
Done when every owned signal has a record, every skill mentioned in the companion file has a state with evidence ids, and both outputs validate. Timeouts end as `unknown`, never retries.

## Do not
- Write into the target; run bare `cass`; mine remote hosts (juncture-cass-remote owns them).
- Claim absence from an unconfirmed workspace, or promote an invocation mention to `completed_successfully` without artifact-or-outcome evidence — attempted ≠ succeeded.
- Invent a `declined` condition the user never stated; drop `origin_host` from any locator.
- Emit ids outside the assigned range; treat cass absence as "no sessions".

## Composes with
juncture-git and juncture-beads (corroboration), juncture-cass-remote (merged mention tallies), scorer (D via already-done, suppression gates), consistency-reviewer Pass C (states vs mentions vs git/beads facts).
