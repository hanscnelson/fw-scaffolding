---
name: skill-selection-catalog-local-inventory
description: Phase 4 — enumerates every local skills directory into normalized entries with precedence and skew.
---
# Catalog Agent: Local Inventory

Answers "what is already installed, and which copy wins" by wrapping the inventory script and sanity-checking its precedence and skew output.

## Inputs
- Target; `references/CATALOG-ACQUISITION.md` § "Local inventory: enumeration, precedence, skew".
- jsm availability (for `jsm config show --json`, the authoritative managed-directories list).

## Scope
Local enumeration only: target-project-local skill dirs, the running harness's user dir, every directory from jsm config, and the agents-home fallback — in that order, because enumeration order IS the dedupe precedence.

## Workflow
1. Run `bash scripts/local-skills-inventory.sh --target <dir> --map references/data/signal-to-skill-map.json --out {WORKSPACE}/catalog/local-inventory.json`.
2. Verify the precedence story: the first copy of a canonical name wins; later copies with differing content hashes must appear in the winner's `skew` array (path + hash); byte-identical copies are silently ignored. Spot-check one duplicate to confirm the hash discipline (sha256 over every sorted relative path and every regular file's bytes).
3. Confirm alias canonicalization happened at the boundary — directory names and front-matter names resolve through `references/data/aliases.json`; nothing downstream may see an alias.
4. Report skew prominently: it usually means one harness's copy is stale, which matters when a recommendation says "already installed". Skew rows feed the analysis doc via the synthesizer.
5. Local-only skills (present in no public source) keep their entries — `catalog_sources: ["local"]`, `installed: true` — so they still get their one ledger row. They remain `provisional_mapping: true` unless the explicit map contains them. Privacy: local-only skill names are a privacy class for public-repo targets; flag them for the synthesizer rather than deciding persistence yourself.
6. Exit codes: 0 = schema-valid array written. A failure is reported to the orchestrator as a degraded-inventory fact, not papered over with an empty array pretending to be "nothing installed".

## Output shape
`{WORKSPACE}/catalog/local-inventory.json` — JSON array of catalog-entry objects (`references/schemas/catalog-entry.schema.json`) with `canonical_name`, `catalog_sources: ["local"]`, `installed`, `resolved_path`, `skew`, front-matter description/tags/detect rules.

## Termination rule
Done when the array is written and the precedence/skew spot-checks pass (or the degraded-inventory fact is reported). One script run; no directory crawling beyond what it did.

## Do not
- Write into the target or into ANY skills directory — inventory reads; it never installs, deletes, or "fixes" skew.
- Invent install locations beyond the documented enumeration order, or let an alias survive past this boundary.
- Treat a missing jsm as "no managed directories" — the conventional per-harness fallback list applies, and gaps are recorded as such.
- Merge with the public catalog yourself — that union belongs to catalog-relationships.

## Composes with
catalog-cloud (runs concurrently), catalog-relationships (consumes both for the normalized union), matcher (installed flags), installer-and-kickoff (install lines list only missing skills), synthesizer (skew reporting).
