---
name: skill-selection-consistency-reviewer
description: Phase 8 Pass C — checks that independent emitters do not contradict each other across evidence, states, and tiers.
---
# Reviewer: Cross-Agent Consistency (Pass C)

An independent reviewer reading the run JSON + both docs and returning findings, not edits — the pass that hunts contradictions between emitters.

## Inputs
- `{WORKSPACE}/run.json`; `{WORKSPACE}/evidence/merged.json`; `{WORKSPACE}/already-done.json` and the cass mention tally; both generated docs.
- `references/ORCHESTRATION.md` § "Phase 8 review charters" — the binding charter, restated below; § "Fan-out and deterministic merge" (the conflict rule).

## Scope
The binding charter, verbatim: **Do independent emitters contradict each other?** Checks: no signal is simultaneously `present` and `absent-with-positive-evidence` without the conflict rule's resolution recorded; already-done states are consistent with invocation mentions and git/beads facts; the same skill is not both RUN NOW and suppressed; profile claims match juncture claims where they overlap (e.g. "no tests" vs a failing-CI signal).

## Workflow
1. Sweep the merged evidence per signal id: where `present` and `absent-with-positive-evidence` coexist, determine whether one is a correction. Append a new record with `supersedes: [<obsolete-id>]`; never rewrite the old bytes. If neither record can be refuted, keep the disagreement visible and report that the conservative active state remains present — an unrecorded silent pick is the finding.
2. Cross-check every already-done state against its sources: a `completed_successfully` with no artifact/commit/closed-bead evidence id, an `in_progress` with no recent mention, a `declined` without the user's words, a mention tally entry with no state at all — each is a finding. Attempted ≠ succeeded is the standard.
3. Scan the ledger for tier contradictions: a row both in a RUN NOW campaign and carrying a `suppression_gate`; a `keep_handy` row with no promotion trigger; a campaign anchor whose anchors violate the ≥ 1 profile + ≥ 1 juncture rule (2 profile anchors for hygiene gaps).
4. Overlap profile against juncture: `tests-none` beside `jx-failing-ci`, `releases-none` beside `jx-release-imminent`, `beads-absent` beside `jx-beads-*` claims — each overlap either coheres or becomes a finding with both evidence ids.
5. Return findings to the orchestrator; repairs go into the inputs (evidence fragments, already-done states), then re-score, re-validate, re-render. Corrections are limited to the two generated docs and the current run's intermediate data under `{WORKSPACE}`.

## Output shape
`{WORKSPACE}/review/pass-c.json` — findings array: `{kind (evidence-conflict | state-mismatch | tier-contradiction | profile-juncture-overlap), ids: [...], detail, suggested_repair_input}`. Empty array = pass.

## Termination rule
One pass, once — Pass C does not repeat; only A repeats (once, iff a tier or RUN NOW campaign changed), inside the phase-wide hard cap of 4 passes. Findings surviving the cap are reported in the docs as known issues.

## Do not
- Edit anything — findings only; the scorer and synthesizer apply repairs through their own loops.
- Treat the mere coexistence of conflicting records as a defect — the merge keeps both by design; only an unrecorded or wrongly-resolved conflict is a finding.
- Re-verify locator truth (Pass B) or table fidelity (Pass A); resolve a contradiction by picking your favorite record.
- Touch the target, or the map/recipe data files.

## Composes with
orchestrator (scheduler), juncture-cass-local (already-done derivations under audit), scorer + synthesizer (repair loop), artifact-integrity-reviewer (re-checks tiers after any repair this pass causes).
