---
name: skill-selection-installer-and-kickoff
description: Phases 9-10 — prints the campaigns verbatim, installs winners under the envelope, and records the run.
---
# Installer & Kickoff

Delivers the run's output to the user — campaigns printed paste-ready, installs and requests under the envelope — and performs the Phase 10 record duties the orchestrator delegates.

## Inputs
- The final portfolio in `{WORKSPACE}/run.json` (post-review); both generated docs.
- The envelope's grants 5 (installs) and 6 (commit/push); `assets/kickoff-block-template.md`.
- The target's own AGENTS.md (read in full by profiler-docs-and-process) for the landing workflow.

## Scope
Terminal delivery, `jsm install` of winners, gap offers, outcome reminder, and the record duties: history appendix retention, header bumps, and the envelope-gated commit.

## Workflow
1. Print every RUN NOW campaign in the kickoff-block shape, the kickoff prompt VERBATIM from the rendered doc — round counts, negative constraints, behaviour-gate riders intact; never paraphrased. Runners-up print directly under each block.
2. Installs, only under grant 5 and only for skills not already installed (the local inventory's `installed` flag): `for s in <missing-skill> <missing-skill>; do jsm install "$s"; done`. When everything is installed, say so instead of printing a no-op loop. Avoid `jsm install --related` unless every related skill is itself recommended — `--related` pulls in alternatives, contradicting a ledger that just ranked one above the others.
3. Offer each validated gap to `jsm requests` (with permission), using the gap's suggested request title and its empty catalog query as the rationale.
4. Give the `jsm outcome` reminder: `jsm outcome -s <name> --success|--failure` after campaigns run, or `jsm outcome --batch <file>.jsonl` extracted from the doc's ledger appendix — this is what feeds the next run's already-done machine.
5. Phase 10 record duties: re-run `python3 scripts/render-recommendations.py` with `--previous` so the history appendix carries this run with retention applied (last 12 runs full, older compacted monthly, stable user decisions always kept); header bumps via `--update-analysis-header` (`juncture_refreshed_at`, generation timestamps; `--profiled` only after a real re-profile).
6. Commit ONLY under grant 6, following the TARGET's own AGENTS.md landing workflow (its branch/sync/message conventions), staging never anything but the two docs; push only if the grant said push. No grant → say where the docs sit and stop.
7. Confirm the Phase 10 exit to the orchestrator: the next run's staleness check and already-done cross-check can see this run.

## Output shape
Terminal: campaign blocks + install/request/outcome lines. Files: the two docs' appendix/header updates via `render-recommendations.py` (never hand edits), and at most one commit touching exactly `docs/COMPREHENSIVE_ANALYSIS_OF_PROJECT_USED_FOR_AUTOMATED_SKILL_SELECTION.md` and `docs/RECOMMENDED_SKILLS_FOR_THIS_PROJECT.md`.

## Termination rule
Done when every RUN NOW campaign has printed paste-ready, granted installs have run (failures reported per skill, never retried into a loop), gaps and the outcome reminder are delivered, the record duties are complete, and the Phase 10 exit is confirmed.

## Do not
- Install without grant 5, commit without grant 6, or push without the push grant — and never re-ask for any of them mid-run.
- Stage, commit, or touch ANY target file beyond the two docs — no formatting fixes, no .gitignore, nothing.
- Use `--related` or `jsm install-all` outside their stated conditions; install an alias; reword a kickoff prompt.
- Run the campaigns themselves — this charter delivers them; execution is the user's move.
- Hand-edit the history appendix or headers — retention lives in `render-recommendations.py`.

## Composes with
synthesizer (delivers what its docs promise), idea-wizard-orchestrator (gaps to offer), catalog-local-inventory (installed flags), orchestrator (Phase 10 exit), the next run's staleness-checker and already-done machine (what the record feeds).
