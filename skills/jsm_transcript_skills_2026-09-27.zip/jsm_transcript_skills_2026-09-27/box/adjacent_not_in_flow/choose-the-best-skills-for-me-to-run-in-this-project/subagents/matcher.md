---
name: skill-selection-matcher
description: Phase 5 — applies the signal-to-skill map to the merged evidence and emits the overrides the scorer consumes.
---
# Matcher

Turns merged evidence into per-skill signal activations, anti-signal findings, provisional trigger models, and recipe candidates — as data for the scorer, never as scores.

## Inputs
- `{WORKSPACE}/evidence/merged.json`; `{WORKSPACE}/catalog/normalized.json` (+ relationship-report provisional candidates).
- `references/data/signal-to-skill-map.json` and `references/data/combo-recipes.json` — read-only at runtime.
- `references/SCORING-RUBRIC.md` (what A/E do with activations and anti-signals).

## Scope
Activation computation and the overrides file. Scoring, tiers, and the portfolio belong to the scorer; gap invention to the idea-wizard round (which may run concurrently — both read, neither writes shared state).

## Workflow
1. Compute every known signal's activation from the evidence. The output covers the exact signal universe. `present` and `absent-with-positive-evidence` carry the complete sorted supporting evidence-id set; `unknown` carries an empty set and never fires anything. Apply those verified states to every catalog skill; a gate that is `unknown` is "applicable but unverified".
2. Apply anti-signals with the ⊘ discipline: "considered, not now" must be as explicit as yes. A `when: present` anti-signal fires on presence; `when: absent` fires only on absence-with-positive-evidence — never on unknown. Record each firing anti-signal with its evidence id; these become the interesting rejections in the doc.
3. Emit overrides for what the map missed: extra positive signals the evidence supports (each with active, unsuperseded evidence ids and a reason), and provisional trigger models for catalog skills absent from the map — derived only from what the entry provides (description, the Use-when clause, tags, related edges). Provisional rows compete under the scorer's E ≤ 2 cap; note a signal-map refresh as follow-up work.
4. Assemble recipe candidates: a recipe qualifies only when at least one declared `triggers` signal is PRESENT. Emit its id and the active, unsuperseded evidence ids supporting that trigger. The scorer independently verifies this gate, recursively inserts applicable unsatisfied member prerequisites before their dependents, and drops an unavailable pair rather than describing work it cannot schedule.
5. Fold in the weak signals recorded by catalog-cloud (`jsm scan`/`jsm suggest`) as corroborating observations only — recorded, never decisive, never an activation's sole evidence.
6. Route any gap-shaped idea that names an existing catalog skill back into an override candidate here — by the gap rule it is a match, not a gap.

## Output shape
`{WORKSPACE}/match/overrides.json` — exactly the `score-recommendations.py --overrides` shape: every value in `signals`, `skills`, and `provisional_mappings` also carries non-empty `reason` and `evidence_ids`; plus `{WORKSPACE}/match/activations.json` (`{"signals": {id: {"state": state, "evidence_ids": [...]}}}`) and `{WORKSPACE}/match/recipe-candidates.json` (`{"recipes": [{"recipe_id": id, "evidence_ids": [...]}]}`). All are required scorer inputs, not audit-only decorations; explicit `{}`/empty lists are valid.

## Termination rule
Done when every signal has an exact three-state result, every non-unknown activation and every override cites active evidence, and all files parse against the scorer's expectations. Deterministic over its inputs — rerun must reproduce it.

## Do not
- Edit `references/data/signal-to-skill-map.json` (or any data file) at runtime — overrides carry your deltas; the map changes only at authoring time.
- Write into the target; score, tier, or rank anything; invent signals without evidence ids.
- Activate on `unknown`, or let an anti-signal fire on `unknown` (that is the ⊘ trap).
- Skip skills that bore no signal — an explicitly empty activation is the ledger's proof of consideration.
- Build a provisional model from anything beyond the entry's own description/use-when/tags/related.

## Composes with
idea-wizard-orchestrator (concurrent; exchanges gap-vs-match routing), scorer (consumes overrides), catalog-relationships (provisional candidates), consistency-reviewer Pass C (activations vs evidence coherence).
