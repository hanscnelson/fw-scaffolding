---
name: skill-selection-profiler-tests
description: Phase 2 — verifies and enriches the tests-and-gaps dimension, reading suspicious tests instead of trusting markers.
---
# Profiler: Tests & Gaps

Owns the "Tests present and the gap logic" taxonomy dimension: which test kinds exist, which are absent, and which gap-* derivations hold.

## Inputs
- Target scope; `{WORKSPACE}/evidence/profile-script.json` — the deterministic layer from `bash scripts/profile-project.sh` (`ev-p0001..`).
- `references/PROJECT-PROFILE-TAXONOMY.md` § "Tests present and the gap logic" (detection table, both-sides-known rule).
- The orchestrator-assigned `ev-p` id range from `{WORKSPACE}/spawn-plan.json`.

## Scope
All `tests-*` signals and the derived `gap-*` signals. The taxonomy names this profiler as the one that READS suspicious tests rather than trusting file layout.

## Workflow
1. Read the script's `tests-*` records; VERIFY and ENRICH, never re-scan wholesale.
2. Open the test files behind the load-bearing claims: do the "integration tests" exercise a real binary or a mock in a costume? `tests-use-mocks` vs `tests-real-services` is decided by reading, not by dep lists. Correct confidence accordingly.
3. Read files flagged with `tests-flaky-markers` (`#[ignore]`, skip marks, sleeps, retries): distinguish a deliberately-manual test from a quarantined flake, and say which in `detail`.
4. Check `tests-none` honestly: it is an aggregate, present only when unit, integration, e2e, property, fuzz, golden, and conformance are ALL absent-with-positive-evidence.
5. Audit each `gap-*` record against the both-sides-known rule: code side `present` AND every covering test kind `absent-with-positive-evidence`. Any `unknown` input makes the gap `unknown`; code side absent makes the gap a clean "no gap". Refute any gap the script derived through a failed scan.
6. Enrich with judgment: tests that exist but assert nothing, snapshot suites nobody regenerates, a fuzz dir with no corpus — signal-tagged where applicable.

## Output shape
`{WORKSPACE}/evidence/profiler-tests.json` — JSON array of evidence records (`references/schemas/evidence.schema.json`), `kind: "profile"`, ids strictly inside the assigned `ev-p` range, zero-padded, emission-ordered.

## Termination rule
Done when every `tests-*` and `gap-*` signal has a verified, corrected, or `unknown` record and the fragment validates. On timeout, return what exists.

## Do not
- Write into the target; never RUN the test suite — this phase reads, it does not execute project code.
- Infer a gap through an `unknown` input, or treat a missing test dir as absence without the completed-search record.
- Emit ids outside the assigned range; delete script records.
- Judge code-kind presence yourself — pair with profiler-code-kinds' records instead.

## Composes with
orchestrator (range, merge), profiler-code-kinds (code side of every gap), scorer (hygiene gaps can anchor RUN NOW with 2 profile anchors), evidence-auditor Pass B, synthesizer (Tests section).
