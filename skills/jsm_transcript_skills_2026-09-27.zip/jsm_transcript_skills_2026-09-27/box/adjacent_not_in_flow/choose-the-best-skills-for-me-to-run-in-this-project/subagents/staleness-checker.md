---
name: skill-selection-staleness-checker
description: Phase 1 — runs the fingerprint delta script and announces the reuse vs re-profile decision verbatim.
---
# Staleness Checker

Decides from the analysis-doc header fingerprint whether the existing profile is reused (cheap rerun) or rebuilt, and announces that decision in the fixed format.

## Inputs
- Resolved target and (for monorepos) the `--scope` component list, from the orchestrator.
- The existing analysis doc `docs/COMPREHENSIVE_ANALYSIS_OF_PROJECT_USED_FOR_AUTOMATED_SKILL_SELECTION.md`, when present.
- `references/STALENESS.md` — the decision procedure and exit-code contract.

## Scope
The reuse/re-profile decision only. It measures nothing else and never edits the doc it reads.

## Workflow
1. Run `bash scripts/check-doc-staleness.sh --target <dir> [--scope <p1,p2>] [--doc <file>] [--fresh]`; pass `--fresh` only when the user explicitly asked for a fresh profile.
2. Capture the single stdout JSON object to `{WORKSPACE}/staleness.json`. Exit 0 = reuse; exit 1 = re-profile (all `error:*` reasons included).
3. Announce the decision in the terminal, verbatim format:
   - reuse: `reusing profile from <ts>; N commits / M changed issue records since — refreshing juncture only`
   - re-profile: `re-profiling because <reason>`
   where `<ts>` = `profiled_at`, N = `commits_since_profile`, M = `bead_issue_records_since_profile`, `<reason>` = the JSON's `reason`; a null count prints as `?`.
4. Return decision + JSON to the orchestrator: on reuse the orchestrator skips Phase 2 entirely, and the end-of-run header bump touches only `juncture_refreshed_at`/`last_updated`; on re-profile the full Phase 2 fan-out runs and `profiled_at` plus every `profile_*` field is reset.

## Output shape
- `{WORKSPACE}/staleness.json` — the script's reason JSON verbatim (`decision`, `reason`, `commits_since_profile`, `bead_issue_records_since_profile`, `changed_file_ratio`, `worktree_digest`, `profiled_at`, `profile_head_sha`, `profile_scope`, `manifest_digests`, `is_git`).
- The one-line announcement, exactly as formatted above, echoed into the run record.

## Termination rule
Done when the JSON is captured and the announcement printed. No retries: a script error surfaces as an `error:*` reason and is a re-profile decision, never a stall.

## Do not
- Write into the target or edit the analysis doc — header bumps belong to Phase 10 via `render-recommendations.py`.
- Paraphrase, reorder, or skip the announcement; downstream checks grep for it.
- Second-guess the exit code with private heuristics — the script IS the decision procedure.
- Do any profiling or large source reads here; the reuse path must stay cheap (invariant 7).

## Composes with
orchestrator (consumes the decision), the six profilers (spawned only on re-profile), synthesizer (analysis-doc header fields come from this JSON).
