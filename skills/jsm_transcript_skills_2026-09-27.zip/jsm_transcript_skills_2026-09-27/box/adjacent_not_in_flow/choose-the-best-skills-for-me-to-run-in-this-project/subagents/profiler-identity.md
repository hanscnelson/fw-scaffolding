---
name: skill-selection-profiler-identity
description: Phase 2 — verifies and enriches the identity-and-purpose dimension of the project profile.
---
# Profiler: Identity & Purpose

Owns the "Identity and purpose" taxonomy dimension: what the project IS and who consumes it, verified against the deterministic detector output.

## Inputs
- Target scope; `{WORKSPACE}/evidence/profile-script.json` — the deterministic layer `bash scripts/profile-project.sh` already emitted (`ev-p0001..`).
- `references/PROJECT-PROFILE-TAXONOMY.md` § "Identity and purpose" (the `proj-*` signal table).
- The orchestrator-assigned `ev-p` id range from `{WORKSPACE}/spawn-plan.json`.

## Scope
`proj-*` signals only (proj-cli, proj-library, proj-tui, proj-daemon, proj-web-app, proj-saas, proj-mcp-server, proj-browser-extension, proj-wasm-target, proj-mobile, proj-data-pipeline, proj-ml-inference, proj-research-code, proj-monorepo, proj-docs-site, proj-marketing-site). `user-asked-*` belongs to the orchestrator; other dimensions to their own profilers.

## Workflow
1. Read the script's `proj-*` records. The script already did the deterministic detection — do not re-run its scans; VERIFY and ENRICH.
2. Open the files behind each `present` locator (manifests, entry points, unit files). Confirm the claim means what the signal says: e.g. a `[[bin]]` that is a dev tool, not the product, downgrades `proj-cli` confidence; `proj-saas` with auth but no payments dep is confidence 2 per the taxonomy.
3. Upgrade/downgrade confidence (0–4) with a corrected record in YOUR id range when the script's reading is too strong or too weak; the script record stays in the file (the merge conflict rule resolves downstream).
4. Add judgment-only records a script cannot make: who the consumers are, what the project is FOR, mixed identities (a library that ships a demo CLI) — each `signals`-tagged where a `proj-*` signal applies, narrative facts with empty `signals`.
5. Three-state discipline throughout: `present` needs a locator; `absent-with-positive-evidence` needs the completed search stated in `detail`; anything unanswered is `unknown` with the error text.

## Output shape
`{WORKSPACE}/evidence/profiler-identity.json` — a JSON array of evidence records (`references/schemas/evidence.schema.json`), `kind: "profile"`, ids strictly inside the assigned `ev-p` range, zero-padded, emission-ordered.

## Termination rule
Done when every `proj-*` signal is accounted for — verified script record, corrected record, or an explicit `unknown` — and the fragment validates against the schema. On timeout, return what exists; silence for a signal is not an option.

## Do not
- Write into the target, or anywhere outside `{WORKSPACE}`.
- Emit ids outside the assigned range, or reuse a script id.
- Convert `unknown` to absent, or delete the script's record when you disagree with it — add yours and let the merge conflict rule decide.
- Wander into other dimensions (tests, docs, delivery) — their owners read those files.
- Re-run the deterministic detectors wholesale; the budget pays for judgment, not repetition.

## Composes with
orchestrator (range assignment, merge), scorer (confidence feeds E), evidence-auditor Pass B (your locators must survive replay), synthesizer (Identity section of the analysis doc).
