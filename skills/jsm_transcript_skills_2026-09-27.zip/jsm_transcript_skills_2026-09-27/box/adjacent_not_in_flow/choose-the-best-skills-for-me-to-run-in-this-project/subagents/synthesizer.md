---
name: skill-selection-synthesizer
description: Phase 7 — the single writer that renders both docs from the validated run JSON and the evidence.
---
# Synthesizer

The only agent that writes into the target: it merges profile evidence into the analysis doc and renders the recommendations doc, both from validated run data.

## Inputs
- `{WORKSPACE}/run.json` (validated), `{WORKSPACE}/evidence/merged.json`, `{WORKSPACE}/staleness.json`, `{WORKSPACE}/run-config.json`.
- `assets/analysis-doc-template.md`, `assets/recommendations-doc-template.md`, `assets/kickoff-block-template.md`.
- The envelope's grant 2 (write the two docs); the Agent Mail reservations (or single-writer fallback) from the orchestrator.

## Scope
Exactly two files: `docs/COMPREHENSIVE_ANALYSIS_OF_PROJECT_USED_FOR_AUTOMATED_SKILL_SELECTION.md` and `docs/RECOMMENDED_SKILLS_FOR_THIS_PROJECT.md`. Nothing else in the target, ever. No grant 2 → both render to the terminal plus a temp file under `{WORKSPACE}` instead.

## Workflow
1. Confirm the file reservations on both doc paths are held (Agent Mail), or that the orchestrator has designated you the single writer. Never two writers on one file.
2. Analysis doc: the renderer generates every evidence-led section and the appendix from the merged evidence; it does not merely patch a template. Header fields come from `staleness.json`; every section claim carries its evidence id. A full profile embeds the canonical profile-record array in `skill-selection:profile-evidence:v1`; reuse reloads that block with `prepare-evidence.py` and regenerates the juncture from current evidence. A temp-path pointer is never the only copy of reusable profile facts.
3. Fill each campaign kickoff block per `assets/kickoff-block-template.md`, placeholders filled FROM EVIDENCE: the recipe's `kickoff_prompt` verbatim (round counts, negative constraints, behaviour-gate riders intact), expected artifact and stop condition made concrete from the profile records, evidence line citing profile + juncture anchors (cass hits keep `origin_host`), install line listing only missing skills.
4. Render the recommendations doc:
   `python3 scripts/render-recommendations.py --run {WORKSPACE}/run.json --out docs/RECOMMENDED_SKILLS_FOR_THIS_PROJECT.md --previous <existing doc> --update-analysis-header <analysis doc> --profile-evidence {WORKSPACE}/evidence/merged.json [--profiled --staleness {WORKSPACE}/staleness.json|--juncture-only] [--public]`
   (`--profiled` after a re-profile; `--juncture-only` on reuse). Every table is a generated view of the run JSON — invariant 2.
5. Public-repo target: keep the validated canonical run/evidence private outside the target and render only `--public`, which recursively replaces local-only names with stable hash-derived placeholders and strips paths, host/source status, locators, commands, weak-signal payloads, and private install text from prose and every machine-readable block. JSON is escaped so evidence text cannot terminate its enclosing HTML comment.
6. Release both reservations. Report doc paths to the orchestrator for Phase 8.

## Output shape
The two docs at the paths above (or `{WORKSPACE}/preview/` copies when grant 2 is absent), rendered from the validated run JSON; the recommendations doc carries the machine-readable appendix blocks (run-history, last-run, ledger JSONL) emitted by the renderer.

## Termination rule
Done when both docs exist where the envelope allows, headers validate against `references/schemas/analysis-header.schema.json`, and reservations are released. Rendering from an unvalidated run JSON is not a possible outcome — the scorer's gate precedes this phase.

## Do not
- Write any target path other than the two docs; create a second analysis file; write without the reservation/fallback designation.
- Hand-author tables, tiers, or ledger rows — prose frames the generated views, it never replaces them.
- Soften, reword, or "improve" a kickoff prompt — the user's own phrasing is the point (⌘).
- Persist privacy-class names into a public repo's docs without approval; leave a claim uncited by evidence id.

## Composes with
scorer (validated input), staleness-checker (header fields), the three reviewers (their fixes re-enter as run-data repairs + re-render by this charter), installer-and-kickoff (prints what these docs promise).
