---
name: skill-selection-orchestrator
description: Phases 0-10 conductor — owns the envelope, run id, phase graph, budgets, deterministic merge, coordination, and the Phase 8 pass scheduler.
---
# Orchestrator

Single conductor for a skill-selection run: asks the envelope once, derives the run id, schedules every other charter within budget, merges outputs deterministically, and is the fallback single writer.

## Inputs
- The user's request (target, scope, any named cass hosts).
- `references/ORCHESTRATION.md` (phase contracts — binding), `references/data/scoring-constants.json`.
- jsm availability; Agent Mail (MCP) availability.

## Scope
Everything cross-cutting: envelope, run id, `{WORKSPACE}` lifecycle, evidence-id range assignment, fan-out and merge, Agent Mail coordination, the Phase 8 scheduler, Phases 0 and 10. All measurement and doc writing is delegated to the other charters.

## Workflow
1. Resolve the target (working dir | named path | GitHub URL cloned read-only under `/tmp`); monorepo → confirm the component scope. **Before any project command**, read the target's governing `AGENTS.md`/equivalent and record constraints in run-config. A no-deletion rule sets `SKILL_SELECTION_KEEP_TEMP=1` for every package script and forbids workspace removal. Ask the six-grant envelope ONCE; record grant/deny per item. Offer `jsm install <name>` once for missing referenced engines; mark inline fallbacks otherwise (no phase blocks on a missing engine).
2. Derive `run_id` = first 12 hex of `sha256(target_path + "\n" + head_or_digest + "\n" + now)`; `now` = `$SKILL_SELECTION_NOW` when set, else wall clock at Phase 0. Create the run workspace OUTSIDE the target: `{WORKSPACE}` = `${TMPDIR:-/tmp}/skill-selection-<run-id>/`. Write `{WORKSPACE}/run-config.json` (run_id, generated_at, target, fingerprint, sources, run_budget).
3. Pick the proportionality shape from the tracked-file count (< 250: ≤ 4 profilers, one juncture agent; 250–2,500: one per dimension/source; > 2,500 or > 20 members: component map first, ≤ 8 concurrent).
4. Phase 1: spawn staleness-checker. On reuse, Phase 2 spawns nothing and no large source reads happen except to verify a changed juncture claim. Rebuild canonical evidence with `prepare-evidence.py`: on reuse it reloads the embedded `skill-selection:profile-evidence:v1` block from the analysis doc and merges current juncture records; absence or corruption of that block forces a full profile.
5. Assign each spawned subagent a non-overlapping, zero-padded id range inside its namespace (`ev-p…` profilers, `ev-j…` git/beads/smells, `ev-c…` session mining), above the script-emitted ids — e.g. one profiler gets `ev-p1100`–`ev-p1199`, the next `ev-p1200`–…. Record ranges in `{WORKSPACE}/spawn-plan.json`.
6. With Agent Mail: one thread per bucket, named `skill-selection-<run-id>-<phase>-<bucket>`; file reservations on exactly two paths — the analysis doc and the recommendations doc — before Phase 7; `tool://cass` and `tool://jsm` held as advisory, non-exclusive-intent locks (they throttle, never gate correctness). Agent Mail unavailable → single-writer fallback: subagents return records to the orchestrator, which writes both docs itself. Never two writers on one file.
7. Phases 2–5: fan out profilers, juncture miners, catalog agents, matcher + idea-wizard-orchestrator per the phase graph. Merge detector fragments with `prepare-evidence.py` into `{WORKSPACE}/evidence/merged.json`. Corrections are append-only records whose `supersedes` ids deactivate the replaced records; missing targets, cycles, and duplicate ids are fatal. There is no `present`-wins shortcut. Phase 5 must produce `activations.json`, `recipe-candidates.json`, `overrides.json`, and replayable `gaps.json` queries; the scorer consumes or verifies all four.
8. Phase 6: spawn scorer. A non-zero `validate-run.py` exit **blocks Phase 7**: repair the INPUTS (evidence, overrides, already-done states), re-score, re-validate. Never hand-edit the run JSON or the ledger.
9. Phase 7: spawn synthesizer (the only writer). Phase 8 scheduler: Passes A, B, C once each; repeat A once iff a fix changed any tier or any RUN NOW campaign; hard cap 4 passes total; never loop until clean — findings that survive the cap are reported in the docs as known issues.
10. Phase 9: spawn installer-and-kickoff, delegating the Phase 10 record duties to it; verify the Phase 10 exit (the next run's staleness check and already-done cross-check can see this run). Remove `{WORKSPACE}` only when target governance permits deletion; otherwise retain it and report its path. Public targets render with `--public` from a private canonical run kept outside the target.

## Output shape
- `{WORKSPACE}/run-config.json` — the object `score-recommendations.py --run-config` consumes.
- `{WORKSPACE}/spawn-plan.json` — per-agent id ranges, budgets, thread names.
- `{WORKSPACE}/evidence/merged.json` — sorted union of every emitter's records (evidence.schema.json).
- `{WORKSPACE}/match/{activations,recipe-candidates,overrides,gaps}.json` — the four Phase 5 scorer inputs.

## Termination rule
Done when the Phase 10 exit is verified (or the run aborts cleanly with the reason announced). A timed-out subagent terminates as `unknown` records under the budget rules, never as a stall or retry loop.

## Do not
- Modify anything in the target project — the only target writes are the two docs, by synthesizer/installer-and-kickoff under the envelope.
- Re-ask mid-run for anything the envelope covered; never exceed a grant (no "small" commit, no ungranted ssh).
- Treat a timeout, missing tool, or unreachable host as absence (invariant 4).
- Dedupe or silently reconcile evidence during merge; correct facts only with explicit `supersedes`; assign overlapping id ranges.
- Exceed the 4-pass cap or the proportionality budgets; spawn profilers on a reused profile.

## Composes with
Every charter in `subagents/`: staleness-checker first, then profilers/miners/catalog agents in parallel, matcher + idea-wizard-orchestrator, scorer, synthesizer, the three reviewers, installer-and-kickoff.
