---
name: skill-selection-profiler-docs-and-process
description: Phase 2 — verifies and enriches the docs-and-process dimension, reading every process document in full.
---
# Profiler: Docs & Process

Owns the "Docs and process artifacts" taxonomy dimension: documentation state, process scaffolding, maturity — with full-file reads, because a skimmed README is not evidence of anything.

## Inputs
- Target scope; `{WORKSPACE}/evidence/profile-script.json` — the deterministic layer from `bash scripts/profile-project.sh` (`ev-p0001..`).
- `references/PROJECT-PROFILE-TAXONOMY.md` § "Docs and process artifacts".
- The orchestrator-assigned `ev-p` id range from `{WORKSPACE}/spawn-plan.json`.

## Scope
`docs-*` signals, `beads-present`/`beads-absent`, `agent-mail-project`, `ci-config`/`ci-none`, `maturity-*`, and `docs-prose-sounds-generated` — the last is THIS charter's named judgment per the taxonomy's detector map (model-written tells over public-facing prose).

## Workflow
1. Read the script's records for the owned signals; VERIFY and ENRICH.
2. READ FULLY, whenever present: README, AGENTS.md/CLAUDE.md, CHANGELOG, plan/roadmap files, CONTRIBUTING, ADRs. Presence is scripted; content judgment is yours — this is the one profiler whose charter requires whole-file reads.
3. From those reads, correct the scripted heuristics: a 55-line README that is genuinely complete refutes `docs-readme-weak`; a CHANGELOG touched recently but describing only ancient tags supports `docs-changelog-stale-vs-tags` at higher confidence.
4. Judge `docs-prose-sounds-generated` over public-facing prose only (README, docs site, marketing copy): cite the telltale phrases verbatim in `detail` with file:line locators. No citations, no claim.
5. Verify `maturity-*` against the git facts in the script record AND what the docs claim about themselves; a "v0.1 experiment" README on a 3-year tagged repo is a finding worth a record.
6. Note process posture a script cannot judge: does AGENTS.md prescribe a landing workflow, do plan files match reality — narrative records, signal-tagged where applicable. Three-state discipline throughout.

## Output shape
`{WORKSPACE}/evidence/profiler-docs-and-process.json` — JSON array of evidence records (`references/schemas/evidence.schema.json`), `kind: "profile"`, ids strictly inside the assigned `ev-p` range, zero-padded, emission-ordered.

## Termination rule
Done when every owned signal has a verified, corrected, or `unknown` record, every present process doc has actually been read in full, and the fragment validates. On timeout, return what exists.

## Do not
- Write into the target, or anywhere outside `{WORKSPACE}`.
- Skim: a partial read of a present AGENTS/README/CHANGELOG/plan file disqualifies any judgment built on it.
- Claim `docs-prose-sounds-generated` without quoted phrases and locators.
- Emit ids outside the assigned range; convert `unknown` to absence; delete script records.
- Read beads databases with mutating tools — `beads-present` here is directory presence; queue analysis belongs to juncture-beads.

## Composes with
orchestrator (range, merge), juncture-beads (queue state for the beads it only marks present), scorer (E), evidence-auditor Pass B, synthesizer (Docs & process section), installer-and-kickoff (the target's AGENTS.md landing workflow read here governs the commit step).
