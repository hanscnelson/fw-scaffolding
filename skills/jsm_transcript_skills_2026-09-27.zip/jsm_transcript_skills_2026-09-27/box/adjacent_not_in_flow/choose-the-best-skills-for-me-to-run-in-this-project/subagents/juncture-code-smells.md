---
name: skill-selection-juncture-code-smells
description: Phase 3 — verifies and enriches the code-smell juncture signals, including the ceremony judgment call.
---
# Juncture Miner: Code Smells

Owns the code-smell juncture source: density signals over non-test, non-generated code, plus the one smell no script can score.

## Inputs
- Target; `{WORKSPACE}/evidence/juncture-script.json` — the scripted layer (`ev-j0001..`) from `bash scripts/juncture-signals.sh`.
- `references/JUNCTURE-SIGNALS.md` § "Source 4: code smells" (density thresholds); the exclusion record from the profile evidence.
- The orchestrator-assigned `ev-j` id range from `{WORKSPACE}/spawn-plan.json`.

## Scope
`jx-todo-density-high`, `jx-unwrap-density-high`, `jx-dead-code-sprawl`, `jx-mock-suspicion`, and `jx-ceremony-smell` — the last is a subagent + cass judgment per the source table, and it is yours.

## Workflow
1. Read the script's smell records; VERIFY and ENRICH. Confirm the densities were computed over non-test, non-generated code (same exclusions as the profiler — check the exclusion record exists before endorsing any density).
2. Open the flagged files: a TODO block that is a design doc in comments reads differently from 40 scattered FIXMEs; `.unwrap()` in a build script differs from `.unwrap()` in a request path. Correct confidence with locators, and name the concentrations (one module vs everywhere) in `detail`.
3. `jx-mock-suspicion` is about NON-test code: verify each stub/placeholder/todo!() hit really ships — a fixture that leaked past the test-path exclusion earns a downgrade.
4. `jx-dead-code-sprawl`: check whether window commits touch the dead regions (growing) — corroborate with juncture-git's churn records rather than re-running git yourself.
5. Judge `jx-ceremony-smell` from both trees: process artifacts (plans, rituals, scaffolding) growing while shipped capability does not — pair the file evidence with the cass-side observations from juncture-cass-local, and cite both. No citations, no claim.
6. Three-state discipline: an `rg` timeout behind a density is `unknown`, and a density over an unconfirmed exclusion set is at most confidence 2.

## Output shape
`{WORKSPACE}/evidence/juncture-code-smells.json` — JSON array of evidence records (`references/schemas/evidence.schema.json`), `kind: "juncture"`, ids strictly inside the assigned `ev-j` range, zero-padded.

## Termination rule
Done when all five owned signals have a verified, corrected, or `unknown` record and the fragment validates. On timeout, return what exists.

## Do not
- Write into the target — no fixing the TODOs you read, no deleting dead code, however tempting.
- Endorse a density computed without the generated/vendored exclusions, or convert a timed-out scan to absence.
- Claim `jx-ceremony-smell` from file counts alone — it needs the capability-not-growing half, with evidence.
- Emit ids outside the assigned range; delete script records; judge git/beads/cass signals beyond the corroborations named above.

## Composes with
orchestrator (range, merge), profiler-code-kinds (shared exclusion record), juncture-git (churn corroboration), juncture-cass-local (ceremony's session half), scorer (J weights), evidence-auditor Pass B.
