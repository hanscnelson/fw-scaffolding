---
name: skill-selection-juncture-beads
description: Phase 3 — verifies and enriches the beads issue-tracker juncture signals via read-only robot forms.
---
# Juncture Miner: Beads

Owns the beads juncture source: queue health of the target's local issue tracker, strictly read-only.

## Inputs
- Target; `{WORKSPACE}/evidence/juncture-script.json` — the scripted layer (`ev-j0001..`) from `bash scripts/juncture-signals.sh`.
- `references/JUNCTURE-SIGNALS.md` § "Source 3: beads" (commands, thresholds).
- The orchestrator-assigned `ev-j` id range from `{WORKSPACE}/spawn-plan.json`.

## Scope
`jx-beads-many-open`, `jx-beads-blocked`, `jx-beads-queue-dry`, `jx-beads-stale-epics`, `jx-beads-corrupt`, `jx-plan-no-beads`.

## Workflow
1. Read the script's beads records; VERIFY and ENRICH using only the read-only robot forms:
   `br --no-auto-flush --no-auto-import list --status all --json` / `blocked --json` / `ready --json` / `doctor --json`, plus `bv --robot-triage --no-cache` and `bv --robot-insights --no-cache`.
2. Enrich the threshold claims with content judgment: WHICH epics are stale (all children closed — the "did we actually finish" smell), which blockers head `blockers_to_clear`, whether the open set is one campaign or scattered — bead ids as locators.
3. `jx-plan-no-beads`: confirm both sides — the plan/roadmap file exists (cite it) and `.beads/` is missing or empty; a plan tracked in a different system is a downgrade, said in `detail`.
4. `.beads/` present but `br` missing → every beads signal is `unknown`, never absent. `br` erroring with schema-mismatch text is `jx-beads-corrupt` evidence, not a reason to poke the database.
5. Corroborate with git where cheap (a bead closed with no landing commit): pass the observation to juncture-cass-local for the already-done derivation rather than deciding completion yourself.

## Output shape
`{WORKSPACE}/evidence/juncture-beads.json` — JSON array of evidence records (`references/schemas/evidence.schema.json`), `kind: "juncture"`, `source_type: "beads"`, ids strictly inside the assigned `ev-j` range, zero-padded.

## Termination rule
Done when all six owned signals have a verified, corrected, or `unknown` record and the fragment validates. A hung `br` call is killed at the budget and recorded `unknown`.

## Do not
- Write into the target; run `br` without `--no-auto-flush --no-auto-import`, or `bv` without `--no-cache` — the flags are what make these calls read-only toward `.beads/`.
- Create, close, update, or sync beads; never run repair commands on a corrupt-looking store — corruption is a finding, not your ticket.
- Treat missing `br` as an empty tracker (invariant 4).
- Emit ids outside the assigned range; delete script records; judge git, cass, or smell signals.

## Composes with
orchestrator (range, merge), juncture-cass-local (beads corroboration for already-done states), juncture-git (shared window), scorer (J weights), evidence-auditor Pass B (robot list forms replay safely).
