---
name: skill-selection-catalog-cloud
description: Phase 4 — fetches the live catalog down the jsm/website/snapshot ladder and reports drift honestly.
---
# Catalog Agent: Cloud

Acquires the public catalog at the best reachable tier, announces the tier once, and reports drift against the bundled snapshot.

## Inputs
- The envelope's grant 4 (authenticated catalog metadata) — ungranted, the ladder starts at tier 2.
- `references/CATALOG-ACQUISITION.md` (jsm surface, headless auth, the fallback ladder, drift protocol).
- `references/data/catalog-snapshot.json` and `references/data/aliases.json`.

## Scope
The name universe and per-skill metadata from public sources; drift classification (new / changed / retired). Local copies belong to catalog-local-inventory; edge normalization to catalog-relationships.

## Workflow
1. Run `bash scripts/catalog-fetch.sh --out {WORKSPACE}/catalog/fetched.json --cache-dir {WORKSPACE}/catalog/cache --deadline 30` (add `--offline` when grant 4 was denied). The script walks the ladder under that one aggregate budget: tier 1 jsm (authenticated `jsm whoami --json` first; only new/changed names fetched live), tier 2 website (sitemap slugs + meta descriptions for new names), tier 3 bundled snapshot as-is. Offline mode makes zero `jsm`/`curl` calls.
2. Headless note: jsm auth needs `JSM_ALLOW_ENV_PASSPHRASE=1` plus `JSM_CREDENTIALS_PASSPHRASE` from the user's secret store — never hardcoded, never echoed into any artifact. Unauthenticated headless jsm falling to tier 2 is correct degradation, not failure.
3. Announce ONCE: `catalog source: tier N`, and record it in the run config's sources. Falling a tier is never a reason to stop, re-ask the envelope, or pad scores.
4. Verify the drift block: retirement and aggregate `drift_known: true` require a
   complete sitemap (`retirement_known: true`). An authenticated newest-page `jsm` list
   may establish new/changed entries but never retirement. Tier 3 emits empty arrays with
   both flags false — "could not check", never "no drift". Retired names keep their ledger
   row this run (disposition explains) and are never recommended.
5. Confirm alias canonicalization on every boundary name (live list, sitemap slugs); confirm the exact `No related skills found.` sentinel was parsed as empty edges, while any other malformed relationship response appears in `source_errors` and retains prior edges.
6. The only hard failure: a missing or schema-invalid bundled snapshot — that is a broken package; report it and stop the phase.

## Output shape
`{WORKSPACE}/catalog/fetched.json` — `{"skills": [catalog entries], "source_tier": "jsm|website|snapshot", "drift": {"new": [], "changed": [], "retired": []}, "drift_known": bool, "retirement_known": bool, "source_errors": []}`, entries per `references/schemas/catalog-entry.schema.json`.

## Termination rule
Done when the object is written, the tier announced, and drift verified — one ladder walk under the script's single aggregate acquisition deadline, never a fresh budget per name.

## Do not
- Write into the target; install anything; call any jsm command that mutates state.
- Persist or print the passphrase, or any credential, anywhere — including error text quoted into evidence.
- Claim drift from tier 3, or spin an empty tier-3 drift report as "no drift".
- Retry a timed-out fetch in a loop — the name stays on its snapshot entry, and that is recorded.
- Treat `jsm scan`/`jsm suggest` output as ground truth — weak signals only, recorded for the matcher, never decisive.

## Composes with
catalog-local-inventory (concurrent), catalog-relationships (consumes the union), matcher (provisional rows for drift-new names), scorer (catalog_drift in the run config), installer-and-kickoff (tier determines install advice).
