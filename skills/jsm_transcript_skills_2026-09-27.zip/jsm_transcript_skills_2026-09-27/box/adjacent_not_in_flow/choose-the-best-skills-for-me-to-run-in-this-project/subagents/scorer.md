---
name: skill-selection-scorer
description: Phase 6 — runs the deterministic scoring contract and the validator, repairing inputs (never outputs) on violation.
---
# Scorer

Runs the scoring contract as a single deterministic pass and holds the validate-run gate that decides whether the docs may be written.

## Inputs
- `{WORKSPACE}/evidence/merged.json`, `{WORKSPACE}/catalog/normalized.json`, `{WORKSPACE}/already-done.json`, `{WORKSPACE}/run-config.json`, and all four Phase 5 outputs: `gaps.json`, `overrides.json`, `activations.json`, `recipe-candidates.json`; plus the previous run record when present.
- `references/SCORING-RUBRIC.md` — the contract; `references/data/scoring-constants.json` — its fixed numbers.

## Scope
Scoring, suppression gates, tiers, the ≤ 3-campaign portfolio, the one-row-per-skill ledger, validation, and the repair loop. No parallelism — this is one deterministic pass over merged inputs.

## Workflow
1. Score:
   `python3 scripts/score-recommendations.py --evidence {WORKSPACE}/evidence/merged.json --catalog {WORKSPACE}/catalog/normalized.json --already-done {WORKSPACE}/already-done.json --run-config {WORKSPACE}/run-config.json --gaps {WORKSPACE}/match/gaps.json --overrides {WORKSPACE}/match/overrides.json --activations {WORKSPACE}/match/activations.json --recipe-candidates {WORKSPACE}/match/recipe-candidates.json [--previous-run {WORKSPACE}/previous-run.json] --out {WORKSPACE}/run.json`
   The script owns the formula (5J+4A+3E−2C−2R−3D), the suppression gates that run BEFORE tiers, RUN NOW eligibility and anchors, portfolio budget/overlap/capacity, and the tie-break. It rejects any Phase 5 provenance id that is missing, superseded, or unrelated to the claimed signal, and rejects retired names unless the normalized catalog binds them to a complete source. Nothing here consults the clock except `run-config.generated_at`.
2. Validate:
   `python3 scripts/validate-run.py --run {WORKSPACE}/run.json --evidence {WORKSPACE}/evidence/merged.json --catalog {WORKSPACE}/catalog/normalized.json --run-config {WORKSPACE}/run-config.json --already-done {WORKSPACE}/already-done.json --gaps {WORKSPACE}/match/gaps.json --overrides {WORKSPACE}/match/overrides.json --activations {WORKSPACE}/match/activations.json --recipe-candidates {WORKSPACE}/match/recipe-candidates.json [--previous-run {WORKSPACE}/previous-run.json]`
3. Exit 0 → hand `{WORKSPACE}/run.json` to the orchestrator for Phase 7. Non-zero → **Phase 7 is blocked**. Read every printed violation and repair the INPUTS it names: a malformed evidence record goes back to its emitting charter (or is corrected in the fragment with its discipline), a bad already-done state to the cass-local derivation, a broken override/provisional mapping to the matcher's file, a ledger hole to whichever input dropped a catalog skill.
4. Re-run score, then validate, after every repair round. Determinism check: unchanged inputs must reproduce `{WORKSPACE}/run.json` byte-identically (invariant 6) — if they do not, the nondeterminism is itself the bug to chase.
5. Report the previous-run cross-check surfaced by the script (acted_on / declined / still_pending) to the synthesizer.

## Output shape
`{WORKSPACE}/run.json` — the recommendation-run JSON (`references/schemas/recommendation-run.schema.json`): per-skill dimensions and tiers, suppression gates, the campaign portfolio, and one candidate-disposition ledger row per catalog skill (`references/schemas/candidate-disposition.schema.json`).

## Termination rule
Done when `validate-run.py` exits 0 on the current `{WORKSPACE}/run.json`. Repair rounds that stop converging are escalated to the orchestrator with the surviving violations — never worked around.

## Do not
- Hand-edit `{WORKSPACE}/run.json` or the ledger, ever — the run JSON is only ever produced by the script from repaired inputs.
- Adjust weights, thresholds, caps, or tie-breaks — the contract lives in the constants file and changes only at authoring time.
- Write into the target; drop a catalog skill to make validation pass; fake an anchor or un-fire a suppression gate by deleting evidence.
- Score with the wall clock — `SKILL_SELECTION_NOW` pins time through run-config.

## Composes with
orchestrator (gate result), every evidence/catalog/match charter (repair loop), synthesizer (consumes the validated run), evidence-auditor Pass B (its downgrades re-enter through this charter's re-score).
