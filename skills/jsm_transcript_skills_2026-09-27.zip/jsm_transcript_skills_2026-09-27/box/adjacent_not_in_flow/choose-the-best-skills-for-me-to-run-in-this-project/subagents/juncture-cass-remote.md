---
name: skill-selection-juncture-cass-remote
description: Phase 3 — mines remote cass hosts for juncture signal, one instance per host, timeouts degrading to unknown.
---
# Juncture Miner: Cass (Remote)

Fans session mining out to the machines where agents actually run — often where the real juncture signal lives — under the envelope's remote grant.

## Inputs
- The envelope's grant 3 (remote cass search) — absent grant, this charter never spawns.
- Host list, ONLY from `cass sources list --json`, `$SKILL_SELECTION_CASS_HOSTS`, or an explicit `--hosts` grant; never an invented host.
- `references/JUNCTURE-SIGNALS.md` § "Source 1: session history via cass" (remote fan-out); the assigned `ev-c` id range from `{WORKSPACE}/spawn-plan.json`.

## Scope
One instance per host (or a single instance iterating the configured sources when the orchestrator so budgets). Error-class batteries ONLY — panics, hangs, flaky tests, perf, payments, auth, deploy, machine-unresponsive — never the per-skill scan on remote hosts.

## Workflow
1. Confirm the host list source and record it. An explicitly empty list means "local only" — record that as a fact and stop.
2. Per host and query, the one-shot form the script uses:
   `ssh <host> 'IFS= read -r q && cass search "$q" --json --fields minimal --limit 20' <<< "$Q"`
   (with `-o ConnectTimeout=5 -o BatchMode=yes` and `--days <N>`); 60s budget per host.
3. Preserve `origin_host` in every cited hit — locators are `source_path:line@<host>`; the `origin_host` field carries the host verbatim into scoring and the docs (privacy: hostnames never persist into docs for a public-repo target without approval — terminal is fine).
4. A host timeout or ssh failure yields exactly ONE `unknown` summary record naming the host and the error — a host timeout is unknown, never "no sessions". Then move on; no retry loops.
5. Merge per-host mention observations into the tally handed to juncture-cass-local; remote hits corroborate local claims (raising E), they do not spawn new per-skill scans.

## Output shape
`{WORKSPACE}/evidence/juncture-cass-remote-<host>.json` (one per instance) — evidence records, `kind: "juncture"`, `source_type: "cass"`, `origin_host` set, ids strictly inside the assigned `ev-c` range, zero-padded.

## Termination rule
Done when every host in the list has either its battery records or its single `unknown` summary record. The whole fan-out is bounded by hosts × 60s; nothing waits on a dead host.

## Do not
- Write into the target or onto any remote host — the ssh forms read; they never install, index, or configure.
- Run without the envelope grant; invent, guess, or expand the host list; re-ask for hosts mid-run.
- Interpret an unreachable host in ANY direction — no absence claims, no "probably fine", just the one `unknown` record.
- Run per-skill invocation scans remotely; strip or rewrite `origin_host`; emit ids outside the assigned range.

## Composes with
orchestrator (spawns one per host within ≤ 8 concurrency), juncture-cass-local (tally merge, corroboration), scorer (E from cross-host corroboration), evidence-auditor Pass B (which may only degrade, never negate, a dead host's claims).
