---
name: skill-selection-idea-wizard-orchestrator
description: Phase 5 — runs the 30-5-10 idea round to surface non-obvious matches and validated catalog gaps.
---
# Idea-Wizard Orchestrator

Runs the divergent half of Phase 5: a 30→5→10 idea round scoped to non-obvious skill matches or skill GAPS for THIS project at THIS juncture.

## Inputs
- `{WORKSPACE}/evidence/merged.json` and `{WORKSPACE}/catalog/normalized.json`.
- `/idea-wizard` when installed; else the inline fallback prompt from `references/ORCHESTRATION.md#fallbacks`.
- The gap rules in the recommendations template (a gap may never name an existing catalog skill).

## Scope
Idea generation and gap validation only. It proposes; the matcher and scorer dispose. Runs concurrently with the matcher — both read, neither writes shared state.

## Workflow
1. Frame the round with the scope phrase verbatim: "non-obvious skill matches or skill GAPS for THIS project at THIS juncture" — seeded with the strongest evidence records, the firing junctures, and the catalog's shape. Not generic brainstorming: every idea must tie to an evidence id.
2. Run 30→5→10: 30 candidate skill-to-evidence pairings, winnow to the best 5 with full rationale, then force the next 10 — the forcing pass is where the non-obvious matches live. With `/idea-wizard` installed, drive it; missing, run the same prompt inline and feed the result forward identically.
3. Sort each surviving idea:
   - names an existing catalog skill → it is a MATCH, not a gap: route it to the matcher as an override candidate with its evidence ids and drop it from the gap list.
   - names no catalog skill → candidate gap: validate by searching the catalog (name, tags, description, `jsm search <query>` at tier 1) and record the exact query that came up empty.
4. A validated gap object carries: the need (grounded in evidence ids), the catalog query that came up empty, and a suggested `jsm requests new` title. No empty-query record, no gap.
5. Keep the round inside its budget: one round, no recursive re-rounds; dry rounds end with an honest empty list.

## Output shape
`{WORKSPACE}/match/gaps.json` — JSON array of gap objects in the run schema's gap shape (the `score-recommendations.py --gaps` input): need, evidence ids, empty catalog query, suggested request title; plus `{WORKSPACE}/match/idea-round.json` (the 30/5/10 trail for the review passes).

## Termination rule
Done when the round has run once, every idea is routed (match → matcher, validated gap → gaps.json, unvalidated → dropped with reason), and both files are written. An empty gap list is a valid termination.

## Do not
- Write into the target; edit map or recipe data files.
- Emit a gap that names ANY existing catalog skill — the validation query exists to catch exactly this; check aliases too.
- Let ideas float free of evidence ids, or pad the round to look productive (that is the ceremony anti-pattern).
- Score, tier, or rank — and never promise the user a gap will become a skill; `jsm requests` is an offer the installer makes.

## Composes with
matcher (receives rerouted matches; concurrent), scorer (consumes gaps.json), installer-and-kickoff (offers validated gaps to `jsm requests`), evidence-auditor Pass B (gap queries are replayable searches).
