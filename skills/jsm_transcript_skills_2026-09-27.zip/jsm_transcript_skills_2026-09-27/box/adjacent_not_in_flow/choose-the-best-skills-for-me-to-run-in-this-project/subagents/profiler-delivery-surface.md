---
name: skill-selection-profiler-delivery-surface
description: Phase 2 — verifies and enriches the delivery-surface-and-polish dimension of the profile.
---
# Profiler: Delivery Surface

Owns the "Delivery surface and polish gaps" taxonomy dimension: how the project reaches users and what is missing at that surface.

## Inputs
- Target scope; `{WORKSPACE}/evidence/profile-script.json` — the deterministic layer from `bash scripts/profile-project.sh` (`ev-p0001..`).
- `references/PROJECT-PROFILE-TAXONOMY.md` § "Delivery surface and polish gaps".
- The orchestrator-assigned `ev-p` id range from `{WORKSPACE}/spawn-plan.json`.

## Scope
`published-registry`, `public-facing`, `release-tags-present`/`releases-none`, `installer-missing-for-cli`, `installer-weak`, `doctor-missing-for-cli`, `json-mode-missing-for-cli`, `docs-site-missing`, `og-image-missing`, `bench-harness-present`, `media-video-files-present`, `media-audio-files-present`, `iphone-takes-present`, `screencast-present`, `slack-export-present`.

## Workflow
1. Read the script's records for the owned signals; VERIFY and ENRICH.
2. `installer-weak`: read the installer script itself and name which of checksums / platform detection / version pin / uninstall are missing — the specific misses go in `detail`, they become campaign evidence.
3. Verify the derived `*-missing-for-cli` signals against their inputs: a doctor-shaped subcommand under a different name refutes `doctor-missing-for-cli`; say where it lives.
4. Registry and `gh` lookups are timeboxed 30s; a timeout or missing tool leaves the claim `unknown` — never "not published". `publish = false` in a manifest is a clean absence with the manifest as locator.
5. `og-image-missing` caps at confidence 2 (the GitHub web-UI setting is invisible from the tree) — never upgrade it above that.
6. Enrich with judgment: does the README's install advice match the installer that exists; are the media files raw takes or finished assets (feeds the media signals' usefulness). Three-state discipline throughout.

## Output shape
`{WORKSPACE}/evidence/profiler-delivery-surface.json` — JSON array of evidence records (`references/schemas/evidence.schema.json`), `kind: "profile"`, ids strictly inside the assigned `ev-p` range, zero-padded, emission-ordered.

## Termination rule
Done when every owned signal has a verified, corrected, or `unknown` record and the fragment validates. On timeout, return what exists.

## Do not
- Write into the target; never publish, tag, or touch registries — lookups only.
- Treat a network/tool failure as "not published" or "not public" (invariant 4).
- Raise `og-image-missing` above confidence 2, or derive `installer-missing-for-cli` when its inputs are `unknown`.
- Emit ids outside the assigned range; delete script records.
- Judge identity or code-kind signals — consume their records via the merge instead.

## Composes with
orchestrator (range, merge), profiler-identity (proj-cli feeds the derived signals), scorer (polish gaps are baseline-hygiene anchors), evidence-auditor Pass B, synthesizer (Delivery-surface section).
