---
name: skill-selection-catalog-relationships
description: Phase 4 — merges local and cloud catalogs into one normalized entry per name and normalizes relationship edges.
---
# Catalog Agent: Relationships

Builds the single normalized catalog — exactly one entry per canonical name — and the relationship-edge layer that recipes and portfolio overlap checks depend on.

## Inputs
- `{WORKSPACE}/catalog/local-inventory.json` and `{WORKSPACE}/catalog/fetched.json` (runs after both).
- `references/data/catalog-snapshot.json` (bundled related data), `references/data/combo-recipes.json`, `references/data/aliases.json`.
- `references/CATALOG-ACQUISITION.md` (drift protocol, jsm related quirks).

## Scope
The union merge, `installed`/`resolved_path`/skew attachment, relationship edges (`pairs_with`, `alternative_to`, `extends`, `prerequisite`), and recipe-membership sanity.

## Workflow
1. Merge as a plain union keyed by canonical name: public/website/snapshot entries plus local entries; `installed`, `resolved_path`, and `skew` land on the normalized entry; a local-only skill still gets its entry (and later its one ledger row). Preserve the fetched catalog's `drift`, `drift_known`, and `retirement_known` fields unchanged at the wrapper level so the scorer can bind retirement claims to their source. Canonicalize any straggler alias — nothing downstream may see one.
2. Edge sourcing reality: a bulk `jsm related --all` only covers INSTALLED skills, so it is empty on fresh machines — never read that emptiness as "no relationships". The sources are per-name `timeout 40 jsm related <name> --json` lookups (tier 1, new/changed names only) plus the bundled snapshot's related data for everything else.
3. Parse the version quirk narrowly: the exact trimmed text `No related skills found.` means empty edges. Any other malformed or truncated response is `unknown`, is recorded in `source_errors`, and retains snapshot relationships rather than fabricating emptiness.
4. Normalize edges to canonical names, drop edges pointing outside the normalized catalog (recording each drop as drift evidence — a dangling edge usually means a retired or renamed skill), and keep `alternative_to` symmetric.
5. Sanity-check recipe membership: every sequence member of every recipe in `references/data/combo-recipes.json` must exist in the normalized catalog; `jsm graph` may corroborate at tier 1. Report violations to the orchestrator — the scorer drops broken recipes, you do not edit the data files.
6. Report drift-relevant facts onward: retired names still present locally ("installed but retired upstream"), skew between copies, and names in no map entry (provisional candidates for the matcher).

## Output shape
`{WORKSPACE}/catalog/normalized.json` — `{"skills": [catalog entries], "drift": {...}, "drift_known": bool, "retirement_known": bool}` with exactly one entry per canonical name (`references/schemas/catalog-entry.schema.json`), edges normalized, `installed`/`resolved_path`/`skew` merged, and catalog-level drift facts preserved; plus `{WORKSPACE}/catalog/relationship-report.json` (dropped edges, recipe violations, provisional candidates).

## Termination rule
Done when the normalized catalog has exactly one entry per canonical name, every edge resolves or is recorded as dropped, and every recipe is checked. Pure computation over local files — no timeouts to manage beyond stray per-name lookups.

## Do not
- Write into the target; edit `references/data/*.json` at runtime — violations are reported, not patched.
- Read an empty bulk related listing as proof that every skill lacks relationships (fresh-machine trap), or treat the exact `No related skills found.` sentinel as an error. Other malformed output is a source error and retains prior edges.
- Emit two entries for one name, or let an alias or dangling edge into the output.
- Rank or score anything — edges inform the scorer's overlap and prerequisite logic, not your opinions.

## Composes with
catalog-local-inventory and catalog-cloud (inputs), matcher (normalized catalog + provisional candidates), scorer (recipes, `alternative_to` overlap rejections), artifact-integrity-reviewer Pass A (campaign members must exist here).
