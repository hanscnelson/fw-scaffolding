---
name: skill-selection-juncture-git
description: Phase 3 — verifies and enriches the git and GitHub juncture signals from the scripted miner.
---
# Juncture Miner: Git

Owns the git and gh juncture sources: what actually changed in the window, verified against the scripted vocabulary-density claims.

## Inputs
- Target; pinned clock (`$SKILL_SELECTION_NOW`); `{WORKSPACE}/evidence/juncture-script.json` — output of `bash scripts/juncture-signals.sh --target <dir> --out …` (`ev-j0001..`).
- `references/JUNCTURE-SIGNALS.md` § "Source 2: git" (commands, thresholds).
- The orchestrator-assigned `ev-j` id range from `{WORKSPACE}/spawn-plan.json`.

## Scope
Git-derived `jx-*` signals (jx-bug-fix-churn, jx-regressions, jx-recurring-panics, jx-perf-commits, jx-port-in-progress, jx-hang-or-deadlock, jx-release-overdue, jx-release-imminent, jx-docs-drift, jx-uncommitted-work, jx-unsafe-touched, jx-dependency-bump, jx-flaky-tests, jx-repo-sprawl, jx-upstream-sync-due, jx-swarm-active, and kin) plus the gh set (jx-open-pr-backlog, jx-open-issue-backlog, jx-failing-ci, jx-issues-triage-due).

## Workflow
1. Read the script's `ev-j` records; VERIFY and ENRICH. Every claim must sit inside the 14-day `--since/--until` window ending at the pinned clock — flag any that does not.
2. Open the commits behind density claims (`git show --stat <sha>`): a subject saying "fix typo" inflating `jx-bug-fix-churn`, or one revert of a docs commit behind `jx-regressions`, earns a downgraded record; recurring panics in ONE module earn an enriched claim naming it (recency belongs in the claim text, not new signal ids).
3. Corroborate `jx-uncommitted-work`/`jx-unsafe-touched` with `git diff HEAD --numstat` and `git ls-files --others --exclude-standard` — read-only forms only, never `git add`, `stash`, `fetch`, or anything mutating.
4. gh claims run under `timeout 30 gh …` read-only (`pr list`, `run list`, `issue list` with `--json`); a timeout, missing gh, or non-GitHub remote leaves those signals `unknown`.
5. A non-git target: every git-derived signal is `unknown` with detail "not a git repository" — confirm the script said so and add nothing else.
6. Remember the weighing: git beats cass for "what actually changed"; a session's claim of completion with no commit is an attempt — feed that corroboration to juncture-cass-local.

## Output shape
`{WORKSPACE}/evidence/juncture-git.json` — JSON array of evidence records (`references/schemas/evidence.schema.json`), `kind: "juncture"`, `source_type` git/gh, ids strictly inside the assigned `ev-j` range, zero-padded.

## Termination rule
Done when every owned signal has a verified, corrected, or `unknown` record and the fragment validates. Budget overruns end as `unknown` records, never retries.

## Do not
- Write into the target; run any mutating git/gh command (no fetch, no checkout, no comment, no label).
- Step outside the window or unpin the clock — determinism dies with it.
- Treat gh absence/timeout as an empty backlog (invariant 4).
- Emit ids outside the assigned range; delete script records; judge beads, cass, or smell signals.

## Composes with
orchestrator (range, merge), juncture-cass-local (git corroboration for already-done states), juncture-beads (shared window), scorer (J weights), evidence-auditor Pass B (git log forms are its safest replays).
