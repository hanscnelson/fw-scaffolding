#!/usr/bin/env python3
"""Unit tests for scripts/score-recommendations.py (stdlib unittest, no fixtures needed).

Covers, against the REAL scoring constants (references/data/scoring-constants.json):
  1. score arithmetic for a hand-computed row
  2. the RUN NOW gate: J/E minimums, the both-kinds anchor rule, and the
     baseline-hygiene two-profile-anchor route
  3. suppression gates capping an otherwise RUN NOW row at KEEP HANDY
  4. portfolio: alternative_to overlap, the one-expensive-campaign budget,
     and capacity spill into run_soon
  5. determinism: byte-identical output for identical inputs
  6. provisional mappings capping E at 2
  7. domain gates: unknown -> applicable (gate-unknown), absent -> not_applicable

Run from any cwd: python3 tests/test_scoring.py
"""
from __future__ import annotations

import importlib.util
import json
import os
import tempfile
import unittest
from pathlib import Path

PKG = Path(__file__).resolve().parent.parent
SCRIPTS = PKG / "scripts"
CONSTANTS_PATH = PKG / "references" / "data" / "scoring-constants.json"


def _load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


score_mod = _load("score_recommendations", SCRIPTS / "score-recommendations.py")
CONSTS = json.loads(CONSTANTS_PATH.read_text(encoding="utf-8"))
NOW = "2026-08-15T12:00:00Z"

# Synthetic signal universe: four profile / four juncture signals, one hygiene-gap
# signal, one gate signal. Every test builds its map from these.
SIGNALS = {}
for i in (1, 2, 3, 4):
    SIGNALS[f"p{i}"] = {"kind": "profile", "description": f"profile signal {i}", "detector": "test"}
    SIGNALS[f"j{i}"] = {"kind": "juncture", "description": f"juncture signal {i}", "detector": "test"}
SIGNALS["hyg1"] = {"kind": "profile", "description": "hygiene gap", "detector": "test"}
SIGNALS["g1"] = {"kind": "profile", "description": "gate signal", "detector": "test"}


def entry(**kw):
    e = {
        "domain_gate": [], "positive_signals": [], "anti_signals": [], "prerequisites": [],
        "pairs": [], "kickoff_phrasing": "Run it.", "baseline_hygiene": None,
        "cost": 1, "risk": 1, "accretive_base": 1,
        "expected_artifact": "an artifact", "stop_condition": "a stop condition", "notes": "",
    }
    e.update(kw)
    return e


def cat(name, provisional=False, installed=False, alternative_to=None):
    return {
        "canonical_name": name, "catalog_sources": ["snapshot"], "installed": installed,
        "resolved_path": None, "description": "test entry", "use_when": None, "tags": [],
        "category": None, "packs": [],
        "related": {"pairs_with": [], "alternative_to": alternative_to or [], "extends": [], "prerequisite": []},
        "detect_rules": [], "provisional_mapping": provisional, "updated_at": None,
    }


_ev_n = 0


def ev(kind, state, signals, conf, source_type="file", locator=None):
    global _ev_n
    _ev_n += 1
    return {
        "id": f"ev-t{_ev_n:04d}", "claim": f"test evidence {_ev_n}", "kind": kind,
        "polarity": "negative" if state == "absent-with-positive-evidence" else "positive",
        "state": state, "source_type": source_type,
        "locator": locator, "observed_at": NOW, "command": "test", "repo_head": None,
        "origin_host": None, "confidence": conf, "signals": signals, "detail": None,
    }


def activation_document(evidence, overrides=None):
    smap = {"signals": SIGNALS}
    merged = score_mod.merged_signals(smap, overrides or {})
    actual = score_mod.activate(evidence, merged)
    document = {"signals": {}}
    for signal in sorted(merged):
        slot = actual[signal]
        supporting = slot["present"] if slot["state"] == "present" else (
            slot["absent"] if slot["state"] == "absent-with-positive-evidence" else []
        )
        document["signals"][signal] = {
            "state": slot["state"], "evidence_ids": sorted(row["id"] for row in supporting),
        }
    return document


def run_score(map_skills, catalog, evidence, already=None, overrides=None, recipes=None,
              activations=None, recipe_candidates=None, gaps=None, previous_run=None,
              retired=None,
              tmp=None, out_name="run.json", omit_phase_five=False):
    tmpdir = Path(tmp)
    smap = {"generator_version": "1.0.0", "signals": SIGNALS, "skills": map_skills}
    recipes = {"generator_version": "2.0.0", "recipes": recipes or []}
    overrides = overrides or {}
    gaps = gaps or []
    merged_signals = score_mod.merged_signals(smap, overrides)
    actual = score_mod.activate(evidence, merged_signals)
    if activations is None:
        activations = activation_document(evidence, overrides)
    if recipe_candidates is None:
        candidates = []
        for recipe in recipes["recipes"]:
            ids = sorted({row["id"] for trigger in recipe.get("triggers", [])
                          for row in actual.get(trigger, {}).get("present", [])})
            if ids:
                candidates.append({"recipe_id": recipe["id"], "evidence_ids": ids})
        recipe_candidates = {"recipes": candidates}
    cfg = {
        "run_id": "abcdef012345", "generated_at": NOW,
        "target": {"path": "/target", "scope": ["."], "is_git": True,
                   "is_ephemeral_clone": False, "is_public_repo": None,
                   "head_sha": "0" * 40, "branch": "main"},
        "fingerprint": {"profile_reused": False, "reason": "no_profile",
                        "commits_since_profile": None, "bead_issue_records_since_profile": None,
                        "changed_file_ratio": None, "worktree_digest": None},
        "sources": {"profile": "ok"},
        "catalog_drift": {"new": [], "renamed": [], "retired": retired or [],
                          "provisional": []},
    }
    catalog_document = {"skills": catalog}
    if retired:
        catalog_document.update({
            "drift": {"new": [], "changed": [], "retired": retired},
            "drift_known": True, "retirement_known": True,
        })
    paths = {}
    for name, obj in [("map", smap), ("recipes", recipes), ("evidence", evidence),
                      ("catalog", catalog_document), ("already", already or {}),
                      ("cfg", cfg), ("gaps", gaps), ("overrides", overrides),
                      ("activations", activations), ("recipe_candidates", recipe_candidates),
                      ("previous", previous_run)]:
        p = tmpdir / f"{name}.json"
        if obj is not None:
            p.write_text(json.dumps(obj, indent=1) + "\n", encoding="utf-8")
        paths[name] = p
    out = tmpdir / out_name
    argv = ["--evidence", str(paths["evidence"]), "--catalog", str(paths["catalog"]),
            "--already-done", str(paths["already"]), "--run-config", str(paths["cfg"]),
            "--map", str(paths["map"]), "--recipes", str(paths["recipes"]),
            "--constants", str(CONSTANTS_PATH), "--out", str(out)]
    if not omit_phase_five:
        argv += ["--gaps", str(paths["gaps"]), "--overrides", str(paths["overrides"]),
                 "--activations", str(paths["activations"]),
                 "--recipe-candidates", str(paths["recipe_candidates"])]
    if previous_run is not None:
        argv += ["--previous-run", str(paths["previous"])]
    rc = score_mod.main(argv)
    if rc != 0:
        raise AssertionError(f"score-recommendations.py exited {rc}")
    return json.loads(out.read_text(encoding="utf-8"))


def row(run, name):
    return next(r for r in run["ledger"] if r["canonical_name"] == name)


class ScoringTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory(prefix="skillsel-scoring-")
        self.tmp = self._tmp.name

    def tearDown(self):
        if os.environ.get("SKILL_SELECTION_KEEP_TEMP", "1") != "0":
            self._tmp._finalizer.detach()
            print(f"kept scoring scratch root {self.tmp}")
        else:
            self._tmp.cleanup()

    # ---- 1. arithmetic --------------------------------------------------
    def test_score_arithmetic_matches_constants(self):
        skills = {"alpha": entry(positive_signals=[{"signal": "p1", "weight": 2},
                                                   {"signal": "j1", "weight": 3}],
                                 cost=1, risk=2)}
        evidence = [ev("profile", "present", ["p1"], 3, "file", "src/a.rs@sha:1"),
                    ev("juncture", "present", ["j1"], 3, "git", "abc123def")]
        run = run_score(skills, [cat("alpha")], evidence, tmp=self.tmp)
        s = row(run, "alpha")["scores"]
        # Hand-computed: J=3 (weight of the firing juncture signal), A=base 1 + best
        # firing profile weight 2 = 3, E=max confidence 3 (two source types, no
        # single-source penalty), C=1, R=2, D=0 (not_seen).
        self.assertEqual({k: s[k] for k in "JAECRD"}, {"J": 3, "A": 3, "E": 3, "C": 1, "R": 2, "D": 0})
        w = CONSTS["weights"]
        expect = w["J"] * 3 + w["A"] * 3 + w["E"] * 3 + w["C"] * 1 + w["R"] * 2 + w["D"] * 0
        self.assertEqual(s["total"], expect)
        self.assertEqual(s["total"], 30)
        self.assertEqual(row(run, "alpha")["disposition"], "run_now")

    # ---- 2. run-now gate ------------------------------------------------
    def test_run_now_requires_both_anchor_kinds(self):
        # High score, J/E clear the bar, but every anchor is juncture: not RUN NOW.
        skills = {"beta": entry(positive_signals=[{"signal": "j1", "weight": 4}],
                                accretive_base=4, cost=0, risk=0)}
        evidence = [ev("juncture", "present", ["j1"], 4, "git", "sha-one"),
                    ev("juncture", "present", ["j1"], 4, "git", "sha-two")]
        run = run_score(skills, [cat("beta")], evidence, tmp=self.tmp)
        r = row(run, "beta")
        self.assertGreaterEqual(r["scores"]["total"], CONSTS["tiers"]["run_now"]["min_score"])
        self.assertEqual(r["disposition"], "run_soon")
        self.assertEqual(r["tier_reason"], "run_soon_rule")
        self.assertNotIn("beta", run["tiers"]["run_now"])

    def test_run_now_j_minimum(self):
        # J=2 with everything else maxed: fails min_J=3, lands run_soon.
        skills = {"gamma": entry(positive_signals=[{"signal": "j1", "weight": 2},
                                                   {"signal": "p1", "weight": 4}],
                                 cost=0, risk=0)}
        evidence = [ev("juncture", "present", ["j1"], 4, "git", "sha-g"),
                    ev("profile", "present", ["p1"], 4, "file", "src/g.rs@sha:1")]
        run = run_score(skills, [cat("gamma")], evidence, tmp=self.tmp)
        r = row(run, "gamma")
        self.assertEqual(r["scores"]["J"], 2)
        self.assertGreaterEqual(r["scores"]["total"], CONSTS["tiers"]["run_now"]["min_score"])
        self.assertEqual(r["disposition"], "run_soon")

    def test_hygiene_route_needs_two_profile_anchors(self):
        hyg = entry(positive_signals=[{"signal": "hyg1", "weight": 4}],
                    baseline_hygiene={"gap_signal": "hyg1", "gap_when": "present", "severity": 4})
        evidence = [
            # two distinct profile anchors -> hygiene route satisfied
            ev("profile", "present", ["hyg1"], 4, "file", "README.md@sha"),
            ev("profile", "present", ["hyg1"], 4, "file", "CHANGELOG.md@sha"),
        ]
        run = run_score({"hygtwo": hyg}, [cat("hygtwo")], evidence, tmp=self.tmp)
        r2 = row(run, "hygtwo")
        self.assertEqual(r2["scores"]["J"], 4)  # hygiene severity supplies J without juncture evidence
        self.assertEqual(r2["disposition"], "run_now")
        self.assertEqual(r2["anchors"]["juncture"], [])

        # Same skill shape, ONE profile anchor: hygiene route fails -> run_soon.
        evidence_one = [ev("profile", "present", ["hyg1"], 4, "file", "README.md@sha")]
        run1 = run_score({"hygone": json.loads(json.dumps(hyg))}, [cat("hygone")],
                         evidence_one, tmp=self.tmp, out_name="run-hygone.json")
        r1 = row(run1, "hygone")
        self.assertGreaterEqual(r1["scores"]["total"], CONSTS["tiers"]["run_now"]["min_score"])
        self.assertEqual(r1["disposition"], "run_soon")

    def test_hygiene_skill_with_juncture_anchor_uses_normal_route(self):
        # A baseline-hygiene skill that ALSO has a juncture anchor must qualify via the
        # normal RUN NOW route (>= 1 profile AND >= 1 juncture anchor). It must never be
        # demoted just because the stricter two-PROFILE-anchor hygiene rule is unmet:
        # hygiene is "the only route WITHOUT a juncture anchor", not a replacement.
        hyg = entry(positive_signals=[{"signal": "hyg1", "weight": 4},
                                      {"signal": "j1", "weight": 4}],
                    baseline_hygiene={"gap_signal": "hyg1", "gap_when": "present", "severity": 4})
        evidence = [
            ev("profile", "present", ["hyg1"], 4, "file", "README.md@sha"),   # 1 profile anchor
            ev("juncture", "present", ["j1"], 4, "git", "sha-hzn"),           # 1 juncture anchor
        ]
        run = run_score({"hzn": hyg}, [cat("hzn")], evidence, tmp=self.tmp, out_name="run-hzn.json")
        r = row(run, "hzn")
        self.assertGreaterEqual(r["scores"]["total"], CONSTS["tiers"]["run_now"]["min_score"])
        self.assertEqual(len(r["anchors"]["profile"]), 1)
        self.assertEqual(len(r["anchors"]["juncture"]), 1)
        self.assertEqual(r["disposition"], "run_now")  # normal route, NOT demoted by hygiene rule

    # ---- 3. suppression gates -------------------------------------------
    def test_completed_recently_caps_at_keep_handy(self):
        delta = entry(positive_signals=[{"signal": "p1", "weight": 4},
                                        {"signal": "j1", "weight": 4}])
        evidence = [ev("profile", "present", ["p1"], 4, "file", "src/d.rs@sha:1"),
                    ev("juncture", "present", ["j1"], 4, "git", "sha-d")]
        # completed 10 days before generated_at: inside the 30-day window
        already = {"delta": {"state": "completed_successfully", "since": "2026-08-05T12:00:00Z",
                             "condition": None, "condition_holds": None, "evidence_ids": [],
                             "suggested_by": None}}
        run = run_score({"delta": delta}, [cat("delta")], evidence, already=already, tmp=self.tmp)
        r = row(run, "delta")
        self.assertEqual(r["scores"]["D"], CONSTS["already_done_D"]["completed_successfully_in_window"])
        self.assertEqual(r["suppression_gate"], "completed_recently")
        self.assertEqual(r["disposition"], "keep_handy")
        self.assertEqual(r["tier_reason"], "suppressed:completed_recently")
        self.assertEqual(run["tiers"]["run_now"], [])

        # Control: the same completion outside the window does not suppress.
        already_old = {"delta": dict(already["delta"], since="2026-07-01T12:00:00Z")}
        run2 = run_score({"delta": json.loads(json.dumps(delta))}, [cat("delta")], evidence,
                         already=already_old, tmp=self.tmp, out_name="run-old.json")
        r2 = row(run2, "delta")
        self.assertIsNone(r2["suppression_gate"])
        self.assertEqual(r2["scores"]["D"], CONSTS["already_done_D"]["completed_successfully_after_window"])
        self.assertEqual(r2["disposition"], "run_now")

    # ---- 4. portfolio ---------------------------------------------------
    def _eligible(self, psig, jsig, **kw):
        return entry(positive_signals=[{"signal": psig, "weight": 4},
                                       {"signal": jsig, "weight": 4}], **kw)

    def _pair_evidence(self, pairs):
        out = []
        for psig, jsig in pairs:
            out.append(ev("profile", "present", [psig], 4, "file", f"src/{psig}.rs@sha:1"))
            out.append(ev("juncture", "present", [jsig], 4, "git", f"sha-{jsig}"))
        return out

    def test_portfolio_overlap_via_alternative_to(self):
        skills = {"a1": self._eligible("p1", "j1", cost=0),
                  "a2": self._eligible("p2", "j2", cost=1)}
        catalog = [cat("a1"), cat("a2", alternative_to=["a1"])]
        run = run_score(skills, catalog, self._pair_evidence([("p1", "j1"), ("p2", "j2")]), tmp=self.tmp)
        self.assertEqual([c["anchor"] for c in run["campaigns"]], ["a1"])
        r = row(run, "a2")
        self.assertEqual(r["disposition"], "run_soon")
        self.assertEqual(r["tier_reason"], "portfolio_overlap")
        self.assertIn("clashes with camp-01", r["reason"])

    def test_portfolio_budget_one_expensive_campaign(self):
        # b2 wins the first slot. b1's own C=4 looks cheap under the old max-member
        # rule, but its unsatisfied helper prerequisite contributes another C=4, so
        # aggregate effort 8 exceeds the later-campaign budget of 6.
        skills = {"b1": self._eligible("p1", "j1", cost=4, risk=0,
                                       prerequisites=[{"skill": "helper", "satisfied_by_signals": []}]),
                  "b2": self._eligible("p2", "j2", cost=3, risk=0),
                  "helper": entry(cost=4, risk=0)}
        run = run_score(skills, [cat("b1"), cat("b2"), cat("helper")],
                        self._pair_evidence([("p1", "j1"), ("p2", "j2")]), tmp=self.tmp)
        self.assertEqual([c["anchor"] for c in run["campaigns"]], ["b2"])
        self.assertLessEqual(run["campaigns"][0]["effort"], CONSTS["portfolio"]["first_campaign_max_effort"])
        r = row(run, "b1")
        self.assertEqual(r["disposition"], "run_soon")
        self.assertEqual(r["tier_reason"], "portfolio_budget")

    def test_portfolio_capacity_caps_at_three_campaigns(self):
        pairs = [("p1", "j1"), ("p2", "j2"), ("p3", "j3"), ("p4", "j4")]
        skills = {}
        for i, (p, j) in enumerate(pairs, start=1):
            # descending totals via rising risk: c1 sorts first, c4 last
            skills[f"c{i}"] = self._eligible(p, j, cost=1, risk=i - 1)
        run = run_score(skills, [cat(f"c{i}") for i in range(1, 5)],
                        self._pair_evidence(pairs), tmp=self.tmp)
        self.assertEqual(len(run["campaigns"]), CONSTS["portfolio"]["max_campaigns"])
        self.assertEqual([c["anchor"] for c in run["campaigns"]], ["c1", "c2", "c3"])
        r = row(run, "c4")
        self.assertEqual(r["disposition"], "run_soon")
        self.assertEqual(r["tier_reason"], "portfolio_capacity")

    # ---- 5. determinism -------------------------------------------------
    def test_byte_identical_reruns(self):
        skills = {"alpha": entry(positive_signals=[{"signal": "p1", "weight": 2},
                                                   {"signal": "j1", "weight": 3}])}
        evidence = [ev("profile", "present", ["p1"], 3, "file", "src/a.rs@sha:1"),
                    ev("juncture", "present", ["j1"], 3, "git", "abc123def")]
        run_score(skills, [cat("alpha")], evidence, tmp=self.tmp, out_name="one.json")
        run_score(skills, [cat("alpha")], evidence, tmp=self.tmp, out_name="two.json")
        one = (Path(self.tmp) / "one.json").read_bytes()
        two = (Path(self.tmp) / "two.json").read_bytes()
        self.assertEqual(one, two)
        self.assertGreater(len(one), 100)

    # ---- 6. provisional mapping caps E ----------------------------------
    def test_provisional_mapping_caps_E_at_2(self):
        evidence = [ev("profile", "present", ["p1"], 4, "file", "src/z.rs@sha:1"),
                    ev("profile", "present", ["p1"], 4, "tool-output", "probe-2")]
        override = entry(positive_signals=[{"signal": "p1", "weight": 3}])
        override.update({"reason": "catalog skill absent from the canonical map",
                         "evidence_ids": [evidence[0]["id"]]})
        overrides = {"provisional_mappings": {"zz-test-provisional": override}}
        run = run_score({}, [cat("zz-test-provisional", provisional=True)], evidence,
                        overrides=overrides, tmp=self.tmp)
        r = row(run, "zz-test-provisional")
        self.assertTrue(r["provisional_mapping"])
        self.assertEqual(r["scores"]["E"], CONSTS["evidence_quality"]["provisional_mapping_cap"])
        self.assertEqual(len(run["ledger"]), 1)  # never silently dropped

    # ---- 7. domain gates ------------------------------------------------
    def test_gate_unknown_is_applicable_gate_absent_is_not(self):
        gated = entry(domain_gate=["g1"])
        # Case A: no evidence at all about g1 -> unknown -> applicable.
        run_a = run_score({"gated": gated}, [cat("gated")], [], tmp=self.tmp, out_name="ga.json")
        ra = row(run_a, "gated")
        self.assertTrue(ra["applicability"])
        self.assertEqual(ra["applicability_basis"], "gate-unknown")
        self.assertEqual(ra["disposition"], "considered_not_now")
        self.assertEqual(ra["tier_reason"], "gate_unknown")
        # Case B: positive absence evidence -> not applicable.
        run_b = run_score({"gated": json.loads(json.dumps(gated))}, [cat("gated")],
                          [ev("profile", "absent-with-positive-evidence", ["g1"], 4, "file")],
                          tmp=self.tmp, out_name="gb.json")
        rb = row(run_b, "gated")
        self.assertFalse(rb["applicability"])
        self.assertEqual(rb["applicability_basis"], "gate-absent")
        self.assertEqual(rb["disposition"], "not_applicable")

    # ---- 8. campaign recipes are evidence-gated and sequence-honest -----
    def _recipe(self, trigger="j1", runner=None):
        recipe = {
            "id": "test-recipe", "title": "Test recipe", "anchor": "alpha",
            "sequence": [{"skill": "alpha", "role": "anchor"},
                         {"skill": "beta", "role": "pair"}],
            "kickoff_prompt": "STATIC RECIPE PROMPT", "expected_artifact": "artifact",
            "stop_condition": "stop", "triggers": [trigger],
        }
        if runner:
            recipe["runner_up"] = {"candidate": runner, "why_it_lost": "test runner"}
        return recipe

    def test_recipe_requires_a_present_trigger(self):
        skills = {"alpha": self._eligible("p1", "j1", cost=1), "beta": entry(cost=1)}
        evidence = self._pair_evidence([("p1", "j1")])
        run = run_score(skills, [cat("alpha"), cat("beta")], evidence,
                        recipes=[self._recipe(trigger="j2")], tmp=self.tmp)
        self.assertIsNone(run["campaigns"][0]["recipe_id"])
        self.assertEqual([m["skill"] for m in run["campaigns"][0]["sequence"]], ["alpha"])

    def test_member_prerequisite_is_inserted_and_static_prompt_is_dropped(self):
        skills = {
            "alpha": self._eligible("p1", "j1", cost=1),
            "beta": entry(cost=1, prerequisites=[{"skill": "pre", "satisfied_by_signals": []}]),
            "pre": entry(cost=1, kickoff_phrasing="Prepare first."),
        }
        evidence = self._pair_evidence([("p1", "j1")])
        run = run_score(skills, [cat("alpha"), cat("beta"), cat("pre")], evidence,
                        recipes=[self._recipe()], tmp=self.tmp)
        campaign = run["campaigns"][0]
        self.assertEqual([m["skill"] for m in campaign["sequence"]], ["alpha", "pre", "beta"])
        self.assertNotEqual(campaign["kickoff_prompt"], "STATIC RECIPE PROMPT")
        self.assertIn("Prepare first.", campaign["kickoff_prompt"])
        self.assertEqual(campaign["effort"], 3)

    def test_dropped_pair_is_not_named_by_prompt_or_runner_up(self):
        skills = {"alpha": self._eligible("p1", "j1", cost=1),
                  "beta": entry(cost=1, domain_gate=["g1"])}
        evidence = self._pair_evidence([("p1", "j1")]) + [
            ev("profile", "absent-with-positive-evidence", ["g1"], 4, "file")
        ]
        run = run_score(skills, [cat("alpha"), cat("beta")], evidence,
                        recipes=[self._recipe(runner="alpha")], tmp=self.tmp)
        campaign = run["campaigns"][0]
        self.assertEqual([m["skill"] for m in campaign["sequence"]], ["alpha"])
        self.assertNotEqual(campaign["kickoff_prompt"], "STATIC RECIPE PROMPT")
        self.assertEqual(campaign["runners_up"], [])

    def test_recipe_candidates_and_activation_outputs_are_enforced(self):
        skills = {"alpha": self._eligible("p1", "j1", cost=1), "beta": entry(cost=1)}
        evidence = self._pair_evidence([("p1", "j1")])
        run = run_score(skills, [cat("alpha"), cat("beta")], evidence,
                        recipes=[self._recipe()], recipe_candidates={"recipes": []},
                        tmp=self.tmp)
        self.assertIsNone(run["campaigns"][0]["recipe_id"])
        bad_activations = activation_document(evidence)
        bad_activations["signals"]["j1"] = {"state": "unknown", "evidence_ids": []}
        with self.assertRaisesRegex(ValueError, "activation disagreement"):
            run_score(skills, [cat("alpha"), cat("beta")], evidence,
                      recipes=[self._recipe()], activations=bad_activations,
                      tmp=self.tmp, out_name="bad-activation.json")

    def test_phase_five_artifacts_are_mandatory_and_evidence_bound(self):
        evidence = [ev("profile", "present", ["p1"], 4, "file", "src/p.rs:1")]
        with self.assertRaises(SystemExit):
            run_score({"alpha": entry()}, [cat("alpha")], evidence, tmp=self.tmp,
                      out_name="missing-phase-five.json", omit_phase_five=True)

        incomplete = {"signals": {
            "p1": {"state": "present", "evidence_ids": []},
        }}
        with self.assertRaisesRegex(ValueError, "activation (coverage|evidence)"):
            run_score({"alpha": entry()}, [cat("alpha")], evidence,
                      activations=incomplete, tmp=self.tmp,
                      out_name="incomplete-activations.json")

        bad_gap = [{
            "id": "gap-01", "description": "uncovered capability",
            "signals": ["j1"], "evidence_ids": [evidence[0]["id"]],
            "catalog_query": "uncovered capability", "names_existing_skill": None,
            "proposed_request_title": None,
        }]
        with self.assertRaisesRegex(ValueError, "gap gap-01.*evidence"):
            run_score({"alpha": entry()}, [cat("alpha")], evidence, gaps=bad_gap,
                      tmp=self.tmp, out_name="bad-gap.json")

        bad_override = {"signals": {"p-new": {
            "kind": "profile", "detector": "manual", "description": "new signal",
            "reason": "manual match", "evidence_ids": [evidence[0]["id"]],
        }}}
        with self.assertRaisesRegex(ValueError, "override signals.p-new.*support"):
            run_score({"alpha": entry()}, [cat("alpha")], evidence,
                      overrides=bad_override, tmp=self.tmp, out_name="bad-override.json")

        with self.assertRaisesRegex(ValueError, "unknown recipe"):
            run_score({"alpha": entry()}, [cat("alpha")], evidence,
                      recipe_candidates={"recipes": [{
                          "recipe_id": "does-not-exist", "evidence_ids": [evidence[0]["id"]],
                      }]}, tmp=self.tmp, out_name="bad-recipe.json")

        bad_provisional = entry(positive_signals=[
            {"signal": "p1", "weight": 3}, {"signal": "j1", "weight": 3},
        ])
        bad_provisional.update({
            "reason": "partial support is insufficient", "evidence_ids": [evidence[0]["id"]],
        })
        with self.assertRaisesRegex(ValueError, "provisional_mappings.*j1"):
            run_score({}, [cat("provisional", provisional=True)], evidence,
                      overrides={"provisional_mappings": {"provisional": bad_provisional}},
                      tmp=self.tmp, out_name="bad-provisional.json")

    def test_fingerprint_binds_every_decision_input(self):
        run = run_score({"alpha": entry()}, [cat("alpha")], [], tmp=self.tmp)
        required = {
            "evidence_sha256", "catalog_sha256", "signal_map_sha256", "recipes_sha256",
            "constants_sha256", "already_done_sha256", "run_config_sha256", "gaps_sha256",
            "overrides_sha256", "activations_sha256", "recipe_candidates_sha256",
            "previous_run_sha256",
        }
        self.assertTrue(required <= set(run["inputs"]))
        self.assertTrue(all(run["inputs"][key].startswith("sha256:")
                            for key in required - {"previous_run_sha256"}))
        self.assertIsNone(run["inputs"]["previous_run_sha256"])

    def test_retired_catalog_entry_is_never_recommended(self):
        skills = {"alpha": self._eligible("p1", "j1", cost=0, risk=0)}
        evidence = self._pair_evidence([("p1", "j1")])
        run = run_score(skills, [cat("alpha")], evidence, retired=["alpha"], tmp=self.tmp)
        retired_row = row(run, "alpha")
        self.assertFalse(retired_row["applicability"])
        self.assertEqual(retired_row["applicability_basis"], "catalog-retired")
        self.assertEqual(retired_row["disposition"], "not_applicable")
        self.assertEqual(run["campaigns"], [])
        with self.assertRaisesRegex(ValueError, "without a complete catalog source"):
            score_mod.validate_catalog_retirement(
                {"skills": [cat("alpha")], "retirement_known": False},
                {"catalog_drift": {"retired": ["alpha"]}},
            )

    def test_previous_run_soon_is_preserved_as_pending(self):
        skills = {"alpha": self._eligible("p1", "j1", cost=1)}
        previous = {"run_id": "111111111111", "tiers": {"run_now": [], "run_soon": ["alpha"]}}
        run = run_score(skills, [cat("alpha")], self._pair_evidence([("p1", "j1")]),
                        previous_run=previous, tmp=self.tmp)
        self.assertEqual(run["previous_run_crosscheck"]["still_pending"], ["alpha"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
