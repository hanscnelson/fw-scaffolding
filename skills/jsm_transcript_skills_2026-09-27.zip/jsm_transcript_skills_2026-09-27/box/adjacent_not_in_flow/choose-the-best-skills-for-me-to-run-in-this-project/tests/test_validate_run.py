#!/usr/bin/env python3
"""Unit tests for scripts/validate-run.py: a minimal VALID run (produced by the real
scorer over tiny inputs against the REAL signal map/constants/recipes) passes with
exit 0, and six deliberate corruptions each fail with exit 1 and the right violation
text:
  1. a dropped ledger row          4. a run_now row without a campaign
  2. a duplicated ledger row       5. a gap that names a catalog skill
  3. evidence_ids -> ghost id      6. tiers/ledger disagreement

Run from any cwd: python3 tests/test_validate_run.py
"""
from __future__ import annotations

import contextlib
import copy
import importlib.util
import io
import json
import os
import tempfile
import unittest
from pathlib import Path

PKG = Path(__file__).resolve().parent.parent
SCRIPTS = PKG / "scripts"


def _load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


score_mod = _load("score_recommendations", SCRIPTS / "score-recommendations.py")
validate_mod = _load("validate_run", SCRIPTS / "validate-run.py")

NOW = "2026-08-15T12:00:00Z"


def cat(name, provisional=False):
    return {
        "canonical_name": name, "catalog_sources": ["snapshot"], "installed": False,
        "resolved_path": None, "description": "test entry", "use_when": None, "tags": [],
        "category": None, "packs": [],
        "related": {"pairs_with": [], "alternative_to": [], "extends": [], "prerequisite": []},
        "detect_rules": [], "provisional_mapping": provisional, "updated_at": None,
    }


def rec(eid, kind, state, signals, conf, source_type, locator):
    return {
        "id": eid, "claim": f"evidence {eid}", "kind": kind,
        "polarity": "negative" if state == "absent-with-positive-evidence" else "positive",
        "state": state, "source_type": source_type, "locator": locator,
        "observed_at": NOW, "command": "test", "repo_head": None, "origin_host": None,
        "confidence": conf, "signals": signals, "detail": None,
    }


# Tiny inputs against the REAL map: code-parser + gap-parser-no-fuzz (profile) and
# jx-recurring-panics (juncture) make testing-fuzzing a RUN NOW anchor, and the real
# parser-hardening recipe pulls multi-pass-bug-hunting in as a campaign pair.
CATALOG = {"skills": [cat("testing-fuzzing"), cat("multi-pass-bug-hunting"),
                      cat("readme-writing"), cat("zz-provisional-only", provisional=True)]}
EVIDENCE = [
    rec("ev-p0001", "profile", "present", ["code-parser"], 3, "file", "src/parser.rs@abc1234:12"),
    rec("ev-p0002", "profile", "present", ["gap-parser-no-fuzz"], 3, "file", "src/parser.rs@abc1234:1"),
    rec("ev-j0001", "juncture", "present", ["jx-recurring-panics"], 3, "git", "abc1234"),
]
CFG = {
    "run_id": "abcdef012345", "generated_at": NOW,
    "target": {"path": "/target", "scope": ["."], "is_git": True, "is_ephemeral_clone": False,
               "is_public_repo": None, "head_sha": "0" * 40, "branch": "main"},
    "fingerprint": {"profile_reused": False, "reason": "no_profile", "commits_since_profile": None,
                    "bead_issue_records_since_profile": None, "changed_file_ratio": None,
                    "worktree_digest": None},
    "sources": {"profile": "ok"},
}


class ValidateRunTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls._tmp = tempfile.TemporaryDirectory(prefix="skillsel-validate-")
        tmp = Path(cls._tmp.name)
        cls.evidence_path = tmp / "evidence.json"
        cls.catalog_path = tmp / "catalog.json"
        cfg_path = tmp / "cfg.json"
        already_path = tmp / "already.json"
        gaps_path = tmp / "gaps.json"
        overrides_path = tmp / "overrides.json"
        activations_path = tmp / "activations.json"
        recipe_candidates_path = tmp / "recipe-candidates.json"
        run_path = tmp / "run.json"
        cls.evidence_path.write_text(json.dumps(EVIDENCE, indent=1) + "\n", encoding="utf-8")
        cls.catalog_path.write_text(json.dumps(CATALOG, indent=1) + "\n", encoding="utf-8")
        cfg_path.write_text(json.dumps(CFG, indent=1) + "\n", encoding="utf-8")
        already_path.write_text("{}\n", encoding="utf-8")
        gaps_path.write_text("[]\n", encoding="utf-8")
        overrides_path.write_text("{}\n", encoding="utf-8")
        real_map = json.loads((PKG / "references/data/signal-to-skill-map.json").read_text())
        real_recipes = json.loads((PKG / "references/data/combo-recipes.json").read_text())["recipes"]
        active = score_mod.activate(EVIDENCE, real_map["signals"])
        activations = {"signals": {}}
        for signal in sorted(real_map["signals"]):
            slot = active[signal]
            rows = slot["present"] if slot["state"] == "present" else (
                slot["absent"] if slot["state"] == "absent-with-positive-evidence" else []
            )
            activations["signals"][signal] = {
                "state": slot["state"], "evidence_ids": sorted(row["id"] for row in rows),
            }
        activations_path.write_text(json.dumps(activations, indent=1) + "\n", encoding="utf-8")
        candidates = []
        for recipe in real_recipes:
            ids = sorted({row["id"] for trigger in recipe.get("triggers", [])
                          for row in active.get(trigger, {}).get("present", [])})
            if ids:
                candidates.append({"recipe_id": recipe["id"], "evidence_ids": ids})
        recipe_candidates_path.write_text(json.dumps({"recipes": candidates}, indent=1) + "\n",
                                          encoding="utf-8")
        cls.already_path = already_path
        cls.cfg_path = cfg_path
        cls.gaps_path = gaps_path
        cls.overrides_path = overrides_path
        cls.activations_path = activations_path
        cls.recipe_candidates_path = recipe_candidates_path
        rc = score_mod.main(["--evidence", str(cls.evidence_path), "--catalog", str(cls.catalog_path),
                             "--already-done", str(already_path), "--run-config", str(cfg_path),
                             "--gaps", str(gaps_path), "--overrides", str(overrides_path),
                             "--activations", str(activations_path),
                             "--recipe-candidates", str(recipe_candidates_path),
                             "--out", str(run_path)])
        assert rc == 0, "scorer failed to produce the baseline run"
        cls.baseline = json.loads(run_path.read_text(encoding="utf-8"))
        cls.tmp = tmp

    @classmethod
    def tearDownClass(cls):
        if os.environ.get("SKILL_SELECTION_KEEP_TEMP", "1") != "0":
            cls._tmp._finalizer.detach()
            print(f"kept validator scratch root {cls.tmp}")
        else:
            cls._tmp.cleanup()

    def _validate(self, run_obj, tag, already_path=None, evidence_path=None):
        run_path = self.tmp / f"run-{tag}.json"
        run_path.write_text(json.dumps(run_obj, indent=1) + "\n", encoding="utf-8")
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = validate_mod.main(["--run", str(run_path), "--evidence", str(evidence_path or self.evidence_path),
                                    "--catalog", str(self.catalog_path),
                                    "--run-config", str(self.cfg_path),
                                    "--already-done", str(already_path or self.already_path),
                                    "--gaps", str(self.gaps_path),
                                    "--overrides", str(self.overrides_path),
                                    "--activations", str(self.activations_path),
                                    "--recipe-candidates", str(self.recipe_candidates_path)])
        return rc, buf.getvalue()

    # ---- the baseline run is valid --------------------------------------
    def test_valid_run_passes(self):
        rc, out = self._validate(self.baseline, "valid")
        self.assertEqual(rc, 0, out)
        self.assertIn("run valid", out)
        # sanity: the baseline really has the shape the corruptions below rely on
        tf = next(r for r in self.baseline["ledger"] if r["canonical_name"] == "testing-fuzzing")
        self.assertEqual(tf["disposition"], "run_now")
        self.assertIsNotNone(tf["campaign_id"])

    # ---- six corruptions, each caught -----------------------------------
    def test_dropped_ledger_row(self):
        bad = copy.deepcopy(self.baseline)
        bad["ledger"] = [r for r in bad["ledger"] if r["canonical_name"] != "readme-writing"]
        rc, out = self._validate(bad, "dropped")
        self.assertEqual(rc, 1)
        self.assertIn("ledger row count", out)
        self.assertIn("no ledger row", out)

    def test_duplicated_ledger_row(self):
        bad = copy.deepcopy(self.baseline)
        bad["ledger"].append(copy.deepcopy(bad["ledger"][0]))
        rc, out = self._validate(bad, "dup")
        self.assertEqual(rc, 1)
        self.assertIn("duplicate rows", out)

    def test_ghost_evidence_id(self):
        bad = copy.deepcopy(self.baseline)
        tf = next(r for r in bad["ledger"] if r["canonical_name"] == "testing-fuzzing")
        tf["evidence_ids"] = ["ev-p9999"]
        rc, out = self._validate(bad, "ghost")
        self.assertEqual(rc, 1)
        self.assertIn("ev-p9999 not in the evidence set", out)

    def test_superseded_evidence_id(self):
        corrected = copy.deepcopy(EVIDENCE)
        replacement = rec("ev-p0003", "profile", "present", ["code-parser"], 3,
                          "file", "src/parser.rs@abc1234:12")
        replacement["supersedes"] = ["ev-p0001"]
        evidence_path = self.tmp / "evidence-corrected.json"
        evidence_path.write_text(json.dumps(corrected + [replacement]) + "\n", encoding="utf-8")
        rc, out = self._validate(self.baseline, "superseded", evidence_path=evidence_path)
        self.assertEqual(rc, 1)
        self.assertIn("superseded evidence id ev-p0001", out)

    def test_run_now_without_campaign(self):
        bad = copy.deepcopy(self.baseline)
        tf = next(r for r in bad["ledger"] if r["canonical_name"] == "testing-fuzzing")
        tf["campaign_id"] = None
        rc, out = self._validate(bad, "nocamp")
        self.assertEqual(rc, 1)
        self.assertIn("run_now without a campaign", out)

    def test_gap_naming_catalog_skill(self):
        bad = copy.deepcopy(self.baseline)
        bad["gaps"] = [{"id": "gap-01",
                        "description": "a skill like readme-writing but for internal design docs",
                        "signals": [], "evidence_ids": [], "catalog_query": "internal design docs",
                        "names_existing_skill": None,
                        "proposed_request_title": None}]
        rc, out = self._validate(bad, "gap")
        self.assertEqual(rc, 1)
        self.assertIn("description mentions catalog skill readme-writing", out)

    def test_tier_ledger_disagreement(self):
        bad = copy.deepcopy(self.baseline)
        self.assertIn("readme-writing", bad["tiers"]["considered_not_now"])
        bad["tiers"]["considered_not_now"].remove("readme-writing")
        bad["tiers"]["keep_handy"].append("readme-writing")
        rc, out = self._validate(bad, "tiers")
        self.assertEqual(rc, 1)
        self.assertIn("tiers.keep_handy: readme-writing ledger disposition is considered_not_now", out)

    # ---- keep_handy is allowed to omit a promotion trigger --------------
    def test_keep_handy_null_promotion_trigger_is_valid(self):
        # Suppression creates a genuine keep_handy row with no promotion trigger.
        already = {"testing-fuzzing": {
            "state": "completed_successfully", "since": "2026-08-10T12:00:00Z",
            "condition": None, "condition_holds": None, "evidence_ids": [],
            "suggested_by": None,
        }}
        already_path = self.tmp / "already-suppressed.json"
        run_path = self.tmp / "run-suppressed.json"
        already_path.write_text(json.dumps(already) + "\n", encoding="utf-8")
        cfg_path = self.tmp / "cfg.json"
        rc = score_mod.main([
            "--evidence", str(self.evidence_path), "--catalog", str(self.catalog_path),
            "--already-done", str(already_path), "--run-config", str(cfg_path),
            "--gaps", str(self.gaps_path), "--overrides", str(self.overrides_path),
            "--activations", str(self.activations_path),
            "--recipe-candidates", str(self.recipe_candidates_path),
            "--out", str(run_path),
        ])
        self.assertEqual(rc, 0)
        run = json.loads(run_path.read_text(encoding="utf-8"))
        tf = next(r for r in run["ledger"] if r["canonical_name"] == "testing-fuzzing")
        self.assertEqual(tf["disposition"], "keep_handy")
        self.assertIsNone(tf["promotion_trigger"])
        rc, out = self._validate(run, "kh-null-promo", already_path)
        self.assertEqual(rc, 0, out)
        self.assertIn("run valid", out)


if __name__ == "__main__":
    unittest.main(verbosity=2)
