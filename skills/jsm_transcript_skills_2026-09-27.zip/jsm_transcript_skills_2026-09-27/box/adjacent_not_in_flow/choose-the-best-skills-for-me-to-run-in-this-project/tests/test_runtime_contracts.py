#!/usr/bin/env python3
"""Focused contracts for durable evidence, corrections, privacy, and history."""
from __future__ import annotations

import copy
import importlib.util
import json
import os
import re
import subprocess
import tempfile
import unittest
from pathlib import Path

PKG = Path(__file__).resolve().parent.parent
SCRIPTS = PKG / "scripts"
NOW = "2026-08-15T12:00:00Z"


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, SCRIPTS / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


common = load("runtime_common", "skillsel_common.py")
scorer = load("runtime_scorer", "score-recommendations.py")
prepare = load("runtime_prepare", "prepare-evidence.py")
renderer = load("runtime_renderer", "render-recommendations.py")


def evidence(eid, kind, state, signal, *, supersedes=None):
    return {
        "id": eid, "claim": f"claim {eid}", "kind": kind,
        "polarity": "negative" if state == scorer.ABSENT else "positive",
        "state": state, "source_type": "git" if kind == "juncture" else "file",
        "locator": "abc123" if state == scorer.PRESENT else None,
        "observed_at": NOW, "command": "test probe", "repo_head": None,
        "origin_host": None, "confidence": 4 if state != scorer.UNKNOWN else 0,
        "signals": [signal], "detail": "positive probe result",
        **({"supersedes": supersedes} if supersedes is not None else {}),
    }


def minimal_run(secret):
    private_path = "/" + "Users/private/project"
    row = {
        "canonical_name": secret, "catalog_sources": ["local"],
        "provisional_mapping": True, "applicability": True,
        "applicability_basis": "universal", "positive_signals": [],
        "anti_signals": [], "prerequisite_status": "none",
        "already_done_state": "not_seen", "suppression_gate": None,
        "scores": {"J": 0, "A": 1, "E": 0, "C": 1, "R": 1, "D": 0, "total": 0},
        "anchors": {"profile": [private_path + "/file.rs:1"], "juncture": []},
        "disposition": "considered_not_now", "tier_reason": "score_below_12",
        "campaign_id": None, "campaign_role": None, "promotion_trigger": None,
        "reason": f"No need for {secret} in {private_path}.", "evidence_ids": [],
    }
    return {
        "run_id": "abcdef012345", "generator_version": "2.0.0", "generated_at": NOW,
        "target": {"path": private_path, "scope": ["."], "is_git": True,
                   "is_ephemeral_clone": False, "is_public_repo": True,
                   "head_sha": "0" * 40, "branch": "main"},
        "fingerprint": {"profile_reused": False, "reason": "no_profile",
                        "commits_since_profile": None,
                        "bead_issue_records_since_profile": None,
                        "changed_file_ratio": None, "worktree_digest": None},
        "inputs": {
            "evidence_sha256": "sha256:" + "1" * 64,
            "catalog_sha256": "sha256:" + "2" * 64,
            "signal_map_sha256": "sha256:" + "3" * 64,
            "recipes_sha256": "sha256:" + "4" * 64,
            "constants_sha256": "sha256:" + "5" * 64,
            "already_done_sha256": "sha256:" + "6" * 64,
            "run_config_sha256": "sha256:" + "7" * 64,
            "gaps_sha256": "sha256:" + "8" * 64,
            "overrides_sha256": "sha256:" + "9" * 64,
            "recipe_candidates_sha256": "sha256:" + "a" * 64,
            "activations_sha256": "sha256:" + "b" * 64,
            "previous_run_sha256": None, "catalog_count": 1,
        }, "sources": {"cass": "unknown:secret-host"},
        "catalog_drift": {"new": [secret], "renamed": [], "retired": [], "provisional": [secret]},
        "campaigns": [],
        "tiers": {"run_now": [], "run_soon": [], "keep_handy": [],
                  "considered_not_now": [secret], "not_applicable": []},
        "ledger": [row], "gaps": [],
        "weak_signals": {"jsm_scan": {"host": "secret-host"}, "jsm_suggest": None},
        "previous_run_crosscheck": {"previous_run_id": None, "acted_on": [],
                                    "declined": [], "still_pending": []},
    }


class RuntimeContracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root = Path(tempfile.mkdtemp(prefix="skillsel-runtime-contracts-"))
        print(f"runtime contract scratch root retained at {cls.root}")

    def test_superseded_present_record_cannot_win(self):
        old = evidence("ev-p0001", "profile", scorer.PRESENT, "p1")
        correction = evidence("ev-p0002", "profile", scorer.ABSENT, "p1", supersedes=["ev-p0001"])
        act = scorer.activate([old, correction], {"p1": {"default_state": scorer.UNKNOWN}})
        self.assertEqual(act["p1"]["state"], scorer.ABSENT)
        self.assertEqual([row["id"] for row in act["p1"]["absent"]], ["ev-p0002"])

    def test_renderer_rejects_malformed_run_before_writing(self):
        malformed = minimal_run("public-skill")
        del malformed["ledger"]
        run_path = self.root / "malformed-render-run.json"
        out = self.root / "malformed-render-output.md"
        run_path.write_text(json.dumps(malformed) + "\n", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "valid recommendation run"):
            renderer.main(["--run", str(run_path), "--out", str(out)])
        self.assertFalse(out.exists())

    def test_invalid_supersession_is_rejected(self):
        row = evidence("ev-p0001", "profile", scorer.PRESENT, "p1", supersedes=["ev-p9999"])
        with self.assertRaisesRegex(ValueError, "missing id"):
            common.active_evidence([row])

    def test_supersession_must_be_a_semantic_correction(self):
        original = evidence("ev-p0001", "profile", scorer.PRESENT, "p1")
        wrong_kind = evidence("ev-j0002", "juncture", scorer.ABSENT, "p1",
                              supersedes=["ev-p0001"])
        with self.assertRaisesRegex(ValueError, "different kind"):
            common.active_evidence([original, wrong_kind])

        unrelated = evidence("ev-p0003", "profile", scorer.ABSENT, "p2",
                             supersedes=["ev-p0001"])
        with self.assertRaisesRegex(ValueError, "unrelated signals"):
            common.active_evidence([original, unrelated])

        older = evidence("ev-p0004", "profile", scorer.ABSENT, "p1",
                         supersedes=["ev-p0001"])
        older["observed_at"] = "2026-08-14T12:00:00Z"
        with self.assertRaisesRegex(ValueError, "older than"):
            common.active_evidence([original, older])

    def test_phase_five_provenance_cannot_cite_superseded_evidence(self):
        old = evidence("ev-p0001", "profile", scorer.PRESENT, "p1")
        correction = evidence("ev-p0002", "profile", scorer.ABSENT, "p1",
                              supersedes=["ev-p0001"])
        overrides = {"signals": {"p2": {
            "kind": "profile", "detector": "manual", "description": "corrected",
            "reason": "audited correction", "evidence_ids": ["ev-p0001"],
        }}}
        with self.assertRaisesRegex(ValueError, "missing or superseded"):
            scorer.validate_override_provenance(overrides, [old, correction])
        with self.assertRaisesRegex(ValueError, "missing or superseded"):
            scorer.allowed_recipe_ids({"recipes": [{
                "recipe_id": "test-recipe", "evidence_ids": ["ev-p0001"],
            }]}, [old, correction])

    def test_profile_evidence_round_trips_through_analysis(self):
        profile = evidence("ev-p0001", "profile", scorer.PRESENT, "p1")
        juncture = evidence("ev-j0001", "juncture", scorer.PRESENT, "j1")
        profile_path = self.root / "profile.json"
        current_path = self.root / "juncture.json"
        profile_path.write_text(json.dumps([profile, juncture]) + "\n", encoding="utf-8")
        current_path.write_text(json.dumps([juncture]) + "\n", encoding="utf-8")
        analysis = self.root / "analysis.md"
        analysis.write_text("""---
last_updated: 2020-01-01T00:00:00Z
profiled_at: 2020-01-01T00:00:00Z
profile_head_sha: null
profile_branch: null
profile_scope:
  - old-scope
profile_tracked_file_count: 0
profile_worktree_digest: sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
profile_manifest_digests: {}
profile_beads_watermark: null
profile_cass_watermark: 2020-01-01T00:00:00Z
juncture_refreshed_at: 2020-01-01T00:00:00Z
recommendations_generated_at: 2020-01-01T00:00:00Z
generator_version: 2.0.0
---
# Analysis
""", encoding="utf-8")
        run_path = self.root / "private-run.json"
        run_path.write_text(json.dumps(minimal_run("private-internal-skill")) + "\n", encoding="utf-8")
        stale_path = self.root / "staleness.json"
        stale_path.write_text(json.dumps({
            "profile_head_sha": "0" * 40, "profile_scope": ["crates/core", "crates/cli"],
            "current_head_sha": "1" * 40,
            "tracked_file_count": 42, "worktree_digest": "sha256:" + "b" * 64,
            "manifest_digests": {"crates/core/Cargo.toml": "sha256:" + "c" * 64},
            "beads_watermark": "2026-08-15T11:00:00Z/7",
        }) + "\n", encoding="utf-8")
        out = self.root / "recommendations.md"
        self.assertEqual(renderer.main([
            "--run", str(run_path), "--out", str(out), "--update-analysis-header", str(analysis),
            "--profiled", "--profile-evidence", str(profile_path), "--staleness", str(stale_path),
        ]), 0)
        header = common.parse_frontmatter(analysis.read_text(encoding="utf-8"))
        self.assertEqual(header["profile_head_sha"], "1" * 40)
        self.assertEqual(header["profile_branch"], "main")
        self.assertEqual(header["profile_scope"], ["crates/core", "crates/cli"])
        self.assertEqual(header["profile_tracked_file_count"], 42)
        self.assertEqual(header["profile_manifest_digests"], {
            "crates/core/Cargo.toml": "sha256:" + "c" * 64,
        })
        self.assertEqual(header["profile_cass_watermark"], None)
        analysis_text = analysis.read_text(encoding="utf-8")
        self.assertIn("claim ev-p0001", analysis_text)
        self.assertIn("claim ev-j0001", analysis_text)
        self.assertNotIn("<What the project IS", analysis_text)
        merged = prepare.prepare([str(current_path)], str(analysis), True)
        self.assertEqual([row["id"] for row in merged], ["ev-j0001", "ev-p0001"])

    def test_profiled_render_creates_the_analysis_document(self):
        analysis = self.root / "new-analysis.md"
        run_path = self.root / "new-analysis-run.json"
        evidence_path = self.root / "new-analysis-evidence.json"
        stale_path = self.root / "new-analysis-staleness.json"
        run_path.write_text(json.dumps(minimal_run("public-skill")) + "\n", encoding="utf-8")
        rows = [evidence("ev-p0100", "profile", scorer.PRESENT, "code-parser"),
                evidence("ev-j0100", "juncture", scorer.PRESENT, "jx-recurring-panics")]
        evidence_path.write_text(json.dumps(rows) + "\n", encoding="utf-8")
        stale_path.write_text(json.dumps({
            "current_head_sha": "2" * 40, "profile_scope": ["."],
            "tracked_file_count": 12, "worktree_digest": "sha256:" + "d" * 64,
            "manifest_digests": {"Cargo.toml": "sha256:" + "e" * 64},
            "beads_watermark": None,
        }) + "\n", encoding="utf-8")
        out = self.root / "new-analysis-recommendations.md"
        self.assertFalse(analysis.exists())
        self.assertEqual(renderer.main([
            "--run", str(run_path), "--out", str(out),
            "--update-analysis-header", str(analysis), "--profiled",
            "--profile-evidence", str(evidence_path), "--staleness", str(stale_path),
        ]), 0)
        text = analysis.read_text(encoding="utf-8")
        self.assertIn("# Comprehensive Analysis Of Project", text)
        self.assertIn("claim ev-p0100", text)
        self.assertIn("claim ev-j0100", text)
        self.assertIsNotNone(renderer.PROFILE_RE.search(text))

    def test_analysis_rejects_duplicate_evidence_ids_before_rendering(self):
        profile = evidence("ev-p0200", "profile", scorer.PRESENT, "p1")
        duplicate = copy.deepcopy(profile)
        duplicate["claim"] = "conflicting duplicate"
        with self.assertRaisesRegex(ValueError, "duplicate evidence id"):
            renderer.render_analysis_document(
                self.root / "duplicate-analysis.md", minimal_run("public-skill"), True,
                {"current_head_sha": "3" * 40, "profile_scope": ["."],
                 "tracked_file_count": 1, "worktree_digest": "sha256:" + "f" * 64,
                 "manifest_digests": {}, "beads_watermark": None},
                [profile, duplicate],
            )

    def test_public_render_is_redacted_and_idempotent(self):
        secret = "my-secret-local-skill"
        run_path = self.root / "public-source-run.json"
        out = self.root / "public-recommendations.md"
        analysis = self.root / "public-analysis.md"
        analysis.write_text("""---
last_updated: 2020-01-01T00:00:00Z
profiled_at: 2020-01-01T00:00:00Z
profile_head_sha: null
profile_branch: null
profile_scope: ["."]
profile_tracked_file_count: 0
profile_worktree_digest: sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
profile_manifest_digests: {}
profile_beads_watermark: null
profile_cass_watermark: null
juncture_refreshed_at: 2020-01-01T00:00:00Z
recommendations_generated_at: 2020-01-01T00:00:00Z
generator_version: 2.0.0
---
# Analysis
""", encoding="utf-8")
        private_path = "/private/var/build tree/project"
        private_host = "builder.private.lan"
        profile = evidence("ev-p0001", "profile", scorer.PRESENT, "p1")
        profile.update({
            "claim": f"Found source under {private_path}",
            "locator": f"{private_path}/src/lib.rs:9@{private_host}",
            "command": f"ssh {private_host} -- pwd",
            "origin_host": private_host,
            "detail": f"private marker --> from {private_host}",
        })
        profile_path = self.root / "public-profile.json"
        profile_path.write_text(json.dumps([profile]) + "\n", encoding="utf-8")
        stale_path = self.root / "public-staleness.json"
        stale_path.write_text(json.dumps({
            "current_head_sha": "0" * 40, "profile_scope": ["."],
            "tracked_file_count": 1, "worktree_digest": "sha256:" + "a" * 64,
            "manifest_digests": {}, "beads_watermark": None,
        }) + "\n", encoding="utf-8")
        run = minimal_run(secret)
        run["gaps"] = [{
            "id": "gap-01", "description": f"Inspect {private_path} on {private_host} --> exposed",
            "signals": ["p1"], "evidence_ids": ["ev-p0001"],
            "catalog_query": "missing private capability", "names_existing_skill": None,
            "proposed_request_title": None,
        }]
        run_path.write_text(json.dumps(run) + "\n", encoding="utf-8")
        for _ in range(2):
            self.assertEqual(renderer.main([
                "--run", str(run_path), "--out", str(out), "--public",
                "--update-analysis-header", str(analysis), "--profiled",
                "--profile-evidence", str(profile_path), "--staleness", str(stale_path),
            ]), 0)
        text = out.read_text(encoding="utf-8")
        analysis_text = analysis.read_text(encoding="utf-8")
        for private_value in (secret, "/" + "Users/private", "secret-host", private_path, private_host):
            self.assertNotIn(private_value, text)
            self.assertNotIn(private_value, analysis_text)
        self.assertRegex(text, r"private-skill-[0-9a-f]{12}")
        history = json.loads(renderer.HIST_RE.search(text).group(1))
        self.assertEqual(len(history["runs"]), 1)
        for tag in ("last-run",):
            match = re.search(rf"<!-- skill-selection:{tag}:v1\n(.*?)\n-->", text, re.DOTALL)
            self.assertIsNotNone(match)
            json.loads(match.group(1))
        profile_match = renderer.PROFILE_RE.search(analysis_text)
        self.assertIsNotNone(profile_match)
        public_profile = json.loads(profile_match.group(1))
        self.assertEqual(public_profile[0]["origin_host"], None)
        self.assertTrue(public_profile[0]["locator"].startswith("redacted:"))
        self.assertEqual(json.loads(profile_path.read_text(encoding="utf-8")), [profile],
                         "public rendering mutated its private source evidence")

    def test_public_projection_aliases_are_stable_and_old_history_fails_closed(self):
        original = minimal_run("zeta-private-skill")
        _, first_aliases = renderer.public_projection(original)
        expanded = copy.deepcopy(original)
        earlier = copy.deepcopy(expanded["ledger"][0])
        earlier["canonical_name"] = "alpha-private-skill"
        expanded["ledger"].append(earlier)
        expanded["inputs"]["catalog_count"] = 2
        expanded["tiers"]["considered_not_now"].append("alpha-private-skill")
        _, second_aliases = renderer.public_projection(expanded)
        self.assertEqual(first_aliases["zeta-private-skill"],
                         second_aliases["zeta-private-skill"])

        old_secret = "retired-private-internal-skill"
        history = {
            "runs": [{
                "run_id": "old000000001", "generated_at": "2026-07-01T00:00:00Z",
                "fingerprint": "old", "profile_reused": False,
                "run_now": [f"C001 private campaign [{old_secret}]"],
                "acted_on": [old_secret],
                "declined": [{"skill": old_secret,
                              "condition": f"after {old_secret} is replaced"}],
                "still_pending": [old_secret],
            }],
            "monthly": [{"month": "2026-06", "run_count": 1,
                          "campaigns": [f"C001 private campaign [{old_secret}]"]}],
            "stable_decisions": [{"skill": old_secret, "condition": "later"}],
        }
        previous = self.root / "private-previous.md"
        previous.write_text(
            "<!-- skill-selection:run-history:v1\n"
            + json.dumps(history, sort_keys=True)
            + "\n-->\n", encoding="utf-8")
        run_path = self.root / "history-source-run.json"
        out = self.root / "history-public.md"
        run_path.write_text(json.dumps(minimal_run("current-private-skill")) + "\n",
                            encoding="utf-8")
        self.assertEqual(renderer.main([
            "--run", str(run_path), "--out", str(out),
            "--previous", str(previous), "--public",
        ]), 0)
        rendered = out.read_text(encoding="utf-8")
        self.assertNotIn(old_secret, rendered)
        self.assertRegex(rendered, r"private-skill-[0-9a-f]{12}")

    def test_offline_catalog_never_invokes_network_tools(self):
        bindir = self.root / "offline-bin"
        bindir.mkdir(exist_ok=True)
        log = self.root / "offline-invocations.log"
        for name in ("jsm", "curl"):
            tool = bindir / name
            tool.write_text(f"#!/usr/bin/env bash\nprintf '%s\\n' {name} >> '{log}'\nexit 99\n", encoding="utf-8")
            tool.chmod(0o755)
        out = self.root / "offline-catalog.json"
        env = dict(os.environ, PATH=str(bindir) + os.pathsep + os.environ["PATH"],
                   SKILL_SELECTION_KEEP_TEMP="1")
        result = subprocess.run([
            "bash", str(SCRIPTS / "catalog-fetch.sh"), "--offline", "--out", str(out)
        ], env=env, text=True, capture_output=True, timeout=15, check=False)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(out.read_text(encoding="utf-8"))["source_tier"], "snapshot")
        self.assertFalse(log.exists(), "offline mode invoked jsm or curl")

    def test_catalog_deadline_is_aggregate_not_per_call(self):
        bindir = self.root / "deadline-bin"
        bindir.mkdir(exist_ok=True)
        calls = self.root / "deadline-calls.log"
        jsm = bindir / "jsm"
        jsm.write_text(f"""#!/usr/bin/env bash
case "$1" in
  whoami) printf '{{"authenticated":true}}\\n' ;;
  list) printf '{{"skills":[{{"name":"deadline-new-skill","updated_at":"2026-08-15T00:00:00Z","content_hash":"new"}}]}}\\n' ;;
  show|related) printf '%s\\n' "$1" >> '{calls}'; sleep 10; exit 1 ;;
  *) exit 1 ;;
esac
""", encoding="utf-8")
        jsm.chmod(0o755)
        curl = bindir / "curl"
        curl.write_text("#!/usr/bin/env bash\nexit 1\n", encoding="utf-8")
        curl.chmod(0o755)
        out = self.root / "deadline-catalog.json"
        env = dict(os.environ, PATH=str(bindir) + os.pathsep + os.environ["PATH"],
                   SKILL_SELECTION_KEEP_TEMP="1")
        result = subprocess.run([
            "bash", str(SCRIPTS / "catalog-fetch.sh"), "--deadline", "5",
            "--snapshot", str(PKG / "tests" / "fixtures" / "fake-catalog.json"),
            "--out", str(out),
        ], env=env, text=True, capture_output=True, timeout=12, check=False)
        self.assertEqual(result.returncode, 0, result.stderr)
        invoked = calls.read_text(encoding="utf-8").splitlines()
        self.assertEqual(invoked, ["show"],
                         "a later network operation started with a fresh per-call budget")
        payload = json.loads(out.read_text(encoding="utf-8"))
        self.assertFalse(payload["retirement_known"])
        self.assertFalse(payload["drift_known"])
        self.assertEqual(payload["drift"]["retired"], [],
                         "a newest-page listing was mistaken for a complete live catalog")

    def test_malformed_related_output_is_unknown_not_empty(self):
        show = self.root / "show"
        related = self.root / "related"
        show.mkdir(exist_ok=True); related.mkdir(exist_ok=True)
        name = "relation-test"
        (show / f"{name}.json").write_text(json.dumps({"skill": {
            "description": "test", "updated_at": NOW, "content_hash": "h",
        }}) + "\n", encoding="utf-8")
        (related / f"{name}.json").write_text("not json and not the exact empty sentinel\n", encoding="utf-8")
        previous = {"skills": [{"canonical_name": name,
                                 "related": {"pairs_with": ["kept-edge"], "alternative_to": [],
                                             "extends": [], "prerequisite": []}}]}
        snapshot = common.assemble_snapshot([name], show, related, {}, NOW, previous)
        self.assertEqual(snapshot["skills"][0]["related"]["pairs_with"], ["kept-edge"])
        self.assertEqual(snapshot["source_errors"][0]["source"], "jsm-related")

    def test_local_inventory_hashes_all_bytes_and_finds_plugin_skills(self):
        codex_home = self.root / "codex-home"
        skill = codex_home / "plugins" / "cache" / "provider" / "bundle" / "skills" / "plugin-only"
        skill.mkdir(parents=True, exist_ok=True)
        (skill / "SKILL.md").write_text("---\nname: plugin-only\ndescription: plugin test\n---\n", encoding="utf-8")
        payload = skill / "payload.txt"
        payload.write_text("first\n", encoding="utf-8")
        env = dict(os.environ, CODEX_HOME=str(codex_home), HOME=str(self.root / "empty-home"),
                   SKILL_SELECTION_KEEP_TEMP="1", JSM_OFFLINE="1")
        outputs = []
        for index, contents in enumerate(("first\n", "other\n"), 1):
            payload.write_text(contents, encoding="utf-8")
            out = self.root / f"inventory-{index}.json"
            result = subprocess.run([
                "bash", str(SCRIPTS / "local-skills-inventory.sh"), "--out", str(out)
            ], env=env, text=True, capture_output=True, timeout=20, check=False)
            self.assertEqual(result.returncode, 0, result.stderr)
            outputs.append(next(row for row in json.loads(out.read_text(encoding="utf-8"))
                                if row["canonical_name"] == "plugin-only"))
        self.assertNotEqual(outputs[0]["content_hash"], outputs[1]["content_hash"])
        self.assertTrue(outputs[1]["provisional_mapping"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
