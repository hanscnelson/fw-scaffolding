#!/usr/bin/env bash
# Bash tests for scripts/check-doc-staleness.sh. Every clock is pinned via
# SKILL_SELECTION_NOW; every repo is built in a throwaway temp root.
#
# Cases:
#   a) no analysis doc                 -> reprofile / no_profile (exit 1)
#   b) fresh doc + tiny delta          -> reuse / within_thresholds (exit 0)
#   c) 25 commits since the profile    -> reprofile / commits_since_profile>=25
#   d) manifest edit                   -> reprofile / manifest_or_lockfile_digest_changed
#   e) non-git dir: unchanged digest   -> reuse; changed file -> reprofile / no_git
#   f) --fresh                         -> reprofile / user_requested_fresh
#   g) monorepo fixture, scoped:       -> crates/a reuse; crates/b scope mismatch
#   h) same-stat content replacement   -> reprofile
#   i) nested manifest edit            -> reprofile
#   j) non-git rename                  -> reprofile
#   k) Beads-only record churn         -> reprofile before the digest fast path
#   l) .beads present but br missing    -> reprofile / beads_watermark_unavailable
#   m) missing durable evidence block   -> reprofile / profile-evidence error
#   n) malformed required header field  -> reprofile / invalid-header error
#   o) odd untracked filename bytes     -> content change is detected
#   p) scope escapes target             -> fail closed before traversal
#
# Run from any cwd: bash tests/test_staleness.sh
set -uo pipefail
TESTS=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)
PKG=$(cd "$TESTS/.." && pwd -P)
CHECK="$PKG/scripts/check-doc-staleness.sh"
export SKILL_SELECTION_NOW="${SKILL_SELECTION_NOW:-2026-08-15T12:00:00Z}"

ROOT=$(mktemp -d "${TMPDIR:-/tmp}/skillsel-staleness.XXXXXX") || exit 1
export SKILL_SELECTION_KEEP_TEMP="${SKILL_SELECTION_KEEP_TEMP:-1}"
cleanup() {
  if [ "${SKILL_SELECTION_KEEP_TEMP:-0}" = 1 ]; then
    echo "staleness tests: kept scratch root $ROOT"
    return
  fi
  rm -rf "$ROOT"
}
trap cleanup EXIT

PASS=0; FAIL=0
ok()  { PASS=$((PASS + 1)); echo "PASS $1"; }
bad() { FAIL=$((FAIL + 1)); echo "FAIL $1: $2"; }

d() { python3 -c 'import sys,datetime as dt; s=sys.argv[1].replace("Z","+00:00"); print((dt.datetime.fromisoformat(s)-dt.timedelta(days=int(sys.argv[2]))).strftime("%Y-%m-%dT%H:%M:%SZ"))' "$SKILL_SELECTION_NOW" "$1"; }

mkrepo() { # mkrepo DIR : 14 tracked files (a 2-file delta stays under the 15% ratio)
  local dir="$1"
  mkdir -p "$dir/src"
  printf '[package]\nname = "stale-fixture"\nversion = "0.1.0"\nedition = "2021"\n' > "$dir/Cargo.toml"
  printf '# stale-fixture\n' > "$dir/README.md"
  local m
  for m in one two three four five six seven eight nine ten eleven main; do printf 'pub fn %s() {}\n' "$m" > "$dir/src/$m.rs"; done
  git -C "$dir" init -q -b main
  git -C "$dir" config user.name "skillsel-fixture"
  git -C "$dir" config user.email "fixture@example.invalid"
  git -C "$dir" add -A
  GIT_AUTHOR_DATE="$(d 5)" GIT_COMMITTER_DATE="$(d 5)" git -C "$dir" commit -q -m "initial import"
}

commit_delta() { # commit_delta DIR DAYS_AGO MSG FILE
  printf '\n// delta\n' >> "$1/$4"
  git -C "$1" add -A
  GIT_AUTHOR_DATE="$(d "$2")" GIT_COMMITTER_DATE="$(d "$2")" git -C "$1" commit -q -m "$3"
}

write_doc() { # write_doc DIR [SCOPE] [DOC_PATH]  : header filled from a live checker run
  local dir="$1" scope="${2:-.}" doc="${3:-}"
  [ -n "$doc" ] || doc="$dir/docs/COMPREHENSIVE_ANALYSIS_OF_PROJECT_USED_FOR_AUTOMATED_SKILL_SELECTION.md"
  local facts
  facts=$(bash "$CHECK" --target "$dir" --scope "$scope" --doc "$doc" || true)
  mkdir -p "$(dirname "$doc")"
  python3 - "$facts" "$SKILL_SELECTION_NOW" "$scope" "$doc" <<'PY'
import json, sys
facts = json.loads(sys.argv[1]); now, scope, out = sys.argv[2], sys.argv[3], sys.argv[4]
scopes = scope.split(",")
lines = ["---", f"last_updated: {now}", f"profiled_at: {now}"]
lines.append(f"profile_head_sha: {facts['profile_head_sha'] or 'null'}")
lines += ["profile_branch: main", "profile_scope: " + json.dumps(scopes, separators=(",", ":")),
          f"profile_tracked_file_count: {facts['tracked_file_count']}",
          f"profile_worktree_digest: {facts['worktree_digest']}",
          "profile_manifest_digests: " + json.dumps(facts.get("manifest_digests") or {}, sort_keys=True, separators=(",", ":"))]
lines += [f"profile_beads_watermark: {facts.get('beads_watermark') or 'null'}", "profile_cass_watermark: null",
          f"juncture_refreshed_at: {now}", f"recommendations_generated_at: {now}",
          "generator_version: 2.0.0", "---", "",
          "<!-- skill-selection:profile-evidence:v1",
          json.dumps([{
              "id": "ev-p0001", "claim": "fixture profile evidence", "kind": "profile",
              "polarity": "positive", "state": "present", "source_type": "file",
              "locator": "README.md:1", "observed_at": now, "command": "fixture probe",
              "repo_head": facts.get("current_head_sha") or facts.get("profile_head_sha"),
              "origin_host": None, "confidence": 4, "signals": [], "detail": "fixture",
          }], sort_keys=True),
          "-->", "", "# analysis fixture", ""]
open(out, "w").write("\n".join(lines))
PY
}

check() { # check LABEL DIR EXPECT_RC EXPECT_DECISION EXPECT_REASON_PREFIX [extra args...]
  local label="$1" dir="$2" want_rc="$3" want_dec="$4" want_reason="$5"; shift 5
  local out rc
  out=$(bash "$CHECK" --target "$dir" "$@"); rc=$?
  local verdict
  verdict=$(printf '%s' "$out" | python3 -c '
import json, sys
want_dec, want_reason = sys.argv[1], sys.argv[2]
try:
    d = json.loads(sys.stdin.read())
except Exception as e:
    print(f"not JSON: {e}"); sys.exit(0)
if d.get("decision") != want_dec:
    print("decision %r != %r" % (d.get("decision"), want_dec)); sys.exit(0)
if not str(d.get("reason", "")).startswith(want_reason):
    print("reason %r does not start with %r" % (d.get("reason"), want_reason)); sys.exit(0)
print("ok")' "$want_dec" "$want_reason")
  if [ "$rc" != "$want_rc" ]; then bad "$label" "exit $rc != $want_rc ($out)"; return; fi
  if [ "$verdict" != "ok" ]; then bad "$label" "$verdict"; return; fi
  ok "$label"
}

# ---- a) no doc --------------------------------------------------------------
mkrepo "$ROOT/a"
check "a:no-doc" "$ROOT/a" 1 reprofile no_profile

# ---- b) fresh doc + tiny delta ---------------------------------------------
mkrepo "$ROOT/b"
write_doc "$ROOT/b"
git -C "$ROOT/b" add docs
GIT_AUTHOR_DATE="$(d 2)" GIT_COMMITTER_DATE="$(d 2)" git -C "$ROOT/b" commit -q -m "record analysis doc"
commit_delta "$ROOT/b" 1 "small delta" "src/one.rs"
check "b:tiny-delta" "$ROOT/b" 0 reuse within_thresholds
HEAD_NOW=$(git -C "$ROOT/b" rev-parse HEAD)
HEAD_FIELDS=$(bash "$CHECK" --target "$ROOT/b")
HEAD_VERDICT=$(printf '%s' "$HEAD_FIELDS" | python3 -c '
import json, sys
d = json.load(sys.stdin)
print("ok" if d.get("current_head_sha") == sys.argv[1] and d.get("profile_head_sha") != sys.argv[1] else "bad")
' "$HEAD_NOW")
if [ "$HEAD_VERDICT" = ok ]; then ok "b:current-head-distinct"; else bad "b:current-head-distinct" "$HEAD_FIELDS"; fi

# ---- f) --fresh (on the same healthy repo) ---------------------------------
check "f:user-fresh" "$ROOT/b" 1 reprofile user_requested_fresh --fresh

# ---- c) 25 commits since ----------------------------------------------------
mkrepo "$ROOT/c"
write_doc "$ROOT/c"
git -C "$ROOT/c" add docs
GIT_AUTHOR_DATE="$(d 4)" GIT_COMMITTER_DATE="$(d 4)" git -C "$ROOT/c" commit -q -m "record analysis doc"
i=1
while [ $i -le 24 ]; do
  GIT_AUTHOR_DATE="$(d 3)" GIT_COMMITTER_DATE="$(d 3)" git -C "$ROOT/c" commit -q --allow-empty -m "churn $i"
  i=$((i + 1))
done
check "c:25-commits" "$ROOT/c" 1 reprofile "commits_since_profile>=25"

# ---- d) manifest edit -------------------------------------------------------
mkrepo "$ROOT/d"
write_doc "$ROOT/d"
printf '\n[dependencies]\nserde = "1"\n' >> "$ROOT/d/Cargo.toml"
check "d:manifest-edit" "$ROOT/d" 1 reprofile manifest_or_lockfile_digest_changed

# ---- e) non-git dir ---------------------------------------------------------
# The doc lives OUTSIDE the target (--doc), the way the real flow handles non-git /
# ephemeral targets: a doc inside the tree would itself change the worktree digest.
mkdir -p "$ROOT/e/src"
printf '# nongit\n' > "$ROOT/e/README.md"
printf 'def f():\n    return 1\n' > "$ROOT/e/src/f.py"
write_doc "$ROOT/e" . "$ROOT/e-analysis.md"
check "e:non-git-unchanged" "$ROOT/e" 0 reuse worktree_digest_unchanged --doc "$ROOT/e-analysis.md"
printf '\ndef g():\n    return 2\n' >> "$ROOT/e/src/f.py"
check "e:non-git-changed" "$ROOT/e" 1 reprofile no_git --doc "$ROOT/e-analysis.md"

# ---- g) monorepo fixture, scoped -------------------------------------------
bash "$TESTS/fixtures/monorepo-scope/setup.sh" "$ROOT/mono" > /dev/null
check "g:scope-a-reuse" "$ROOT/mono" 0 reuse worktree_digest_unchanged --scope crates/a
check "g:scope-b-reprofile" "$ROOT/mono" 1 reprofile profile_scope_changed --scope crates/b

# ---- h) byte changes hidden by a same-stat summary --------------------------
mkrepo "$ROOT/h"
write_doc "$ROOT/h"
printf 'pub fn one() { }\n' > "$ROOT/h/src/one.rs"
check "h:same-stat-content" "$ROOT/h" 1 reprofile uncommitted_tracked_changes

# ---- i) nested manifest / lockfile ------------------------------------------
mkrepo "$ROOT/i"
mkdir -p "$ROOT/i/crates/nested"
printf '[package]\nname="nested"\nversion="0.1.0"\n' > "$ROOT/i/crates/nested/Cargo.toml"
git -C "$ROOT/i" add -A
GIT_AUTHOR_DATE="$(d 4)" GIT_COMMITTER_DATE="$(d 4)" git -C "$ROOT/i" commit -q -m "add nested crate"
write_doc "$ROOT/i"
printf '[package]\nname="nested"\nversion="0.2.0"\n' > "$ROOT/i/crates/nested/Cargo.toml"
check "i:nested-manifest" "$ROOT/i" 1 reprofile manifest_or_lockfile_digest_changed

# ---- j) non-git path identity is part of the digest -------------------------
mkdir -p "$ROOT/j/src"
printf 'same bytes\n' > "$ROOT/j/src/old-name.txt"
write_doc "$ROOT/j" . "$ROOT/j-analysis.md"
mv "$ROOT/j/src/old-name.txt" "$ROOT/j/src/new-name.txt"
check "j:non-git-rename" "$ROOT/j" 1 reprofile no_git --doc "$ROOT/j-analysis.md"

# ---- k) Beads-only drift cannot take the worktree fast path -----------------
mkrepo "$ROOT/k"
mkdir -p "$ROOT/k/.beads" "$ROOT/bin"
printf '[{"id":"b1","updated_at":"2026-08-01T00:00:00Z"}]\n' > "$ROOT/k/.beads/issues.json"
apply_stub="$ROOT/bin/br"
printf '#!/usr/bin/env bash\ncat "%s/.beads/issues.json"\n' "$ROOT/k" > "$apply_stub"
chmod +x "$apply_stub"
OLD_PATH="$PATH"; PATH="$ROOT/bin:$PATH"; export PATH
write_doc "$ROOT/k"
python3 - "$ROOT/k/.beads/issues.json" <<'PY'
import json, sys
rows = [{"id": f"b{i}", "updated_at": "2026-08-14T00:00:00Z"} for i in range(1, 11)]
open(sys.argv[1], "w").write(json.dumps(rows) + "\n")
PY
check "k:beads-only-drift" "$ROOT/k" 1 reprofile "bead_issue_records_since_profile>=10"
PATH="$OLD_PATH"; export PATH

# ---- l) Beads state cannot be certified when its reader is unavailable -----
mkrepo "$ROOT/l"
mkdir -p "$ROOT/l/.beads" "$ROOT/lbin"
printf '[{"id":"b1","updated_at":"2026-08-01T00:00:00Z"}]\n' > "$ROOT/l/.beads/issues.json"
printf '#!/usr/bin/env bash\ncat "%s/.beads/issues.json"\n' "$ROOT/l" > "$ROOT/lbin/br"
chmod +x "$ROOT/lbin/br"
PATH="$ROOT/lbin:$OLD_PATH"; export PATH
write_doc "$ROOT/l"
PATH="/usr/bin:/bin:/usr/sbin:/sbin"; export PATH
check "l:beads-reader-unavailable" "$ROOT/l" 1 reprofile beads_watermark_unavailable
PATH="$OLD_PATH"; export PATH

# ---- m) a fingerprint header cannot substitute for durable profile facts --
mkrepo "$ROOT/m"
write_doc "$ROOT/m"
python3 - "$ROOT/m/docs/COMPREHENSIVE_ANALYSIS_OF_PROJECT_USED_FOR_AUTOMATED_SKILL_SELECTION.md" <<'PY'
import re, sys
path = sys.argv[1]
text = open(path).read()
open(path, "w").write(re.sub(r"\n<!-- skill-selection:profile-evidence:v1\n.*?\n-->\n", "\n", text, flags=re.S))
PY
check "m:missing-profile-evidence" "$ROOT/m" 1 reprofile error:profile-evidence-missing-or-invalid

# ---- n) all required header fields are typed and validated before reuse ----
mkrepo "$ROOT/n"
write_doc "$ROOT/n"
python3 - "$ROOT/n/docs/COMPREHENSIVE_ANALYSIS_OF_PROJECT_USED_FOR_AUTOMATED_SKILL_SELECTION.md" <<'PY'
import sys
path = sys.argv[1]
text = open(path).read().replace("profile_tracked_file_count: 14", "profile_tracked_file_count: fourteen")
open(path, "w").write(text)
PY
check "n:invalid-header" "$ROOT/n" 1 reprofile error:invalid-analysis-header

# ---- o) NUL-delimited Git paths bind odd untracked filenames to their bytes -
mkrepo "$ROOT/o"
python3 - "$ROOT/o" <<'PY'
import pathlib, sys
root = pathlib.Path(sys.argv[1])
for index in range(3):
    (root / f'odd-{index}\n"name.rs').write_text("one\n")
PY
write_doc "$ROOT/o" . "$ROOT/o-analysis.md"
python3 - "$ROOT/o" <<'PY'
import pathlib, sys
(pathlib.Path(sys.argv[1]) / 'odd-0\n"name.rs').write_text("two\n")
PY
check "o:odd-untracked-content" "$ROOT/o" 1 reprofile changed_file_ratio --doc "$ROOT/o-analysis.md"

# ---- p) a requested scope may never traverse outside the target ------------
mkdir -p "$ROOT/outside-scope"
mkrepo "$ROOT/p"
check "p:scope-escape" "$ROOT/p" 1 reprofile error:scope-outside-target --scope ../outside-scope

echo "----------------------------------------"
echo "staleness tests: $PASS passed, $FAIL failed"
[ "$FAIL" -eq 0 ]
