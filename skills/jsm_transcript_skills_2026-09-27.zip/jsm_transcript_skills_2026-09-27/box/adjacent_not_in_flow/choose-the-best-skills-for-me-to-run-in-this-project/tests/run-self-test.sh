#!/usr/bin/env bash
# End-to-end self-test for the skill-selection package (see SELF-TEST.md for the
# scenario list). Builds the fixtures in a scratch root, runs the REAL detector
# scripts against them (external tools served by tests/stubs — never the network),
# synthesizes the small scorer inputs, then scores, validates, renders, and asserts
# each numbered scenario, printing "PASS <n>" / "FAIL <n> <why>".
#
# Honors $SKILL_SELECTION_TEST_ROOT for the scratch root (default: mktemp -d).
# Writes ONLY under the scratch root. Exits non-zero on any FAIL.
set -uo pipefail
TESTS=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)
PKG=$(cd "$TESTS/.." && pwd -P)
# Stubs ship non-executable (jsm validate rejects executable bits in packages);
# copy them into the scratch root and add the exec bit there before use.
STUBS_SRC="$TESTS/stubs"
FAKECAT="$TESTS/fixtures/fake-catalog.json"
export SKILL_SELECTION_NOW="${SKILL_SELECTION_NOW:-2026-08-15T12:00:00Z}"
export SKILL_SELECTION_KEEP_TEMP="${SKILL_SELECTION_KEEP_TEMP:-1}"

SCRATCH="${SKILL_SELECTION_TEST_ROOT:-}"
if [ -z "$SCRATCH" ]; then
  SCRATCH=$(mktemp -d "${TMPDIR:-/tmp}/skillsel-selftest.XXXXXX") || exit 1
else
  mkdir -p "$SCRATCH" || exit 1
fi
# The no-history scenario's honesty depends on the fixture NOT sitting inside a repo.
if git -C "$SCRATCH" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo "refusing to run: scratch root $SCRATCH is inside a git work tree (breaks the no-history fixture)" >&2
  exit 2
fi
FIX="$SCRATCH/fixtures"; W="$SCRATCH/work"
mkdir -p "$FIX" "$W"
STUBS="$SCRATCH/stubs"
mkdir -p "$STUBS"
cp "$STUBS_SRC"/* "$STUBS"/ || exit 1
chmod +x "$STUBS"/* || exit 1
echo "scratch root: $SCRATCH"

PASS_N=0; FAIL_N=0; PIPE_ERRS=""
pass() { PASS_N=$((PASS_N + 1)); echo "PASS $1"; }
fail() { FAIL_N=$((FAIL_N + 1)); echo "FAIL $1 $2"; }
pipe_err() { PIPE_ERRS="${PIPE_ERRS}  $1"$'\n'; echo "pipeline error: $1" >&2; }
step() { echo "-- $*" >&2; }

# ---------------------------------------------------------------- fixtures --
for f in rust-cli next-supabase-stripe fresh-analysis-rerun monorepo-scope no-history; do
  step "building fixture $f"
  bash "$TESTS/fixtures/$f/setup.sh" "$FIX/$f" > /dev/null || { pipe_err "fixture $f setup failed"; }
done

# Scenario 8 baseline: content hash over the fixture trees (excluding .git internals,
# which git's own read paths may refresh, and the two doc paths the workflow owns).
tree_hash() {
  local dd
  for dd in rust-cli next-supabase-stripe fresh-analysis-rerun monorepo-scope no-history; do
    find "$FIX/$dd" -type f \
      ! -path '*/.git/*' \
      ! -name 'COMPREHENSIVE_ANALYSIS_OF_PROJECT_USED_FOR_AUTOMATED_SKILL_SELECTION.md' \
      ! -name 'RECOMMENDED_SKILLS_FOR_THIS_PROJECT.md' -print
  done | LC_ALL=C sort | while IFS= read -r f; do shasum -a 256 "$f"; done | shasum -a 256 | cut -d' ' -f1
}
HASH_BEFORE=$(tree_hash)

# ------------------------------------------------------------------ helpers --
detect() { # detect SCRIPT TARGET OUT [extra args...] : real detector under the stub PATH
  local script="$1" tgt="$2" out="$3"; shift 3
  PATH="$STUBS:$PATH" bash "$PKG/scripts/$script" --target "$tgt" --out "$out" "$@" \
    > "$out.log" 2>&1 || { pipe_err "$script on $tgt failed (see $out.log)"; return 1; }
}

merge_evidence() { # merge_evidence OUT PART... : concatenate evidence arrays
  python3 - "$@" <<'PY'
import json, sys
out, parts = sys.argv[1], sys.argv[2:]
ev = []
for p in parts:
    ev += json.load(open(p, encoding="utf-8"))
with open(out, "w", encoding="utf-8") as f:
    f.write(json.dumps(ev, indent=2, sort_keys=True, ensure_ascii=False) + "\n")
PY
}

make_cfg() { # make_cfg NAME TARGET IS_GIT : synthesize the run-config the scorer needs
  local name="$1" tgt="$2" isgit="$3" head="" branch=""
  if [ "$isgit" = true ]; then
    head=$(git -C "$tgt" rev-parse HEAD 2>/dev/null || true)
    branch=$(git -C "$tgt" rev-parse --abbrev-ref HEAD 2>/dev/null || true)
  fi
  python3 - "$W/$name.cfg.json" "$tgt" "$isgit" "$head" "$branch" "$PKG" <<'PY'
import json, sys
sys.path.insert(0, sys.argv[6] + "/scripts")
import skillsel_common as slib
out, tgt, isgit, head, branch = sys.argv[1:6]
cfg = {
    "run_id": slib.run_id(tgt, head or "worktree"),
    "generated_at": slib.now_iso(),
    "target": {"path": tgt, "scope": ["."], "is_git": isgit == "true",
               "is_ephemeral_clone": False, "is_public_repo": None,
               "head_sha": head or None, "branch": branch or None},
    "fingerprint": {"profile_reused": False, "reason": "no_profile",
                    "commits_since_profile": None, "bead_issue_records_since_profile": None,
                    "changed_file_ratio": None, "worktree_digest": None},
    "sources": {"profile": "ok", "juncture-git": "ok",
                "cass-local": "ok" if isgit == "true" else "skipped:no-history-scenario"},
}
with open(out, "w", encoding="utf-8") as f:
    f.write(json.dumps(cfg, indent=2, sort_keys=True) + "\n")
PY
}

score_run() { # score_run NAME OUT : score $W/NAME.evidence.json into OUT
  local name="$1" out="$2"
  python3 - "$W/$name.evidence.json" "$PKG" "$W/$name" <<'PY'
import importlib.util, json, sys
from pathlib import Path
evidence_path, package, prefix = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
spec = importlib.util.spec_from_file_location("selftest_scorer", package / "scripts/score-recommendations.py")
scorer = importlib.util.module_from_spec(spec); spec.loader.exec_module(scorer)
evidence = json.loads(evidence_path.read_text())
smap = json.loads((package / "references/data/signal-to-skill-map.json").read_text())
recipes = json.loads((package / "references/data/combo-recipes.json").read_text())["recipes"]
active = scorer.activate(evidence, smap["signals"])
activations = {"signals": {}}
for signal in sorted(smap["signals"]):
    slot = active[signal]
    rows = slot["present"] if slot["state"] == scorer.PRESENT else slot["absent"] if slot["state"] == scorer.ABSENT else []
    activations["signals"][signal] = {
        "state": slot["state"], "evidence_ids": sorted(row["id"] for row in rows),
    }
candidates = []
for recipe in recipes:
    ids = sorted({row["id"] for trigger in recipe.get("triggers", [])
                  for row in active.get(trigger, {}).get("present", [])})
    if ids:
        candidates.append({"recipe_id": recipe["id"], "evidence_ids": ids})
for suffix, value in (("gaps.json", []), ("overrides.json", {}),
                      ("activations.json", activations),
                      ("recipe-candidates.json", {"recipes": candidates})):
    Path(str(prefix) + "." + suffix).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
PY
  python3 "$PKG/scripts/score-recommendations.py" \
    --evidence "$W/$name.evidence.json" --catalog "$FAKECAT" \
    --already-done "$W/already.json" --run-config "$W/$name.cfg.json" \
    --gaps "$W/$name.gaps.json" --overrides "$W/$name.overrides.json" \
    --activations "$W/$name.activations.json" \
    --recipe-candidates "$W/$name.recipe-candidates.json" \
    --out "$out" > "$out.log" 2>&1 || pipe_err "score-recommendations for $name failed (see $out.log)"
}

validate_run() { # validate_run NAME RUNFILE : record the validator exit code
  local name="$1" runfile="$2" rc=0
  python3 "$PKG/scripts/validate-run.py" --run "$runfile" \
    --evidence "$W/$name.evidence.json" --catalog "$FAKECAT" \
    --run-config "$W/$name.cfg.json" --already-done "$W/already.json" \
    --gaps "$W/$name.gaps.json" --overrides "$W/$name.overrides.json" \
    --activations "$W/$name.activations.json" \
    --recipe-candidates "$W/$name.recipe-candidates.json" \
    > "$W/$name.validate.out" 2>&1 || rc=$?
  echo "$rc" > "$W/$name.validate.rc"
}

printf '{}\n' > "$W/already.json"

# ------------------------------------------------------------- RUN A: rust-cli
step "RUN A: rust-cli (profile + juncture + cass with unreachable remote)"
detect profile-project.sh "$FIX/rust-cli" "$W/rust-cli.profile.json"
detect juncture-signals.sh "$FIX/rust-cli" "$W/rust-cli.junc.json"
CASS_RC=0
PATH="$STUBS:$PATH" CASS_STUB_WS="$FIX/rust-cli" bash "$PKG/scripts/cass-juncture-mine.sh" \
  --target "$FIX/rust-cli" --catalog "$FAKECAT" --hosts "stub-unreachable-host" \
  --out "$W/rust-cli.cass.json" --already-out "$W/rust-cli.cass.already.json" \
  > "$W/rust-cli.cass.log" 2>&1 || CASS_RC=$?
echo "$CASS_RC" > "$W/rust-cli.cass.rc"
[ "$CASS_RC" -eq 0 ] || pipe_err "cass-juncture-mine on rust-cli exited $CASS_RC"
merge_evidence "$W/rust-cli.evidence.json" "$W/rust-cli.profile.json" "$W/rust-cli.junc.json" "$W/rust-cli.cass.json"
make_cfg rust-cli "$FIX/rust-cli" true
score_run rust-cli "$W/rust-cli.run.json"
validate_run rust-cli "$W/rust-cli.run.json"

# ------------------------------------------------ RUN B: next-supabase-stripe
step "RUN B: next-supabase-stripe (profile + juncture; scored twice)"
detect profile-project.sh "$FIX/next-supabase-stripe" "$W/next.profile.json"
detect juncture-signals.sh "$FIX/next-supabase-stripe" "$W/next.junc.json"
merge_evidence "$W/next.evidence.json" "$W/next.profile.json" "$W/next.junc.json"
make_cfg next "$FIX/next-supabase-stripe" true
score_run next "$W/next.run.json"
score_run next "$W/next.run2.json"
validate_run next "$W/next.run.json"
RENDER_RC=0
mkdir -p "$W/render"
bash "$PKG/scripts/check-doc-staleness.sh" --target "$FIX/next-supabase-stripe" \
  --doc "$W/render/COMPREHENSIVE_ANALYSIS_OF_PROJECT_USED_FOR_AUTOMATED_SKILL_SELECTION.md" \
  > "$W/next.render-staleness.json" 2> "$W/next.render-staleness.log" || true
python3 "$PKG/scripts/render-recommendations.py" --run "$W/next.run.json" \
  --out "$W/render/RECOMMENDED_SKILLS_FOR_THIS_PROJECT.md" \
  --update-analysis-header "$W/render/COMPREHENSIVE_ANALYSIS_OF_PROJECT_USED_FOR_AUTOMATED_SKILL_SELECTION.md" \
  --profiled --profile-evidence "$W/next.evidence.json" \
  --staleness "$W/next.render-staleness.json" > "$W/render.log" 2>&1 || RENDER_RC=$?
[ "$RENDER_RC" -eq 0 ] || pipe_err "render-recommendations exited $RENDER_RC (see $W/render.log)"

# ---------------------------------------------------------- RUN E: no-history
step "RUN E: no-history (profile + juncture, no git)"
detect profile-project.sh "$FIX/no-history" "$W/noh.profile.json"
detect juncture-signals.sh "$FIX/no-history" "$W/noh.junc.json"
merge_evidence "$W/noh.evidence.json" "$W/noh.profile.json" "$W/noh.junc.json"
make_cfg noh "$FIX/no-history" false
score_run noh "$W/noh.run.json"
validate_run noh "$W/noh.run.json"

# ------------------------------------------- RUN C: fresh-analysis-rerun (staleness)
step "RUN C: fresh-analysis-rerun (staleness reuse branch)"
STALE_RC=0
bash "$PKG/scripts/check-doc-staleness.sh" --target "$FIX/fresh-analysis-rerun" \
  > "$W/fresh.staleness.json" 2> "$W/fresh.staleness.log" || STALE_RC=$?
echo "$STALE_RC" > "$W/fresh.staleness.rc"
if [ "$STALE_RC" -ne 0 ]; then
  # The re-profile branch a real orchestrator would take; the marker file is what
  # scenario 4 asserts is ABSENT on the reuse branch.
  : > "$W/fresh.profile-invoked"
  detect profile-project.sh "$FIX/fresh-analysis-rerun" "$W/fresh.profile.json"
fi

# Scenario 8: hash AFTER every run that touched the fixture trees.
HASH_AFTER=$(tree_hash)

# =========================================================== the assertions ==
run_py() { # run_py <<'PY' ... : prints why-on-failure, exit 1 on failure
  python3 - "$W" "$PKG" "$TESTS" "$FIX"
}

# --- 1. rust-cli -> testing-fuzzing recommended -------------------------------
why=$(run_py <<'PY'
import json, sys
W = sys.argv[1]
run = json.load(open(W + "/rust-cli.run.json"))
row = next(r for r in run["ledger"] if r["canonical_name"] == "testing-fuzzing")
if row["disposition"] not in ("run_now", "run_soon"):
    print(f"testing-fuzzing disposition is {row['disposition']}, not run_now/run_soon"); sys.exit(1)
PY
) && pass 1 || fail 1 "${why:-assertion error}"

# --- 2. rust-cli -> both unsafe exorcists not_applicable with absence evidence ---
why=$(run_py <<'PY'
import json, sys
W = sys.argv[1]
run = json.load(open(W + "/rust-cli.run.json"))
ev = json.load(open(W + "/rust-cli.evidence.json"))
def absent(sig):
    return [e for e in ev if sig in e["signals"] and e["state"] == "absent-with-positive-evidence"]
for name, gate_sigs in [("rust-unsafe-code-exorcist", ["code-unsafe-any"]),
                        ("rust-undefined-behavior-exorcist", ["code-unsafe-any", "code-ffi-boundary"])]:
    row = next(r for r in run["ledger"] if r["canonical_name"] == name)
    if row["disposition"] != "not_applicable" or row["applicability_basis"] != "gate-absent":
        print(f"{name}: disposition={row['disposition']} basis={row['applicability_basis']}"); sys.exit(1)
    for sig in gate_sigs:
        if not absent(sig):
            print(f"{name}: no absence evidence record for gate signal {sig}"); sys.exit(1)
    if "Domain gate absent with positive evidence" not in row["reason"]:
        print(f"{name}: reason does not cite the absent gate: {row['reason']}"); sys.exit(1)
PY
) && pass 2 || fail 2 "${why:-assertion error}"

# --- 3. next -> billing/security recommended; rust-cli billing gate-absent ----
why=$(run_py <<'PY'
import json, sys
W = sys.argv[1]
nxt = json.load(open(W + "/next.run.json"))
recommended = set(nxt["tiers"]["run_now"]) | set(nxt["tiers"]["run_soon"])
for name in ("saas-billing-patterns-for-stripe-and-paypal", "security-audit-for-saas"):
    if name not in recommended:
        print(f"{name} not recommended in the next-supabase-stripe run"); sys.exit(1)
billing = next(r for r in nxt["ledger"] if r["canonical_name"] == "saas-billing-patterns-for-stripe-and-paypal")
if billing["disposition"] != "run_now" or not billing["campaign_id"]:
    print(f"billing skill not a run_now campaign member: {billing['disposition']}"); sys.exit(1)
rc = json.load(open(W + "/rust-cli.run.json"))
row = next(r for r in rc["ledger"] if r["canonical_name"] == "saas-billing-patterns-for-stripe-and-paypal")
if row["disposition"] != "not_applicable" or row["applicability_basis"] != "gate-absent":
    print(f"rust-cli billing row: disposition={row['disposition']} basis={row['applicability_basis']}"); sys.exit(1)
ev = json.load(open(W + "/rust-cli.evidence.json"))
hits = [e for e in ev if "fw-stripe" in e["signals"] and e["state"] == "absent-with-positive-evidence"]
if not hits:
    print("rust-cli evidence has no positive-absence record for fw-stripe"); sys.exit(1)
if not any("no dependency matched" in (e.get("detail") or "") for e in hits):
    print("fw-stripe absence record does not cite the no-stripe-dependency scan"); sys.exit(1)
PY
) && pass 3 || fail 3 "${why:-assertion error}"

# --- 4. fresh-analysis-rerun -> staleness reuse, profiler NOT invoked ---------
why=$(run_py <<'PY'
import json, os, sys
W = sys.argv[1]
rc = int(open(W + "/fresh.staleness.rc").read().strip())
if rc != 0:
    print(f"check-doc-staleness exited {rc}, expected 0 (reuse)"); sys.exit(1)
d = json.load(open(W + "/fresh.staleness.json"))
if d.get("decision") != "reuse":
    print(f"staleness decision {d.get('decision')!r} != 'reuse'"); sys.exit(1)
if os.path.exists(W + "/fresh.profile-invoked"):
    print("profile-project.sh WAS invoked on the reuse branch"); sys.exit(1)
PY
) && pass 4 || fail 4 "${why:-assertion error}"

# --- 5. one disposition per catalog entry; validate-run exit 0 ----------------
why=$(run_py <<'PY'
import json, sys
W, TESTS = sys.argv[1], sys.argv[3]
cat = json.load(open(TESTS + "/fixtures/fake-catalog.json"))
names = sorted(s["canonical_name"] for s in cat["skills"])
for tag in ("rust-cli", "next", "noh"):
    run = json.load(open(f"{W}/{tag}.run.json"))
    ledger_names = sorted(r["canonical_name"] for r in run["ledger"])
    if ledger_names != names:
        print(f"{tag}: ledger names differ from the catalog ({len(ledger_names)} rows)"); sys.exit(1)
    tiered = sorted(n for members in run["tiers"].values() for n in members)
    if tiered != names:
        print(f"{tag}: tiers do not partition the catalog"); sys.exit(1)
    rc = int(open(f"{W}/{tag}.validate.rc").read().strip())
    if rc != 0:
        print(f"{tag}: validate-run.py exited {rc}: " + open(f"{W}/{tag}.validate.out").read()[:200]); sys.exit(1)
PY
) && pass 5 || fail 5 "${why:-assertion error}"

# --- 6. determinism: two scored runs byte-identical ---------------------------
if cmp -s "$W/next.run.json" "$W/next.run2.json"; then
  pass 6
else
  fail 6 "next.run.json and next.run2.json differ byte-wise under the pinned clock"
fi

# --- 7. unreachable remote cass host -> unknown record naming the host --------
why=$(run_py <<'PY'
import json, sys
W = sys.argv[1]
rc = int(open(W + "/rust-cli.cass.rc").read().strip())
if rc != 0:
    print(f"cass-juncture-mine exited {rc}; the run must complete despite the dead host"); sys.exit(1)
ev = json.load(open(W + "/rust-cli.cass.json"))
hits = [e for e in ev if e.get("origin_host") == "stub-unreachable-host"]
if not hits:
    print("no evidence record names stub-unreachable-host"); sys.exit(1)
if not any(e["state"] == "unknown" for e in hits):
    print("the stub-unreachable-host record is not state=unknown"); sys.exit(1)
if any(e["state"] == "absent-with-positive-evidence" for e in hits):
    print("a timeout produced an absence claim (invariant 4 violation)"); sys.exit(1)
PY
) && pass 7 || fail 7 "${why:-assertion error}"

# --- 8. no target writes: fixture trees byte-identical ------------------------
if [ "$HASH_BEFORE" = "$HASH_AFTER" ]; then
  pass 8
else
  fail 8 "fixture tree content hash changed ($HASH_BEFORE -> $HASH_AFTER)"
fi

# --- 9. scan-shipped-package.sh clean -----------------------------------------
python3 - "$W" "$PKG" "$TESTS" <<'PY'
import json, sys
W, PKG, TESTS = sys.argv[1], sys.argv[2], sys.argv[3]
snap = json.load(open(PKG + "/references/data/catalog-snapshot.json"))
names = {s["canonical_name"] for s in snap["skills"]}
names.add("choose-the-best-skills-for-me-to-run-in-this-project")
names.add("zz-provisional-only")
open(W + "/scan-allowed.txt", "w").write("\n".join(sorted(names)) + "\n")
PY
SCAN_RC=0
bash "$PKG/scripts/scan-shipped-package.sh" --strict /dev/null --allowed "$W/scan-allowed.txt" \
  --hostnames /dev/null --repo-names /dev/null > "$W/scan.out" 2>&1 || SCAN_RC=$?
if [ "$SCAN_RC" -ne 0 ]; then
  fail 9 "scan-shipped-package.sh exited $SCAN_RC: $(tail -3 "$W/scan.out" | tr '\n' ' ')"
elif grep -q '^review:' "$W/scan.out"; then
  fail 9 "unresolved review lines: $(grep '^review:' "$W/scan.out" | head -2 | tr '\n' ' ')"
else
  pass 9
fi

# --- 10. zz-provisional-only: provisional row, E capped, never dropped --------
why=$(run_py <<'PY'
import json, sys
W = sys.argv[1]
run = json.load(open(W + "/next.run.json"))
rows = [r for r in run["ledger"] if r["canonical_name"] == "zz-provisional-only"]
if len(rows) != 1:
    print(f"zz-provisional-only has {len(rows)} ledger rows, expected exactly 1"); sys.exit(1)
row = rows[0]
if not row["provisional_mapping"]:
    print("zz-provisional-only row is not marked provisional_mapping"); sys.exit(1)
if row["scores"]["E"] > 2:
    print(f"zz-provisional-only E={row['scores']['E']} exceeds the provisional cap of 2"); sys.exit(1)
if row["canonical_name"] not in {n for m in run["tiers"].values() for n in m}:
    print("zz-provisional-only missing from the tier partition"); sys.exit(1)
PY
) && pass 10 || fail 10 "${why:-assertion error}"

# --- 11. no-history: unknown juncture; hygiene-only RUN NOW/RUN SOON ----------
why=$(run_py <<'PY'
import json, sys
W, PKG = sys.argv[1], sys.argv[2]
run = json.load(open(W + "/noh.run.json"))
smap = json.load(open(PKG + "/references/data/signal-to-skill-map.json"))
for name in run["tiers"]["run_now"] + run["tiers"]["run_soon"]:
    entry = smap["skills"].get(name) or {}
    if not entry.get("baseline_hygiene"):
        print(f"non-hygiene skill {name} reached RUN NOW/RUN SOON without git history"); sys.exit(1)
ev = json.load(open(W + "/noh.evidence.json"))
# spot-check one representative git-derived signal: unknown, never absent
sig = "jx-bug-fix-churn"
states = {e["state"] for e in ev if sig in e["signals"]}
if "absent-with-positive-evidence" in states:
    print(f"{sig} claimed absent although the target has no git history"); sys.exit(1)
if "unknown" not in states:
    print(f"{sig} has no unknown record (states: {sorted(states)})"); sys.exit(1)
PY
) && pass 11 || fail 11 "${why:-assertion error}"

# --- 12. Phase 7 renders both real documents from the evidence ----------------
why=$(run_py <<'PY'
import json, re, subprocess, sys
W, PKG = sys.argv[1], sys.argv[2]
sys.path.insert(0, PKG + "/scripts")
import skillsel_common as common
analysis = open(W + "/render/COMPREHENSIVE_ANALYSIS_OF_PROJECT_USED_FOR_AUTOMATED_SKILL_SELECTION.md").read()
recommendations = open(W + "/render/RECOMMENDED_SKILLS_FOR_THIS_PROJECT.md").read()
if "<What the project IS" in analysis or "<Top recurring problems" in analysis:
    print("analysis document still contains template placeholders"); sys.exit(1)
if "## What this project is going through right now (juncture)" not in analysis:
    print("analysis document lacks the juncture section"); sys.exit(1)
match = re.search(r"<!-- skill-selection:profile-evidence:v1\n(.*?)\n-->", analysis, re.S)
if not match or not json.loads(match.group(1)):
    print("analysis document lacks parseable durable profile evidence"); sys.exit(1)
header = common.parse_frontmatter(analysis)
expected_head = json.load(open(W + "/next.run.json"))["target"]["head_sha"]
if header.get("profile_head_sha") != expected_head:
    print("analysis document did not record the current profiled HEAD"); sys.exit(1)
if "<!-- skill-selection:last-run:v1" not in recommendations:
    print("recommendations document lacks its machine-readable run"); sys.exit(1)
PY
) && pass 12 || fail 12 "${why:-assertion error}"

# The fixture runner is also the documented full gate: keep the Python runtime
# contracts wired so a green end-to-end shell path cannot hide a broken library seam.
mkdir -p "$W/unit-tmp"
UNIT_RC=0
TMPDIR="$W/unit-tmp" python3 -m unittest discover -s "$TESTS" -p 'test_*.py' \
  > "$W/python-runtime-tests.log" 2>&1 || UNIT_RC=$?
if [ "$UNIT_RC" -eq 0 ]; then
  pass 13
else
  fail 13 "Python runtime contracts failed: $(tail -5 "$W/python-runtime-tests.log" | tr '\n' ' ')"
fi

# ------------------------------------------------------------------ summary --
echo "----------------------------------------"
echo "self-test: $PASS_N passed, $FAIL_N failed (scratch: $SCRATCH)"
if [ -n "$PIPE_ERRS" ]; then
  echo "pipeline errors:"; printf '%s' "$PIPE_ERRS"
fi
[ "$FAIL_N" -eq 0 ] && [ -z "$PIPE_ERRS" ]
