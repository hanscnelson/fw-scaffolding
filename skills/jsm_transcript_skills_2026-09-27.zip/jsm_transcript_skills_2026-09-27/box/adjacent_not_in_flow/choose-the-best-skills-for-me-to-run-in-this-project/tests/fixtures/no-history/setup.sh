#!/usr/bin/env bash
# Build the no-history fixture into "$1": source files only — deliberately NO git, NO
# beads, NO cass workspace. The honest expectation encoded in the self-test: every
# git-derived juncture signal is unknown (never absent), and only baseline-hygiene
# routes that need no git (e.g. the weak 3-line README) can put anything into
# RUN NOW / RUN SOON.
set -euo pipefail
SRC=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)
DEST="${1:?usage: setup.sh DEST_DIR}"
mkdir -p "$DEST"
shopt -s dotglob nullglob
for item in "$SRC"/*; do
  [ "$(basename "$item")" = setup.sh ] && continue
  cp -R "$item" "$DEST/"
done
echo "no-history fixture ready at $DEST (no git history, by design)"
