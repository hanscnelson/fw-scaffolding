use clap::{Parser, Subcommand};

mod parser;

#[derive(Parser)]
#[command(name = "rcli-fixture", about = "tiny fixture CLI with a hand-written parser")]
struct Cli {
    #[command(subcommand)]
    command: Command,
}

#[derive(Subcommand)]
enum Command {
    /// Parse a record file and print the field count.
    Check { path: String },
    /// Print the header of a record file.
    Header { path: String },
}

fn main() {
    let cli = Cli::parse();
    match cli.command {
        Command::Check { path } => {
            let data = std::fs::read_to_string(&path).expect("read input");
            let rec = parser::parse(&data).expect("parse input");
            println!("{} fields", rec.fields.len());
        }
        Command::Header { path } => {
            let data = std::fs::read_to_string(&path).expect("read input");
            let hdr = parser::parse_header(&data).expect("parse header");
            println!("version {}", hdr.version);
        }
    }
}
