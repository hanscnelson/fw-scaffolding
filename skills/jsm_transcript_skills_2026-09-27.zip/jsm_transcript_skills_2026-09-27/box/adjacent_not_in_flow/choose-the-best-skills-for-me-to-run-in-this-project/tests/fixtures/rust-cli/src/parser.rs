//! Hand-written record parser: `VERSION|field1;field2;...` — no external parser crate.

pub struct Header {
    pub version: u32,
}

pub struct Record {
    pub header: Header,
    pub fields: Vec<String>,
}

pub fn parse(input: &str) -> Result<Record, String> {
    let header = parse_header(input)?;
    let body = input.split_once('|').map(|(_, b)| b).unwrap_or("");
    let fields = parse_fields(body)?;
    Ok(Record { header, fields })
}

pub fn parse_header(input: &str) -> Result<Header, String> {
    let head = input.split('|').next().ok_or_else(|| "empty input".to_string())?;
    let version: u32 = head.trim().parse().map_err(|_| format!("bad version {head:?}"))?;
    Ok(Header { version })
}

fn parse_fields(body: &str) -> Result<Vec<String>, String> {
    let mut out = Vec::new();
    for raw in body.split(';') {
        let f = raw.trim();
        if f.is_empty() {
            continue;
        }
        out.push(f.to_string());
    }
    Ok(out)
}
