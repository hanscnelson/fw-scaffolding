#!/usr/bin/env bash
# Build the next-supabase-stripe fixture into "$1": copy the tree, git init, and make
# scripted commits (dates derived from SKILL_SELECTION_NOW) carrying billing-bug and
# security juncture vocabulary for the self-test scenarios.
set -euo pipefail
SRC=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)
DEST="${1:?usage: setup.sh DEST_DIR}"
NOW="${SKILL_SELECTION_NOW:-2026-08-15T12:00:00Z}"
d() { python3 -c 'import sys,datetime as dt; s=sys.argv[1].replace("Z","+00:00"); print((dt.datetime.fromisoformat(s)-dt.timedelta(days=int(sys.argv[2]))).strftime("%Y-%m-%dT%H:%M:%SZ"))' "$NOW" "$1"; }

mkdir -p "$DEST"
shopt -s dotglob nullglob
for item in "$SRC"/*; do
  [ "$(basename "$item")" = setup.sh ] && continue
  cp -R "$item" "$DEST/"
done
cd "$DEST"

git init -q -b main
git config user.name "skillsel-fixture"
git config user.email "fixture@example.invalid"
commit() { # commit DAYS_AGO MESSAGE
  GIT_AUTHOR_DATE="$(d "$1")" GIT_COMMITTER_DATE="$(d "$1")" git commit -q -m "$2"
}

git add -A
commit 9 "initial import"

printf '// dedupe delivered event ids\n' >> app/api/webhooks/route.ts
git add -A; commit 5 "fix stripe webhook double-fire"

printf '// serialize state transitions\n' >> app/api/webhooks/route.ts
git add -A; commit 4 "hotfix: subscription state race"

printf '// constant-time signature compare\n' >> app/api/webhooks/route.ts
git add -A; commit 3 "fix security hardening of signature verification"

echo "next-supabase-stripe fixture ready at $DEST ($(git rev-parse --short HEAD))"
