pub fn net_noop() {}
