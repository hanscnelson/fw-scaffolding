#!/usr/bin/env bash
# Build the monorepo-scope fixture into "$1": a two-member Cargo workspace whose
# analysis doc was profiled with profile_scope [crates/a] (header facts captured by
# invoking check-doc-staleness.sh --scope crates/a). A later commit touches only
# crates/b, so a crates/a-scoped staleness check must still say "reuse" while a
# crates/b-scoped check must re-profile.
set -euo pipefail
SRC=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)
PKG=$(cd "$SRC/../../.." && pwd -P)
DEST="${1:?usage: setup.sh DEST_DIR}"
NOW="${SKILL_SELECTION_NOW:-2026-08-15T12:00:00Z}"
d() { python3 -c 'import sys,datetime as dt; s=sys.argv[1].replace("Z","+00:00"); print((dt.datetime.fromisoformat(s)-dt.timedelta(days=int(sys.argv[2]))).strftime("%Y-%m-%dT%H:%M:%SZ"))' "$NOW" "$1"; }

mkdir -p "$DEST"
shopt -s dotglob nullglob
for item in "$SRC"/*; do
  [ "$(basename "$item")" = setup.sh ] && continue
  cp -R "$item" "$DEST/"
done
cd "$DEST"

git init -q -b main
git config user.name "skillsel-fixture"
git config user.email "fixture@example.invalid"
commit() { GIT_AUTHOR_DATE="$(d "$1")" GIT_COMMITTER_DATE="$(d "$1")" git commit -q -m "$2"; }

git add -A
commit 4 "initial workspace import"

FACTS=$(SKILL_SELECTION_NOW="$NOW" bash "$PKG/scripts/check-doc-staleness.sh" --target "$DEST" --scope crates/a || true)

mkdir -p docs
python3 - "$FACTS" "$NOW" docs/COMPREHENSIVE_ANALYSIS_OF_PROJECT_USED_FOR_AUTOMATED_SKILL_SELECTION.md <<'PY'
import json, sys
facts = json.loads(sys.argv[1])
now, out = sys.argv[2], sys.argv[3]
lines = [
    "---",
    f"last_updated: {now}",
    f"profiled_at: {now}",
    f"profile_head_sha: {facts['profile_head_sha']}",
    "profile_branch: main",
    'profile_scope: ["crates/a"]',
    f"profile_tracked_file_count: {facts['tracked_file_count']}",
    f"profile_worktree_digest: {facts['worktree_digest']}",
    "profile_manifest_digests: " + json.dumps(facts.get("manifest_digests") or {}, sort_keys=True, separators=(",", ":")),
]
lines += [
    "profile_beads_watermark: null",
    "profile_cass_watermark: null",
    f"juncture_refreshed_at: {now}",
    f"recommendations_generated_at: {now}",
    "generator_version: 2.0.0",
    "---",
    "",
    "<!-- skill-selection:profile-evidence:v1",
    json.dumps([{
        "id": "ev-p0001", "claim": "fixture profile evidence", "kind": "profile",
        "polarity": "positive", "state": "present", "source_type": "file",
        "locator": "crates/a/Cargo.toml:1", "observed_at": now,
        "command": "fixture probe", "repo_head": facts.get("current_head_sha"),
        "origin_host": None, "confidence": 4, "signals": [], "detail": "fixture",
    }], sort_keys=True),
    "-->",
    "",
    "# Comprehensive Analysis (fixture, scope crates/a)",
    "",
]
open(out, "w").write("\n".join(lines))
PY
# The doc stays deliberately untracked (outside every scope), and the only new commit
# touches crates/b: the crates/a fingerprint is byte-identical afterwards.
printf '\npub fn b_extra() -> u32 { 3 }\n' >> crates/b/src/lib.rs
git add crates/b
commit 1 "touch crates/b only"

echo "monorepo-scope fixture ready at $DEST ($(git rev-parse --short HEAD))"
