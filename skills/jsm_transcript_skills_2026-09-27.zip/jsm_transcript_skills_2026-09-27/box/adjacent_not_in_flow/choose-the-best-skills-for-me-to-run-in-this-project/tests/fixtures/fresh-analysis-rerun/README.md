# fresh-fixture

Staleness-check fixture: enough tracked files that a two-file delta stays under the 15% ratio.
