#!/usr/bin/env bash
# Build the fresh-analysis-rerun fixture into "$1": copy, git init, commit, then write
# the analysis doc whose header carries the REAL post-init head sha / digests / counts
# (obtained by invoking check-doc-staleness.sh) with timestamps pinned to
# SKILL_SELECTION_NOW so the 30-day rule never ages out. After the doc is committed, one
# extra commit touches one file: a small delta the staleness checker must call "reuse".
set -euo pipefail
SRC=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)
PKG=$(cd "$SRC/../../.." && pwd -P)
DEST="${1:?usage: setup.sh DEST_DIR}"
NOW="${SKILL_SELECTION_NOW:-2026-08-15T12:00:00Z}"
d() { python3 -c 'import sys,datetime as dt; s=sys.argv[1].replace("Z","+00:00"); print((dt.datetime.fromisoformat(s)-dt.timedelta(days=int(sys.argv[2]))).strftime("%Y-%m-%dT%H:%M:%SZ"))' "$NOW" "$1"; }

mkdir -p "$DEST"
shopt -s dotglob nullglob
for item in "$SRC"/*; do
  [ "$(basename "$item")" = setup.sh ] && continue
  cp -R "$item" "$DEST/"
done
cd "$DEST"

git init -q -b main
git config user.name "skillsel-fixture"
git config user.email "fixture@example.invalid"
commit() { GIT_AUTHOR_DATE="$(d "$1")" GIT_COMMITTER_DATE="$(d "$1")" git commit -q -m "$2"; }

git add -A
commit 3 "initial import"

# Capture the real post-init fingerprint facts from the checker itself (doc missing =>
# exit 1, but the JSON on stdout carries head/digest/count/manifests for this tree).
FACTS=$(SKILL_SELECTION_NOW="$NOW" bash "$PKG/scripts/check-doc-staleness.sh" --target "$DEST" || true)

mkdir -p docs
python3 - "$FACTS" "$NOW" docs/COMPREHENSIVE_ANALYSIS_OF_PROJECT_USED_FOR_AUTOMATED_SKILL_SELECTION.md <<'PY'
import json, sys
facts = json.loads(sys.argv[1])
now, out = sys.argv[2], sys.argv[3]
lines = [
    "---",
    f"last_updated: {now}",
    f"profiled_at: {now}",
    f"profile_head_sha: {facts['profile_head_sha'] or facts.get('profile_head_sha')}",
    "profile_branch: main",
    'profile_scope: ["."]',
    f"profile_tracked_file_count: {facts['tracked_file_count']}",
    f"profile_worktree_digest: {facts['worktree_digest']}",
    "profile_manifest_digests: " + json.dumps(facts.get("manifest_digests") or {}, sort_keys=True, separators=(",", ":")),
]
lines += [
    "profile_beads_watermark: null",
    "profile_cass_watermark: null",
    f"juncture_refreshed_at: {now}",
    f"recommendations_generated_at: {now}",
    "generator_version: 2.0.0",
    "---",
    "",
    "<!-- skill-selection:profile-evidence:v1",
    json.dumps([{
        "id": "ev-p0001", "claim": "fixture profile evidence", "kind": "profile",
        "polarity": "positive", "state": "present", "source_type": "file",
        "locator": "README.md:1", "observed_at": now,
        "command": "fixture probe", "repo_head": facts.get("current_head_sha"),
        "origin_host": None, "confidence": 4, "signals": [], "detail": "fixture",
    }], sort_keys=True),
    "-->",
    "",
    "# Comprehensive Analysis (fixture)",
    "",
    "Fixture analysis doc: only the YAML header above matters to the staleness checker.",
    "",
]
open(out, "w").write("\n".join(lines))
PY
# The checker reports the pre-doc head; the doc commit and the delta commit that follow
# keep that head an ancestor with a small, under-threshold delta.
git add docs
commit 2 "record analysis profile doc"

printf '\npub fn util_extra() {}\n' >> src/util.rs
git add -A
commit 1 "small delta touching one file"

echo "fresh-analysis-rerun fixture ready at $DEST ($(git rev-parse --short HEAD))"
