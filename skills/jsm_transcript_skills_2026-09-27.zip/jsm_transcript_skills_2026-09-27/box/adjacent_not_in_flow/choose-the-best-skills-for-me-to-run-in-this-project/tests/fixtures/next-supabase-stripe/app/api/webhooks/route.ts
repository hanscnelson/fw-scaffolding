// Stripe webhook endpoint: verifies the signature, then updates subscription state.
import Stripe from "stripe";
import { NextResponse } from "next/server";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY ?? "", { apiVersion: "2024-06-20" });

export async function POST(req: Request) {
  const payload = await req.text();
  const signature = req.headers.get("stripe-signature") ?? "";
  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(payload, signature, process.env.STRIPE_WEBHOOK_SECRET ?? "");
  } catch {
    return NextResponse.json({ error: "bad signature" }, { status: 400 });
  }
  switch (event.type) {
    case "checkout.session.completed":
      // grant the entitlement for the new subscription_id
      break;
    case "invoice.payment_failed":
      // mark the Subscription past_due and start dunning
      break;
    case "customer.subscription.deleted":
      // revoke the entitlement for this subscription_id
      break;
  }
  return NextResponse.json({ received: true });
}
