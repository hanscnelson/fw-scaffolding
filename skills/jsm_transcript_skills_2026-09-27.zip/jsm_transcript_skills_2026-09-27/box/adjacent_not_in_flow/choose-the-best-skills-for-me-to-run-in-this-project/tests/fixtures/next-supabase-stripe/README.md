# next-fixture-app

Tiny Next.js + Supabase + Stripe fixture app (billing webhook plus mocked billing tests).
