// One plain unit test; deliberately NO fuzz targets anywhere in this fixture.
#[test]
fn splits_fields() {
    assert_eq!("a;b".split(';').count(), 2);
}
