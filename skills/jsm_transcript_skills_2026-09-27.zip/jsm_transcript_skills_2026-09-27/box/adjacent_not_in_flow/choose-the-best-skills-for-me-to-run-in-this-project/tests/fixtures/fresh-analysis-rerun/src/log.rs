pub fn log_noop() {}
