# rcli-fixture

Tiny fixture CLI with a hand-written record parser (kept deliberately short).
