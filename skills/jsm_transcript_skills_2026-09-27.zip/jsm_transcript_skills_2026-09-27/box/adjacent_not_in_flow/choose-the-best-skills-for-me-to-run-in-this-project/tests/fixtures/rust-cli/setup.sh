#!/usr/bin/env bash
# Build the rust-cli fixture into "$1" (a temp dir the runner provides): copy the tree,
# git init, and make scripted commits whose dates derive from SKILL_SELECTION_NOW so
# byte-determinism holds. The commit messages carry the juncture vocabulary the
# self-test scenarios assert on (recurring panics, bug-fix churn, a revert).
set -euo pipefail
SRC=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)
DEST="${1:?usage: setup.sh DEST_DIR}"
NOW="${SKILL_SELECTION_NOW:-2026-08-15T12:00:00Z}"
d() { python3 -c 'import sys,datetime as dt; s=sys.argv[1].replace("Z","+00:00"); print((dt.datetime.fromisoformat(s)-dt.timedelta(days=int(sys.argv[2]))).strftime("%Y-%m-%dT%H:%M:%SZ"))' "$NOW" "$1"; }

mkdir -p "$DEST"
shopt -s dotglob nullglob
for item in "$SRC"/*; do
  [ "$(basename "$item")" = setup.sh ] && continue
  cp -R "$item" "$DEST/"
done
cd "$DEST"

git init -q -b main
git config user.name "skillsel-fixture"
git config user.email "fixture@example.invalid"
commit() { # commit DAYS_AGO MESSAGE
  GIT_AUTHOR_DATE="$(d "$1")" GIT_COMMITTER_DATE="$(d "$1")" git commit -q -m "$2"
}

git add -A
commit 10 "initial import"

printf '\n// guard against truncated input\n' >> src/parser.rs
git add -A; commit 6 "fix parser panic on truncated input"

printf '\n// tolerate an empty header\n' >> src/parser.rs
git add -A; commit 4 "fix: parser crash on empty header"

printf '\n// zero-length header guard\n' >> src/parser.rs
git add -A; commit 3 "fix parser panic when header length is zero"

printf '\n// (reverted an earlier change)\n' >> src/parser.rs
git add -A; commit 2 "revert bad parser fix"

echo "rust-cli fixture ready at $DEST ($(git rev-parse --short HEAD))"
