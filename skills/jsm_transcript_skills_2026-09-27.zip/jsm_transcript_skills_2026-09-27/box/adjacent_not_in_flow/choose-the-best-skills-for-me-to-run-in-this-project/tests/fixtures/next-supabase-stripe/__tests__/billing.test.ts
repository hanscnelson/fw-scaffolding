// Billing tests that MOCK stripe. The event re-delivery / duplicate-event coverage the
// gap detector scans test paths for is deliberately absent, and so is its vocabulary
// (this file must not contain the detector's search terms).
jest.mock("stripe", () => {
  return jest.fn().mockImplementation(() => ({
    subscriptions: { retrieve: jest.fn().mockResolvedValue({ status: "active" }) },
  }));
});

import Stripe from "stripe";

test("subscription status is read from the mocked client", async () => {
  const client = new (Stripe as unknown as jest.Mock)() as {
    subscriptions: { retrieve: (id: string) => Promise<{ status: string }> };
  };
  const sub = await client.subscriptions.retrieve("sub_fixture_123");
  expect(sub.status).toBe("active");
});
