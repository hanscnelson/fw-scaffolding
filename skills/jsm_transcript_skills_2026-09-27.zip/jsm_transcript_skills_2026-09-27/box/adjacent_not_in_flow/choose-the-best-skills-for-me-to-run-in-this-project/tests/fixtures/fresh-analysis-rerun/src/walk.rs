pub fn walk_noop() {}
