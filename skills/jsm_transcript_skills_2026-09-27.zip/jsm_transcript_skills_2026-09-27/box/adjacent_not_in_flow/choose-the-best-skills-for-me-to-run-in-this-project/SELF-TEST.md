# Self-Test

Trigger calibration plus the end-to-end fixture scenarios that `tests/run-self-test.sh`
executes and asserts. Everything runs offline: external tools are served by the PATH
shims in `tests/stubs/` (the only "remote host" is the obviously fake
`stub-unreachable-host`), and the clock is pinned via `SKILL_SELECTION_NOW` so every
scored artifact is byte-reproducible.

## Should trigger

The skill should activate on requests like:

1. "which skills should I run here"
2. "what skill fits this project"
3. "choose the best skills for this repo"
4. "what should I do next in this project"
5. "rank my skills against this codebase"
6. "which of my skills would help most right now"
7. "recommend skills for this project"
8. "what skills apply to this repo at this point"

## Should NOT trigger

Routing for near-miss phrasings — the user has already chosen, or wants something else:

1. "install skill X" → run `jsm` directly; an install command is not a selection question.
2. "write a new skill for X" → the skill-authoring/onboarding path, not selection.
3. "run reality check on this project" → `/reality-check-for-project` directly.
4. "which of these two design ideas is better" → `/idea-wizard`; ranking ideas, not skills.
5. "what does this codebase even do" → `/codebase-archaeology`; understanding, not selection.

## Fixture scenarios (asserted by `bash tests/run-self-test.sh`)

The runner builds each fixture into a scratch root via its `setup.sh` (scripted commits
dated from `SKILL_SELECTION_NOW`), runs the REAL detector scripts, synthesizes the small
already-done/run-config inputs inline, then scores, validates, and renders. Each
scenario prints `PASS <n>` or `FAIL <n> <why>`; any FAIL makes the suite exit non-zero.

1. **rust-cli → testing-fuzzing recommended.** The parser fixture (hand-written
   `fn parse*`, no fuzz targets, panic-vocabulary commits) puts `testing-fuzzing` in
   RUN NOW or RUN SOON. *Asserted:* its ledger disposition is one of the two (in
   practice RUN NOW as the parser-hardening campaign anchor).
2. **rust-cli → both unsafe exorcists not_applicable.** No `unsafe`, no FFI. *Asserted:*
   `rust-unsafe-code-exorcist` and `rust-undefined-behavior-exorcist` rows are
   `not_applicable` with basis `gate-absent`, the evidence set contains
   `absent-with-positive-evidence` records for every gate signal
   (`code-unsafe-any`, and `code-ffi-boundary` for the UB exorcist), and each row's
   reason cites the absent gate.
3. **next-supabase-stripe → billing/security recommended; cross-fixture gate.**
   *Asserted:* `saas-billing-patterns-for-stripe-and-paypal` and
   `security-audit-for-saas` are both in RUN NOW ∪ RUN SOON of the Next.js run (billing
   as a RUN NOW campaign member), while the rust-cli run's ledger shows the billing
   skill `not_applicable` (`gate-absent`) backed by a positive-absence `fw-stripe`
   record whose detail cites the no-dependency scan.
4. **fresh-analysis-rerun → reuse, no re-profiling.** The fixture's analysis header
   carries the real post-init head sha/digests plus a small (2-commit, 2-file) delta.
   *Asserted:* `check-doc-staleness.sh` exits 0 with decision `reuse`, and the runner's
   re-profile branch was never taken (its `fresh.profile-invoked` marker, written only
   on the exit-1 branch, does not exist) — so `profile-project.sh` was not invoked.
5. **Whole-catalog ledger.** *Asserted for all three scored runs:* the ledger names are
   exactly the fake catalog's 13 names (one row each), the five tiers partition them,
   and `validate-run.py` exits 0.
6. **Determinism.** The Next.js run is scored twice from identical inputs under the
   pinned clock. *Asserted:* the two run JSONs are byte-identical (`cmp`).
7. **Unreachable remote cass host.** `cass-juncture-mine.sh` runs with
   `--hosts stub-unreachable-host`; the ssh stub simulates a timeout (exit 124).
   *Asserted:* the miner still exits 0, and the evidence contains a `state=unknown`
   record whose `origin_host` is `stub-unreachable-host` — never an absence claim
   (invariant 4).
8. **No target writes.** *Asserted:* a recursive content hash over the five fixture
   trees (excluding `.git/` internals, which git's own read paths may refresh, and the
   two workflow-owned doc paths) is byte-identical before and after every run.
9. **Shipped-package scan clean.** `scan-shipped-package.sh` runs with the
   `/dev/null`-lists form and `--allowed` = snapshot names + the package name +
   `zz-provisional-only`. *Asserted:* exit 0 and zero `review:` lines.
10. **zz-provisional-only (absent from the signal map).** *Asserted:* exactly one ledger
    row, `provisional_mapping: true`, `E ≤ 2`, and it appears in the tier partition —
    never silently dropped.
11. **no-history → unknown stays unknown.** Source files only: no git, no beads, no cass
    workspace. *Asserted:* every skill in RUN NOW/RUN SOON is baseline-hygiene-eligible
    (in this fixture that is `readme-writing`, promoted by the deliberate 3-line README
    — a profile signal needing no git); and for a representative git-derived signal
    (`jx-bug-fix-churn`) the evidence holds an `unknown` record and no absence claim.
12. **Analysis generation is real and durable.** The renderer runs in full-profile mode
    against merged profile+juncture evidence. *Asserted:* it creates a complete analysis
    document, embeds a parseable durable profile-evidence block, cites evidence in the
    generated sections, refreshes the current HEAD fingerprint, and emits no template
    placeholders.
13. **Python runtime contracts are wired into the executable gate.** The self-test invokes
    `unittest discover` over every `test_*.py`. *Asserted:* privacy, catalog, scoring,
    validation, evidence, and rendering regressions make the top-level self-test fail.

## Unit tests

- `python3 tests/test_scoring.py` — arithmetic, eligibility and suppression gates,
  portfolio constraints, catalog retirement, complete Phase 5 activation/provenance
  verification, decision-input fingerprints, determinism, and domain gates.
- `python3 tests/test_validate_run.py` — a scorer-produced run passes; deliberate ledger,
  evidence, campaign, gap, tier, and input-fingerprint corruptions fail closed.
- `python3 -m unittest discover -s tests -p 'test_*.py' -v` — every Python runtime
  contract, including public-mode privacy and full analysis generation.
- `bash tests/test_staleness.sh` — 19 staleness cases, including malformed headers/profile
  evidence, manifest drift before reuse, odd filenames, and scope-containment failures.

## Running

```
python3 tests/test_scoring.py
python3 tests/test_validate_run.py
python3 -m unittest discover -s tests -p 'test_*.py' -v
bash tests/test_staleness.sh
bash tests/run-self-test.sh
```

All commands honor `SKILL_SELECTION_NOW` (default `2026-08-15T12:00:00Z`). The self-test
honors `SKILL_SELECTION_TEST_ROOT` for its scratch root (default `mktemp -d`) and writes
nothing outside it; the scratch root must not sit inside a git work tree, or the
no-history fixture would inherit a repository.
