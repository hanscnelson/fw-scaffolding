# Recommended Skills doc — reference shape

> docs/RECOMMENDED_SKILLS_FOR_THIS_PROJECT.md is REGENERATED each run by
> scripts/render-recommendations.py from the recommendation-run JSON. This template
> documents the contract for reviewers (Phase 8 Pass A) — do not hand-author the doc.

Sections, in order:

1. **Header** — run id, generated_at, generator version, target + scope, profile
   reused/rebuilt with the fingerprint reason, catalog count ("every one has exactly
   one row in the ledger"), tier counts.
2. **RUN NOW — the portfolio** — one to three campaign kickoff blocks
   (assets/kickoff-block-template.md), each with runners-up.
3. **RUN SOON** — table: skill, score, J/A/E/C/R/D, why, evidence ids. Includes
   RUN NOW-eligible rows that lost on portfolio capacity/overlap/budget, labeled so.
4. **KEEP HANDY** — same table; every row names its promotion trigger.
5. **Considered — not now** — only the interesting rejections, as prose bullets
   (anti-signals first). The ledger proves the rest were considered.
6. **Gaps** — signals with no matching catalog skill; each names its evidence and a
   suggested `jsm requests new` title. A gap may never name an existing catalog skill.
7. **Source status** — per source: ok / unknown:<error> / skipped:<reason>. Unknown is
   never spun as absence.
8. **Catalog drift** — new / renamed / retired / provisional vs the bundled snapshot.
9. **Previous-run cross-check** — acted on / declined (with conditions) / still pending,
   plus the `jsm outcome` reminder.
10. **Appendix A — run history** — last 12 runs in full (date, fingerprint, campaigns,
    acted-on/declined), older runs compacted into monthly summaries, stable user
    decisions ("declined until X") always preserved.
11. **Appendix B — machine-readable run record** — three HTML-comment blocks:
    `skill-selection:run-history:v1` (bounded history JSON),
    `skill-selection:last-run:v1` (the full run JSON),
    `skill-selection:ledger:v1` (one ledger row per line — extract to JSONL for
    `jsm outcome --batch` and for the next run's diff).

One file, overwritten each run; history lives in its appendix and stays bounded.
