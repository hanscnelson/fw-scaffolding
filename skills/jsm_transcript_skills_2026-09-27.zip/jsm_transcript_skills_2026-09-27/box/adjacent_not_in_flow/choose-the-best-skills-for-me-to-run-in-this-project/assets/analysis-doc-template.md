---
last_updated: <ISO-8601Z — display only, never used for staleness>
profiled_at: <ISO-8601Z — when Phase 2 last ran in full>
profile_head_sha: <full sha, or null when the target is not a git repo>
profile_branch: <branch, or null>
profile_scope:
  - <"." or each monorepo component path profiled>
profile_tracked_file_count: <int>
profile_worktree_digest: sha256:<hex — from check-doc-staleness.sh output>
profile_manifest_digests:
  <manifest-or-lockfile-path>: sha256:<hex>
profile_beads_watermark: <max updated_at>/<issue count>   # null when no .beads/
profile_cass_watermark: <newest session timestamp seen>   # null when cass unavailable
juncture_refreshed_at: <ISO-8601Z>
recommendations_generated_at: <ISO-8601Z>
generator_version: 2.0.0
---

<!-- skill-selection:profile-evidence:v1
[<canonical append-only profile evidence records; corrections use supersedes>]
-->

# Comprehensive Analysis Of Project (Automated Skill Selection)

> Source of truth across runs. The header is machine-parsed by check-doc-staleness.sh
> (validate against references/schemas/analysis-header.schema.json). Every fact below
> carries its evidence id (ev-…) from the run's evidence set. Update in place when
> re-profiling — never create a second analysis file.

## Identity & purpose
<What the project IS, who uses it, shipped-to-public status, maturity — each claim with (ev-…).>

## Languages, build systems, toolchains
<Languages with line counts, workspace layout, dependency-graph shape, unusual pins. (ev-…)>

## Kinds of code present
<One line per detected code kind with its locator and evidence id. Include the
generated/vendored exclusion record so absence claims are grounded.>

## Tests — present and absent
<Test kinds that exist; test kinds ABSENT for the code kinds present (the gap-* signals),
each with both underlying evidence ids.>

## Documentation & process artifacts
<AGENTS/README/CHANGELOG state, plan files, beads counts, CI, licensing. (ev-…)>

## Delivery surface & polish gaps
<Changelog vs tags, installer quality, doctor/--json coverage, docs site, OG images,
dependency freshness, monolith files. (ev-…)>

## What this project is going through right now (juncture)
> Refreshed every run even when the profile is reused; bump juncture_refreshed_at.
<Top recurring problems with evidence (cass hits carry origin_host); git/beads corroboration;
the already-done state for every skill seen in history.>

## Evidence appendix
<The embedded profile-evidence block above is the durable canonical copy used by profile
reuse. A workspace path may be mentioned only as a convenience, never as the sole copy.>
