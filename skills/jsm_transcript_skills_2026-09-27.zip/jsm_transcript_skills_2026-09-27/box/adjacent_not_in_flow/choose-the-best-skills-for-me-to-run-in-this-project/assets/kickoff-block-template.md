# Campaign kickoff block (the shape every RUN NOW campaign is printed in)

```text
Campaign: <title — what the campaign accomplishes, not the skill name>

Sequence:
1. /<prerequisite-skill>            (prerequisite)
2. /<anchor-skill>
3. /<pair-skill> — <note>           (pair)

Kickoff prompt (paste verbatim):
"<the user's own phrasing from the recipe or the skill's kickoff_phrasing —
  including round counts ('at least 10 times sequentially'), negative constraints
  ('NOT gh actions'), and the behaviour-gate rider where the recipe carries one>"

Expected artifact:
<one concrete deliverable the user can point at when the campaign is done>

Stop condition:
<a measurable stop rule — never 'until it feels done'>

Evidence: ev-#### (profile), ev-#### (juncture, cass@<origin_host>), ev-#### (git)
Install:  for s in <missing-skill> <missing-skill>; do jsm install "$s"; done
```

Rules:
- Prerequisites precede the anchor; pairs follow it.
- Every campaign cites at least one profile anchor and one juncture anchor
  (two profile anchors for a baseline-hygiene campaign).
- The install line lists only skills not already installed; when everything is
  installed, say so instead of printing a no-op loop.
- Runners-up (the alternative recipe or skill and why it lost) are printed
  directly under the block.
