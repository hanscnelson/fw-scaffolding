# Scoring Rubric

The scoring contract. The numbers live in `references/data/scoring-constants.json`;
`scripts/score-recommendations.py` loads that file and improvises nothing. Changing anything
there bumps `generator_version` and the unit tests.

## Contents

- [The formula and tier rules (verbatim)](#the-formula-and-tier-rules-verbatim)
- [What each level means, per dimension](#what-each-level-means-per-dimension)
- [How each dimension is computed](#how-each-dimension-is-computed)
- [Suppression gates run first](#suppression-gates-run-first)
- [Phase 5 is executable input, not commentary](#phase-5-is-executable-input-not-commentary)
- [The portfolio](#the-portfolio)
- [Worked example A: parser project with recurring panics](#worked-example-a-parser-project-with-recurring-panics)
- [Worked example B: no-history project](#worked-example-b-no-history-project)
- [Worked example C: suppressed despite the score](#worked-example-c-suppressed-despite-the-score)

## The formula and tier rules (verbatim)

```
score = 5·J + 4·A + 3·E − 2·C − 2·R − 3·D          range −28 … 48, dimensions 0–4

RUN NOW eligible:  score ≥ 30 ∧ J ≥ 3 ∧ E ≥ 3 ∧ ≥ 2 independent anchors
                   (≥ 1 profile AND ≥ 1 juncture anchor)
                   ∧ prerequisites satisfied or in-campaign
Baseline-hygiene RUN NOW (the only route without a juncture anchor):
                   score ≥ 30 ∧ J ≥ 3 ∧ E ≥ 3 ∧ ≥ 2 distinct PROFILE anchors
RUN SOON:          score ≥ 22 ∧ J ≥ 2
KEEP HANDY:        score ≥ 12 (row names its promotion trigger)
else               CONSIDERED, NOT NOW · gate-absent ⇒ NOT APPLICABLE

Tie-break: J desc → E desc → C asc → R asc → canonical name asc.
```

**Independence = distinct locators.** Each anchor's key is its evidence `locator` (record id
when null); two records pointing at the same `path@sha:line` count once. This is why a
derived gap plus its own base signal is ONE anchor, not two.

## What each level means, per dimension

**J — juncture fit** (max weight of firing juncture signals, or hygiene severity)

| J | Meaning |
|---|---|
| 0 | Nothing at this juncture calls for it |
| 1 | A weak or aging mention; background noise |
| 2 | A real but moderate signal in the window |
| 3 | A strong recent signal, or a severity-3 hygiene gap |
| 4 | The user's current pain: recurring this-week failures or their own words |

**A — accretiveness** (base + best profile signal − anti-signal penalties)

| A | Meaning |
|---|---|
| 0 | Anti-signals dominate; running it would re-do or undo existing work |
| 1 | Generically useful here, nothing project-specific |
| 2 | Fits the project's kind (right language/shape) |
| 3 | Strong profile match to what this project is |
| 4 | Aimed at this project's exact detected gap or identity |

**E — evidence quality** (max anchor confidence, penalized and capped)

| E | Meaning |
|---|---|
| 0 | No supporting evidence records |
| 1 | Weak inference (low-confidence heuristic match) |
| 2 | Single-source evidence, or a provisional mapping (hard cap) |
| 3 | A solid direct observation |
| 4 | Confidence-4 observation corroborated across source types |

**C — cost to run**

| C | Meaning |
|---|---|
| 0 | Free: a reference read or one robot command |
| 1 | Under an hour |
| 2 | About one focused session |
| 3 | Multi-session effort |
| 4 | A days-long campaign |

**R — risk if run**

| R | Meaning |
|---|---|
| 0 | Read-only |
| 1 | Additive only (new files, new tests) |
| 2 | Modifies code with test coverage behind it |
| 3 | Broad refactor or deploy-touching risk |
| 4 | Destructive potential or hard to reverse |

**D — already-done debt** (from the state machine, JUNCTURE-SIGNALS.md)

| D | State |
|---|---|
| 0 | not_seen |
| 1 | unknown, suggested_untried; completed after the 30-day window; declined with condition lifted |
| 2 | attempted_failed |
| 3 | in_progress, superseded |
| 4 | completed within the window; declined while the condition holds |

## How each dimension is computed

- **J** = clamp(max(weight of firing juncture-kind positive signals,
  `baseline_hygiene.severity` when its gap signal fires)). The hygiene severity is the ONLY
  J source for a project with no juncture history — which is exactly why only
  baseline-hygiene skills can reach RUN NOW there (worked example B).
- **A** = clamp(`accretive_base` + max weight of firing profile-kind positive signals −
  Σ anti-signal penalties), penalty 1 per weak and 2 per strong firing anti-signal. An
  anti-signal with `when: present` fires on presence; `when: absent` fires only on
  absence-with-positive-evidence — never on unknown.
- **E** = max confidence across all anchor records (supporters of every firing positive
  signal plus the hygiene gap), then −1 unless at least two distinct `source_type` values
  each contribute confidence ≥ 2, then capped at 2 when the skill's mapping is
  provisional, then clamped. Repeating confidence-1 records from another source cannot
  manufacture corroboration.
- **C**, **R** come from the skill's map entry (defaults 2/2).
- **D** from the already-done state machine; `completed_successfully` and `declined` split
  on the 30-day window / condition_holds respectively.

## Suppression gates run first

`completed_recently`, `declined_condition_holds`, and `in_progress` short-circuit RUN NOW
eligibility and cap the ledger row at KEEP HANDY (score ≥ 12) or CONSIDERED — regardless of
score. The row's tier reason is `suppressed:<gate>` so the reader sees the cap was a gate,
not arithmetic. Gates evaluate before tier thresholds, so no suppressed skill can leak into
a campaign as an anchor or a pair.

## Phase 5 is executable input, not commentary

The scorer requires all four Phase 5 artifacts even when they are empty: `gaps.json`,
`overrides.json`, `activations.json`, and `recipe-candidates.json`. It rejects an activation
file unless it covers the exact known-signal universe and every state plus supporting-id set
equals the state recomputed from active evidence. Unknown carries no supporting ids.

Every gap, override, provisional mapping, and recipe candidate must cite active evidence
that actually supports the named signal or live recipe trigger. Merely naming an evidence id
is insufficient. The run fingerprints these four files together with evidence, catalog,
already-done state, run configuration, data tables, and the previous run. `validate-run.py`
checks those hashes and recomputes the run from the supplied files, so editing a decision
input after scoring or omitting a supposedly inconvenient file fails closed.

A name established as retired by a complete catalog source remains in the audit ledger but
is scored inapplicable with basis `catalog-retired`; it cannot enter a tier or campaign.
The scorer cross-checks the run-config retirement list against the normalized catalog's
`retirement_known` flag and exact retired set, so a hand-authored or partial-list retirement
claim fails before scoring.

## The portfolio

**Eligibility is not selection.** Eligibility is per-skill (the RUN NOW rule above);
selection builds at most **3** complementary campaigns from the eligible list in tie-break
order. RUN NOW is a portfolio, not a leaderboard.

Campaign construction, per eligible anchor:

1. If a recipe in `references/data/combo-recipes.json` has this anchor, at least one of its
   declared trigger signals is present, a Phase 5 recipe-candidate record cites the trigger
   evidence, and every sequence member exists in the catalog, take its sequence. Pairs are
   dropped when inapplicable or suppressed; prerequisite members are dropped when already
   satisfied (completed/superseded state, or a `satisfied_by_signals` signal present).
   Recursively insert every applicable unsatisfied prerequisite before the member that
   needs it. No live recipe → prerequisites first, then the anchor.
2. **Budget**: campaign effort = the sum of C across distinct members. One campaign in the
   portfolio may cost up to 12; every other campaign must cost ≤ 6. A candidate that would be the second
   expensive campaign is rejected (`portfolio_budget`).
3. **Overlap**: rejected (`portfolio_overlap`) when any member pair is linked by an
   `alternative_to` edge, or when the anchors' firing-signal sets overlap by more than 50%
   of the smaller set — two treatments of one disease.
4. Capacity: beyond 3 campaigns, or already included as a member of a selected campaign →
   `portfolio_capacity`.

Rejected-but-eligible skills land in RUN SOON with the rejection reason, and appear as
**runners-up** on the campaign that beat them (plus any runner-up the recipe itself
declares, with its why-it-lost line). Campaign members get ledger disposition `run_now` with
role `campaign_pair`/`campaign_prerequisite` even when their own row would not qualify.

## Worked example A: parser project with recurring panics

Rust CLI with hand-written parsers; panics recur in commits and sessions; no fuzz targets.

Evidence: `code-parser` present (conf 3, file, `src/lexer.rs@a1b2c3d:41`);
`gap-parser-no-fuzz` present (conf 3, file, same locator — derived gaps reuse the base
signal's locator); `jx-recurring-panics` present twice — git vocabulary (conf 3, locator a
commit sha) and a cass battery hit (conf 3, `...jsonl:212@local`).

Scoring `testing-fuzzing` (map: C=2, R=1, base=1; positives gap-parser-no-fuzz w4,
jx-recurring-panics w3, code-parser w2; the anti-signal tests-fuzz-targets, `when: present`, does not fire):

```
J = 3        (jx-recurring-panics, weight 3, is the strongest firing juncture signal)
A = 4        clamp(1 + 4)   — gap-parser-no-fuzz w4 is the best firing profile signal
E = 3        max conf 3; source types {file, git, cass} → no single-source penalty
C = 2  R = 1  D = 0 (not_seen)
score = 5·3 + 4·4 + 3·3 − 2·2 − 2·1 − 3·0 = 15 + 16 + 9 − 4 − 2 = 34
```

Eligible: 34 ≥ 30; J=3; E=3; distinct anchors = 3 (`src/lexer.rs@a1b2c3d:41` + two juncture
locators) with ≥ 1 profile and ≥ 1 juncture. The parser-hardening recipe anchors campaign 1:
`testing-fuzzing` + `multi-pass-bug-hunting` (pair). Campaign effort = 2 + 3 = 5 — legal
as the single ≤ 12 campaign; every other selected campaign must cost ≤ 6. Runner-up from the
recipe: `testing-golden-artifacts` (goldens catch drift, not crashes on hostile input).

`multi-pass-bug-hunting` on its own row: J=3, A=1 (no profile positives), E=3, C=3, R=2 →
15 + 4 + 9 − 6 − 4 = 18 — not eligible alone (no profile anchor, score < 30), yet it ships
inside the campaign with role `campaign_pair`.

## Worked example B: no-history project

Fresh clone on a new machine: the cass workspace aggregate confirms zero sessions
(`jx-onboarding`), the 14-day git window is quiet, no beads events. No juncture-kind
positive signal fires for anything → the normal RUN NOW route (which requires a juncture
anchor) is closed for every skill. Only baseline-hygiene entries can reach RUN NOW.

The project is a clap CLI with 9 subcommands, no `--json` anywhere, and agent scaffolding.
Evidence: `code-cli-subcommands` present (conf 3, `src/cli.rs@f00dfeed`);
`json-mode-missing-for-cli` present (conf 3, same locator — derived);
`code-agent-swarm-scaffolding` present (conf 4, `.beads@f00dfeed`).

Scoring `agent-ergonomics-and-intuitiveness-maximization-for-cli-tools` (C=2, R=2, base=1;
hygiene gap json-mode-missing-for-cli severity 3):

```
J = 3        no juncture fires; baseline_hygiene severity 3 supplies J
A = 4        clamp(1 + 4)   — json-mode-missing-for-cli w4
E = 3        max conf 4, but every anchor is source_type file → −1
C = 2  R = 2  D = 0
score = 15 + 16 + 9 − 4 − 4 = 32
```

Hygiene route: 32 ≥ 30, J ≥ 3, E ≥ 3, and TWO distinct profile anchors
(`src/cli.rs@f00dfeed`, `.beads@f00dfeed`) → RUN NOW. Note the trap: without the
scaffolding record there is only one distinct locator (the derived gap shares the CLI
file's) and the row stops at RUN SOON.

Contrast: `multi-pass-bug-hunting` here scores J=0, A=1, E=0, C=3, R=2 →
0 + 4 + 0 − 6 − 4 = −6 → CONSIDERED, NOT NOW. Correct: nothing is failing yet.

## Worked example C: suppressed despite the score

Same parser project, three weeks later. `testing-fuzzing` was run and recorded
`completed_successfully` 10 days ago (closed bead + committed fuzz targets). A new parser
module landed without a target, so `gap-parser-no-fuzz` fires again; panics resumed; the
user said so this session (a user-statement record, conf 4, tagged jx-recurring-panics).

```
Pre-D subtotal: J=3, A=4, E=4 (conf 4; sources {file, git, cass, user-statement}), C=2, R=1
                5·3 + 4·4 + 3·4 − 2·2 − 2·1 = 15 + 16 + 12 − 4 − 2 = 37
Already-done:   completed_successfully, since = 10 days ago → inside the 30-day window
                D = 4 → score = 37 − 12 = 25
```

The `completed_recently` gate caps the row at KEEP HANDY, tier reason
`suppressed:completed_recently` — even though 25 would otherwise clear RUN SOON, and even a
score above 30 would change nothing, because gates run before tier rules. On day 31 the
window lapses: D drops to 1, score = 37 − 3 = 34, the gate lifts, and the row competes for
RUN NOW again — with the ledger noting the previous completion.
