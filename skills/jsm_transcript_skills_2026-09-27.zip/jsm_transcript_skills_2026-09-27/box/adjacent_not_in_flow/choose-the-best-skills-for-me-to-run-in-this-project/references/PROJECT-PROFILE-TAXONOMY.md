# Project Profile Taxonomy

What Phase 2 measures about a target project, the exact detector each dimension uses, and the
signal ids each observation feeds. The deterministic detector is `scripts/profile-project.sh`
(evidence JSON, ids `ev-p0001..`); profiler subagents add only what a script cannot judge.
Signal ids and kinds are canonical in `references/data/signal-to-skill-map.json`.

## Contents

- [The three-state evidence rule](#the-three-state-evidence-rule)
- [Evidence record examples (one per state)](#evidence-record-examples-one-per-state)
- [Identity and purpose](#identity-and-purpose)
- [Languages, build, toolchains](#languages-build-toolchains)
- [Kinds of code](#kinds-of-code)
- [Tests present and the gap logic](#tests-present-and-the-gap-logic)
- [Docs and process artifacts](#docs-and-process-artifacts)
- [Delivery surface and polish gaps](#delivery-surface-and-polish-gaps)
- [Dimension → signals → detector](#dimension--signals--detector)

## The three-state evidence rule

Every claim about the target is exactly one of three states. This rule is load-bearing:
`unknown` is never treated as `absent`, and an absence claim is only as good as the search
that produced it.

| State | Meaning | When it may be recorded |
|---|---|---|
| `present` | The thing was observed | A match, file, or tool output exists; locator points at it |
| `absent-with-positive-evidence` | The search ran and found nothing | Only after generated/vendored paths were identified and excluded (the `code-generated-or-vendored-excluded` record must be `present` first); the record's `detail` states the threshold and exclusions |
| `unknown` | The question was not answered | Tool missing, timeout (rg/find get 60s), scan error, non-git target for a git question — the error text goes in `detail` |

Consequences:

- A code-kind absence claim before the exclusion record exists is invalid evidence.
- `rg` exit 124/142 (timeout) or 2 (error) → `unknown`, never `absent`.
- Scoring treats `unknown` gates as "applicable but unverified", never as a firing anti-signal.

## Evidence record examples (one per state)

All three conform to `references/schemas/evidence.schema.json`.

```json
{
  "id": "ev-p0031",
  "claim": "hand-written parser/lexer/decoder present",
  "kind": "profile",
  "polarity": "positive",
  "state": "present",
  "source_type": "file",
  "locator": "src/lexer.rs@a1b2c3d:41",
  "observed_at": "2026-08-26T00:00:00Z",
  "command": "rg -n --hidden -e '\\bfn (parse|lex|tokenize|decode)[A-Za-z0-9_]*\\(' <generated/vendored exclusions> <test-path exclusions> -- .",
  "repo_head": "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0",
  "origin_host": null,
  "confidence": 3,
  "signals": ["code-parser"],
  "detail": "9 matches in 3 files (generated/vendored paths excluded; test paths excluded); e.g. src/lexer.rs:41: fn parse_frame(input: &[u8])"
}
```

```json
{
  "id": "ev-p0052",
  "claim": "fuzz harness code absent",
  "kind": "profile",
  "polarity": "negative",
  "state": "absent-with-positive-evidence",
  "source_type": "file",
  "locator": null,
  "observed_at": "2026-08-26T00:00:00Z",
  "command": "rg -n --hidden -e 'fuzz_target!|LLVMFuzzerTestOneInput|cargo[- ]fuzz' -- .",
  "repo_head": "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0",
  "origin_host": null,
  "confidence": 3,
  "signals": ["tests-fuzz-targets"],
  "detail": "0 matches (threshold 1) generated/vendored paths excluded (see code-generated-or-vendored-excluded)"
}
```

```json
{
  "id": "ev-p0068",
  "claim": "concurrency primitives in non-test code: scan timed out",
  "kind": "profile",
  "polarity": "positive",
  "state": "unknown",
  "source_type": "file",
  "locator": null,
  "observed_at": "2026-08-26T00:00:00Z",
  "command": "rg -n --hidden -e '\\b(Mutex|RwLock|Atomic(Usize|U64|Bool))\\b' -- .",
  "repo_head": "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0",
  "origin_host": null,
  "confidence": 0,
  "signals": ["code-concurrency-primitives"],
  "detail": "timeout after 60s"
}
```

## Identity and purpose

What the project IS and who consumes it. Detected from manifests first, source scans second.

| Signal | Detection (as profile-project.sh runs it, or an equivalent one-liner) |
|---|---|
| `proj-cli` | Manifest bin targets (`[[bin]]`, `package.json` bin, `[project.scripts]`), CLI framework deps (clap/argparse/cobra/commander), or `rg -n '^package main$' -g '*.go'` |
| `proj-library` | `[lib]`/`src/lib.rs`, npm main/exports without bin, pyproject without scripts |
| `proj-tui` | tui deps: ratatui/crossterm/cursive/bubbletea/tcell/textual/blessed/ink |
| `proj-daemon` | `.service`/`.plist` unit files, else `rg 'ListenAndServe|TcpListener::bind|axum::serve|serve_forever'` |
| `proj-web-app` | Web framework dep (next/django/axum/express/...), else `rg 'Router::new\(\)|@app\.route\(|NextResponse'` |
| `proj-saas` | `proj-web-app` present AND a payments dep (stripe/paypal/paddle/lemonsqueezy) — auth-only demotes confidence to 2 |
| `proj-mcp-server` | MCP SDK dep, else `rg 'McpServer|FastMCP|ListToolsRequestSchema|StdioServerTransport'` |
| `proj-browser-extension` | `manifest.json` with `manifest_version` AND background/content_scripts/action keys |
| `proj-wasm-target` | wasm-bindgen/wasm-pack/trunk deps, cargo config targeting wasm32, or `rg 'wasm32-unknown-unknown|wasm-pack build'` in build files |
| `proj-mobile` | Xcode project, gradle app module, AndroidManifest, Podfile, capacitor config, or react-native/expo dep |
| `proj-data-pipeline` | airflow/dagster/dbt/polars/pandas deps (when not a web app), dags/pipelines/etl layout, or DAG/COPY INTO/read_parquet scans |
| `proj-ml-inference` | Weight files (`.safetensors`/`.gguf`/`.onnx`/`.pt`), or torch/onnxruntime/candle/tract/ggml deps |
| `proj-research-code` | Notebooks or papers/experiments dirs AND no packaging manifest |
| `proj-monorepo` | Cargo workspace ≥ 2 members, npm workspaces, go.work/pnpm-workspace, or ≥ 3 manifest directories |
| `proj-docs-site` | nextra/docusaurus/vitepress/starlight/mkdocs/mdBook/sphinx config or dep |
| `proj-marketing-site` | site/website/www/landing dir with an app inside, else a non-registry homepage URL in a manifest |
| `proj-skills-repo` | ≥ 2 SKILL.md files in the inventory |
| `proj-is-*` | Package/crate names matched against the identity table (exact name or `<prefix>-x`/`<prefix>_x`) |
| `user-asked-*` | Orchestrator-only: fires only when the user's own words in this session asked for it (`default_state` is absent-with-positive-evidence, so silence is a clean absence, not unknown) |

## Languages, build, toolchains

A language is primary when its manifest exists (confidence 4) or its line share clears the
threshold (confidence 3): default 15% of code LOC and ≥ 3 files; JavaScript 25%, C/C++ 20%,
shell 10% (or shell is the largest language).

| Signal | Detection |
|---|---|
| `lang-rust` / `lang-typescript` / `lang-python` / `lang-go` / `lang-zig` / `lang-c-cpp` | Cargo.toml / tsconfig.json / pyproject.toml (or requirements/setup.py) / go.mod / build.zig / CMakeLists.txt, else line-share |
| `lang-javascript` | package.json with no tsconfig, else 25% line-share |
| `lang-shell`, `lang-swift-kotlin-java` | Line-share only |
| `build-cargo-workspace` | `[workspace]` members parsed from Cargo.toml |
| `cargo-profile-tuned` | `[profile.release]` keys (lto/codegen-units/opt-level/panic/strip) or `-C target-cpu` in cargo config |
| `cargo-features-heavy` | features max ≥ 5 or optional deps ≥ 3 |
| `native-ffi-deps` | build.rs with cc/bindgen/cmake, `-sys` crates, binding.gyp, node-gyp/cffi/pybind11/maturin deps |
| `unusual-pins` | git/path dependencies or exact `=` pins in manifests |
| `framework-heavy` | Framework dep AND ≥ 15 direct deps, or ≥ 40 direct deps |
| `hand-rolled` | ≤ 10 direct deps and no framework dep (unknown when no manifest exists) |
| `fw-nextjs` `fw-supabase` `fw-vercel` `fw-cloudflare-workers` `fw-tanstack` `fw-stripe` `fw-paypal` `fw-snowflake` `fw-ga4` `fw-playwright` `fw-drizzle-prisma` `fw-tokio` `fw-charm-bubbletea` `fw-threejs` `fw-nextra` | Dependency-name regex over parsed manifests, falling back to a config-file pattern (e.g. `wrangler.toml`, `playwright.config.*`) |
| `fw-gh-actions` | Workflow yml files under the .github workflows dir |
| `dep-frankensqlite` `dep-asupersync` `dep-frankensearch` `dep-frankentui` | Crate-name regex over Cargo.toml deps + Cargo.lock names, excluding the workspace's own crates |
| `deps-outdated` | Newest commit (else mtime) of each lockfile older than 180 days; emits confidence 1 and means only "dependency freshness review due" until a real outdated check corroborates it |

## Kinds of code

Each kind: what it is, how it is found, and the signal it feeds. All scans run `rg` over
non-generated source (see exclusions below) with test paths excluded where noted (nt),
60s timeout, minimum-match thresholds in parentheses.

**Exclusions come first.** Before any code-kind claim, the inventory pass excludes generated
and vendored paths — target, node_modules, vendor, dist, build, third_party, upstream,
legacy*, .next, coverage, venvs, lockfiles, `*.min.js`, `*.generated.*`, protobuf output,
plus `.gitattributes` linguist-generated/vendored globs — and records
`code-generated-or-vendored-excluded` (present) with the counts. Only then may any kind be
declared absent.

| Signal | What it is | Detection pattern (rg -n, nt = non-test) |
|---|---|---|
| `code-parser` (nt, ≥2) | Hand-written parser/lexer/decoder over untrusted input | `\bfn (parse\|lex\|tokenize\|decode)\w*\(\|impl FromStr for\|\b(nom\|winnow\|pest\|logos\|chumsky\|lalrpop\|tree_sitter)::\|(struct\|class) (Parser\|Lexer\|Tokenizer)` |
| `code-binary-format` (nt, ≥2) | Binary format read/write | `from_(le\|be)_bytes\|byteorder::\|\bMAGIC(_NUMBER)?\b\|struct\.(pack\|unpack)\(\|encoding/binary\|zerocopy::\|bytemuck::` |
| `code-network-protocol` (nt, ≥2) | Custom wire protocol/transport | `framing\|Frame::\|Codec\|handshake\|quinn::\|QUIC\|UdpSocket\|tokio_util::codec\|LengthDelimited\|raptorq\|PROTOCOL_VERSION` |
| `code-storage-engine` (nt, ≥2) | WAL/MVCC/B-tree/page-cache/fsync internals | `\bWAL\b\|write_ahead\|\bMVCC\b\|B[-+]?[Tt]ree\|page_cache\|\bfsync\b\|sync_all\(\)\|\bLSM\b\|SSTable\|memtable\|\bPager\b` |
| `code-sqlite-persistence` (≥1) | State persisted in SQLite | sqlite dep regex over manifests, else `rusqlite::\|sqlite3\.connect\(\|Connection::open\(\|PRAGMA journal_mode` |
| `code-search-index` (nt, ≥2) | Search index implemented or embedded | search dep regex (tantivy/frankensearch/bm25/hnsw/...), else `BM25\|InvertedIndex\|fts5\|TwoTierSearcher\|posting_list\|rrf_fuse` |
| `code-concurrency-primitives` (nt, ≥1) | Locks/channels/atomics in non-test code | `\b(Mutex\|RwLock\|Condvar\|Semaphore\|Atomic\w+\|parking_lot\|tokio::sync\|crossbeam\|mpsc::channel\|sync\.(Mutex\|RWMutex))\b` |
| `code-lock-free` (nt, ≥1) | Explicit ordering / lock-free structures | `Ordering::(Acquire\|Release\|AcqRel\|SeqCst\|Relaxed)\|crossbeam_epoch\|compare_exchange\|fetch_(add\|sub)\(\|memory_order_` |
| `code-async-holding-lock` (nt) | Guard live across `.await`, or `block_on` in async fn | Two `rg -l` passes (`.await`, `.lock()/.read()/.write()`) intersected, then a python pass: guard and `.await` within 10 lines in the same fn (heuristic, confidence 2) |
| `code-unsafe-any` / `code-unsafe-heavy` (nt) | Any unsafe / unsafe-dense Rust | `^[^/]*\bunsafe\s*(\{\|fn\b\|impl\b\|trait\b\|extern\b)` in `*.rs`; heavy = ≥ 5 sites or ≥ 1 per 500 non-test Rust LOC |
| `code-ffi-boundary` (nt, ≥1) | extern "C"/bindgen/N-API/cffi/JNI | `extern "C"\|#\[no_mangle\]\|bindgen::\|#\[napi\|\bcffi\b\|ctypes\.\|import "C"\|#\[pyfunction\]` |
| `code-wasm-bindgen` (nt, ≥1) | wasm-bindgen/js-sys/web-sys usage | `#\[wasm_bindgen\|js_sys::\|web_sys::` in `*.rs` |
| `code-simd-hot-loops` (nt, ≥1) | SIMD intrinsics / explicit vectorization | `(core\|std)::arch::\|_mm(256\|512)?_\w+\(\|#\[target_feature\|std::simd\|#\[inline\(always\)\]` |
| `code-gpu-cuda` (≥1) | GPU kernels | Kernel file extensions (.cu/.cuh/.metal/.wgsl/.cl) in inventory, else `__global__\|cudaMalloc\|wgpu::\|MTLDevice\|kernel void` |
| `code-ml-kernels` (nt, ≥2) | Matmul/attention/quantization in-tree | `(fn\|def\|func) (matmul\|gemm\|attention\|softmax\|rms_?norm\|rope\|quantize\|dequantize\|kv_cache)\w*\(\|\b(vdotq\|VNNI\|SDOT)\b` |
| `code-numeric-transforms` (nt, ≥3) | Numeric/transform code with algebraic relations | `fft\|convolve\|eigen\|quantile\|variance\|dijkstra\|pagerank\|kalman\|welford\|histogram\|reed_solomon\|cosine_similarity\|matmul` |
| `code-codegen-renderer` (nt, ≥2) | Durable-artifact producers (renderers, generators, exporters) | `\b(Renderer\|CodeGen\|Emitter\|Exporter)\b\|fn (render\|to_html\|to_svg\|to_pdf\|generate_code\|emit\|export_\w+)\(\|(tera\|askama\|handlebars\|minijinja)::` |
| `code-tui-renderer` (nt, ≥2) | Bespoke terminal renderer/layout engine | `struct (Cell\|CellBuffer\|ScreenBuffer\|Grid\|Surface)\b\|\\x1b\[\|EnterAlternateScreen\|(termwiz\|vte\|vt100\|crossterm\|ratatui)::` |
| `code-spec-reimplementation` (≥2) | Reimplements a spec or upstream oracle | SPEC/conformance/PARITY/oracle files in inventory, else vocabulary scan (`RFC \d+\|conformance\|bit-identical\|parity (matrix\|harness)`) |
| `code-port-of-other-language` (≥2) | A port to Rust (or similar) | upstream/reference/orig source dirs or PORT/PARITY docs, else port vocabulary (`ported from\|faithful port\|1:1 port\|parity with`) |
| `code-cli-subcommands` (nt) | CLI surface with ≥ 5 subcommands | `rg -l` for Subcommand/Command::new/AddCommand/add_parser, then a python pass counting clap enum variants / builder / registration calls; threshold 5 |
| `code-json-robot-mode` (nt, ≥1) | CLI --json/--robot output | `--json\b\|--robot\b\|--format[= ]json\|OutputFormat::Json` |
| `code-doctor-command` (nt, ≥1) | doctor/diagnose subcommand | `"doctor"\|\bDoctor\b\|"diagnose"\|"healthcheck"` |
| `code-installer-script` (≥1) | Installer exists | install.sh/install.ps1 in inventory, else curl-pipe-shell scan in docs |
| `code-release-workflow` | Release automation | release/publish workflow files, cargo-dist/goreleaser/release-please/cliff config, semantic-release deps |
| `code-crypto-auth` (nt, ≥2) | Crypto or auth code | `ring::\|rustls\|ed25519\|hmac::\|argon2\|jsonwebtoken\|OAuth2?\|PKCE\|NextAuth\|crypto\.subtle\|verify_signature` |
| `code-payments-billing` (nt, ≥3) | Billing logic | `Stripe\|stripe\.(webhooks\|checkout\|subscriptions)\|PaymentIntent\|Invoice\|entitlement\|billing_portal\|price_id` |
| `code-webhooks` (nt, ≥1) | Inbound webhook handlers | `webhook\|constructEvent\|verify_webhook\|X-Hub-Signature\|Stripe-Signature\|svix` |
| `code-arena-self-referential` (nt, ≥2) | Arena/slab/self-referential structures | `Pin<\|pin_project\|NonNull<\|\*mut \|(Arena\|Slab<\|SlotMap\|bumpalo\|petgraph\|NodeIndex)` |
| `code-mcp-tools` (nt, ≥1) | MCP tool definitions in-tree | `@mcp\.tool\|server\.(tool\|registerTool)\(\|"tools/call"\|rmcp::\|FastMCP\(` |
| `code-agent-swarm-scaffolding` | Swarm scaffolding | `.beads/` dir, `.agent-mail-project-id`, ntm config files, else swarm-orchestration vocabulary in agent docs |
| `monolith-file` | One file dominates | Line counts per non-test code file: > 3000 lines, or ≥ 1500 and > 5% of code LOC in a ≥ 20k-LOC tree |
| `tangled-code` | Deep nesting, god modules, cycles | Subagent judgment (profiler for code kinds) — not scriptable; cite files and line spans |

## Tests present and the gap logic

Test kinds, then derived gaps. `tests-none` is an aggregate: present only when unit,
integration, e2e, property, fuzz, golden, and conformance are ALL absent-with-positive-evidence.

| Signal | Detection |
|---|---|
| `tests-unit` | `#[test]\|#[cfg(test)]\|def test_\|func Test[A-Z]\|(it\|test\|describe)\(\|@pytest\.\|XCTestCase` |
| `tests-integration` | Integration-test file layout in inventory, else integration markers scan |
| `tests-e2e` | e2e/cypress layout, Playwright configured, else real-binary/browser drivers (`assert_cmd::\|cargo_bin(\|page.goto(\|execa(`) |
| `tests-property` | proptest/quickcheck/hypothesis/fast-check deps, else `proptest!\|@given\(\|fc\.assert` |
| `tests-fuzz-targets` | Fuzz-target layout or Cargo fuzz manifest, else `fuzz_target!\|LLVMFuzzerTestOneInput\|func Fuzz\|cargo[- ]fuzz` |
| `tests-golden` | insta/expect-test/goldie/syrupy deps or snapshot/golden/testdata files (`.snap`, `.golden`), else snapshot-assertion scan |
| `tests-metamorphic` | `metamorphic\|relation_test\|invariance_test\|test_mr_\|MR[0-9]+` |
| `tests-conformance` | conformance/parity/compat dirs, else `parity_matrix\|oracle_test\|against_upstream\|differential_test` |
| `tests-loom-shuttle` | loom/shuttle dep, else `loom::\|#[cfg(loom)]\|shuttle::check` |
| `tests-miri` | `cargo miri\|MIRIFLAGS\|cargo careful` in CI/scripts/build files |
| `tests-sanitizer` | `-Zsanitizer=\|-fsanitize=\|ASAN\|TSAN\|valgrind` in CI/scripts/build files |
| `tests-use-mocks` | mockall/wiremock/msw/sinon/gomock/testify deps, else mock/patch/Fake*/Stub* scan |
| `tests-real-services` | `testcontainers\|DATABASE_URL\|docker[ -]compose\|localhost:(5432\|6379...)` under test paths and CI; spawning a local process or CLI alone is not a real-service seam |
| `tests-flaky-markers` | `#[ignore]\|@pytest\.mark\.skip\|\.skip(\|t\.Skip(\|retry\|thread::sleep(` under test paths |
| `tests-static-analysis-gate` | CI files scanned for `clippy -D warnings\|ubs\|eslint\|mypy\|semgrep\|ruff\|golangci-lint\|shellcheck` |

**Gap logic (the both-sides-known rule).** A `gap-*` signal is derived, present only when the
code side is `present` AND every covering test kind is `absent-with-positive-evidence`. Any
`unknown` input makes the gap `unknown` — a gap is never inferred through a failed scan.
When the code side is absent, the gap is absent ("no gap") — a clean negative, not a shrug.

| Gap signal | Code side (any present) | Test side (all absent) |
|---|---|---|
| `gap-parser-no-fuzz` | code-parser, code-binary-format | tests-fuzz-targets |
| `gap-concurrency-no-model` | code-concurrency-primitives | tests-loom-shuttle, tests-sanitizer |
| `gap-payments-no-webhook-replay` | code-webhooks, code-payments-billing | ad-hoc: replay/idempotency scan under test paths |
| `gap-cli-no-json-snapshot` | code-json-robot-mode | ad-hoc: json-snapshot scan under test paths |
| `gap-webapp-no-e2e` | proj-web-app | tests-e2e |
| `gap-numeric-no-metamorphic` | code-numeric-transforms | tests-metamorphic, tests-property |
| `gap-renderer-no-golden` | code-codegen-renderer | tests-golden |
| `gap-spec-no-conformance` | code-spec-reimplementation, code-port-of-other-language | tests-conformance |
| `gap-mocks-without-real-e2e` | tests-use-mocks | tests-real-services |
| `gap-unsafe-no-miri` | code-unsafe-any | tests-miri, tests-sanitizer |

## Docs and process artifacts

Presence is scripted; content judgment belongs to the docs-and-process profiler subagent,
which READS THE FULL FILE whenever one of these exists: README, AGENTS.md/CLAUDE.md, plan
files, CONTRIBUTING, ADRs. A skimmed README is not evidence of anything.

| Signal | Detection |
|---|---|
| `docs-agents-md` | AGENTS.md or CLAUDE.md at target or scope root |
| `docs-readme-missing` / `docs-readme-weak` | README lookup; weak = < 60 lines, or no install/usage/getting-started heading, or template phrases |
| `docs-changelog-missing` | No changelog file although version tags exist (no tags → not a gap) |
| `docs-changelog-stale-vs-tags` / `docs-changelog-fresh` | Last commit touching the changelog vs newest tag date; does the changelog mention the newest tag string |
| `docs-plan-file` | PLAN*/ROADMAP*/TODO.md/plan-dir markdown in inventory |
| `docs-adrs` | adr/decisions/design/rfcs markdown layout |
| `docs-contributing`, `docs-security-md`, `docs-license`, `issue-templates` | File lookups (root and .github) |
| `docs-prose-sounds-generated` | Subagent judgment over public-facing prose: model-written tells, cited phrases |
| `beads-present` / `beads-absent` | `.beads/` directory (both sides emitted explicitly) |
| `agent-mail-project` | `.agent-mail-project-id` file |
| `ci-config` / `ci-none` | Known CI config paths (workflows, gitlab-ci, circleci, Jenkinsfile, buildkite, azure, travis, drone) |
| Maturity (`maturity-greenfield` / `-active-buildout` / `-stabilization` / `-maintenance` / `-revived`) | Git facts: commit count, age, tags, commits in last 90 days, fix-like vs feat-like share of last 50 subjects, longest dormant gap (> 90 days then recent activity = revived) |

## Delivery surface and polish gaps

How the project reaches users, and what is missing at that surface.

| Signal | Detection |
|---|---|
| `published-registry` | `timeout 30 cargo search --limit 1 <crate>`, `timeout 30 npm view <pkg> version`, or a PyPI JSON lookup; publish=false/private=true in a manifest is a clean absence |
| `public-facing` | `timeout 30 gh repo view --json isPrivate` on a GitHub remote; registry publication as fallback evidence; gh missing → unknown |
| `release-tags-present` / `releases-none` | `git tag -l --sort=-creatordate` filtered to version-like tags |
| `installer-missing-for-cli` | Derived: proj-cli AND release-tags-present AND NOT code-installer-script |
| `installer-weak` | The installer file grepped for checksums, platform detection, version pin, uninstall — missing any is the finding |
| `doctor-missing-for-cli` | Derived: code-cli-subcommands present AND code-doctor-command absent |
| `json-mode-missing-for-cli` | Derived: code-cli-subcommands present AND code-json-robot-mode absent |
| `docs-site-missing` | Derived: public-facing AND ≥ 5 docs markdown files (or ≥ 500 lines) AND NOT proj-docs-site |
| `og-image-missing` | No og:image/openGraph references in site sources and no social-preview image file (confidence 2 — the GitHub web-UI setting is not visible from the tree) |
| `bench-harness-present` | benches layout, criterion/divan/hyperfine markers, `#[bench]`, `testing.B` |
| `media-video-files-present`, `media-audio-files-present`, `iphone-takes-present`, `screencast-present`, `slack-export-present` | `find` over the tree (media are often gitignored), name-pattern classification |

## Dimension → signals → detector

| Dimension | Signals | Detector |
|---|---|---|
| Identity & purpose | `proj-*`, `user-asked-*` | profile-project.sh; orchestrator for user-asked-* |
| Languages/build/toolchains | `lang-*`, `build-*`, `cargo-*`, `fw-*`, `dep-*`, `native-ffi-deps`, `unusual-pins`, `framework-heavy`, `hand-rolled`, `deps-outdated` | profile-project.sh (build-and-deps profiler verifies oddities) |
| Kinds of code | `code-*`, `monolith-file`, `tangled-code` | profile-project.sh; subagent for tangled-code |
| Tests & gaps | `tests-*`, `gap-*` | profile-project.sh (tests profiler reads suspicious tests) |
| Docs & process | `docs-*`, `beads-*`, `agent-mail-project`, `ci-*`, `maturity-*`, `docs-prose-sounds-generated` | profile-project.sh; docs-and-process profiler reads files fully |
| Delivery surface & polish | `published-registry`, `public-facing`, `release*`, `installer-*`, `*-missing-for-cli`, `docs-site-missing`, `og-image-missing`, `bench-harness-present`, `media-*`, `slack-export-present` | profile-project.sh; delivery-surface profiler |

Juncture-kind signals (`jx-*`) are deliberately not here: they describe the moment, not the
project. See JUNCTURE-SIGNALS.md.
