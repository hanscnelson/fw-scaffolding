<!-- generated_from_sha256: sha256:7fe679a1ea022c5f85b27c5106959933799579ca0af81aa2a3f61e28041c39c5 -->
<!-- generated_at: 2026-08-27T14:00:00Z -->
<!-- generator_version: 2.0.0 -->
<!-- GENERATED VIEW - do not hand-edit. Source: references/data/catalog-snapshot.json; regenerate with scripts/render-reference-views.py -->


# Catalog Snapshot (generated view)

Refreshed 2026-08-26T13:30:00Z — 131 public skills; newest update 2026-08-26T06:34:33.181Z; listing sha `2446fdde986d3107…`.

| Skill | Category | Packs | Updated | Related | Use when |
|---|---|---|---|---|---|
| ab-testing | other | saas-development | 2026-08-06 | 1 | Use when: A/B test, experiment, variant, conversion optimization, or personalization. |
| admin-page-for-nextjs-sites | other | — | 2026-08-06 | 0 | Use when building or expanding `/admin` and `/api/admin` with unified IA, permissions, audit, analytics, ops, moderatio… |
| agent-ergonomics-and-intuitiveness-maximization-for-cli-tools | other | agent-orchestration, code-quality, term… | 2026-08-06 | 0 | Use when auditing agent-friendly CLI UX, robot/json modes, help/errors, or applying fixes in-tree. |
| agent-fungibility-philosophy | other | — | 2026-08-06 | 1 | Use when scaling agent swarms, designing multi-agent workflows, recovering from agent failures, or choosing specialized… |
| agent-mail | other | agent-orchestration, mcp-development | 2026-08-06 | 5 | Use when agents need file locks, messaging, inboxes, or conflict prevention. Handles macro_start_session, file_reservat… |
| ai-model-into-rust-mega-fused-hyper-kernel | other | rust-development | 2026-08-06 | 0 | Use when: frankenize a model, port model weights to Rust, custom inference engine, int8 SIMD kernels (SDOT/VNNI), bit-i… |
| asupersync-mega-skill | other | — | 2026-08-14 | 0 | Use when migrating Tokio/axum/hyper/tonic apps, designing Cx/region services, debugging internals, or classifying proof… |
| automating-your-automations | other | — | 2026-08-06 | 0 | Use when analyzing command patterns or finding automation opportunities. |
| bd-to-br-migration | other | — | 2026-08-06 | 0 | Use when updating AGENTS.md, converting bd commands, "bd sync" → "br sync --flush-only", or beads migration. |
| beads-br | other | agent-orchestration | 2026-08-06 | 2 | Use when tracking tasks, managing dependencies, finding ready work, or syncing issues to git via JSONL. |
| beads-bv | other | agent-orchestration | 2026-08-06 | 2 | Use when prioritizing work, finding bottlenecks, tracking dependencies, or managing local issues across projects. |
| beads-compliance-and-completion-verification | other | agent-orchestration, code-quality | 2026-08-06 | 0 | Use when "audit closed beads", "false-closed beads", "beads compliance audit", or "did we actually finish". |
| beads-workflow | other | agent-orchestration | 2026-08-06 | 2 | Use when creating task graphs, polishing beads before implementation, or bridging planning to agent swarm execution. |
| brenner | other | — | 2026-08-06 | 0 | Use when in your brenner_bot repo, managing hypotheses, searching corpus, or running multi-agent sessions. |
| brennerbot-with-ntm | other | agent-orchestration, research-explorati… | 2026-08-06 | 0 | Use when investigating design spaces, adversarial audits, incident RCA, methodology distillation, or session resume/dri… |
| browser-extension-automation | other | — | 2026-08-06 | 1 | Use when Google blocks Playwright, OAuth flows fail, or "browser may not be secure" errors appear. |
| caam | other | — | 2026-08-14 | 1 | Use when hitting rate limits on Claude Max, GPT Pro, or Gemini Ultra subscriptions and need instant account swapping wi… |
| cass | other | agent-orchestration | 2026-08-06 | 1 | Use when "what did I ask?", "find that prompt", session archaeology, or agent history. |
| cass-memory | other | agent-orchestration | 2026-08-06 | 0 | Use when starting non-trivial tasks, learning from past sessions, building playbooks, or preventing repeated mistakes v… |
| cc-hooks | other | — | 2026-08-06 | 0 | Use when blocking commands, auto-formatting, custom permissions, or writing hooks. |
| changelog-md-workmanship | other | code-quality | 2026-08-06 | 0 | Use when writing changelogs, version timelines, or agent-facing project history summaries. |
| code-review-gemini-swarm-with-ntm | other | agent-orchestration, code-quality | 2026-08-06 | 0 | Use when "gemini review swarm", "agy review swarm", "code review with gemini/agy", or multi-round code auditing with Ge… |
| codebase-archaeology | other | essential, research-exploration | 2026-08-06 | 3 | Use when onboarding to new project, "what does this do", or understanding legacy code. |
| codebase-audit | other | code-quality | 2026-08-06 | 2 | Use when auditing code, assessing quality, finding issues, or pre-launch review. |
| codebase-pattern-extraction | other | research-exploration | 2026-08-06 | 2 | Use when "I've seen this before", DRY across repos, or building shared libraries. |
| codebase-report | other | research-exploration | 2026-08-06 | 1 | Use when onboarding, "write up what this does", architecture docs, or handoff. |
| csctf | other | — | 2026-08-06 | 1 | Use when archiving AI conversations, preserving code fences, or publishing transcripts to GitHub Pages. |
| cursor | other | terminal-power-user | 2026-08-06 | 1 | Use when opening files, comparing diffs, managing extensions, or configuring Cursor as git editor. |
| dcg | other | code-quality, essential | 2026-08-06 | 1 | Use when dcg blocks rm -rf, git reset --hard, DROP DATABASE, kubectl delete, or when configuring agent safety guardrail… |
| de-monolithize-your-codebase-isomorphically | other | code-quality | 2026-08-06 | 0 | Use when de-monolithize, split giant file, modularize repo, or file too big. |
| de-slopify | other | code-quality | 2026-08-17 | 2 | Use when polishing READMEs, docs, marketing copy, or public-facing text, or when text "sounds like ChatGPT". |
| deadlock-finder-and-fixer | other | code-quality, rust-development | 2026-08-06 | 0 | Use when processes hang, tests flake, or auditing concurrency. |
| documentation-website-for-software-project | other | saas-development | 2026-08-06 | 0 | Use when building a docs site, "docs site for this repo", MDX docs, or deploying docs to Vercel. |
| dsr | other | — | 2026-08-06 | 0 | Use when: GH Actions slow, local release, build hosts, dsr command. |
| dueling-idea-wizards | other | agent-orchestration | 2026-08-06 | 0 | Use when "dueling idea wizards", "competing ideas", "adversarial brainstorm", or cross-model idea evaluation for any pr… |
| e2e-testing-for-webapps | other | code-quality | 2026-08-06 | 0 | Use when: E2E, Playwright, visual regression, Electron testing. |
| eidetic-engine-cli | other | agent-orchestration | 2026-08-26 | 0 | Use when getting context before a task (`ee pack`; `ee context` is the soft-deprecated alias), capturing rules (`ee rem… |
| extreme-software-optimization | other | code-quality | 2026-08-06 | 0 | Use when: optimize, slow, bottleneck, hotspot, profile, p95, latency, throughput, or algorithmic improvements. |
| focr | other | rust-development | 2026-08-19 | 0 | Use when working with focr/franken_ocr: OCR CLI, OcrEngine, robot NDJSON, .focrq artifacts, Model Zoo (GOT, SmolVLM2, O… |
| frankensearch-integration-for-rust-projects | other | rust-development | 2026-08-06 | 0 | Use when: frankensearch, hybrid search, two-tier search, TwoTierSearcher, IndexBuilder, EmbedderStack, RRF fusion, sema… |
| frankensqlite-mega-skill | other | rust-development | 2026-08-14 | 0 | Use when fixing engine bugs, adding SQL features, running harnesses, or embedding fsqlite downstream. |
| frankensuite-website-development | other | — | 2026-08-06 | 0 | Use when creating a new FrankenSuite website, adding pages/sections, or adapting the design system for a different proj… |
| frankentui | other | — | 2026-08-06 | 0 | Use when working in ftui-demo-showcase, diagnosing TUI issues with doctor_frankentui, polishing TUI UX, or replacing pl… |
| fsnow | other | rust-development | 2026-08-06 | 0 | Use when querying Snowflake live/offline, integrating franken_snowflake crates, or working in the repo. |
| ftts | other | rust-development | 2026-08-14 | 0 | Use when you make WAV/raw PCM, fix robot JSON, enroll voices, inspect FTTSQ, benchmark FTTS_INT8, test resident mode, d… |
| fw | other | rust-development | 2026-08-14 | 0 | Use when work names fw/franken_whisper or its FastEnhancer browser: CLI, models, robot NDJSON, diarization, release, WA… |
| ga4 | other | saas-development | 2026-08-06 | 1 | Use when setting up analytics, tracking conversions, or implementing A/B tests. |
| gcloud | other | devops-infrastructure | 2026-08-06 | 1 | Use when working with Compute Engine, Cloud Run, GKE, Cloud Functions, Storage, BigQuery, or other GCP services. |
| gdb-for-debugging | other | code-quality | 2026-08-06 | 0 | Use when: process hang, spin loop, segfault, crash, backtrace, attach debugger, ptrace, core dump, thread starvation, a… |
| gh-actions | other | devops-infrastructure, essential | 2026-08-06 | 1 | Use when creating workflows, release automation, signing, checksums, cross-platform builds, or .github/workflows files. |
| gh-cli | other | devops-infrastructure, essential | 2026-08-06 | 3 | Use when working with GitHub or running gh commands. |
| gh-og-share-images | other | — | 2026-08-06 | 0 | Use when: social preview, GitHub share image, OG image for repo, social card, gh_share_image, preview image. |
| gh-triage-ru | other | — | 2026-08-06 | 1 | Use when processing issues, closing PRs (no-contributions policy), or bulk triage. Independent verification required. |
| ghostty | other | devops-infrastructure, terminal-power-u… | 2026-08-06 | 1 | Use when managing windows, tabs, splits, fonts, or configuration for Ghostty. |
| giil | other | — | 2026-08-06 | 0 | Use when extracting images from cloud share URLs, remote debugging with screenshots, or downloading shared photo albums. |
| git-repo-janitor | other | agent-orchestration, code-quality, devo… | 2026-08-06 | 0 | Use when "clean up my repo", "the repo junk cleaner", "tidy up the project root", "random `.db` / `.md` files committed… |
| git-stash-janitor | other | agent-orchestration, code-quality, devo… | 2026-08-06 | 0 | Use when a project has piled up stashes ("*N" in the prompt), "clean up my stashes", "stash archaeology", "are any of t… |
| git-worktree-branch-rationalization | other | agent-orchestration, code-quality, devo… | 2026-08-06 | 0 | Use when a project has piled up local branches or linked worktrees ("213 branches, 47 worktrees", agent-swarm aftermath… |
| idea-wizard | other | research-exploration | 2026-08-06 | 1 | Use when brainstorming features, planning improvements, creating beads from ideas, or "what should we build next". |
| installer-workmanship | other | — | 2026-08-06 | 0 | Use when creating install.sh, curl-pipe-bash installer, or one-liner install for CLI tools. |
| interactive-visualization-creator | other | — | 2026-08-06 | 0 | Use when creating diagrams, animations, simulations, or data visualizations. |
| iphone-videos-to-music-video-with-audio-track | other | — | 2026-08-17 | 0 | Use when editing music video footage, syncing takes to a song, or lip-sync editing. |
| just-say-no-to-process-porn-and-ceremony | other | agent-orchestration | 2026-08-10 | 0 | Use when auditing agent work for honesty, when progress looks busy but ships nothing, or for honesty inventories. |
| lean-formal-feedback-loop | other | code-quality | 2026-08-06 | 0 | Use when proving theorems, triaging hard proof blockers, checking conformance, or closing formal assurance gaps. |
| library-updater | other | essential, rust-development | 2026-08-06 | 2 | Use when upgrading libraries, updating Cargo.toml, pyproject.toml, package.json, go.mod, Gemfile, or modernizing depend… |
| mcp-server-design | other | mcp-development | 2026-08-06 | 1 | Use when building MCP tools, designing agent APIs, writing tool documentation, implementing error handling, or creating… |
| mock-code-finder | other | code-quality, research-exploration | 2026-08-06 | 0 | Use when "find mocks", "find stubs", "find placeholders", "check for fake code", or auditing for incomplete code. |
| modes-of-reasoning-project-analysis | other | agent-orchestration, research-explorati… | 2026-08-10 | 0 |  |
| multi-model-triangulation | other | research-exploration | 2026-08-06 | 1 | Use when "get a second opinion", evaluating approaches, or high-stakes decisions. |
| multi-pass-bug-hunting | other | code-quality | 2026-08-06 | 2 | Use when code review, deep audit, "find all bugs", or pre-release hardening. |
| ntm | other | agent-orchestration, terminal-power-user | 2026-08-06 | 5 | Use when spawning/sending panes, robot state, triaging work, locks/mail, safety, pipelines, serve, code-first/batch-ver… |
| og-share-images | other | saas-development | 2026-08-06 | 1 | Use when building OG images, Twitter cards, social previews, or share images. |
| operationalizing-expertise | other | research-exploration | 2026-08-06 | 1 | Use when distilling a methodology or mining session history into executable rules. |
| optimizing-your-rust-projects-for-wasm-in-browsers-and-phones | other | rust-development | 2026-08-12 | 0 | Use when: wasm, WebAssembly, wasm-pack, wasm-bindgen, browser port, web demo, SIMD128, wasm threads, SharedArrayBuffer,… |
| path-rationalization | other | terminal-power-user | 2026-08-06 | 0 | Use when PATH has junk, wrong binary resolves, temp dirs in PATH, or duplicates. |
| pi-agent-rust | other | — | 2026-08-06 | 0 | Use when editing providers, tools, sessions, extensions, installer/uninstaller logic, or triaging regressions in this r… |
| planning-workflow | other | essential, research-exploration | 2026-08-06 | 1 | Use when starting a new project, creating implementation plans, or refining architecture before coding. |
| profiling-software-performance | other | code-quality | 2026-08-06 | 0 | Use when: profile, flamegraph, hotspot, bottleneck, p95/p99, IOPS, fsync, "why is this slow". |
| rch | other | rust-development | 2026-08-26 | 2 | Use when compilation slow, "[RCH] local" in stderr, workers unhealthy, hook silent, sync fails, disk pressure, or SSH/d… |
| readme-writing | other | code-quality, essential | 2026-08-06 | 1 | Use when creating or revising a README, documenting a CLI tool, library, or open source project, or when user asks abou… |
| reality-check-for-project | other | research-exploration | 2026-08-06 | 0 | Use when "where are we", "reality check", "what's missing", "are we on track", "gap analysis", or "does this actually w… |
| redacting-sensitive-parts-of-screencast-videos | other | — | 2026-08-06 | 0 | Use when redacting parts of a screencast (.mkv/.mp4/.mov) or a recording that leaked secrets. |
| release-preparations | other | code-quality, devops-infrastructure | 2026-08-06 | 0 | Use when: release, cut release, prepare release, version bump, pre-release, ship it, tag release, gh actions release, d… |
| repeatedly-apply-skill | other | agent-orchestration | 2026-08-06 | 0 | Use when "apply 10 times", "keep improving", "run again", iterative polish, improvement loop, or multi-pass refinement. |
| research-software | other | essential, research-exploration | 2026-08-06 | 2 | Use when creating skills, learning new tools, finding undocumented features, or bleeding-edge patterns. |
| rg-optimized | other | rust-development, terminal-power-user | 2026-08-06 | 1 | Use when the user has stock rg but needs PCRE2 features (lookahead, lookbehind, possessive quantifiers, atomic groups v… |
| ru-multi-repo-workflow | other | — | 2026-08-06 | 0 | Use when managing repos, syncing projects, reviewing GitHub issues, or automating maintenance en masse. |
| running-the-gauntlet-on-your-rust-port | other | rust-development | 2026-08-06 | 0 | Use when running the gauntlet, certifying parity, measuring honest perf vs reference, building oracle/differential/meta… |
| rust-cli-with-sqlite | other | rust-development | 2026-08-06 | 1 | Use when choosing a source of truth, designing sync strategy, WAL/PRAGMA tuning, atomic JSONL writes, recovery, or dura… |
| rust-crates-publishing | other | rust-development | 2026-08-06 | 2 | Use when cargo publish, crates.io tokens, GitHub Actions release workflows, or version/tag alignment are needed. |
| rust-undefined-behavior-exorcist | other | rust-development | 2026-08-06 | 0 | Use when "rust UB audit", "miri sweep", "rustonomicon audit", or "race hunt". |
| rust-unsafe-code-exorcist | other | rust-development | 2026-08-06 | 0 | Use when removing unsafe blocks, validating unsafe necessity, hardening FFI/SIMD, exorcising unsafe, or checking `#![fo… |
| saas-billing-patterns-for-stripe-and-paypal | other | saas-development | 2026-08-06 | 0 | Use when fixing webhooks, duplicate charges, billing security, dunning, MRR, migrations, or Next.js billing. |
| saas-cli-auth-flow | other | saas-development | 2026-08-06 | 0 | Use when building CLI login, device-code verify, token refresh, or headless SSH auth. |
| saas-customer-analytics | other | saas-development | 2026-08-06 | 0 | Use when building subscription analytics, revenue projections, or admin dashboards. |
| security-audit-for-saas | other | saas-development | 2026-08-06 | 0 | Use when "security audit", "billing security", or pre-launch review. |
| seo-for-saas-businesses | other | saas-development | 2026-08-06 | 0 | Use when auditing technical SEO, Core Web Vitals, AI Overview citations, schema, hreflang, programmatic templates, or s… |
| simplify-and-refactor-code-isomorphically | other | code-quality | 2026-08-06 | 0 | Use when: simplify, refactor, reduce duplication, remove lines, extract helper, reuse component, DRY, collapse, better … |
| slack-migration-to-mattermost-phase-1-extraction | other | — | 2026-08-06 | 0 | Use when exporting history, DMs, private channels, files, emoji, canvases, or building handoff ZIP/JSONL artifacts. |
| slack-migration-to-mattermost-phase-2-setup-and-import | other | — | 2026-08-06 | 0 | Use when validating handoff ZIPs, provisioning Mattermost, running mmctl import, configuring Nginx/WebSockets, or drivi… |
| slack-migration-to-mattermost-phase-3-ongoing-maintenance | other | — | 2026-08-06 | 0 | Use when running weekly health checks, applying OS security patches, upgrading Mattermost, taking and verifying Postgre… |
| slb | other | agent-orchestration | 2026-08-06 | 2 | Use when coordinating dangerous operations between agents, requiring peer review for rm -rf, git push --force, kubectl … |
| ssh | other | devops-infrastructure, terminal-power-u… | 2026-08-06 | 1 | Use when connecting to servers, managing SSH keys, setting up port forwarding, or transferring files with scp/rsync. |
| stripe-checkout | other | saas-development | 2026-08-06 | 1 | Use when implementing payment checkout, recurring billing, subscription management, or webhook handling for Next.js wit… |
| supabase | other | saas-development | 2026-08-06 | 4 | Use when setting up Supabase, connecting Drizzle, SSR auth, or optimizing costs. |
| system-performance-remediation | other | — | 2026-08-11 | 0 | Use when system unresponsive, high CPU/load average, IO pressure, filesystem cache bloat, memory pressure from btrfs/ex… |
| tanstack | other | saas-development | 2026-08-06 | 3 | Use when improving React/Next.js apps after vanilla implementation works, avoiding man-with-hammer syndrome. |
| tax-return-preparation-and-advice-generic | other | — | 2026-08-06 | 0 | Use when preparing tax returns, detecting multi-year filing errors, optimizing deductions across entity structures, or … |
| testing-conformance-harnesses | other | code-quality | 2026-08-06 | 0 | Use when: porting libraries across languages, implementing RFCs/specs, building database engines, validating protocol c… |
| testing-fuzzing | other | code-quality | 2026-08-06 | 0 | Use when: testing parsers, protocols, serialization, cryptography, state machines, file formats, APIs, or any input-pro… |
| testing-golden-artifacts | other | code-quality | 2026-08-06 | 0 | Use when: snapshot testing, approval testing, compiler output validation, query plan verification, UI snapshots, CLI ou… |
| testing-metamorphic | other | code-quality | 2026-08-06 | 0 | Use when: testing ML models, scientific computing, compilers, search engines, databases, graphics pipelines, or any sys… |
| testing-real-service-e2e-no-mocks | other | code-quality | 2026-08-06 | 0 | Use when: replacing mocked tests with real-DB tests, transaction rollback isolation, test data factories, structured JS… |
| threejs-visualizations-with-good-quality-and-real-physics | other | saas-development | 2026-08-18 | 0 | Use when making 3D or WebGL scenes, hero visuals, touch/mobile 3D controls, HUDs, or sim kernels. |
| transcribing-audio-from-calls-and-meetings | other | — | 2026-08-10 | 0 | Use when transcribing audio, diarizing speakers, or cleaning a whisper transcript. |
| transcribing-youtube-videos | other | — | 2026-08-10 | 0 | Use when transcribing a video, podcast, or interview, or pulling clickable-timestamp quotes. |
| tui-glamorous | other | terminal-power-user | 2026-08-06 | 0 | Use when: Go TUI, shell prompts/spinners, "make CLI prettier", adaptive layouts, async rendering, focus state machines,… |
| tui-inspector | other | — | 2026-08-06 | 0 | Use when debugging TUI rendering, reproducing visual regressions, or sharing keyboard-driven UI behavior. |
| ubs | other | code-quality, essential | 2026-08-06 | 3 | Use when reviewing code, checking for bugs, scanning for security issues, validating AI-generated code, or pre-commit q… |
| ui-polish | other | saas-development | 2026-08-06 | 3 | Use when app already works and looks decent, wanting to elevate to world-class through multiple passes. Not for complet… |
| user-support-ticketing-system-for-saas | other | saas-development | 2026-08-06 | 0 | Use when adding tickets or SLA tracking. |
| user-support-triage-for-saas-and-open-source-projects | other | saas-development | 2026-08-06 | 0 | Use when reviewing tickets, SLA breaches, refunds, hostile users, GDPR/CCPA, or onboarding agent-driven support. |
| ux-audit | other | code-quality | 2026-08-06 | 1 | Use when reviewing UI, "is this usable", improving user experience, or pre-launch. |
| vercel | other | saas-development | 2026-08-06 | 3 | Use when deploying to Vercel, reducing build costs, managing secrets, or splitting traffic between Vercel and Cloudflar… |
| vibing-with-ntm | other | agent-orchestration | 2026-08-06 | 0 | Use when running orchestrator ticks, unsticking panes, rate limits, marching orders, review mode, convergence, queue-dr… |
| video-obs-youtube-music | other | — | 2026-08-06 | 0 | Use when preparing screen recordings for YouTube or X/Twitter upload. |
| wezterm | other | devops-infrastructure, terminal-power-u… | 2026-08-06 | 1 | Use when wezterm mux unresponsive, agent sessions need rescue, tuning scrollback, or configuring persistent remote sess… |
| wills-and-estate-planning-skill | other | — | 2026-08-06 | 0 | Use when creating/reviewing a plan, life-event updates, urgent signing, beneficiary or succession changes, or estate ad… |
| world-class-doctor-mode-for-cli-tools | other | code-quality | 2026-08-06 | 0 | Use when: "add doctor", "upgrade doctor", "make CLI agent-friendly", "absorb playbook into doctor", "self-healing CLI",… |
| wrangler | other | devops-infrastructure | 2026-08-06 | 1 | Use when working with wrangler, Cloudflare Workers, or edge deployments. |
| xf | other | — | 2026-08-06 | 1 | Use when mining tweets, DMs, Grok chats, likes, or extracting information from X data exports. |

Related-edge detail lives in the JSON (`related.pairs_with/alternative_to/extends/prerequisite`).
