# Operator Library

One card per move in the SKILL.md operator line. Each card: when the operator fires, the
literal question it asks, what skipping it costs (tied to a real anti-pattern), a
paste-ready prompt module for a subagent, and what it composes with. The cards are
consistent with SCORING-RUBRIC.md and
JUNCTURE-SIGNALS.md — where they overlap, those documents are the
contract.

## Contents

- [★ PROFILE](#-profile) · [◎ FINGERPRINT](#-fingerprint) · [✦ LISTEN](#-listen) ·
  [◐ CORROBORATE](#-corroborate) · [⬡ MATCH](#-match) · [⊘ ANTI-SIGNAL](#-anti-signal) ·
  [⊕ COMBINE](#-combine) · [⚖ SCORE](#-score) · [⊙ DEBOUNCE-ALREADY-DONE](#-debounce-already-done) ·
  [⌘ KICKOFF](#-kickoff) · [⊞ RECORD](#-record) · [∅ UNKNOWN-IS-NOT-ABSENT](#-unknown-is-not-absent)

### ★ PROFILE

- **Trigger:** Phase 2, on any target the fingerprint says is new or stale.
- **Question:** "What IS this project — not what does its directory name suggest?"
- **Failure modes:** recommending from directory names (an empty fuzz dir, a vendored
  site, a stale plan file); A scores built on vibes instead of profile signals — the
  ledger then proves enthusiasm, not judgment.
- **Prompt module:** "Profile dimension <D> of <target>. Emit three-state evidence
  records (present / absent-with-positive-evidence / unknown), each with a signal id,
  confidence 0–4, a locator (`path@sha:line`), and the exact command run. Never infer a
  dimension from a name; run the detection command or record unknown."
- **Composes with:** ◎ FINGERPRINT (decides whether ★ runs at all), ⬡ MATCH (consumes
  its signals), ∅ (its third state).

### ◎ FINGERPRINT

- **Trigger:** Phase 1, every run, before anything expensive.
- **Question:** "Has anything changed since the last profile that would change the
  answer?"
- **Failure modes:** heavy analysis on a fresh profile (budget violation — the
  anti-pattern table's "the fingerprint said reuse"); or reusing a profile whose
  manifests changed and scoring against a project that no longer exists.
- **Prompt module:** "Run `bash scripts/check-doc-staleness.sh --target <dir>`. Report
  the exit code, the reason JSON verbatim, and the one-line announcement for the user.
  Do not read any source file."
- **Composes with:** ★ PROFILE (gates it), ⊞ RECORD (writes the header ◎ reads next
  run).

### ✦ LISTEN

- **Trigger:** Phase 3, first among juncture sources — cass outranks git for "what is
  the user struggling with".
- **Question:** "What is the user actually struggling with right now, in their own
  words?"
- **Failure modes:** ranking from commit vocabulary alone while the sessions show the
  user's real pain elsewhere; missing a decline ("not until the port is done") and
  re-recommending it; J=4 requires the user's own words — without ✦ nothing can reach
  it.
- **Prompt module:** "Mine session history for <target> per JUNCTURE-SIGNALS.md source 1:
  resolve the workspace key first, run the phrase batteries with `--json` under timeout,
  keep locators `source_path:line@origin_host`. Report hits, confirmed absences, and
  unknowns separately. Never run the session tool bare — it is a TUI."
- **Composes with:** ◐ CORROBORATE (cross-checks its claims), ⊙ DEBOUNCE (its mention
  tally), ∅ (host timeouts).

### ◐ CORROBORATE

- **Trigger:** any claim about to anchor a RUN NOW row on a single source.
- **Question:** "What does a second, independent source type say about this claim?"
- **Failure modes:** corroboration threshold ignored (E loses 1 without two source types
  each at confidence ≥ 2); a
  cass "completion" with no commit treated as done — sessions record intent, git records
  what landed.
- **Prompt module:** "For each claim in <list>, find one supporting or contradicting
  record from a DIFFERENT source type (git, beads, file, session, user statement).
  Report agreement, contradiction, or 'no second source' — do not manufacture
  corroboration."
- **Composes with:** ✦ LISTEN (the usual first source), ⚖ SCORE (E and the
  two-anchor eligibility rule feed on it).

### ⬡ MATCH

- **Trigger:** Phase 5, once evidence and catalog are both normalized.
- **Question:** "Which catalog skills does this evidence activate — and through which
  signals?"
- **Failure modes:** naming a skill that is in no catalog (validate-run.py blocks the
  artifact); matching on descriptions instead of signals; a "gap" that names an existing
  skill — that is a failed catalog read, not a gap.
- **Prompt module:** "Using signal-to-skill-map.json, compute activations for every
  catalog skill against evidence <file>. Every activation cites evidence ids. Output:
  activations, non-activations (empty is a valid result), and gaps phrased as the
  catalog query that came up empty."
- **Composes with:** ⊘ ANTI-SIGNAL (subtracts), ⊕ COMBINE (assembles recipes from
  matches), ⚖ SCORE.

### ⊘ ANTI-SIGNAL

- **Trigger:** whenever a positive match lands on a project that may already have the
  outcome.
- **Question:** "What evidence says running this skill here would re-do or undo existing
  work?"
- **Failure modes:** recommending fuzzing to a project with mature fuzz targets
  (the anti-pattern table's "ignoring anti-signals"); silence where "not now, already
  covered" was the honest answer — saying no clearly is part of the deliverable.
- **Prompt module:** "For skills <list>, evaluate their anti-signals: `when: present`
  fires on presence; `when: absent` fires only on absence-with-positive-evidence, never
  on unknown. Report each firing anti-signal with its evidence id and the A penalty it
  implies."
- **Composes with:** ⬡ MATCH (its negative half), ⊙ DEBOUNCE (already-done is the
  temporal anti-signal), ∅ (the absent-vs-unknown line).

### ⊕ COMBINE

- **Trigger:** portfolio construction — an eligible anchor that a recipe covers.
- **Question:** "Is there a proven multi-skill sequence here, and are its prerequisites
  satisfied or in-campaign?"
- **Failure modes:** recommending a bare anchor whose prerequisite is missing (the
  optimizer without the profiler — the recipes exist because singletons kept failing);
  filling RUN NOW with three steps of one campaign instead of one recipe row.
- **Prompt module:** "For eligible anchor <name>, load its recipe from
  `references/data/combo-recipes.json`. Drop satisfied prerequisites and
  suppressed/inapplicable pairs; verify every remaining member is in the catalog. Output
  recursively insert applicable unsatisfied prerequisites before their dependents, then
  output the sequence, aggregate campaign effort (sum of distinct member C), and the
  recipe's declared runner-up."
- **Composes with:** ⚖ SCORE (budget/overlap rules), ⌘ KICKOFF (recipes carry the
  kickoff prompt).

### ⚖ SCORE

- **Trigger:** Phase 6, after matching; never before the evidence is merged.
- **Question:** "What do the numbers say when the contract is applied — and does the
  validator agree?"
- **Failure modes:** improvised weights ("it feels like a RUN NOW"); tiers assigned
  before suppression gates; hand-edited ledger rows — the contract lives in
  `references/data/scoring-constants.json` and the scorer improvises nothing.
- **Prompt module:** "Run `python3 scripts/score-recommendations.py` then
  `python3 scripts/validate-run.py`. On violations: report them, repair INPUTS, and
  re-score. Never edit scores, tiers, or ledger rows by hand."
- **Composes with:** everything upstream; ⊞ RECORD (persists its output).

### ⊙ DEBOUNCE-ALREADY-DONE

- **Trigger:** before any tier is assigned — the suppression gates run first.
- **Question:** "Was this already done, declined, or started — and does the evidence
  clear the bar for that claim?"
- **Failure modes:** re-recommending last week's campaign (the credibility-killing
  anti-pattern); the opposite error too — treating a mere invocation mention as
  completion: an invocation proves attempted, never succeeded.
- **Prompt module:** "For each catalog skill, derive the already-done state per
  JUNCTURE-SIGNALS.md: completion requires artifact-or-outcome evidence; declines carry
  the user's condition verbatim; recent-invocation-without-completion is in_progress.
  Output state, D value, and which suppression gate (if any) caps the tier."
- **Composes with:** ✦ LISTEN (mention tally), ⚖ SCORE (D and the gates), ⊞ RECORD
  (previous-run cross-check).

### ⌘ KICKOFF

- **Trigger:** Phase 9, printing the campaigns.
- **Question:** "Would the user recognize this prompt as the one they would have typed?"
- **Failure modes:** generic imperative prose the user must rewrite; dropping the
  behaviour gate and re-earning the recorded regression (a speed loop that broke output
  quality); omitting the negative constraints the user states in caps every time.
- **Prompt module:** "Render the kickoff block for campaign <id> from its recipe,
  filling placeholders from evidence. Preserve the user's phrasing patterns: explicit
  round counts ('at least 10 rounds', escalated only when results stall), negative
  constraints verbatim where the recipe carries them ('NOT gh actions'; 'ONLY use the
  `br` tool'), and behaviour gates ('every pass must keep the behaviour/quality gate
  green — speed that breaks output is a regression, not a win'). Canonical skill names
  only."
- **Composes with:** ⊕ COMBINE (source of the sequence), EXEMPLARS.md
  (the phrasing corpus).

### ⊞ RECORD

- **Trigger:** Phase 10, and every mid-run event worth replaying.
- **Question:** "Will the next run be able to see what this run did and decided?"
- **Failure modes:** the next run re-recommends acted-on work because history was never
  written; outcomes never reported (`jsm outcome`), so the bandit and the already-done
  machine both stay blind; retention ignored and the appendix grows unbounded.
- **Prompt module:** "Append this run's history row (run id, tiers, campaigns,
  dispositions) to the recommendations doc appendix with retention applied; bump the
  header timestamps; remind the user of the `jsm outcome` forms for each campaign."
- **Composes with:** ◎ FINGERPRINT and ⊙ DEBOUNCE (their next-run inputs).

### ∅ UNKNOWN-IS-NOT-ABSENT

- **Trigger:** continuously — every timeout, missing tool, unreachable host, or
  unconfirmed workspace.
- **Question:** "Did anything actually verify this absence, or did the check merely fail
  to run?"
- **Failure modes:** the treating-a-timeout-as-absence anti-pattern: a dead host
  recorded as "no sessions", a missing beads binary as "no beads", then an anti-signal
  firing on the fake absence and suppressing a legitimate recommendation.
- **Prompt module:** "Audit records <list>: every absence claim must carry positive
  evidence of a completed search over a confirmed scope; anything else becomes
  `state: unknown` with the error text. unknown keeps D=0 and never fires a
  `when: absent` anti-signal."
- **Composes with:** every other card — it is the discipline the three-state records
  exist to enforce.
