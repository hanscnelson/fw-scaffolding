<!-- generated_from_sha256: sha256:4de864ceab1f295c3f4f9f44c345c0e64899304caa841e426af798b3497c140b -->
<!-- generated_at: 2026-08-27T14:00:00Z -->
<!-- generator_version: 2.0.0 -->
<!-- GENERATED VIEW - do not hand-edit. Source: references/data/combo-recipes.json; regenerate with scripts/render-reference-views.py -->


# Combo Recipes (generated view)

Campaigns the portfolio selector can pick when their anchor is RUN NOW eligible. The kickoff prompt is pasted verbatim.

## Establish the performance bottleneck, then optimize it  
`perf-profile-then-optimize` — anchor **extreme-software-optimization**, triggers: jx-perf-complaints, jx-perf-commits, jx-wasm-size-or-speed

**Sequence:** profiling-software-performance (prerequisite) → repeatedly-apply-skill (pair) → extreme-software-optimization

**Kickoff (paste verbatim):**
> First profile using /profiling-software-performance; then use /repeatedly-apply-skill at least 10 times sequentially to apply /extreme-software-optimization. Every pass must keep the behaviour/quality gate green — speed that breaks output is a regression, not a win.

**Expected artifact:** A before/after benchmark report with the dominant bottleneck identified, per-pass commits, and a negative-evidence ledger of rejected seams.

**Stop condition:** Stop when two consecutive optimization rounds fail to improve the primary benchmark by >= 1%, unless a newly discovered bottleneck justifies changing the benchmark.

## Prove the port beats the original, honestly  
`port-gauntlet` — anchor **running-the-gauntlet-on-your-rust-port**, triggers: jx-port-in-progress, code-port-of-other-language

**Sequence:** testing-conformance-harnesses (prerequisite) → running-the-gauntlet-on-your-rust-port → profiling-software-performance (pair) → extreme-software-optimization (pair)

**Kickoff (paste verbatim):**
> Follow the process in /running-the-gauntlet-on-your-rust-port: build the conformance harness against the original with /testing-conformance-harnesses, then a workload-matrix benchmark harness, and keep a negative-evidence ledger; quantify with /profiling-software-performance before each /extreme-software-optimization round.

**Expected artifact:** A parity matrix plus head-to-head workload benchmarks vs the original, and docs/negative_evidence.md.

**Stop condition:** Stop when the port wins or ties every workload cell with parity intact, or the ledger shows no seam with headroom.

## Find the hang and pin it with an interleaving model  
`hang-hunt` — anchor **deadlock-finder-and-fixer**, triggers: jx-hang-or-deadlock, jx-flaky-tests, code-async-holding-lock

**Sequence:** deadlock-finder-and-fixer → multi-pass-bug-hunting (pair)

**Kickoff (paste verbatim):**
> Use /deadlock-finder-and-fixer on the modules that hang or flake under load: classify each candidate (await-holding-lock, lock ordering, block_on inside async, DB write contention), trace the actual call chain, and write the loom/shuttle model that reproduces it before fixing. Then /multi-pass-bug-hunting over the same modules with a different lens each pass.

**Expected artifact:** Classified concurrency defects with reproductions; the worst one pinned by an interleaving model that fails before the fix and passes after.

**Stop condition:** Stop when the observed hang reproduces under the model and the fix passes it, and one further pass finds nothing new.

**Runner-up:** testing-fuzzing — Fuzzing finds input bugs, not interleavings.

## Break the fix-regress cycle with the right test kind  
`bugs-keep-coming-back` — anchor **multi-pass-bug-hunting**, triggers: jx-bug-fix-churn, jx-recurring-panics, jx-regressions

**Sequence:** multi-pass-bug-hunting → testing-fuzzing (pair) → testing-metamorphic (pair) → testing-golden-artifacts (pair) → testing-conformance-harnesses (pair) → mock-code-finder (pair)

**Kickoff (paste verbatim):**
> Run /multi-pass-bug-hunting over the modules with the most recent fixes, a different lens each pass, filing every confirmed defect as a bead with file:line. Then lock the wins in with the test kind that matches the code shape: /testing-fuzzing for parsers and binary formats, /testing-metamorphic for numeric/transform code, /testing-golden-artifacts for renderers and --json surfaces, /testing-conformance-harnesses for spec reimplementations, and /mock-code-finder if the tests are green but the product is broken.

**Expected artifact:** Confirmed defects as beads with fixes, and a new test harness of the matching kind that fails before and passes after.

**Stop condition:** Stop when two consecutive passes find no new confirmed defect and the new harness runs in CI.

**Runner-up:** codebase-audit — It surveys broadly; this juncture needs depth on the modules that keep breaking.

## Harden the parsers that keep panicking  
`parser-hardening` — anchor **testing-fuzzing**, triggers: gap-parser-no-fuzz, jx-recurring-panics

**Sequence:** testing-fuzzing → multi-pass-bug-hunting (pair)

**Kickoff (paste verbatim):**
> Apply /testing-fuzzing to every parse_/from_str/decode function over untrusted input that lacks a target in fuzz/fuzz_targets/: structure-aware targets with panic-as-bug, corpus committed, a CI smoke run. Feed every crash into /multi-pass-bug-hunting and fix root causes, not symptoms.

**Expected artifact:** Fuzz targets covering each parser, a seed corpus, and beads/fixes for every crash found.

**Stop condition:** Stop when every parser has a target and a 10-minute run finds no new crash.

**Runner-up:** testing-golden-artifacts — Goldens catch drift in known outputs, not crashes on hostile input.

## Find out where the project REALLY is  
`off-track-reality-check` — anchor **reality-check-for-project**, triggers: jx-beads-queue-dry, jx-beads-stale-epics, jx-ceremony-smell

**Sequence:** reality-check-for-project → beads-compliance-and-completion-verification (pair) → just-say-no-to-process-porn-and-ceremony (pair)

**Kickoff (paste verbatim):**
> First read ALL of AGENTS.md and README.md super carefully and understand ALL of both. Then use /reality-check-for-project end to end in a comprehensive way: where are we REALLY on this project? Then audit the closed beads with /beads-compliance-and-completion-verification — did we actually finish? Be brutally honest; keep /just-say-no-to-process-porn-and-ceremony top of mind at all times. Really take the time to meticulously ruminate on everything before responding.

**Expected artifact:** A Vision Checklist with WORKING/PARTIAL/STUB/UNPROVEN status and evidence per goal, reopened false-closed beads, and a bridge plan filed as beads.

**Stop condition:** Stop when every vision goal has an evidenced status and every gap has a bead.

**Runner-up:** modes-of-reasoning-project-analysis — It is a lens, not a status audit; it pairs well as a follow-on lane.

## Run and tend a swarm on the open bead graph  
`swarm-tending` — anchor **vibing-with-ntm**, triggers: jx-beads-many-open, jx-swarm-active

**Sequence:** planning-workflow (prerequisite) → beads-workflow (prerequisite) → beads-bv (prerequisite) → ntm (pair) → vibing-with-ntm → agent-mail (pair)

**Kickoff (paste verbatim):**
> Use /ntm and /vibing-with-ntm to create a swarm for this project working the ready beads (see /beads-bv), coordinating via /agent-mail; tend it actively — idle panes are a cardinal sin — checking in every 4 minutes, and keep /just-say-no-to-process-porn-and-ceremony top of mind at all times.

**Expected artifact:** Beads closing with evidence across the swarm; a tending log; no idle panes.

**Stop condition:** Stop when ready==0 and in_progress is unchanged for two ticks with convergence language in every pane.

**Runner-up:** beads-br — Single-agent bead execution loses when the ready set is wide enough to parallelize.

## Turn the plan into a dependency-correct bead graph  
`plan-to-beads` — anchor **beads-workflow**, triggers: jx-plan-no-beads, jx-big-change-no-plan

**Sequence:** planning-workflow (prerequisite) → beads-workflow → beads-bv (pair)

**Kickoff (paste verbatim):**
> Using /planning-workflow and /beads-workflow, convert the plan into beads with dependencies — so detailed that we never need to consult back to the original markdown plan; ONLY use the `br` tool. Then check over each bead super carefully: are you sure it makes sense? Is it optimal? Then ONCE AGAIN. Validate with `bv --robot-triage`.

**Expected artifact:** A bead graph covering every plan goal, no cycles, ready work visible in bv.

**Stop condition:** Stop when every plan goal maps to a bead and bv shows no cycles.

**Runner-up:** idea-wizard — The plan already exists; idea generation wins only when the question is still what to build.

## Stop the webhook and billing bugs  
`billing-hardening` — anchor **saas-billing-patterns-for-stripe-and-paypal**, triggers: jx-payments-bugs, gap-payments-no-webhook-replay

**Sequence:** saas-billing-patterns-for-stripe-and-paypal → security-audit-for-saas (pair) → testing-real-service-e2e-no-mocks (pair)

**Kickoff (paste verbatim):**
> Audit and fix the billing flows with /saas-billing-patterns-for-stripe-and-paypal — webhook idempotency and replay, hijack cross-checks, stale-event gates, dunning — then /security-audit-for-saas on the same surfaces, and lock it in with /testing-real-service-e2e-no-mocks webhook-replay tests against the provider's test mode.

**Expected artifact:** A coverage matrix over the billing patterns with fixes landed and a webhook replay test in CI.

**Stop condition:** Stop when every 'missing' row scoring >= 5 is closed and the replay test is green.

**Runner-up:** stripe-checkout — It builds a checkout; it does not harden an existing one.

## Make the CLI agent-ready  
`cli-agent-ready` — anchor **agent-ergonomics-and-intuitiveness-maximization-for-cli-tools**, triggers: json-mode-missing-for-cli, doctor-missing-for-cli, jx-cli-ergonomics-complaints

**Sequence:** agent-ergonomics-and-intuitiveness-maximization-for-cli-tools → world-class-doctor-mode-for-cli-tools (pair) → rust-cli-with-sqlite (pair)

**Kickoff (paste verbatim):**
> Score and aggressively improve the CLI's ergonomics for agents per /agent-ergonomics-and-intuitiveness-maximization-for-cli-tools (--json/--robot on every subcommand, agent-readable errors, help that teaches), then add a world-class `doctor` per /world-class-doctor-mode-for-cli-tools; apply the fixes in-tree.

**Expected artifact:** A scored ergonomics audit with the fixes landed, and a `doctor` subcommand whose checks name their fix.

**Stop condition:** Stop when every subcommand has --json, errors say what to do next, and doctor covers auth/config/paths/connectivity.

**Runner-up:** installer-workmanship — Installability matters after usability; it follows this campaign.

## Cut the release properly  
`release-train` — anchor **release-preparations**, triggers: jx-release-imminent, jx-release-overdue

**Sequence:** changelog-md-workmanship (prerequisite) → readme-writing (pair) → de-slopify (pair) → release-preparations → dsr (pair)

**Kickoff (paste verbatim):**
> Use /changelog-md-workmanship first to document the changes, update the README with /readme-writing and apply /de-slopify at the end, then cut the release with /release-preparations and /dsr (NOT gh actions) for all platforms, updating crates.io and homebrew; use /cass to see how we've done this recently and verify the installer on real machines.

**Expected artifact:** A tagged, published release with accurate CHANGELOG and README, binaries for every platform.

**Stop condition:** Stop when the release is live, the installer verified on a fresh machine, and the docs match HEAD.

## Close the delivery-surface gaps  
`docs-polish-bundle` — anchor **changelog-md-workmanship**, triggers: docs-changelog-stale-vs-tags, docs-changelog-missing, installer-missing-for-cli, docs-readme-weak, jx-docs-drift

**Sequence:** changelog-md-workmanship → readme-writing (pair) → installer-workmanship (pair) → de-slopify (pair) → gh-og-share-images (pair)

**Kickoff (paste verbatim):**
> Update the CHANGELOG.md using /changelog-md-workmanship, update the README (consult /readme-writing and apply /de-slopify to everything you write), create a world-class installer for every platform with /installer-workmanship, and finish with /gh-og-share-images.

**Expected artifact:** CHANGELOG current to the newest tag, README true of HEAD, installer with checksums and platform detection, a social card.

**Stop condition:** Stop when each artifact exists and matches HEAD.

**Runner-up:** documentation-website-for-software-project — A docs site before a true README is ceremony.

## Build a mental model before touching anything  
`onboard-unfamiliar-repo` — anchor **codebase-archaeology**, triggers: jx-onboarding, jx-context-loss

**Sequence:** cass (pair) → codebase-archaeology → codebase-report (pair)

**Kickoff (paste verbatim):**
> Use /cass to see what we've been working on in recent sessions for this project, then /codebase-archaeology to build a working mental model (documentation first, then data flow from entry points outward), and write it up with /codebase-report including file:line references so it survives context compaction.

**Expected artifact:** An architecture report with entry points, key types, data flow, and file:line citations.

**Stop condition:** Stop when the report template is filled and every claim cites a location.

**Runner-up:** reality-check-for-project — On first contact you cannot check reality against a vision you have not read yet.

## Make the wasm build small and fast on a phone  
`wasm-ship` — anchor **optimizing-your-rust-projects-for-wasm-in-browsers-and-phones**, triggers: jx-wasm-size-or-speed, proj-wasm-target

**Sequence:** profiling-software-performance (prerequisite) → optimizing-your-rust-projects-for-wasm-in-browsers-and-phones

**Kickoff (paste verbatim):**
> First profile using /profiling-software-performance in the browser; then apply /optimizing-your-rust-projects-for-wasm-in-browsers-and-phones — bundle size, SIMD/threads availability, allocator and panic settings, real-device timings — keeping the demo working after every change.

**Expected artifact:** Smaller, faster wasm with before/after numbers on desktop and a real phone.

**Stop condition:** Stop when the size and frame-time targets are met on a real phone.

**Runner-up:** extreme-software-optimization — Native-first optimization misses the browser constraints that dominate a wasm build.

## Exorcise unsafe, then hunt undefined behaviour  
`unsafe-then-ub` — anchor **rust-unsafe-code-exorcist**, triggers: code-unsafe-heavy, jx-unsafe-touched, gap-unsafe-no-miri

**Sequence:** rust-unsafe-code-exorcist → rust-undefined-behavior-exorcist (pair)

**Kickoff (paste verbatim):**
> Apply /rust-unsafe-code-exorcist as a multi-pass audit of every unsafe block (justify, remove, or fix; keep the audit files in-tree), then follow with /rust-undefined-behavior-exorcist: a UB experiment registry seeded from the audit with Miri/sanitizer traces and OPEN | CONFIRMED_UB | NO_EVIDENCE verdicts. No invented remediation timelines in the write-up.

**Expected artifact:** An unsafe audit with every block justified or gone, and a UB registry with no OPEN entries.

**Stop condition:** Stop when no unjustified unsafe remains and the registry has no OPEN entries.

**Runner-up:** gdb-for-debugging — It explains one crash; the audit explains the class.

## Bring dependencies to the latest and release  
`library-lockstep` — anchor **library-updater**, triggers: jx-dependency-bump, deps-outdated

**Sequence:** library-updater → asupersync-mega-skill (pair) → frankensqlite-mega-skill (pair) → release-preparations (pair)

**Kickoff (paste verbatim):**
> Run /library-updater on this project to bring every dependency to the latest stable release; where the project embeds asupersync or fsqlite, consult /asupersync-mega-skill and /frankensqlite-mega-skill to make sure the usage is optimal on the new version; then cut a release with /release-preparations so everything is harmonized on the very latest.

**Expected artifact:** Updated manifests and lockfile, green build, a migration note per breaking change, and a release.

**Stop condition:** Stop when no dependency is more than one minor behind (or has a written reason) and the release is live.

## Split the giant file without changing behaviour  
`split-the-monolith` — anchor **de-monolithize-your-codebase-isomorphically**, triggers: monolith-file, jx-large-refactor-discussed

**Sequence:** de-monolithize-your-codebase-isomorphically → simplify-and-refactor-code-isomorphically (pair) → planning-workflow (prerequisite) → beads-workflow (pair)

**Kickoff (paste verbatim):**
> Use /de-monolithize-your-codebase-isomorphically on the giant files: prove the seams empirically, split with zero API/perf/compile drift, then /simplify-and-refactor-code-isomorphically on the pieces, and hand the remaining work off as beads with /beads-workflow.

**Expected artifact:** A seam map, the first split landed with identical behaviour, and a bead graph for the rest.

**Stop condition:** Stop when no file exceeds the threshold and the isomorphism checks pass.

## Clear the GitHub issue and PR backlog  
`triage-the-backlog` — anchor **gh-triage-ru**, triggers: jx-open-issue-backlog, jx-open-pr-backlog

**Sequence:** gh-triage-ru → ru-multi-repo-workflow (pair)

**Kickoff (paste verbatim):**
> Use /gh-triage-ru to go over all my open issues and PRs and actually do this stuff the optimal way, following the highest possible standards; also read /ru-multi-repo-workflow for background on committing across repos.

**Expected artifact:** Every open issue/PR answered, labelled, fixed, or closed with a reason.

**Stop condition:** Stop when nothing open lacks a response.

**Runner-up:** user-support-triage-for-saas-and-open-source-projects — It triages tickets, not code changes.

## Decide what to build next  
`idea-round` — anchor **idea-wizard**, triggers: jx-design-questions, jx-beads-queue-dry

**Sequence:** idea-wizard → planning-workflow (pair) → beads-workflow (pair)

**Kickoff (paste verbatim):**
> Use /idea-wizard: come up with your very best 30 ideas for improving this project while staying obviously accretive and pragmatic, winnow to your VERY best 5 with full rationale, then your next best 10; then turn the winners into a plan with /planning-workflow and beads with /beads-workflow.

**Expected artifact:** A ranked idea slate, a plan, and beads.

**Stop condition:** Stop when the winners are beads with acceptance criteria.

**Runner-up:** dueling-idea-wizards — It needs a second model or swarm available; the single-model round comes first.
