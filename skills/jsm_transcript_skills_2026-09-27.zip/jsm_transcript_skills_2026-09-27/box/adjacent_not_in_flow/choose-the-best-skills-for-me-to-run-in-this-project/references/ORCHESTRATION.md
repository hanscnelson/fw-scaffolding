# Orchestration

The full phase contracts behind the loop in SKILL.md, plus the machinery
that makes parallel runs deterministic: the single permission envelope, run-id derivation,
proportionality budgets, subagent fan-out with deterministic merge, Agent Mail
conventions, the Phase 8 review charters, and the inline fallbacks for every referenced
engine skill. Subagent roles named below are the charters in `subagents/`.

## Contents

- [The permission envelope](#the-permission-envelope)
- [Run-id derivation](#run-id-derivation)
- [Proportionality budgets](#proportionality-budgets)
- [Phase contracts](#phase-contracts)
- [Fan-out and deterministic merge](#fan-out-and-deterministic-merge)
- [Agent Mail conventions](#agent-mail-conventions)
- [Phase 8 review charters](#phase-8-review-charters)
- [Fallbacks](#fallbacks)

## The permission envelope

One envelope, asked once in Phase 0, covering six grants:

1. **Target** — working directory, a named path, or a GitHub URL cloned read-only into
   `/tmp/`; monorepo → the component scope.
2. **Write the two docs** into `docs/` (creating `docs/` if missing); ephemeral clone →
   a sibling temp directory instead.
3. **Remote cass search** — configured sources or a one-shot ssh fan-out over hosts the
   user names.
4. **Authenticated catalog metadata** via jsm/API.
5. **Installs via jsm** — missing referenced engines at bootstrap and the recommended
   winners at the end.
6. **Commit** (and push only if granted here) the two docs, per the target's own
   AGENTS.md.

**Defaults when nothing is granted:** read-only analysis, local sources only, no
installs, no commit; results go to the terminal plus a temp file. Two hard rules follow:
**never re-ask** mid-run for anything the envelope covered (a denied grant stays denied;
a granted one is not re-confirmed), and **never exceed** it (no "small" commit because the
docs grant was given; no remote ssh because local cass was allowed). Public-repo target:
nothing from the privacy classes (local-only skill names, hostnames) is persisted into
the docs without explicit approval — the terminal is fine.

## Run-id derivation

```
run_id = first 12 hex chars of sha256( target_path + "\n" + head_or_digest + "\n" + now )
```

- `target_path` — the resolved absolute target (component-scoped for monorepos).
- `head_or_digest` — the full HEAD sha for git targets; the worktree digest for non-git.
- `now` — the pinned timestamp: `SKILL_SELECTION_NOW` when set, else wall clock at
  Phase 0.

The run id namespaces everything downstream: run JSON filenames, Agent Mail threads,
the Phase B sampling seed, and the history appendix rows. Pinning
`SKILL_SELECTION_NOW` therefore makes the whole run replayable — same inputs, same
run id, byte-identical scored JSON (invariant 6).

## Proportionality budgets

The block from SKILL.md, verbatim:

```
< 250 tracked files:    ≤ 4 profiler subagents, single juncture agent
250–2,500:              one subagent per dimension/source
> 2,500 or > 20 members: component map first; per-component profiling; ≤ 8 concurrent
Reused profile:         NO Phase 2 profiler; no large source reads unless verifying a changed juncture claim
Timeouts: gh 30s; jsm/API 30s; each remote cass host 60s → failure records `unknown` and the run continues.
```

What each line means operationally:

- **< 250 tracked files** — a small project does not get the full six-profiler fan-out:
  at most 4 profiler charters run (merge adjacent dimensions, e.g. identity +
  build-and-deps), and one juncture agent covers all local sources. Anything more is the
  "heavy analysis on a fresh profile" anti-pattern.
- **250–2,500** — the standard shape: one subagent per profile dimension and one per
  juncture source, all parallel.
- **> 2,500 files or > 20 workspace members** — a component map is built FIRST (cheap:
  manifests and directory topology), then profilers run per component with a global
  concurrency cap of 8; evidence records carry the component in their locator.
- **Reused profile** — Phase 2 spawns nothing. The only permitted source reads are
  spot-verifications of a changed juncture claim (e.g. confirming a panic-vocabulary
  commit actually touched the module it names).
- **Timeouts** — a budget overrun is an `unknown` evidence record with the error text,
  never a retry loop and never a blocker (invariant 4).

## Phase contracts

Each phase: inputs → outputs, who runs it, what may run in parallel, and the measurable
exit criteria. "Engine" scripts are run with `bash`/`python3` as shipped.

### Phase 0 — CONFIRM + BOOTSTRAP (orchestrator)

- **Inputs:** the user's request; the current directory; jsm availability.
- **Work:** resolve the target; read its governing `AGENTS.md`/`CLAUDE.md` before any
  target command; ask the six-grant envelope once; derive the run id; offer `jsm install`
  for missing referenced engines (once, inside the envelope). If governance forbids file
  deletion, set `SKILL_SELECTION_KEEP_TEMP=1`; the shipped detector scripts also detect the
  common no-deletion wording and retain their temporary directories automatically.
- **Outputs:** envelope record (grant/deny per item), resolved target, run id,
  bootstrap report.
- **Parallelism:** none — this phase is a conversation.
- **Exit:** all six grants have a recorded answer; run id derived; every referenced
  engine is either present, installed, or marked for its inline fallback. No phase
  blocks on a missing engine.

### Phase 1 — STALENESS (staleness-checker)

- **Inputs:** target; the existing analysis doc (if any).
- **Engine:** `bash scripts/check-doc-staleness.sh --target <dir>`.
- **Outputs:** exit 0 (reuse) or 1 (re-profile) plus the reason JSON.
- **Parallelism:** none (one cheap script).
- **Exit:** the decision is **announced** in the terminal with its reason ("reusing
  profile from <ts>; N commits / M changed issue records since" or "re-profiling because
  <reason>"), and recorded in the run JSON. Rules: STALENESS.md.

### Phase 2 — PROFILE (six profilers; skipped on reuse)

- **Inputs:** target scope; the taxonomy in
  PROJECT-PROFILE-TAXONOMY.md.
- **Engine:** `bash scripts/profile-project.sh` for the deterministic detectors, plus
  profiler subagents: **identity, build-and-deps, code-kinds, tests, docs-and-process,
  delivery-surface** — as many as the budget allows.
- **Outputs:** evidence records (`ev-p…`), three-state
  (present / absent-with-positive-evidence / unknown), signal-tagged, with locators.
- **Parallelism:** all profilers concurrently within the budget.
- **Exit:** every spawned profiler has returned or timed out to `unknown`; the merged
  evidence validates against `references/schemas/evidence.schema.json`; every taxonomy
  dimension has at least one record (unknown counts — silence does not). The canonical
  profile records are embedded into the analysis doc's
  `skill-selection:profile-evidence:v1` block so a later reuse run is self-contained.

### Phase 3 — JUNCTURE (five miners; every run, reuse included)

- **Inputs:** target; pinned clock; catalog snapshot (for the invocation scan).
- **Engines:** `bash scripts/juncture-signals.sh` (git/gh/beads/smells, `ev-j…`) and
  `bash scripts/cass-juncture-mine.sh` (sessions, `ev-c…`), driven by the miner
  charters: **git, beads, cass-local, cass-remote, code-smells**.
- **Outputs:** juncture evidence + the already-done mention tally (the companion file).
- **Parallelism:** miners concurrently; remote hosts in parallel inside the cass-remote
  charter, 60s each.
- **Exit:** all five sources have reported (records or `unknown`); every remote host has
  exactly one summary record on failure; the already-done file exists (empty is valid).
  Source weighing and the state machine: JUNCTURE-SIGNALS.md.

### Phase 4 — CATALOG (three catalog agents)

- **Inputs:** snapshot; jsm/network availability per the envelope.
- **Engines:** `bash scripts/local-skills-inventory.sh` (local-inventory charter) and
  `bash scripts/catalog-fetch.sh` (cloud charter); the **relationships** charter
  normalizes related edges and recipe membership.
- **Outputs:** the normalized catalog with `installed`/`resolved_path`/skew merged in and
  the fetched `drift`/`drift_known`/`retirement_known` wrapper facts preserved; provisional
  marks and relationship report.
- **Parallelism:** inventory and cloud fetch run concurrently; relationships runs after
  both.
- **Exit:** exactly one normalized entry per canonical name; source tier announced;
  drift reported (or `drift_known: false` stated). Details:
  CATALOG-ACQUISITION.md.

### Phase 5 — MATCH (matcher + idea-wizard-orchestrator)

- **Inputs:** merged evidence; normalized catalog;
  `references/data/signal-to-skill-map.json`; `references/data/combo-recipes.json`.
- **Work:** compute every known signal's three-state activation (present/absent states cite
  the complete supporting evidence-id set; unknown cites `[]`); apply those signals per skill;
  anti-signals; assemble recipe candidates; run the idea-wizard round (30 candidate
  pairings → best 5 with rationale → next 10) to surface non-obvious matches and gaps;
  record overrides with reasons.
- **Outputs:** four explicit JSON inputs: activations, overrides, recipe candidates, and
  gap list. Overrides and recipe candidates cite active, unsuperseded evidence ids; a
  recipe is not live merely because its anchor scored well.
- **Parallelism:** matcher and idea-wizard round may run concurrently; both read, neither
  writes shared state.
- **Exit:** the activation file covers the exact known-signal universe with no omissions
  or extras; every non-unknown state cites exactly the active evidence records that support
  it; every gap has signals, active evidence support, and the exact catalog query that came
  up empty (a gap naming an existing skill is a match, not a gap). All four files are
  mandatory even when an override/gap/recipe list is explicitly empty.

### Phase 6 — SCORE + PORTFOLIO + LEDGER (scorer)

- **Engines:** `python3 scripts/score-recommendations.py` then
  `python3 scripts/validate-run.py`.
- **Outputs:** scored run JSON: per-skill dimensions, tiers, suppression gates, the ≤ 3
  campaign portfolio, and the one-row-per-skill ledger.
- **Parallelism:** none — scoring is a single deterministic pass over merged inputs.
- **Exit:** `validate-run.py` exits 0. A non-zero exit **blocks Phase 7**: repair the
  inputs (evidence, activations, states), re-score, re-validate. Never hand-edit the run
  JSON or the ledger. Contract: SCORING-RUBRIC.md.

### Phase 7 — WRITE DOCS (synthesizer)

- **Engine:** `python3 scripts/render-recommendations.py` over the validated run JSON and
  merged evidence. It generates the comprehensive analysis sections and durable profile
  block as well as the recommendations doc. Public-repository persistence uses `--public`,
  producing a recursive, HTML-comment-safe redacted projection while leaving the private
  canonical inputs unchanged.
- **Outputs:** the two docs (analysis + recommendations), including the machine-readable
  ledger block and the history appendix.
- **Parallelism:** none at the file level — one writer per file, enforced by Agent Mail
  reservation or the single-writer fallback (below).
- **Exit:** both docs rendered FROM the validated run JSON (every table a generated
  view, invariant 2); written only where the envelope allows; reservations released.

### Phase 8 — REVIEW (three reviewers)

- Passes A, B, C once each; repeat A once iff a tier or RUN NOW campaign changed;
  hard cap 4 passes. Charters below. Fixes land in run data + re-render, never in
  hand-edited tables.

### Phase 9 — INSTALL + KICKOFF (installer-and-kickoff)

- **Inputs:** the final portfolio; the envelope's install grant.
- **Outputs:** terminal campaign printout with verbatim kickoff prompts (from the recipe
  `kickoff_prompt`, placeholders filled from evidence) and `jsm install` lines; installs
  executed only under grant 5.
- **Exit:** every RUN NOW campaign printed paste-ready; gaps offered to `jsm requests`
  (with permission); the `jsm outcome` reminder given.

### Phase 10 — RECORD (orchestrator)

- **Outputs:** history appendix row upserted by run id (tiers, campaigns, dispositions) with
  retention applied; doc header bumps (`juncture_refreshed_at`, generation timestamps);
  commit/push only under grant 6.
- **Exit:** the next run's staleness check and already-done cross-check can see this
  run.

## Fan-out and deterministic merge

Evidence ids are namespaced per emitter so parallel work cannot collide:

- `ev-p####` — profile records (script + profiler subagents);
- `ev-j####` — juncture records from git/gh/beads/smells;
- `ev-c####` — juncture records from session mining.

The orchestrator assigns each subagent a **non-overlapping id range** inside its
namespace at spawn time, above the script-emitted ids (the scripts count up from
`ev-p0001`/`ev-j0001`/`ev-c0001`) — e.g. one profiler emits `ev-p1100`–`ev-p1199`, the
next `ev-p1200`–…. Ids are zero-padded, so lexicographic order equals numeric order.

**Merge = concatenate, sort by id.** No destructive dedupe pass and no silent LLM
judgment: the merged evidence file is the sorted union of every emitter's records. A
correction appends a new record whose `supersedes` array names the older record; the old
bytes remain auditable, but scorer and validator use only the active, unsuperseded set.
Duplicate ids, missing/self targets, and supersession cycles are fatal. Among active
records, present/absent disagreement remains visible and present is the conservative
activation state; Pass B must either verify it or append an explicit correction. This
prevents an obsolete present detector hit from permanently overpowering its audited
absence correction.

## Agent Mail conventions

When Agent Mail (MCP) is available, the run uses it for coordination:

- **Thread ids:** `skill-selection-<run-id>-<phase>-<bucket>`, e.g.
  `skill-selection-<run-id>-3-cass-remote` for the remote-mining bucket of Phase 3.
  One thread per bucket keeps replay ordered per topic.
- **File reservations:** taken on exactly two paths — the analysis doc and the
  recommendations doc — before Phase 7 writes them. Nothing else in the target is ever
  reserved because nothing else is ever written.
- **Advisory tool locks:** `tool://cass` and `tool://jsm` are reserved as advisory,
  non-exclusive-intent locks so parallel subagents queue on one index/API instead of
  hammering it. They throttle; they do not gate correctness.
- **Agent Mail unavailable → single-writer fallback:** the orchestrator becomes the only
  writer — subagents return their records to it, and it writes both docs itself.
  Whatever the topology, the invariant is: **never two writers on one file**.

## Phase 8 review charters

Three independent reviewers, each reading the run JSON + both docs, each returning
findings (not edits). A, B, C run **once each**; A repeats **once** iff a fix changed any
tier or any RUN NOW campaign; hard cap **4 passes total**; never loop until clean —
findings that survive the cap are reported in the docs as known issues.

**Pass A — artifact integrity (artifact-integrity charter).** Do the artifacts agree
with the run data and with themselves? Checks: every table matches the run JSON
(generated-view invariant); ledger has exactly one row per catalog skill; tier rules and
suppression gates applied as recorded; campaign members exist in the catalog; kickoff
prompts name only catalog skills; links resolve; headers carry the right run id and
timestamps.

**Pass B — evidence audit (evidence-auditor charter).** Are the claims true? Method:
re-run recorded commands **where safe and read-only** (git log forms, robot list/health
commands, searches — never installs, never writes); take a **deterministic,
run-id-seeded sample of at least 10 claims** across evidence kinds and verify each
locator supports its claim; an **unavailable source degrades the claim to `unknown`,
never to negative** — Pass B may not convert a dead host into an absence finding.

**Pass C — cross-agent consistency (consistency charter).** Do independent emitters
contradict each other? Checks: no signal is simultaneously `present` and
`absent-with-positive-evidence` without the conflict rule's resolution recorded;
already-done states are consistent with invocation mentions and git/beads facts;
the same skill is not both RUN NOW and suppressed; profile claims match juncture claims
where they overlap (e.g. "no tests" vs a failing-CI signal).

## Fallbacks

The referenced engine skills are **accelerants, not prerequisites** — every phase has an
inline fallback, and no phase blocks on a missing skill (bootstrap offers an install
once; declining it costs speed, not capability).

- **`/codebase-archaeology` / `/codebase-report` missing** (Phase 2 depth, doc
  structure): do the four-phase read inline — documentation first, then entry points,
  then data flow outward, then synthesis — keeping file:line notes for every claim, and
  render the analysis doc from the template in `assets/` with those notes as the
  evidence base.
- **`/cass` missing** (Phase 3, already-done scanning): skip session mining entirely and
  mark every cass-derived signal `unknown` — the miner script already emits exactly this
  (one summary unknown record listing the affected signals). Git, beads, and smells still
  run; absence claims that would have needed session evidence are not made.
- **`/idea-wizard` missing** (Phase 5): run the 30→5→10 prompt inline — 30 candidate
  skill-to-evidence pairings, winnow to the best 5 with full rationale, then the next
  10 — and feed the result into matching like the skill's output.
- **`/reality-check-for-project` missing** (juncture corroboration on drift-suspect
  targets): apply the vision-vs-code checklist inline — list the README/plan's stated
  goals, mark each WORKING / PARTIAL / STUB / UNPROVEN with a file:line citation, and
  emit the deltas as juncture evidence.
