# Staleness: When Is the Profile Reused?

Phase 1 decides reuse vs re-profile by comparing the analysis doc's fingerprint header
against the target. Implementation: `scripts/check-doc-staleness.sh` (the rules below are
exactly what it does). A reused profile skips every Phase 2 profiler subagent; the juncture
is refreshed on EVERY run regardless.

## Contents

- [The analysis-doc header](#the-analysis-doc-header)
- [What each fingerprint component measures](#what-each-fingerprint-component-measures)
- [The decision procedure](#the-decision-procedure)
- [What reuse and re-profile each update](#what-reuse-and-re-profile-each-update)
- [Monorepos](#monorepos)
- [Exit-code contract and reason JSON](#exit-code-contract-and-reason-json)

## The analysis-doc header

YAML front matter of the analysis doc, schema
`references/schemas/analysis-header.schema.json`. Staleness reads `profiled_at` and the
`profile_*` fields ONLY; `last_updated` is display-only and never enters the decision.

| Field | Meaning |
|---|---|
| `profiled_at` | When Phase 2 last actually ran — the age clock |
| `profile_head_sha` | Full commit profiled (null for non-git targets) |
| `profile_branch` | Branch at profile time (informational) |
| `profile_scope` | `["."]` or the monorepo component path(s) profiled |
| `profile_tracked_file_count` | Denominator for the changed-file ratio |
| `profile_worktree_digest` | `sha256:...` over tree objects + dirty diff + untracked hashes — the fast "nothing changed at all" short-circuit |
| `profile_manifest_digests` | `{path: sha256:...}` for every manifest AND lockfile in scope |
| `profile_beads_watermark` | `<newest updated_at>/<issue count>` from `br list --status all --json`, or null |
| `profile_cass_watermark` | Newest session timestamp seen at profile time, or null |
| `juncture_refreshed_at` | Bumped every run, including reuse runs |
| `recommendations_generated_at`, `last_updated`, `generator_version` | Bookkeeping/display |

## What each fingerprint component measures

- **Worktree digest** — any byte or path change in scope (committed, uncommitted, or
  untracked). For git targets: tree hashes per scope + the full binary worktree diff +
  NUL-delimited relative paths and length-delimited bytes of untracked files (including
  whitespace, quotes, and newlines in names). For non-git targets, relative path lengths,
  paths, and bytes are hashed. Equality means byte-identical scope and names → instant
  reuse.
- **HEAD ancestry** — did history move forward, or sideways? `git merge-base --is-ancestor
  <profiled> HEAD`. A branch switch to a line that does not contain the profiled commit, a
  rebase, or an amend makes the profiled snapshot describe a tree that never existed on this
  line → re-profile, whatever the counts say.
- **Commit count** — `git rev-list --count <profiled>..HEAD`; volume of drift.
- **Changed-file ratio** — unique(`git diff --name-only <profiled>` in scope + untracked
  files) / `profile_tracked_file_count` (falls back to the current count). Catches large
  uncommitted rewrites that the commit count misses.
- **Manifest + lockfile digests** — dependency changes invalidate build/framework/deps
  evidence even when few files changed. The recursive scan within every scope watches names
  including Cargo.toml/Cargo.lock,
  package.json + npm/pnpm/yarn/bun locks, pyproject/poetry/uv/requirements, go.mod/go.sum,
  Gemfile(.lock), build.zig(.zon), CMakeLists.txt, mix.exs/mix.lock.
- **Beads watermark** — issue records whose `updated_at` is newer than the recorded
  watermark timestamp, plus absolute issue-count change; measures process drift (work items
  moved even if code did not). If the current watermark cannot be read, reuse is denied.
- **Age** — days between `profiled_at` and the pinned clock. Never computed from
  `last_updated`: juncture refreshes bump `last_updated` without re-verifying the profile.

## The decision procedure

Checks run in this order; the first hit decides. Thresholds are constants in the script.

| # | Check | Decision (reason) |
|---|---|---|
| 1 | No analysis doc | re-profile (`no_profile`) |
| 2 | `--fresh` flag (the user asked for fresh) | re-profile (`user_requested_fresh`) |
| 3 | Requested scope is missing or resolves outside the target | re-profile (`error:scope-not-found` / `error:scope-outside-target`) |
| 4 | Header fails `analysis-header.schema.json` | re-profile (`error:invalid-analysis-header`) |
| 5 | Embedded profile block is missing, malformed, schema-invalid, semantically invalid, or has no active profile record | re-profile (`error:profile-evidence-missing-or-invalid`) |
| 6 | Requested `--scope` differs from `profile_scope` | re-profile (`profile_scope_changed`) |
| 7 | Saved manifest/lockfile set or digest differs | re-profile (`manifest_or_lockfile_digest_changed`) |
| 8 | Beads watermark unavailable or ≥ **10** changed issue records | re-profile (`beads_watermark_unavailable`/`beads_change_count_unavailable` or `bead_issue_records_since_profile>=10`) |
| 9 | `profiled_at` older than **30 days** | re-profile (`profile_older_than_30_days`) |
| 10 | Worktree digest unchanged and Beads watermark unchanged | **reuse** (`worktree_digest_unchanged`) — fast path |
| 11 | Non-git target (and digest changed) | re-profile (`no_git`) — worktree digest is the ONLY reuse test for non-git targets |
| 12 | Profiled commit not an ancestor of HEAD | re-profile (`profiled_commit_not_ancestor`) |
| 13 | ≥ **25** commits since profile | re-profile (`commits_since_profile>=25`) |
| 14 | Changed-file ratio ≥ **0.15** (committed + uncommitted + untracked) | re-profile (`changed_file_ratio>=0.15`) |
| 15 | Any uncommitted tracked bytes changed | re-profile (`uncommitted_tracked_changes`) |
| 16 | None of the above | **reuse** (`within_thresholds`) |

Any unexpected error exits 1 with reason `error:<what>` — re-profiling is the safe default.
Announce the decision either way ("reusing profile from <ts>; N commits / M changed issue records
since" or "re-profiling because <reason>").

## What reuse and re-profile each update

- **Reuse** still refreshes the juncture (Phases 3+ run) and bumps ONLY
  `juncture_refreshed_at` and `last_updated`. `profiled_at` and every `profile_*` field stay
  untouched — they describe the last real profile.
- **Re-profile** creates the analysis doc when absent or regenerates it **in place**, and
  sets `profiled_at` plus all `profile_*` fields from the current snapshot. The checker
  emits both the saved `profile_head_sha` (when one exists) and `current_head_sha`; the
  renderer records the latter after a full profile. An unavailable CASS watermark becomes
  `null` rather than silently carrying an older value. There is never a second analysis
  file — one doc per target, with the run history appendix carrying the trail.
- A reused-profile run invokes NO profiler subagent and does no large source reads unless
  verifying a changed juncture claim (proportionality invariant).

## Monorepos

`profile_scope` holds the component path list (e.g. `["crates/engine", "crates/cli"]`),
matching the `--scope` argument (comma-separated). Every fingerprint component — file count,
digests, ratio, manifest set — is computed inside the scope only, so churn in a sibling
component neither invalidates this profile nor hides behind it. A different scope than the
header's is a different profile question: re-profile.

## Exit-code contract and reason JSON

```bash
bash scripts/check-doc-staleness.sh --target <dir> [--scope <p1,p2>] [--doc <file>] [--fresh]
```

Exit **0** = reuse; exit **1** = re-profile (including all `error:*` reasons). Exactly one
JSON object is always printed on stdout:

```json
{
  "decision": "reprofile",
  "reason": "changed_file_ratio>=0.15",
  "commits_since_profile": 9,
  "bead_issue_records_since_profile": null,
  "changed_file_ratio": 0.2138,
  "worktree_digest": "sha256:6b1f6d9a0c6f2f3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f",
  "profiled_at": "2026-08-11T09:12:44Z",
  "profile_head_sha": "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0",
  "current_head_sha": "b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1",
  "is_git": true,
  "tracked_file_count": 412,
  "profile_scope": ["."],
  "manifest_digests": {"Cargo.toml": "sha256:...", "Cargo.lock": "sha256:..."},
  "beads_watermark": "2026-08-25T18:02:11Z/143"
}
```

Fields not yet computed when a check short-circuits are null. The orchestrator records this
JSON with the run and quotes `reason` verbatim in the staleness announcement.
