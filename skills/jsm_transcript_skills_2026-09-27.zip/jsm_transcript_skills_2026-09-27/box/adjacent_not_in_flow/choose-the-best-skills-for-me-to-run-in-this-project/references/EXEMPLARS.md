# Mined Exemplars

Conclusions from a Track-A mining pass over the user's real session history (local and
remote machines, hand-verified user-role prompts only — injected skill bodies,
orchestrator marching orders, and compaction summaries stripped). This is the phrasing
corpus behind ⌘ KICKOFF and several combo recipes: what the user actually types, what
triggers it, and what happened next. Quotes are ≤ 25 words and de-identified; skills that
are not in the public catalog appear generically ("a private idea-mining skill"), never
by name. No counts here — categories and conclusions only.

## Contents

- [The rituals that repeat](#the-rituals-that-repeat)
- [Trigger vocabulary observed](#trigger-vocabulary-observed)
- [Which testing skill for which code shape](#which-testing-skill-for-which-code-shape)
- [Read vs run](#read-vs-run)
- [Frequency conclusions](#frequency-conclusions)

## The rituals that repeat

### The performance ritual (escalating rounds, and the gate it earned)

The most-repeated exact recipe in the corpus: "applying /profiling-software-performance
and then /repeatedly-apply-skill applying /extreme-software-optimization 10+ times in a
row". The round count is always explicit and escalates when results stall — "20+ rounds",
"50+ times in a row". Two private idea-mining skills are regularly named alongside as
idea sources, and the gauntlet is pulled in for exactly one artifact: "Follow the process
outlined in /running-the-gauntlet-on-your-rust-port in terms of the negative evidence
ledger."

The recorded failure: after a 20x loop on a wasm audio project, the user's reply was
"that RUINED the audio quality" — the loop had optimized speed while destroying output.
This is why the perf recipe's kickoff carries a behaviour gate ("every pass must keep the
behaviour/quality gate green — speed that breaks output is a regression, not a win") and
why ⌘ KICKOFF never drops it. The other observed loop pathology: grinding a seam with a
long rejection streak in the negative-evidence ledger and no shipped wins — the recipes'
stop conditions exist for that.

### The release train ("NOT gh actions")

Releases end nearly every work session, in one shape: "cut a new tag/version/binary using
/release-preparations with /dsr (NO gh actions) for all platforms". `/release-preparations`
and `/dsr` travel as a single unit, and the negative constraint is restated — often in
caps — almost every time ("you CANNOT use gh actions for ANYTHING"): CI-hosted release
builds are the recorded wrong choice for this user, and an agent proposing them gets
corrected mid-flight. Two riders recur: "use /cass to see how we've done this recently"
(history as the release how-to), and verifying the installer on real machines before
declaring victory. The immediately preceding prompt is usually the fresh-eyes ritual
(below), not a release request — the release is the tail of polish, not its own event.

### The docs-polish four-skill bundle

One breath, four skills: "update the README (consult /readme-writing and apply
/de-slopify to everything you write); also update the CHANGELOG.md using
/changelog-md-workmanship", plus "create world class installer for every platform with
/installer-workmanship" — frequently finished with `/gh-og-share-images` or
`/og-share-images` for the social card. `/de-slopify` is never a standalone task: it is a
trailing clause on any writing instruction ("apply /de-slopify at the end"), including on
a private catalog-onboarding pipeline's release copy. README triggers are drift-shaped:
"the last time it was updated was weeks ago and so much has changed."

### Plan → beads, with the double-check polish

Plans become dependency graphs in a fixed sequence: `/planning-workflow` then
`/beads-workflow` (with `/beads-br` and `/beads-bv` cited as background), under two
constraints stated every time: "The beads should be so detailed that we never need to
consult back to the original markdown plan document" and "ONLY use the `br` tool" (the
recorded wrong choice: editing the JSONL directly or reaching for the legacy tool). Then
the polish ritual, verbatim and doubled: "Check over each bead super carefully — are you
sure it makes sense? Is it optimal?" followed by "ONCE AGAIN: Check over each bead super
carefully."

### Swarm kickoff bundle and the queue-dry rotation

Swarm kickoffs are a fixed bundle fanned to every pane, in a fixed order: "First read ALL
of the AGENTS.md file and README.md file super carefully and understand ALL of both!" →
investigate the code → work the ready beads ("execute remaining beads in the optimal
logical order", see `/beads-br` / `/beads-bv`) → "communicate with your fellow agents
(see /agent-mail)" → the doctrine clause ("keep /just-say-no-to-process-porn-and-ceremony
top of mind at all times") → "use /cass to see what we've been working on" → build
routing rules (`/rch`). Tending is its own ritual: `/ntm` and `/vibing-with-ntm` are
always invoked as a pair, inside a recurring operator loop — "having agent panes in the
swarm be idle is a CARDINAL SIN", "checking in on the swarm every 4 minutes".

When the ready queue drains, the user delegates the pivot rather than picking: rotate
audit lenses — `/mock-code-finder`, `/deadlock-finder-and-fixer`,
`/reality-check-for-project`, `/modes-of-reasoning-project-analysis`,
`/profiling-software-performance`, `/security-audit-for-saas` "(only to the extent
applicable)" — with the operator rule "Do not repeat the same skill across consecutive
rounds." Review swarms follow `/code-review-gemini-swarm-with-ntm`'s workflow even when
the user swaps in different model panes — the workflow is wanted, not the model binding.

### The audit lane: reality-check + modes-of-reasoning

`/reality-check-for-project` and `/modes-of-reasoning-project-analysis` run as ONE lane,
not two campaigns: first "use /reality-check-for-project end to end in a comprehensive
way" (typically preceded by the AGENTS.md/README opener and followed by "Really take the
time to meticulously ruminate on everything before responding."), then the reasoning-modes
pass as the fresh angle over the same ground. Triggers: a drained bead queue, or suspicion
that the docs promise more than the repo delivers. The typical follow-up is the user
accepting the findings and asking the agent to start closing the biggest gaps — the lane
is a bead generator, not a report generator.

### The fresh-eyes ritual

The most common polish prompt in the corpus, nearly verbatim each time: "check over
everything again with fresh eyes looking for any blunders, mistakes, errors, oversights,
omissions, problems, misconceptions, bugs" — closed with "Be SUPER thorough and
meticulous!" It precedes releases and de-slop passes more than any other prompt, and it
repeats ("one more even more meticulous fresh eyes polish pass"). A kickoff block printed
before a release campaign should expect it rather than fight it.

## Trigger vocabulary observed

- **Anger as trigger.** The e2e and perf skills are most often invoked right after a
  failure the user finds intolerable, with the vocabulary carrying the signal:
  "we should have REAL e2e integration tests that catch <...> like that, it's
  indefensible. See /testing-real-service-e2e-no-mocks" — and, on performance,
  "defeatist" plus "THERE IS NO EXCUSE TO LOSE." A juncture miner that sees this
  vocabulary is looking at J=4 (the user's current pain, their own words).
- **Polish-gap vocabulary.** Doc drift sounds like "so much has changed" and "update
  obsolete claims"; prose failure sounds like AI-ness: "reads like impenetrable, cringe
  AI slop", "avoid 'cringe' stuff that screams 'written by ai'". Both map to the
  docs-polish bundle, not to a rewrite campaign.
- **Delegation vocabulary.** The user routinely names a skill family and delegates
  selection: "use the various skills with names beginning with the string 'testing-'
  <...> as relevant and applicable", and hedges niche fits with "(only to the extent
  applicable)". This is a mandate for exactly the evidence-based selection this package
  performs — the user's own phrasing licenses the agent to choose.

## Which testing skill for which code shape

The user almost never picks a testing skill by hand; the operator layer does, and its
choices are consistent enough to serve as a matching table:

| Code shape | Skill |
|---|---|
| Parsers/decoders over untrusted input — "parse_/from_str/deserialize functions on untrusted input that lack fuzz harnesses"; format and manifest parsers; anything "whose entire contract is fail-closed behavior on hostile input" | `testing-fuzzing` |
| Ports with an upstream oracle — wide parity matrices against the original implementation, at a scale where hand-picked cases stop being representative | `testing-conformance-harnesses` |
| Pure compute with relations but no oracle — diff-with-self is empty, invariance under relabeling, monotonicity, determinism across runs | `testing-metamorphic` |
| Durable bytes crossing a trust boundary — canonical serializers, certificate formats ("its bytes are a contract, not an implementation detail"), stable JSON surfaces | `testing-golden-artifacts` |
| Recently landed or placeholder-prone trees — stub/placeholder functions, hardcoded fixtures shipping, green tests over fake code ("looks exactly like a pass") | `mock-code-finder` |
| Async/lock-heavy modules — await while holding a sync guard, lock-order inconsistency, blocked channels; a long-running TUI that dies after days; a test that hangs alone | `deadlock-finder-and-fixer` |
| Installers/CLIs/webapps that must be proven on real machines and real services | `testing-real-service-e2e-no-mocks` (recorded skip: "NOT applicable here (no DB)") |

One operational note worth keeping: fuzzing briefs have twice tripped a model provider's
safety filter on wording alone; the recorded fix is to reword — "my wording tripped a
provider content filter <...> ordinary input-validation and robustness testing of a
decoder we own" — not to abandon the campaign.

## Read vs run

The corpus draws a sharp line between invoking a skill and citing it as context, and a
selection run should preserve it. "use /gh-triage-ru to go over all my open issues and
PRs" is an execution order; the same prompt continues "also read /ru-multi-repo-workflow
and /gh-actions <...> for good background" — those are reading assignments, not
campaigns. The same pattern appears as "for insights on this" and "for tips", sometimes
with the skill's default explicitly overridden ("see /git-stash-janitor for insights on
this, but don't create a separate workspace or branch or worktree"). For the already-done
machine this matters directly: a "read /X for background" mention is not an attempt at X,
and must not produce an `in_progress` or `attempted_failed` state.

## Frequency conclusions

Categories, not counts — the corpus's pane-fan-out and re-invocation records make raw
numbers misleading:

- **Hand-typed, habitual.** The release pair (`release-preparations` + `dsr`),
  `de-slopify`, `cass`, `reality-check-for-project`, the perf ritual trio
  (`profiling-software-performance`, `repeatedly-apply-skill`,
  `extreme-software-optimization`), the swarm pair (`ntm` + `vibing-with-ntm`), the
  doctrine rider (`just-say-no-to-process-porn-and-ceremony`), the beads trio, `gh-triage-ru`,
  `ru-multi-repo-workflow`, `readme-writing`, `changelog-md-workmanship`, and one
  fixed-template media transcription skill (`transcribing-audio-from-calls-and-meetings`).
- **Orchestrator-selected, rarely hand-typed.** The `testing-*` family,
  `mock-code-finder`, `deadlock-finder-and-fixer`, `multi-pass-bug-hunting`,
  `codebase-audit`, `security-audit-for-saas`, `library-updater` — the user seeds the
  rotation ("as relevant and applicable") and the operator layer picks per code shape.
- **Reference-only.** Cited for background or as authoring exemplars but not executed:
  `codebase-archaeology`, `codebase-report`, several mega-skills consulted as
  library-usage guides during dependency bumps (`asupersync-mega-skill`,
  `frankensqlite-mega-skill`).
- **Never invoked in the corpus.** Most of the SaaS suite, the doctor-mode and docs-site
  skills, and various single-purpose tools — zero hand-typed invocations anywhere.
  Absence of use is not a verdict on quality; for scoring it simply means the
  already-done state is `not_seen` and history contributes nothing to J.
- **Alias-typed.** One media-remux skill was invoked exclusively under a former shorter
  name — alias recognition has to stay in the loop even though recommendations always
  print canonical names.
