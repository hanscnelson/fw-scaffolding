# Juncture Signals

What is happening on this project RIGHT NOW, mined from four sources in priority order, and
the already-done state machine that keeps the run from recommending yesterday's work.
Deterministic detectors: `scripts/juncture-signals.sh` (git/gh/beads/smells, ids `ev-j0001..`)
and `scripts/cass-juncture-mine.sh` (session history, ids `ev-c0001..`). Signal ids:
`references/data/signal-to-skill-map.json`.

## Contents

- [Source 1: session history via cass](#source-1-session-history-via-cass)
- [Source 2: git](#source-2-git)
- [Source 3: beads](#source-3-beads)
- [Source 4: code smells](#source-4-code-smells)
- [How to weigh the sources](#how-to-weigh-the-sources)
- [The already-done state machine](#the-already-done-state-machine)
- [Re-recommendation rules](#re-recommendation-rules)

## Source 1: session history via cass

The highest-signal source for "what is the user struggling with". Never run `cass` bare (it
is a TUI); always `--json`/`--robot` forms under a timeout.

Ad-hoc mining (juncture subagents), exact invocation:

```bash
cass search "<q>" --json --limit 60 --days 14 --max-content-length 400
```

Widen to `--days 60` when the 14-day window is sparse (the scripted batteries widen at
< 5 total hits across all batteries).

**Workspace-key resolution — do this BEFORE trusting zero hits.** The same project lives
under different roots on different machines, so a path-scoped query that misses proves
nothing. Resolve the workspace bucket first:

```bash
cass search "<target-basename>" --aggregate workspace --limit 1 --json
```

Only a confirmed workspace (the aggregate shows indexed sessions for the target path or its
basename) licenses an absence claim ("0 hits in confirmed workspace <key>"). No matching
bucket at all is itself a signal: `jx-onboarding` (no prior sessions on this project).

**Scripted batteries** (`scripts/cass-juncture-mine.sh`): each `jx-*` battery runs 2–3 phrase
queries of the form

```bash
cass search "<phrase>" --workspace "<key>" --since <ISO> --until <ISO> --json \
  --fields source_path,line_number,content --max-content-length 110 --limit 8
```

Hit confidence 2, or 3 at ≥ 3 hits. Locators are `source_path:line@origin_host`
(`@local` for local hits) — origin_host is preserved in every cited hit.

**Remote fan-out.** Agents on other machines often hold the real juncture signal. Hosts come
ONLY from `cass sources list --json` or `$SKILL_SELECTION_CASS_HOSTS` (or an explicit
`--hosts` grant); never invent a host. One-shot form per host and query:

```bash
ssh <host> 'IFS= read -r q && cass search "$q" --json --fields minimal --limit 20' <<< "$Q"
```

(The script adds `-o ConnectTimeout=5 -o BatchMode=yes` and `--days <N>`.) Remote hosts run
the error-class batteries only (panics, hangs, flaky tests, perf, payments, auth, deploy,
machine-unresponsive) — never the per-skill scan. A host timeout (60s) or ssh failure yields
ONE `unknown` record naming the host and the error — **a host timeout is unknown, never "no
sessions"**. An explicitly empty host list means "local only", recorded as a fact.

Cass-only signals worth knowing: `jx-user-frustration`, `jx-context-loss`,
`jx-contested-decision`, `jx-design-questions`, `jx-agents-deleted-things`,
`jx-cli-ergonomics-complaints`, `jx-history-underused` (sessions exist but recent ones never
consult history), `jx-cass-index-stale` (from `cass health --json`), `jx-onboarding`.

## Source 2: git

The ground truth for "what actually changed". Window = 14 days ending at the pinned clock;
every log carries `--since/--until`. Exact commands as `scripts/juncture-signals.sh` runs
them (`$WINDOW` = `--since=<NOW-14d> --until=<NOW>`):

```bash
git log $WINDOW --format='%h%x1f%an%x1f%cI%x1f%s' HEAD     # window commits + authors
git log $WINDOW --format=%b HEAD                            # bodies (agent co-author trailers)
git log $WINDOW --format='%x1e%h' --name-only HEAD          # churn by top-level directory
git rev-list --count <last-tag>..HEAD                       # release-overdue
git diff HEAD --numstat; git ls-files --others --exclude-standard   # uncommitted work
git for-each-ref refs/heads/; git worktree list; git stash list     # sprawl
```

Vocabulary densities are regex categories over window commit subjects (fix, hotfix, revert,
regress, flaky, perf, wip, port/parity/gauntlet, unsafe, deadlock/hang/timeout,
panic/crash/segfault, release, bump/upgrade, security, auth, deploy, payments, wasm, slow).
Thresholds:

| Signal | Rule |
|---|---|
| `jx-bug-fix-churn` | ≥ 4 commits in window AND fix-like ≥ 40% of them |
| `jx-regressions` | ≥ 1 revert or regression-vocabulary commit |
| `jx-recurring-panics` | ≥ 2 panic/crash commits (recurrence, not one incident) |
| `jx-perf-commits`, `jx-port-in-progress`, `jx-hang-or-deadlock`, `jx-auth-loops`, `jx-deploy-failures`, `jx-payments-bugs`, `jx-perf-complaints`, `jx-security-concern`, `jx-wasm-size-or-speed` | ≥ 1 matching commit (confidence 2–3) |
| `jx-release-overdue` | ≥ 40 commits since the last tag (projects with tags only) |
| `jx-release-imminent` | Release vocabulary or a `+version` manifest bump in the last 7 days |
| `jx-docs-drift` | ≥ 30 non-doc commits since README/CHANGELOG was last touched |
| `jx-uncommitted-work` | ≥ 200 uncommitted lines (diff numstat + untracked) |
| `jx-unsafe-touched` | Any added/removed line mentioning `unsafe` in window (committed or uncommitted) |
| `jx-dependency-bump` | Bump vocabulary ≥ 1 or any lockfile commit in window |
| `jx-flaky-tests` | Flaky vocabulary ≥ 1 or window commits touching ignore/skip markers |
| `jx-repo-sprawl` | Stale branches ≥ 10, or stashes ≥ 3, or extra worktrees ≥ 2 |
| `jx-upstream-sync-due` | An `upstream` remote ≥ 50 commits ahead (local refs only, no fetch) |
| `jx-swarm-active` | Multiple authors or agent co-author trailers in window |

GitHub adds (via `gh`, 30s timeouts, GitHub remote only): `jx-open-pr-backlog` (≥ 3 open or
any > 14 days), `jx-open-issue-backlog` (≥ 5 open or unanswered > 14 days), `jx-failing-ci`
(≥ 3 of the last 10 completed runs failed), `jx-issues-triage-due`. A non-git target makes
every git-derived signal `unknown` with detail "not a git repository".

## Source 3: beads

Read-only robot forms only (`br` runs with `--no-auto-flush --no-auto-import`; the bead
viewer with `--no-cache`):

```bash
br --no-auto-flush --no-auto-import list --status all --json
br --no-auto-flush --no-auto-import blocked --json
br --no-auto-flush --no-auto-import ready --json
br --no-auto-flush --no-auto-import doctor --json
bv --robot-triage --no-cache        # blockers_to_clear, top picks
bv --robot-insights --no-cache      # cycles
```

| Signal | Rule |
|---|---|
| `jx-beads-many-open` | ≥ 20 open beads |
| `jx-beads-blocked` | Blocked beads, blockers_to_clear, or dependency cycles |
| `jx-beads-queue-dry` | 0 ready while open > 0 |
| `jx-beads-stale-epics` | Open epics whose children are ALL closed — the "did we actually finish" smell; pairs with the closed-bead compliance audit |
| `jx-beads-corrupt` | doctor reports corruption/drift, or `br list` errors with schema-mismatch text |
| `jx-plan-no-beads` | A plan/roadmap file exists but `.beads/` is missing or empty |

`.beads/` present but `br` missing → every beads signal is `unknown`, never absent.

## Source 4: code smells

Density thresholds over non-test, non-generated code (same exclusions as the profiler):

| Signal | Rule |
|---|---|
| `jx-todo-density-high` | TODO/FIXME/HACK/XXX ≥ 5 per kLOC |
| `jx-unwrap-density-high` | `.unwrap()`/`.expect(` ≥ 8 per kLOC of non-test Rust |
| `jx-dead-code-sprawl` | allow(dead_code/unused) ≥ 5, or ≥ 50 commented-out code lines, or ≥ 1 with window commits touching them (growing) |
| `jx-mock-suspicion` | ≥ 3 stubs/placeholders/todo!() in non-test code |
| `jx-ceremony-smell` | Subagent + cass: process artifacts growing while shipped capability does not |

## How to weigh the sources

- **cass beats git beats beads** for "what is the user struggling with": a session where the
  user typed "still broken, so frustrating" outweighs any commit-message inference, which
  outweighs a bead title.
- **git beats cass** for "what actually changed": sessions record intent and attempts; the
  log records what landed. A cass claim of completion with no commit is an attempt.
- Corroboration across sources raises E (evidence quality); fewer than two source types
  contributing confidence ≥ 2 takes the corroboration penalty at scoring time.
- Recency wins inside a source: a 3-day-old panic outweighs a 13-day-old one; say so in the
  claim rather than inventing extra signal ids.

## The already-done state machine

Every catalog skill carries one state per run, derived from cass invocation mentions
(the miner's companion file maps `<canonical-name>` → mention_count/refs/hosts, scanned via
`cass search "<canonical-name>" --workspace "<key>" --since <ISO> --until <ISO> --json
--fields minimal --limit 12`), run history, beads, and git. The 8 states and their D values
(from `references/data/scoring-constants.json`, `already_done_D`):

| State | Meaning | D |
|---|---|---|
| `not_seen` | No trace of this skill for this project | 0 |
| `unknown` | Sources that would show it were unavailable | 1 |
| `suggested_untried` | A previous run recommended it; nothing happened | 1 |
| `attempted_failed` | Invoked, but the outcome failed or was abandoned | 2 |
| `in_progress` | Running now or mid-flight (recent invocation, no completion evidence) | 3 |
| `superseded` | Another skill/campaign already covered its outcome | 3 |
| `completed_successfully` | Finished with verifiable outcome | 4 in the 30-day window, 1 after |
| `declined` | The user said no | 4 while the stated condition holds, 1 once lifted |

**Derivation rules — the evidence bar rises with the claim:**

- An invocation found in cass (a slash-invocation of the skill's canonical name in a
  session) proves **attempted, never succeeded**. Alone it yields `in_progress` (recent) or `attempted_failed`/`suggested_untried`
  (older, depending on what the transcript shows).
- `completed_successfully` requires artifact-or-outcome evidence: the expected artifact
  exists in the tree, a commit landed the work, or a matching bead was closed. Record the
  evidence ids on the state.
- `declined` requires the user's own words; carry the condition verbatim
  (e.g. declined "until the port is done") in the already-done record's `condition` field
  with `condition_holds` re-evaluated each run (null is treated as still holding).
- No trace at all in a confirmed workspace → `not_seen`. Unconfirmed workspace or cass
  unavailable → `unknown` (D=0, no gate — but say so in the ledger).

## Re-recommendation rules

Suppression gates run BEFORE tier rules and cap a row at KEEP HANDY regardless of score
(`suppression` in scoring-constants: gates `completed_recently`, `declined_condition_holds`,
`in_progress`; `completed_window_days: 30`; `cap_tier: keep_handy`):

- **Completed within 30 days** (`since` vs the pinned clock): D=4 AND the
  `completed_recently` gate caps the tier. After 30 days the gate lifts and D drops to 1 —
  recurring hygiene (changelog, deps, triage) becomes recommendable again on its own merits.
- **Declined while the condition holds**: D=4 AND `declined_condition_holds` caps the tier.
  The condition is carried forward run to run ("declined until X"); each run re-checks X.
  Once lifted, D=1 and the row competes normally — with the history noted in its reason.
- **In progress**: D=3 AND the `in_progress` gate caps the tier. Do not re-kick a running
  campaign; the ledger row says so instead.
- `attempted_failed` (D=2) does NOT gate: a failed attempt plus a persisting signal is a
  legitimate re-recommendation — say what failed last time in the reason.
- The scorer's cross-check compares the previous run's RUN NOW/RUN SOON rows against current
  states and reports acted_on / declined / still_pending, so repeated suggestions are visible
  rather than silent.

Scoring mechanics for J/E and the gates: SCORING-RUBRIC.md.
