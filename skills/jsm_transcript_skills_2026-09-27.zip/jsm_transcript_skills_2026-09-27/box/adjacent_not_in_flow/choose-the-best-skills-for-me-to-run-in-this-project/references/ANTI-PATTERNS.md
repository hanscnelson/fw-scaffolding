# Anti-Patterns

The failure modes this skill is built to prevent. Each: the smell, why it fails, the
correction. The table in SKILL.md is the summary; this is the expansion.

## Contents

- [Selection anti-patterns](#selection-anti-patterns)
- [Evidence anti-patterns](#evidence-anti-patterns)
- [Process anti-patterns](#process-anti-patterns)

## Selection anti-patterns

**Recommending everything.** Smell: 20 skills in RUN NOW, every table row enthusiastic.
Why it fails: an unranked pile transfers the selection work back to the user; the ledger
exists to prove judgment, not enthusiasm. Correction: the portfolio cap is 3 campaigns;
everything else earns an explicit tier and a reason, including "not now".

**Recommending from directory names.** Smell: "it has a fuzz directory, recommend fuzzing"
with no evidence record behind it. Why it fails: names lie — an empty fuzz dir, a vendored
site, a stale plan file. Correction: every activation cites an evidence record with a
locator; no record, no signal.

**Ignoring anti-signals.** Smell: recommending a fuzzing campaign to a project with mature
fuzz targets. Why it fails: A is scored down by firing anti-signals precisely so accretive
work wins over re-work; ignoring them recommends undoing. Correction: say "not now, already
covered" as clearly as "yes" — the ⊘ move is part of the deliverable.

**Re-recommending what was just done.** Smell: last week's campaign back in RUN NOW. Why it
fails: it proves the run never looked at its own history, which costs all credibility.
Correction: the already-done state machine and the 30-day suppression gates run BEFORE tier
rules; check the run history appendix and the cross-check block every run.

**Filling RUN NOW with three steps of one campaign.** Smell: three "campaigns" that are
really phase 1/2/3 of one effort. Why it fails: it spends the whole portfolio on one
disease and hides the cap. Correction: steps live inside ONE campaign's sequence; the other
slots go to unrelated wins (the overlap rule rejects >50% shared firing signals or
alternative_to pairs mechanically).

**Naming skills that don't exist.** Smell: a plausible-sounding name in a table that is in
no catalog. Why it fails: the user pastes a kickoff that cannot run; validate-run.py blocks
the artifact for exactly this — but the fix is not to produce such names, not to fight the
validator. Correction: every name comes from the normalized catalog; unmapped-but-real
skills get provisional rows (E capped at 2), never invented ones.

**Gaps that name an existing skill.** Smell: the gap list proposes "a skill for webhook
replay testing" while the catalog has one. Why it fails: a gap row is a request to build; it
signals the catalog was never actually read. Correction: that is a MATCH — activate the
existing skill; a gap must state which catalog query came up empty.

## Evidence anti-patterns

**Treating a timeout as absence.** Smell: an unreachable host or a 60s rg timeout recorded
as "no sessions"/"absent". Why it fails: it violates the three-state rule and silently
poisons every downstream absence claim. Correction: record `unknown` plus the error text;
absence requires positive evidence (a completed search over an excluded-and-confirmed
scope).

**Treating `jsm suggest` as ground truth.** Smell: the run's top picks mirror `jsm suggest`
output. Why it fails: it is a Thompson-sampling bandit over INSTALLED skills — empty on a
fresh machine, which is exactly why this skill exists; it knows popularity, not this
project's juncture. Correction: record it as one weak signal in the run data, never
decisive, never a tier justification.

**Spinning "unknown" as reassurance.** Smell: "no security concerns were found" when the
scan errored, or "tests look healthy" when the tests dimension is unknown. Why it fails:
the reader hears a verified negative; the doc is now wrong the moment the tool works.
Correction: report unknowns as unknowns with what failed and what would resolve them —
"unknown ≠ absent" applies to prose, not just JSON.

## Process anti-patterns

**Heavy analysis on a fresh profile.** Smell: profiler subagents fanning out after Phase 1
said reuse. Why it fails: it burns the run budget re-deriving what the fingerprint already
guarantees, and invites drift between two profiles of the same tree. Correction: reuse
means NO Phase 2 subagents and no large source reads except to verify a changed juncture
claim; the juncture alone refreshes.

**Modifying anything in the target project.** Smell: "while I was there I fixed…", a
formatter run, a bead closed, a branch created. Why it fails: this is the one hard runtime
rule — analysis must be trustable as read-only or it cannot be run casually. Correction:
the only writes are the two approved docs (and the temp dir for ephemeral clones);
recommendations propose work, campaigns do it later under their own permissions.

**Letting the review passes loop.** Smell: pass A → B → C → A → B → … "one more fix".
Why it fails: unbounded self-review is ceremony that never converges; each pass rewrites
the last one's phrasing. Correction: A, B, C run once each; A repeats once more only iff a
tier or campaign membership changed; four passes total, then ship.

**Building process artifacts about the process.** Smell: a run summary of the ledger of the
analysis, meta-reports, a tracking doc for the recommendation workflow itself. Why it
fails: this skill routinely recommends the anti-ceremony doctrine
(`just-say-no-to-process-porn-and-ceremony`) — it must obey it; artifacts that no next run
reads are pure ceremony. Correction: exactly two docs plus the run JSON; anything else must
name the consumer who will read it, or not exist.
