# Catalog Acquisition

How a run learns what skills exist: the `jsm` command surface it actually uses, the
three-tier fallback ladder (`scripts/catalog-fetch.sh`), the drift and
provisional-mapping protocol, and the local inventory of what is already installed. The
output is the **normalized catalog**: exactly one entry per canonical skill name, each
validating against `references/schemas/catalog-entry.schema.json`, feeding the
one-row-per-skill ledger invariant.

## Contents

- [The jsm surface this skill uses](#the-jsm-surface-this-skill-uses)
- [Headless auth and offline mode](#headless-auth-and-offline-mode)
- [The fallback ladder](#the-fallback-ladder)
- [Drift and the provisional-mapping protocol](#drift-and-the-provisional-mapping-protocol)
- [Local inventory: enumeration, precedence, skew](#local-inventory-enumeration-precedence-skew)
- [Timeouts and degraded mode](#timeouts-and-degraded-mode)
- [Renames and aliases](#renames-and-aliases)
- [Authoring-time snapshot refresh](#authoring-time-snapshot-refresh)

## The jsm surface this skill uses

Every invocation is a `--json`/robot form under a timeout; nothing below writes to the
target project. Grouped by what the run uses them for:

**Session state**

| Command | Use here |
|---|---|
| `jsm whoami --json` | The tier-1 gate: `.authenticated` true/false. Run first, with only the remaining aggregate acquisition budget. |
| `jsm doctor` / `jsm status` | Diagnosis when whoami fails or behaves oddly — auth, paths, connectivity. Never parsed for catalog data. |
| `jsm config show --json` | **The authoritative managed-directories list** (`.values.skills_dir` plus the per-harness `.values.skills.*_dir` entries). The local inventory enumerates from it; nothing else guesses at install locations. |

**Catalog enumeration and metadata**

| Command | Use here |
|---|---|
| `jsm list --remote --jeffreys --json` | The live name list (newest page). Tier-1 name source, bounded by the same aggregate deadline. |
| `jsm show <name> --json` | Per-skill description, tags, category, `updated_at`, `content_hash`, author, visibility. Fetched only for names that are new or changed vs the snapshot. |
| `jsm related <name> --json` | Relationship edges (`pairs_with`, `alternative_to`, `extends`, `prerequisite`). **Version quirk:** older jsm prints the exact plain-text sentinel `No related skills found.` when a skill has no edges; current versions return the structured empty shape. Only that exact sentinel means "no edges." Any other malformed response is a source error, and a previous snapshot's edges are retained. |
| `jsm search <query>` / `jsm why <name>` / `jsm examples <name>` | Ad-hoc lookups while matching: confirm a suspected match, read the rationale, pull invocation examples for kickoff blocks. Never a name-list source. |
| `jsm tags` | The tag vocabulary, for normalizing tag-based trigger models on provisional rows. |
| `jsm context --json` | jsm's own view of the current project context. Recorded as one more observation; the profiler's evidence records outrank it. |
| `jsm graph` | Relationship overview across the catalog; useful when the relationships catalog-agent sanity-checks recipe membership. |

**Weak-signal commands (recorded, never decisive)**

| Command | What it is — and is not |
|---|---|
| `jsm scan --json` | Runs the catalog's `detect:` rules against the tree. Returns nothing on catalogs whose entries carry no detect rules — an empty result is a fact about the catalog, not about the project. |
| `jsm suggest --json --debug` | A Thompson-sampling bandit over INSTALLED skills and recorded outcome history. Empty on a fresh machine; blind to everything not installed. One weak signal among many — recorded in the evidence, never the answer. |

**Acting on results**

| Command | Use here |
|---|---|
| `jsm install <name>` | Install a winner or a missing referenced engine — only under the envelope grant. |
| `jsm install --related <name>` | **Avoid** unless every related skill is itself recommended: `--related` pulls in alternatives, which contradicts a ledger that just ranked one of them above the others. |
| `jsm install-all` | Bulk install; envelope-gated, and only when the user asked for the whole set. |
| `jsm load <name> --level overview` | Cheap skill-content peek while matching, without paying for the full body. |
| `jsm outcome -s <name> --success` / `--failure`, `jsm outcome --batch <file>.jsonl` | Close the loop after campaigns run; the batch form when several outcomes are reported at once. The end-of-run checklist reminds the user. |
| `jsm requests` | Where confirmed gaps (catalog queries that came up empty) are offered as skill requests — with permission. |
| `jsm validate` | Package validation; used by this package's own `scripts/validate-skill.py` as an informational report. |

## Headless auth and offline mode

`jsm` prompts for a credentials passphrase interactively; a subagent has no TTY. For
headless runs:

```bash
export JSM_ALLOW_ENV_PASSPHRASE=1
export JSM_CREDENTIALS_PASSPHRASE=<passphrase>   # from the user's secret store, never hardcoded
```

Both are required — the first is the opt-in switch, the second the value. Without them,
a headless `jsm whoami --json` reports unauthenticated and the ladder falls to tier 2;
that is a correct degradation, not a failure.

Offline mode: `bash scripts/catalog-fetch.sh --offline ...` or `JSM_OFFLINE=1` forces
local-only behavior — useful when the network is outside the approved envelope. It makes
**zero** `jsm` or `curl` calls and uses the bundled snapshot directly, so catalog
acquisition behaves as tier 3 even when those tools are installed.

## The fallback ladder

`bash scripts/catalog-fetch.sh --out FILE [--snapshot FILE] [--cache-dir DIR]
[--deadline SECONDS] [--offline]` emits
`{"skills": [...], "source_tier": "jsm|website|snapshot", "drift": {...}, "drift_known": bool, "retirement_known": bool}`.
The ladder degrades in confidence, never in coverage — every tier still yields one entry
per known name.

**Tier 1 — `jsm` (authoritative).** Requires `jsm` on PATH and `jsm whoami --json`
authenticated within the remaining deadline. The name universe is the union of `jsm list
--remote --jeffreys --json`, the public sitemap slugs (when reachable), and the bundled snapshot's
names. Only names that are **new or whose `updated_at` or `content_hash` differs** from the snapshot are
fetched live (`jsm show/related <name> --json`, each receiving only the remaining budget,
cached in `--cache-dir`; a
cache file is reused only when written this run). Live-confirmed entries get
`catalog_sources: ["public"]`; unchanged names reuse the snapshot entry normalized to
`["snapshot"]`. The exact `No related skills found.` sentinel is parsed as empty related
groups. Any other malformed relationship response is recorded in `source_errors` and
keeps the previous snapshot edges instead of erasing them.

**Tier 2 — website.** `jsm` missing or unauthenticated, but `curl` and the network work.
Slugs come from `https://jeffreys-skills.md/skills/sitemap.xml`; names already in the
snapshot reuse the snapshot entry; **new** names get their preview page's
`<meta name="description">` as the description, tagged `catalog_sources: ["website"]` —
and matches built on that thin metadata carry lower confidence (this is one of the inputs
behind the provisional E cap below).

**Tier 3 — bundled snapshot.** Neither jsm nor the website reachable: the shipped
`references/data/catalog-snapshot.json` is used as-is, every entry `["snapshot"]`, with a
stderr warning. The run proceeds normally, but **drift is unknowable** — see below.

The ladder is announced once ("catalog source: tier N") and recorded in the run JSON.
Falling a tier is never a reason to stop, re-ask the envelope, or pad scores.

## Drift and the provisional-mapping protocol

Drift compares the live name universe against the bundled snapshot, after canonicalizing
former names through `references/data/aliases.json`:

- **new** — live names absent from the snapshot;
- **changed** — `updated_at` or `content_hash` differs from the snapshot entry;
- **retired** — snapshot names absent from the complete public sitemap. The newest-page
  `jsm list` response is never treated as proof of retirement.

New and changed entries can be reported from either live source. Retirement and the
aggregate `drift_known: true` claim require a complete sitemap
(`retirement_known: true`). Thus an authenticated `jsm` newest-page result with an
unreachable sitemap may report new/changed entries while emitting `retired: []` and both
completeness flags false. Tier 3 emits empty arrays with both flags false — an empty drift
report means "could not check", never "no drift". Retired names keep their ledger row for
audit continuity with `applicability_basis: catalog-retired`; they are never recommended.

**Provisional mapping.** The trigger models live in
`references/data/signal-to-skill-map.json`. A skill present in the catalog but absent from
that map — typically a `new` drift entry — still gets its one ledger row, marked
`provisional_mapping: true`, with:

- **E capped at 2** (the hard cap in the scoring contract — see
  SCORING-RUBRIC.md), because the match rests on improvised triggers;
- a trigger model **derived on the fly** from what the catalog entry does provide: its
  description, the `Use when` clause, tags, and related edges;
- a note in the recommendations doc suggesting a signal-map refresh as follow-up work.

Provisional rows compete normally under the cap. The protocol never blocks a run and
never invents evidence: a provisional skill that genuinely fits the juncture can still
reach RUN SOON on a J-heavy score; it cannot fake E=4 corroboration it does not have.

## Local inventory: enumeration, precedence, skew

`bash scripts/local-skills-inventory.sh [--target DIR] --out FILE` answers "what is
already installed, and which copy wins". Enumeration order **is** the dedupe precedence —
the first copy of a canonical name wins:

1. **Target-project-local**: `<target>/.claude/skills` and `<target>/.agents/skills`
   (only when `--target` is given).
2. **The running harness's user dir**: `$CLAUDE_CONFIG_DIR/skills` (else
   `~/.claude/skills`) when a Claude Code env var is present; `$CODEX_HOME/skills` when
   `CODEX_HOME` is set. Codex plugin-cache trees are searched recursively for their
   `skills/` roots. When no harness is detectable, jsm's `skills_dir` becomes the primary
   instead.
3. **Every directory from `jsm config show --json`**: `.values.skills_dir` first, then
   the per-harness `.values.skills.{claude_dir,codex_dir,gemini_dir,cursor_dir,openclaw_dir,hermes_dir}`
   entries (nulls skipped). With no `jsm`, a literal fallback list of the conventional
   per-harness home directories is used instead.
4. `~/.agents/skills` last.

Duplicate handling: a later copy whose content hash differs from the winner's is recorded
in the winner's `skew` array (path + hash); byte-identical copies are ignored silently.
Skew is reported in the analysis doc — it usually means one harness's copy is stale, which
matters when a recommendation says "already installed". The content hash is stable:
sha256 over every sorted relative path and every regular file's bytes, so a payload change
outside `SKILL.md` cannot hide while reordering files or touching timestamps does not fake
a skew. Local-only entries stay `provisional_mapping: true` unless an explicit map entry
exists.

Entries are catalog-entry objects (`catalog_sources: ["local"]`, `installed: true`,
front-matter description/tags/detect rules), so the merge with the public catalog is a
plain union keyed by canonical name — `installed` and `resolved_path` land on the
normalized entry, and a local-only skill (in no public source) still gets its ledger row.

## Timeouts and degraded mode

Two layers, both degrading to `unknown` — never to absence, never to a stalled run:

- **One aggregate acquisition deadline**: `catalog-fetch.sh --deadline N` defaults to 30
  seconds. Every `jsm` and `curl` receives only the remaining budget; once it is exhausted,
  no new network call begins. A timed-out per-skill fetch leaves that name on its snapshot
  entry and records the source error.
- **Run-level budgets** (the proportionality block in SKILL.md):
  `gh` 30s, jsm/API 30s, each remote cass host 60s. Exceeding a budget writes an evidence
  record with `state: unknown` plus the error text, and the run continues.

Degraded mode is therefore a spectrum, not a switch: jsm slow → tier 1 with more snapshot
reuse; jsm gone → tier 2; network gone → tier 3 with `drift_known: false`. The only
hard failure is a snapshot that is missing or fails schema validation — that is a broken
package, exit 1.

## Renames and aliases

`references/data/aliases.json` maps **former** public names to current canonical names.
It is used for recognition only, at every boundary where a name enters the run: live list
names and sitemap slugs (catalog-fetch), local directory names and front-matter names
(inventory), and session-history mentions (the already-done scanner). Rules:

- Canonicalize immediately; nothing downstream ever sees an alias.
- Never recommend, install, or print an alias — kickoff prompts and install lines use
  canonical names exclusively, even when the user's own history shows they habitually
  type a former name.
- An alias hit still counts for the already-done state machine (an invocation under the
  old name is an invocation).

## Authoring-time snapshot refresh

`bash scripts/refresh-catalog-snapshot.sh` is the one script allowed to rewrite
`references/data/catalog-snapshot.json`, and it is an authoring tool, not a run phase: it
**refuses to run without `jsm`**, confirms every candidate via `jsm show` (keeping only
public catalog skills), treats only the exact no-related sentinel as empty, preserves
prior edges on malformed relationship responses, and re-renders the generated views when
the renderer is present. Runs never mutate the snapshot; they only
read it. When a run's drift report keeps flagging the same `new` names, the follow-up is
to run the refresh on an authoring machine — not to hand-edit the snapshot.
