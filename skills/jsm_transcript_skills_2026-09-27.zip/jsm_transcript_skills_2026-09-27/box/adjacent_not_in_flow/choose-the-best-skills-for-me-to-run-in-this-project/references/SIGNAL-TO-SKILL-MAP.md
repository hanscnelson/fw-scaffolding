<!-- generated_from_sha256: sha256:9638a1cf12186149edbf296d716fb23d60b2180ec08016b28105614e0322739a -->
<!-- generated_at: 2026-08-27T14:00:00Z -->
<!-- generator_version: 2.0.0 -->
<!-- GENERATED VIEW - do not hand-edit. Source: references/data/signal-to-skill-map.json; regenerate with scripts/render-reference-views.py -->


# Signal-to-Skill Map (generated view)

Covers 131 skills with 243 signals; harmonized against the catalog listing of 2026-08-26T13:30:00Z.

## Signal vocabulary

| Signal | Kind | Detector | Description |
|---|---|---|---|
| agent-mail-project | profile | profile-project.sh | .agent-mail-project-id present. |
| beads-absent | profile | profile-project.sh | No .beads/ directory. |
| beads-present | profile | profile-project.sh | .beads/ directory exists. |
| bench-harness-present | profile | profile-project.sh | criterion/divan benches, hyperfine scripts, or benches/ directory. |
| build-cargo-workspace | profile | profile-project.sh | [workspace] with members in Cargo.toml. |
| cargo-features-heavy | profile | profile-project.sh | Many [features] flags (>= 5) or optional dependencies. |
| cargo-profile-tuned | profile | profile-project.sh | [profile.release] tuning (lto, codegen-units, opt-level, panic=abort) or -C target-cpu in .cargo/config. |
| ci-config | profile | profile-project.sh | CI configuration exists. |
| ci-none | profile | profile-project.sh | No CI configuration found. |
| code-agent-swarm-scaffolding | profile | profile-project.sh | .beads/, .agent-mail-project-id, ntm config, or swarm orchestration docs present. |
| code-arena-self-referential | profile | profile-project.sh | Arena/slab/index-based graphs or self-referential structures (Pin, raw pointers). |
| code-async-holding-lock | profile | profile-project.sh | await while a std::sync guard is live, or block_on inside async code. |
| code-binary-format | profile | profile-project.sh | Binary format read/write (from_le_bytes, byteorder, magic headers, container formats). |
| code-cli-subcommands | profile | profile-project.sh | A multi-subcommand CLI surface (>= 5 subcommands). |
| code-codegen-renderer | profile | profile-project.sh | Produces durable artifacts whose bytes are a contract (renderers, code generators, serializers, exporters). |
| code-concurrency-primitives | profile | profile-project.sh | Mutex/RwLock/tokio::sync/parking_lot/channels/atomics in non-test code. |
| code-crypto-auth | profile | profile-project.sh | Cryptography or authentication code (signatures, JWT, OAuth flows, key handling). |
| code-doctor-command | profile | profile-project.sh | CLI exposes a doctor/health/diagnose subcommand. |
| code-ffi-boundary | profile | profile-project.sh | extern "C", bindgen, cffi, N-API, or #[no_mangle] exports. |
| code-generated-or-vendored-excluded | profile | profile-project.sh | Generated and vendored paths were identified and excluded from the code-kind scans (required before any absence claim about code … |
| code-gpu-cuda | profile | profile-project.sh | CUDA/Metal/wgpu kernels. |
| code-installer-script | profile | profile-project.sh | install.sh / install.ps1 / curl-bash installer exists. |
| code-json-robot-mode | profile | profile-project.sh | CLI exposes --json/--robot output. |
| code-lock-free | profile | profile-project.sh | Atomics with explicit Ordering, crossbeam-epoch, lock-free structures. |
| code-mcp-tools | profile | profile-project.sh | MCP tool definitions in-tree. |
| code-ml-kernels | profile | profile-project.sh | Matmul/attention/quantization kernels implemented in-tree. |
| code-network-protocol | profile | profile-project.sh | Custom wire protocol or transport (framing, handshakes, QUIC/UDP, fountain codes). |
| code-numeric-transforms | profile | profile-project.sh | Numerical/transform code with algebraic relations (DSP, statistics, graph algorithms, geometry). |
| code-parser | profile | profile-project.sh | Hand-written parser/lexer/decoder over untrusted input (fn parse, from_str, nom/winnow/pest, tokenizer). |
| code-payments-billing | profile | profile-project.sh | Billing logic: subscriptions, invoices, checkout sessions, entitlements. |
| code-port-of-other-language | profile | profile-project.sh | A port of C/C++/Python/Zig/Go code to Rust (parity docs, upstream/ references, port commit vocabulary). |
| code-release-workflow | profile | profile-project.sh | Release automation exists (release workflow, cargo-dist, goreleaser, semantic-release). |
| code-search-index | profile | profile-project.sh | Implements or embeds a search index (tantivy, frankensearch, BM25, embeddings). |
| code-simd-hot-loops | profile | profile-project.sh | SIMD intrinsics, #[inline(always)] hot paths, or explicit vectorization. |
| code-spec-reimplementation | profile | profile-project.sh | Reimplements a published spec or an upstream oracle (SQLite, rsync, networkx, a wire spec). |
| code-sqlite-persistence | profile | profile-project.sh | Persists state in SQLite (rusqlite, sqlx sqlite, fsqlite, better-sqlite3). |
| code-storage-engine | profile | profile-project.sh | Storage engine internals (WAL, MVCC, B-tree, page cache, fsync). |
| code-tui-renderer | profile | profile-project.sh | A bespoke terminal renderer/layout engine (cell buffers, diffing, escape sequences). |
| code-unsafe-any | profile | profile-project.sh | At least one unsafe block in non-generated, non-vendored Rust. |
| code-unsafe-heavy | profile | profile-project.sh | unsafe blocks/fns in non-generated, non-vendored Rust (count >= 5 or >= 1 per 500 LOC). |
| code-wasm-bindgen | profile | profile-project.sh | wasm-bindgen/js-sys/web-sys usage. |
| code-webhooks | profile | profile-project.sh | Inbound webhook handlers (signature verification, event dispatch). |
| dep-asupersync | profile | profile-project.sh | Depends on the asupersync crate. |
| dep-frankensearch | profile | profile-project.sh | Depends on frankensearch crates. |
| dep-frankensqlite | profile | profile-project.sh | Depends on the fsqlite crates. |
| dep-frankentui | profile | profile-project.sh | Depends on frankentui/ftui crates. |
| deps-outdated | profile | profile-project.sh | Dependency freshness review is due. Lockfile age is weak evidence only unless an outdated-check result corroborates it. |
| docs-adrs | profile | profile-project.sh | ADRs/design records exist. |
| docs-agents-md | profile | profile-project.sh | AGENTS.md or CLAUDE.md present. |
| docs-changelog-fresh | profile | profile-project.sh | CHANGELOG.md mentions the latest tag or was touched after it. |
| docs-changelog-missing | profile | profile-project.sh | No CHANGELOG.md (or equivalent) although the project has tags/releases. |
| docs-changelog-stale-vs-tags | profile | profile-project.sh | CHANGELOG.md last touched before the most recent tag, or does not mention the latest tag. |
| docs-contributing | profile | profile-project.sh | CONTRIBUTING.md exists. |
| docs-license | profile | profile-project.sh | LICENSE file exists. |
| docs-plan-file | profile | profile-project.sh | A plan/roadmap/spec markdown file exists (PLAN*.md, *_PLAN.md, ROADMAP*, docs/plan*). |
| docs-prose-sounds-generated | profile | subagent:profiler-docs-and-process | Public-facing prose (README, site copy) carries model-written tells (judgment call, cite phrases). |
| docs-readme-missing | profile | profile-project.sh | No README.md. |
| docs-readme-weak | profile | profile-project.sh | README is short (< 60 lines), lacks install/usage sections, or is template text. |
| docs-security-md | profile | profile-project.sh | SECURITY.md exists. |
| docs-site-missing | profile | profile-project.sh | Public project with substantial docs/ but no docs site. |
| doctor-missing-for-cli | profile | profile-project.sh | Multi-subcommand CLI with no doctor/diagnose command. |
| framework-heavy | profile | profile-project.sh | Dependency graph dominated by a framework (Next.js, Django, Rails, actix/axum + many middleware crates). |
| fw-charm-bubbletea | profile | profile-project.sh | Go charmbracelet dependencies (bubbletea, lipgloss, gum). |
| fw-cloudflare-workers | profile | profile-project.sh | wrangler.toml/json present. |
| fw-drizzle-prisma | profile | profile-project.sh | drizzle-orm or prisma dependency / migrations directory. |
| fw-ga4 | profile | profile-project.sh | GA4/gtag/GTM integration present. |
| fw-gh-actions | profile | profile-project.sh | .github/workflows/*.yml present. |
| fw-nextjs | profile | profile-project.sh | next dependency / next.config.* |
| fw-nextra | profile | profile-project.sh | nextra dependency (docs site). |
| fw-paypal | profile | profile-project.sh | PayPal SDK dependency or PayPal webhook code. |
| fw-playwright | profile | profile-project.sh | @playwright/test dependency or playwright.config.* |
| fw-snowflake | profile | profile-project.sh | Snowflake connector/SQL present. |
| fw-stripe | profile | profile-project.sh | stripe dependency or Stripe webhook/checkout code. |
| fw-supabase | profile | profile-project.sh | @supabase/* dependency or supabase/ directory. |
| fw-tanstack | profile | profile-project.sh | @tanstack/* dependency. |
| fw-threejs | profile | profile-project.sh | three / @react-three dependency. |
| fw-tokio | profile | profile-project.sh | tokio/async-std runtime dependency. |
| fw-vercel | profile | profile-project.sh | vercel.json or .vercel/ present. |
| gap-cli-no-json-snapshot | profile | profile-project.sh | CLI with --json output but no snapshot/golden test of that output. |
| gap-concurrency-no-model | profile | profile-project.sh | Concurrency primitives present with no loom/shuttle model and no sanitizer run. |
| gap-mocks-without-real-e2e | profile | profile-project.sh | Tests mock the services the product depends on and no real-service test exists. |
| gap-numeric-no-metamorphic | profile | profile-project.sh | Numeric/transform code with no metamorphic or property tests. |
| gap-parser-no-fuzz | profile | profile-project.sh | Parser/binary-format code present with no fuzz target covering it. |
| gap-payments-no-webhook-replay | profile | profile-project.sh | Webhook/billing code present with no webhook replay or idempotency test. |
| gap-renderer-no-golden | profile | profile-project.sh | Renderer/codegen/serializer output with no golden tests. |
| gap-spec-no-conformance | profile | profile-project.sh | Spec reimplementation or port with no conformance harness. |
| gap-unsafe-no-miri | profile | profile-project.sh | unsafe code present with no Miri/sanitizer run. |
| gap-webapp-no-e2e | profile | profile-project.sh | Web app with no e2e/browser tests. |
| hand-rolled | profile | profile-project.sh | Few dependencies; core mechanisms implemented in-tree. |
| installer-missing-for-cli | profile | profile-project.sh | CLI with releases but no installer script. |
| installer-weak | profile | profile-project.sh | Installer lacks checksums, platform detection, version pin, or uninstall. |
| iphone-takes-present | profile | profile-project.sh | Multiple iPhone video takes of one performance present. |
| issue-templates | profile | profile-project.sh | .github/ISSUE_TEMPLATE present. |
| json-mode-missing-for-cli | profile | profile-project.sh | Multi-subcommand CLI with no --json/--robot mode. |
| jx-agents-deleted-things | juncture | cass-juncture-mine.sh | Sessions show destructive commands or lost work. |
| jx-auth-loops | juncture | cass-juncture-mine.sh\|juncture-signals.sh | Auth/login/OAuth failures recently. |
| jx-beads-blocked | juncture | juncture-signals.sh | Blocked beads or dependency cycles reported by bv. |
| jx-beads-corrupt | juncture | juncture-signals.sh | br doctor reports corruption or JSONL drift. |
| jx-beads-many-open | juncture | juncture-signals.sh | >= 20 open beads. |
| jx-beads-queue-dry | juncture | juncture-signals.sh | No ready beads while the vision is not delivered. |
| jx-beads-stale-epics | juncture | juncture-signals.sh | Open epics whose children are all closed ('did we actually finish'). |
| jx-big-change-no-plan | juncture | cass-juncture-mine.sh\|subagent:juncture-git | A large change is being discussed or started with no plan file. |
| jx-bug-fix-churn | juncture | juncture-signals.sh | High density of fix/hotfix commits in the window (>= 40% of commits). |
| jx-cass-index-stale | juncture | cass-juncture-mine.sh | The local cass index is stale or missing. |
| jx-ceremony-smell | juncture | subagent:juncture-code-smells\|cass-junctur… | Process artifacts growing while shipped capability does not; status reports without code. |
| jx-cli-ergonomics-complaints | juncture | cass-juncture-mine.sh | Agents or users struggled with the CLI's output/flags recently. |
| jx-contested-decision | juncture | cass-juncture-mine.sh | A decision was argued back and forth or reverted recently. |
| jx-context-loss | juncture | cass-juncture-mine.sh | Sessions ended in compaction or the user re-explained the same thing repeatedly. |
| jx-dead-code-sprawl | juncture | juncture-signals.sh | allow(dead_code)/commented-out blocks growing. |
| jx-dependency-bump | juncture | juncture-signals.sh\|cass-juncture-mine.sh | Dependency upgrades in progress or an upstream release the project should adopt. |
| jx-deploy-failures | juncture | cass-juncture-mine.sh\|juncture-signals.sh | Failed deploys or hosting issues recently. |
| jx-design-questions | juncture | cass-juncture-mine.sh | Design-space or 'what should we build next' questions in recent sessions. |
| jx-docs-drift | juncture | juncture-signals.sh | README/CHANGELOG untouched while >= 30 code commits landed. |
| jx-failing-ci | juncture | juncture-signals.sh | Red CI streak (>= 3 of last 10 runs failed). |
| jx-flaky-tests | juncture | juncture-signals.sh\|cass-juncture-mine.sh | Flaky/retry/intermittent test vocabulary recently; new #[ignore] markers. |
| jx-going-public | juncture | cass-juncture-mine.sh | The project is about to be made public or announced. |
| jx-hang-or-deadlock | juncture | cass-juncture-mine.sh\|juncture-signals.sh | Hangs, timeouts, deadlocks, or lock contention reported recently. |
| jx-history-underused | juncture | cass-juncture-mine.sh | Sessions exist for this project but recent sessions re-solved known problems without consulting history. |
| jx-issues-triage-due | juncture | juncture-signals.sh | Open issues/PRs across the user's repos need triage. |
| jx-large-refactor-discussed | juncture | cass-juncture-mine.sh | Splitting/refactoring modules discussed recently. |
| jx-machine-unresponsive | juncture | cass-juncture-mine.sh | System load/disk/memory pressure complaints recently. |
| jx-mock-suspicion | juncture | cass-juncture-mine.sh\|juncture-signals.sh | Tests green but product broken; stubs/placeholders suspected. |
| jx-ocr-accuracy | juncture | cass-juncture-mine.sh | OCR accuracy problems recently. |
| jx-onboarding | juncture | cass-juncture-mine.sh | No prior sessions on this project, or the user said they are new to it. |
| jx-open-issue-backlog | juncture | juncture-signals.sh | >= 5 open issues, or issues without a response in 14 days. |
| jx-open-pr-backlog | juncture | juncture-signals.sh | >= 3 open PRs, or PRs older than 14 days. |
| jx-payments-bugs | juncture | cass-juncture-mine.sh\|juncture-signals.sh | Webhook/billing/subscription bugs recently. |
| jx-perf-commits | juncture | juncture-signals.sh | perf/optimize/speed vocabulary in recent commit messages. |
| jx-perf-complaints | juncture | cass-juncture-mine.sh\|juncture-signals.sh | Recent sessions, issues, or beads complain about slowness/latency/throughput. |
| jx-plan-no-beads | juncture | juncture-signals.sh | A plan file exists but there is no .beads/ (or beads are empty). |
| jx-port-in-progress | juncture | juncture-signals.sh\|cass-juncture-mine.sh | Port/parity/gauntlet vocabulary in recent commits or sessions. |
| jx-recurring-panics | juncture | cass-juncture-mine.sh\|juncture-signals.sh | Panics/crashes/unwrap-on-None recur in recent sessions or commits. |
| jx-regressions | juncture | juncture-signals.sh | Revert commits or 'regression' vocabulary in the window. |
| jx-release-imminent | juncture | juncture-signals.sh\|cass-juncture-mine.sh | Version bump, release prep vocabulary, or the user said a release is due. |
| jx-release-overdue | juncture | juncture-signals.sh | >= 40 commits since the last tag on a project that has tags. |
| jx-repo-sprawl | juncture | juncture-signals.sh | Many stale branches, worktrees, or stashes. |
| jx-security-concern | juncture | cass-juncture-mine.sh\|juncture-signals.sh | Security vulnerabilities or audit findings discussed recently. |
| jx-slow-builds | juncture | cass-juncture-mine.sh | Build time complaints or build contention recently. |
| jx-swarm-active | juncture | cass-juncture-mine.sh\|juncture-signals.sh | Multiple agents/sessions active on the project recently (ntm, agent mail traffic, many concurrent sessions). |
| jx-todo-density-high | juncture | juncture-signals.sh | TODO/FIXME/HACK/XXX density high or growing. |
| jx-uncommitted-work | juncture | juncture-signals.sh | Substantial uncommitted changes in the working tree. |
| jx-unsafe-touched | juncture | juncture-signals.sh | Recent commits touch unsafe code. |
| jx-unwrap-density-high | juncture | juncture-signals.sh | unwrap()/expect() density high in non-test code. |
| jx-upstream-sync-due | juncture | juncture-signals.sh | A fork is behind its upstream by many commits. |
| jx-user-frustration | juncture | cass-juncture-mine.sh | Anger/frustration phrases in recent user prompts about this project. |
| jx-ux-complaints | juncture | cass-juncture-mine.sh | UI/UX polish complaints recently. |
| jx-wasm-size-or-speed | juncture | cass-juncture-mine.sh\|juncture-signals.sh | wasm bundle size or in-browser speed complaints recently. |
| lang-c-cpp | profile | profile-project.sh | C/C++ sources present (CMakeLists.txt, Makefile with .c/.cc). |
| lang-go | profile | profile-project.sh | Go is a primary language (go.mod). |
| lang-javascript | profile | profile-project.sh | JavaScript is a primary language. |
| lang-python | profile | profile-project.sh | Python is a primary language (pyproject.toml / requirements.txt). |
| lang-rust | profile | profile-project.sh | Cargo.toml present / Rust is a primary language. |
| lang-shell | profile | profile-project.sh | Shell scripts are a significant part of the deliverable. |
| lang-swift-kotlin-java | profile | profile-project.sh | Swift/Kotlin/Java sources present. |
| lang-typescript | profile | profile-project.sh | TypeScript is a primary language (tsconfig.json, .ts/.tsx majority). |
| lang-zig | profile | profile-project.sh | Zig sources present (build.zig). |
| mac-mini-remote-browser | profile | profile-project.sh | Browser-extension automation host configured. |
| maturity-active-buildout | profile | profile-project.sh | Feature commits dominate recent history; tags exist or are imminent. |
| maturity-greenfield | profile | profile-project.sh | Very young: < 50 commits or < 30 days old, no tags. |
| maturity-maintenance | profile | profile-project.sh | Low commit rate; mostly dependency bumps and small fixes. |
| maturity-revived | profile | profile-project.sh | A long dormant gap (> 90 days) followed by recent activity. |
| maturity-stabilization | profile | profile-project.sh | Fix/test commits dominate recent history; features rare. |
| media-audio-files-present | profile | profile-project.sh | Audio files (.m4a/.mp3/.wav) in the target. |
| media-video-files-present | profile | profile-project.sh | Video files (.mkv/.mp4/.mov) in the target. |
| monolith-file | profile | profile-project.sh | A source file exceeds 3000 lines (or 5% of the codebase). |
| native-ffi-deps | profile | profile-project.sh | Native/FFI dependencies (build.rs with cc/bindgen, -sys crates, node-gyp, cffi). |
| og-image-missing | profile | profile-project.sh | Public repo/site with no social preview (og:image / .github social image). |
| proj-browser-extension | profile | profile-project.sh | manifest.json with browser-extension keys (background, content_scripts). |
| proj-cli | profile | profile-project.sh | Ships a command-line binary (bin target, clap/argparse/cobra, package.json bin). |
| proj-daemon | profile | profile-project.sh | Long-running service/daemon (systemd unit, launchd plist, serve/daemon subcommand, tokio main loop). |
| proj-data-pipeline | profile | profile-project.sh | Batch/ETL/data pipeline code (airflow/dagster/spark, Snowflake SQL, pandas/polars jobs). |
| proj-docs-site | profile | profile-project.sh | A documentation site exists (Nextra/Docusaurus/mkdocs/mdBook config). |
| proj-is-asupersync | profile | profile-project.sh | The target IS the Asupersync repo. |
| proj-is-brenner-bot | profile | profile-project.sh | The target IS the brenner_bot research repo. |
| proj-is-franken-ocr | profile | profile-project.sh | The target IS franken_ocr (focr). |
| proj-is-franken-snowflake | profile | profile-project.sh | The target IS franken_snowflake (fsnow). |
| proj-is-franken-tts | profile | profile-project.sh | The target IS FrankenTTS (ftts). |
| proj-is-franken-whisper | profile | profile-project.sh | The target IS franken_whisper (fw). |
| proj-is-frankensqlite | profile | profile-project.sh | The target IS the FrankenSQLite engine repo. |
| proj-is-frankensuite-site | profile | profile-project.sh | The target is a FrankenSuite project website. |
| proj-is-frankentui | profile | profile-project.sh | The target IS the FrankenTUI repo or its showcase. |
| proj-is-pi-agent | profile | profile-project.sh | The target IS the pi-agent Rust port. |
| proj-library | profile | profile-project.sh | Ships a library crate/package (lib.rs, package main export, pyproject library) as a primary deliverable. |
| proj-marketing-site | profile | profile-project.sh | A public marketing/landing site for the project exists in or beside the repo. |
| proj-mcp-server | profile | profile-project.sh | Implements MCP tools/resources (mcp SDK dependency, tool registration). |
| proj-ml-inference | profile | profile-project.sh | Runs model inference (safetensors/gguf weights, torch/onnx/candle, quantization code). |
| proj-mobile | profile | profile-project.sh | iOS/Android target (Xcode project, gradle app module, react-native, capacitor). |
| proj-monorepo | profile | profile-project.sh | Several deliverables in one repo (workspace with >1 member, packages/, apps/). |
| proj-research-code | profile | profile-project.sh | Research/experiment code (notebooks, papers/, experiments/, no packaging). |
| proj-saas | profile | profile-project.sh | Web app with accounts, subscriptions, or billing (auth provider + payments/billing dependency). |
| proj-skills-repo | profile | profile-project.sh | The repo is itself a collection of SKILL.md packages. |
| proj-tui | profile | profile-project.sh | Renders a terminal UI (ratatui, crossterm, bubbletea, textual, frankentui). |
| proj-uses-frankenterm | profile | profile-project.sh | The target is the FrankenTerm fork of WezTerm. |
| proj-wasm-target | profile | profile-project.sh | Builds for wasm32 (wasm-bindgen, wasm-pack, Trunk, [lib] cdylib for wasm, target wasm32 in config). |
| proj-web-app | profile | profile-project.sh | Serves HTTP pages/APIs to browsers (Next.js, app router, axum/actix HTML routes, Express). |
| public-facing | profile | profile-project.sh | Shipped to the public: public GitHub remote, crates.io/npm/pypi publication, homebrew tap, or download counts. |
| published-registry | profile | profile-project.sh | Published to crates.io/npm/pypi/homebrew (publish metadata or registry lookup). |
| release-tags-present | profile | profile-project.sh | At least one version tag exists. |
| releases-none | profile | profile-project.sh | No version tags and no releases. |
| screencast-present | profile | profile-project.sh | Screen recordings present. |
| slack-export-present | profile | profile-project.sh | A Slack export or Mattermost import bundle is present. |
| tangled-code | profile | subagent:profiler-code-kinds | Deep nesting, god modules, or circular module dependencies observed. |
| tests-conformance | profile | profile-project.sh | Conformance/parity harness exists (conformance/, parity matrix, oracle comparison). |
| tests-e2e | profile | profile-project.sh | End-to-end tests exist (e2e/, playwright, real binaries invoked). |
| tests-flaky-markers | profile | profile-project.sh | #[ignore], skip markers, retry loops, or sleep() in tests. |
| tests-fuzz-targets | profile | profile-project.sh | Fuzz targets exist (fuzz/fuzz_targets, cargo-fuzz, libFuzzer, go fuzz). |
| tests-golden | profile | profile-project.sh | Golden/snapshot tests exist (insta, tests/golden/, __snapshots__). |
| tests-integration | profile | profile-project.sh | Integration tests exist (tests/ dir, integration markers). |
| tests-loom-shuttle | profile | profile-project.sh | loom or shuttle interleaving models exist. |
| tests-metamorphic | profile | profile-project.sh | Metamorphic relation tests exist (named metamorphic, relation, invariance tests). |
| tests-miri | profile | profile-project.sh | Miri or cargo-careful runs are configured (CI or scripts). |
| tests-none | profile | profile-project.sh | No tests of any kind found. |
| tests-property | profile | profile-project.sh | Property tests exist (proptest, quickcheck, hypothesis, fast-check). |
| tests-real-services | profile | profile-project.sh | Tests hit real services/databases (test containers, real DB URLs, real binaries). |
| tests-sanitizer | profile | profile-project.sh | ASAN, TSAN, another sanitizer, or valgrind is configured (CI or scripts). |
| tests-static-analysis-gate | profile | profile-project.sh | CI runs a static-analysis gate (clippy -D warnings, ubs, eslint, mypy, semgrep). |
| tests-unit | profile | profile-project.sh | Unit tests exist. |
| tests-use-mocks | profile | profile-project.sh | Tests use mocks/fakes (mockall, jest.mock, vi.mock, msw, unittest.mock). |
| unusual-pins | profile | profile-project.sh | Git/path dependencies or exact '=' pins in manifests. |
| user-asked-3d-visual | profile | orchestrator | The user asked for a 3D/WebGL scene or physics sim. (defaults to absent when no evidence mentions it) |
| user-asked-account-switching | profile | orchestrator | The user hit rate limits and asked to switch accounts. (defaults to absent when no evidence mentions it) |
| user-asked-brenner-research | profile | orchestrator | The user asked for Brenner-style hypothesis research. (defaults to absent when no evidence mentions it) |
| user-asked-dashboard | profile | orchestrator | The user asked for a dashboard/visualization page. (defaults to absent when no evidence mentions it) |
| user-asked-debugger | profile | orchestrator | The user asked to debug a crash with gdb/lldb. (defaults to absent when no evidence mentions it) |
| user-asked-editor-tooling | profile | orchestrator | The user asked about Cursor/WezTerm/Ghostty/ssh configuration. (defaults to absent when no evidence mentions it) |
| user-asked-estate-planning | profile | orchestrator | The user asked for estate-planning work. (defaults to absent when no evidence mentions it) |
| user-asked-gcloud | profile | orchestrator | The user asked for Google Cloud operations. (defaults to absent when no evidence mentions it) |
| user-asked-image-download | profile | orchestrator | The user asked to download images from a share link. (defaults to absent when no evidence mentions it) |
| user-asked-lean-formalization | profile | orchestrator | The user asked to formalize in Lean. (defaults to absent when no evidence mentions it) |
| user-asked-mail-search | profile | orchestrator | The user asked to search mail/messages with xf. (defaults to absent when no evidence mentions it) |
| user-asked-math-research | profile | orchestrator | The user asked for proofs/conjecture work. (defaults to absent when no evidence mentions it) |
| user-asked-mattermost-migration | profile | orchestrator | The user asked to migrate Slack to Mattermost. (defaults to absent when no evidence mentions it) |
| user-asked-multi-repo-commit | profile | orchestrator | The user asked to commit/release across many repos. (defaults to absent when no evidence mentions it) |
| user-asked-remote-build | profile | orchestrator | The user asked to offload builds or complained about build contention. (defaults to absent when no evidence mentions it) |
| user-asked-share-images | profile | orchestrator | The user asked for OG/social share images. (defaults to absent when no evidence mentions it) |
| user-asked-share-links-archive | profile | orchestrator | The user asked to archive AI chat share links. (defaults to absent when no evidence mentions it) |
| user-asked-shell-automation | profile | orchestrator | The user asked to automate repetitive shell workflows. (defaults to absent when no evidence mentions it) |
| user-asked-skill-authoring | profile | orchestrator | The user asked to create or operationalize a skill/methodology. (defaults to absent when no evidence mentions it) |
| user-asked-tax-return | profile | orchestrator | The user asked for tax-return work. (defaults to absent when no evidence mentions it) |
| user-asked-transcription | profile | orchestrator | The user asked to transcribe audio/video. (defaults to absent when no evidence mentions it) |
| user-asked-video-edit | profile | orchestrator | The user asked for video editing/remuxing. (defaults to absent when no evidence mentions it) |
| user-asked-website-for-project | profile | orchestrator | The user asked for a marketing/docs website. (defaults to absent when no evidence mentions it) |
| user-asked-youtube-transcript | profile | orchestrator | The user asked to transcribe a YouTube video. (defaults to absent when no evidence mentions it) |

## Per-skill trigger models

Weights are 1–4; `(absent)` marks a signal that fires on verified absence. C/R = cost/risk 0–4; H = baseline-hygiene severity.

| Skill | Gate | Positive signals | Anti-signals | Prereqs | Pairs | C/R | H |
|---|---|---|---|---|---|---|---|
| ab-testing | proj-saas, fw-nextjs | fw-ga4:2, proj-saas:1, jx-design-questions:1 | — | — | saas-customer-analytics, ga4 | 3/2 | — |
| admin-page-for-nextjs-sites | fw-nextjs, proj-saas | proj-saas:2, fw-supabase:1 | — | — | security-audit-for-saas | 3/2 | — |
| agent-ergonomics-and-intuitiveness-maximization-for-cli-tools | proj-cli | json-mode-missing-for-cli:4, jx-cli-ergonomics-complaints:4, code-cli-subcommands:2, code-agent-swa… | code-json-robot-mode:weak | — | world-class-doctor-mode-for-cli-tools, rust-cli-w… | 2/2 | 3 |
| agent-fungibility-philosophy | code-agent-swarm-scaffolding, jx-swarm-active | jx-swarm-active:1, jx-context-loss:2 | — | — | vibing-with-ntm | 1/0 | — |
| agent-mail | code-agent-swarm-scaffolding, jx-swarm-active | jx-swarm-active:2, agent-mail-project:1 | — | — | ntm, beads-br | 0/0 | — |
| ai-model-into-rust-mega-fused-hyper-kernel | proj-ml-inference, code-ml-kernels | code-ml-kernels:3, proj-ml-inference:3, jx-perf-complaints:3, code-simd-hot-loops:1 | lang-rust(absent):strong | — | profiling-software-performance, extreme-software-… | 4/3 | — |
| asupersync-mega-skill | dep-asupersync, proj-is-asupersync, fw-tokio | proj-is-asupersync:4, dep-asupersync:3, jx-dependency-bump:3, fw-tokio:1 | — | — | frankensqlite-mega-skill, library-updater | 2/2 | — |
| automating-your-automations | user-asked-shell-automation | user-asked-shell-automation:4 | — | — | — | 2/1 | — |
| bd-to-br-migration | beads-present | jx-beads-corrupt:2 | — | — | — | 0/1 | — |
| beads-br | beads-present, jx-plan-no-beads | beads-present:1, jx-beads-corrupt:2 | — | — | beads-bv, beads-workflow | 0/0 | — |
| beads-bv | beads-present | jx-beads-blocked:3, jx-beads-many-open:2, jx-beads-queue-dry:2 | — | — | beads-br | 0/0 | — |
| beads-compliance-and-completion-verification | beads-present | jx-beads-stale-epics:4, jx-mock-suspicion:3, jx-swarm-active:2, jx-ceremony-smell:2 | maturity-greenfield:weak | — | reality-check-for-project, mock-code-finder | 2/0 | — |
| beads-workflow | docs-plan-file, beads-present, jx-big-change-no-plan | jx-plan-no-beads:4, docs-plan-file:2, jx-big-change-no-plan:2 | jx-beads-many-open:weak | planning-workflow | beads-br, beads-bv | 2/1 | — |
| brenner | proj-is-brenner-bot, user-asked-brenner-research | proj-is-brenner-bot:3, user-asked-brenner-research:4 | — | — | brennerbot-with-ntm | 1/0 | — |
| brennerbot-with-ntm | user-asked-brenner-research, jx-contested-decision | user-asked-brenner-research:4, jx-contested-decision:2 | — | — | ntm | 3/0 | — |
| browser-extension-automation | mac-mini-remote-browser, proj-browser-extension, jx-auth-lo… | jx-auth-loops:3, proj-browser-extension:2 | — | — | e2e-testing-for-webapps | 1/1 | — |
| caam | user-asked-account-switching | user-asked-account-switching:4 | — | — | — | 0/0 | — |
| cass | universal | jx-history-underused:3, jx-onboarding:2, jx-context-loss:3, jx-swarm-active:1 | jx-cass-index-stale:weak | — | just-say-no-to-process-porn-and-ceremony | 0/0 | — |
| cass-memory | code-agent-swarm-scaffolding, jx-swarm-active, jx-context-l… | jx-context-loss:2, jx-swarm-active:1 | — | cass | cass | 1/0 | — |
| cc-hooks | code-agent-swarm-scaffolding, jx-agents-deleted-things, doc… | jx-agents-deleted-things:2, tests-static-analysis-gate(absent):1 | — | — | dcg, ubs | 1/1 | — |
| changelog-md-workmanship | universal | docs-changelog-stale-vs-tags:4, docs-changelog-missing:3, jx-release-imminent:3, jx-docs-drift:2 | docs-changelog-fresh:strong, releases-none:weak | — | readme-writing, release-preparations, de-slopify | 1/1 | 3 |
| code-review-gemini-swarm-with-ntm | code-agent-swarm-scaffolding, jx-swarm-active | jx-beads-queue-dry:3, jx-swarm-active:2, jx-bug-fix-churn:1 | — | ntm | ntm, agent-mail | 3/1 | — |
| codebase-archaeology | universal | jx-onboarding:4, jx-context-loss:2, docs-readme-weak:1 | docs-agents-md:weak | — | codebase-report | 1/0 | — |
| codebase-audit | universal | jx-beads-queue-dry:2, jx-security-concern:3, jx-going-public:3, jx-swarm-active:1 | — | codebase-archaeology | multi-pass-bug-hunting | 2/0 | — |
| codebase-pattern-extraction | proj-monorepo, user-asked-skill-authoring | proj-monorepo:2, user-asked-skill-authoring:3 | — | — | operationalizing-expertise | 2/1 | — |
| codebase-report | universal | jx-onboarding:3, jx-context-loss:3, docs-adrs(absent):1 | — | codebase-archaeology | codebase-archaeology | 1/1 | — |
| csctf | user-asked-share-links-archive | user-asked-share-links-archive:4 | — | — | — | 0/0 | — |
| cursor | user-asked-editor-tooling | user-asked-editor-tooling:3 | — | — | — | 0/0 | — |
| dcg | code-agent-swarm-scaffolding, jx-agents-deleted-things, jx-… | jx-agents-deleted-things:4, jx-swarm-active:1 | — | — | — | 0/0 | — |
| de-monolithize-your-codebase-isomorphically | monolith-file | monolith-file:3, jx-large-refactor-discussed:3, jx-swarm-active:1 | tests-none:strong | — | simplify-and-refactor-code-isomorphically, beads-… | 3/3 | — |
| de-slopify | universal | docs-prose-sounds-generated:4, jx-going-public:2, jx-docs-drift:1, public-facing:1 | docs-readme-missing:strong | — | readme-writing, changelog-md-workmanship | 0/1 | — |
| deadlock-finder-and-fixer | code-concurrency-primitives, code-async-holding-lock, code-… | jx-hang-or-deadlock:4, jx-flaky-tests:3, code-async-holding-lock:3, gap-concurrency-no-model:2, cod… | tests-loom-shuttle:weak | — | testing-metamorphic, multi-pass-bug-hunting | 2/2 | — |
| documentation-website-for-software-project | public-facing, user-asked-website-for-project | user-asked-website-for-project:4, docs-site-missing:3, jx-going-public:2 | proj-docs-site:strong, maturity-greenfield:weak | readme-writing | de-slopify, og-share-images | 4/1 | — |
| dsr | release-tags-present, jx-release-imminent, public-facing | jx-release-imminent:4, jx-failing-ci:2, jx-release-overdue:2 | — | release-preparations | release-preparations | 2/4 | — |
| dueling-idea-wizards | code-agent-swarm-scaffolding, jx-swarm-active, jx-design-qu… | jx-design-questions:3, jx-contested-decision:3 | — | idea-wizard | ntm | 2/0 | — |
| e2e-testing-for-webapps | proj-web-app, fw-nextjs | gap-webapp-no-e2e:4, jx-regressions:3, fw-playwright:1, fw-supabase:1 | tests-e2e:weak | — | testing-real-service-e2e-no-mocks, security-audit… | 2/1 | — |
| eidetic-engine-cli | code-agent-swarm-scaffolding, jx-context-loss, jx-swarm-act… | jx-context-loss:3, jx-history-underused:2, jx-swarm-active:1 | — | — | cass, cass-memory | 1/0 | — |
| extreme-software-optimization | universal | jx-perf-complaints:4, jx-perf-commits:3, jx-wasm-size-or-speed:3, code-simd-hot-loops:1, code-port-… | bench-harness-present(absent):weak | profiling-software-performance | repeatedly-apply-skill, profiling-software-perfor… | 4/3 | — |
| focr | proj-is-franken-ocr, jx-ocr-accuracy | proj-is-franken-ocr:4, jx-ocr-accuracy:3 | — | — | — | 0/0 | — |
| frankensearch-integration-for-rust-projects | dep-frankensearch, code-search-index | dep-frankensearch:3, code-search-index:2, jx-dependency-bump:1 | — | — | library-updater | 2/2 | — |
| frankensqlite-mega-skill | dep-frankensqlite, proj-is-frankensqlite | proj-is-frankensqlite:4, jx-dependency-bump:3, dep-frankensqlite:2 | — | — | asupersync-mega-skill, library-updater | 1/2 | — |
| frankensuite-website-development | proj-is-frankensuite-site, user-asked-website-for-project | proj-is-frankensuite-site:4, user-asked-website-for-project:3 | — | — | interactive-visualization-creator, de-slopify, og… | 3/2 | — |
| frankentui | dep-frankentui, proj-is-frankentui, proj-tui | proj-is-frankentui:4, dep-frankentui:3, jx-ux-complaints:2 | lang-rust(absent):strong | — | tui-inspector | 2/2 | — |
| fsnow | proj-is-franken-snowflake, fw-snowflake | proj-is-franken-snowflake:4, fw-snowflake:2 | — | — | — | 0/0 | — |
| ftts | proj-is-franken-tts | proj-is-franken-tts:4 | — | — | — | 0/0 | — |
| fw | proj-is-franken-whisper | proj-is-franken-whisper:4 | — | — | — | 0/0 | — |
| ga4 | fw-ga4, proj-saas, proj-marketing-site | fw-ga4:2 | — | — | saas-customer-analytics | 0/0 | — |
| gcloud | user-asked-gcloud | user-asked-gcloud:4 | — | — | — | 0/2 | — |
| gdb-for-debugging | user-asked-debugger, jx-recurring-panics, lang-c-cpp, code-… | user-asked-debugger:4, jx-recurring-panics:2, code-ffi-boundary:1 | — | — | rust-undefined-behavior-exorcist | 1/0 | — |
| gh-actions | fw-gh-actions, ci-none, jx-failing-ci | jx-failing-ci:4, ci-none:2 | jx-release-imminent:weak | — | ubs | 1/1 | — |
| gh-cli | public-facing, jx-going-public, jx-open-issue-backlog | jx-going-public:3, jx-open-issue-backlog:1 | — | — | gh-triage-ru | 0/2 | — |
| gh-og-share-images | public-facing | og-image-missing:3, jx-going-public:3, user-asked-share-images:3 | — | readme-writing | readme-writing | 0/1 | 1 |
| gh-triage-ru | public-facing, jx-open-issue-backlog, jx-open-pr-backlog | jx-open-issue-backlog:4, jx-open-pr-backlog:4, jx-issues-triage-due:3 | — | — | ru-multi-repo-workflow, gh-cli | 2/2 | — |
| ghostty | user-asked-editor-tooling | user-asked-editor-tooling:2 | — | — | — | 0/0 | — |
| giil | user-asked-image-download | user-asked-image-download:4 | — | — | — | 0/0 | — |
| git-repo-janitor | universal | jx-repo-sprawl:4, jx-uncommitted-work:2 | — | — | git-stash-janitor, git-worktree-branch-rationaliz… | 1/3 | — |
| git-stash-janitor | universal | jx-repo-sprawl:3, jx-uncommitted-work:2 | — | — | git-repo-janitor | 1/2 | — |
| git-worktree-branch-rationalization | universal | jx-repo-sprawl:4 | — | — | git-repo-janitor | 1/3 | — |
| idea-wizard | universal | jx-design-questions:4, jx-beads-queue-dry:2, maturity-active-buildout:1 | jx-bug-fix-churn:weak | — | planning-workflow, beads-workflow | 1/0 | — |
| installer-workmanship | proj-cli, code-installer-script | installer-missing-for-cli:4, installer-weak:3, jx-release-imminent:2, jx-deploy-failures:2 | releases-none:weak | — | release-preparations, readme-writing, dsr | 1/2 | 3 |
| interactive-visualization-creator | proj-marketing-site, proj-web-app, user-asked-dashboard, pr… | user-asked-dashboard:4, proj-marketing-site:2, jx-ux-complaints:2 | — | — | de-slopify, og-share-images | 2/2 | — |
| iphone-videos-to-music-video-with-audio-track | user-asked-video-edit, iphone-takes-present | iphone-takes-present:4, user-asked-video-edit:2 | — | — | — | 1/0 | — |
| just-say-no-to-process-porn-and-ceremony | universal | jx-ceremony-smell:4, jx-swarm-active:2, code-agent-swarm-scaffolding:1 | — | — | reality-check-for-project, vibing-with-ntm | 0/0 | — |
| lean-formal-feedback-loop | user-asked-lean-formalization, user-asked-math-research | user-asked-lean-formalization:4, user-asked-math-research:2 | — | — | — | 3/0 | — |
| library-updater | universal | jx-dependency-bump:4, deps-outdated:3 | tests-none:weak | — | release-preparations, asupersync-mega-skill, fran… | 2/2 | 2 |
| mcp-server-design | proj-mcp-server, code-mcp-tools | proj-mcp-server:3, code-mcp-tools:3, jx-cli-ergonomics-complaints:2 | — | — | agent-ergonomics-and-intuitiveness-maximization-f… | 2/2 | — |
| mock-code-finder | universal | jx-mock-suspicion:4, tests-use-mocks:2, jx-beads-queue-dry:2, jx-swarm-active:1 | maturity-greenfield:weak | — | reality-check-for-project, testing-real-service-e… | 1/0 | — |
| modes-of-reasoning-project-analysis | universal | jx-beads-queue-dry:3, jx-swarm-active:2, jx-contested-decision:2 | maturity-greenfield:weak | — | reality-check-for-project | 2/0 | — |
| multi-model-triangulation | universal | jx-contested-decision:4, jx-regressions:1 | — | — | modes-of-reasoning-project-analysis | 1/0 | — |
| multi-pass-bug-hunting | universal | jx-bug-fix-churn:4, jx-recurring-panics:3, jx-regressions:3, jx-flaky-tests:2, jx-unwrap-density-hi… | tests-none:weak | — | testing-fuzzing, testing-metamorphic, testing-gol… | 3/2 | — |
| ntm | code-agent-swarm-scaffolding, jx-swarm-active, jx-beads-man… | jx-beads-many-open:3, jx-swarm-active:2 | maturity-greenfield:weak | — | vibing-with-ntm, agent-mail, beads-bv | 3/2 | — |
| og-share-images | proj-web-app, proj-marketing-site, user-asked-share-images,… | user-asked-share-images:4, og-image-missing:3, jx-going-public:2 | — | — | gh-og-share-images, de-slopify | 0/1 | — |
| operationalizing-expertise | user-asked-skill-authoring, proj-skills-repo | user-asked-skill-authoring:4, proj-skills-repo:2 | — | — | cass | 3/1 | — |
| optimizing-your-rust-projects-for-wasm-in-browsers-and-phones | proj-wasm-target, code-wasm-bindgen | jx-wasm-size-or-speed:4, proj-wasm-target:3, jx-perf-complaints:2, proj-mobile:1 | — | profiling-software-performance | extreme-software-optimization, threejs-visualizat… | 3/3 | — |
| path-rationalization | proj-monorepo, proj-skills-repo | proj-monorepo:1 | — | — | — | 1/2 | — |
| pi-agent-rust | proj-is-pi-agent | proj-is-pi-agent:3 | — | — | — | 0/0 | — |
| planning-workflow | universal | jx-big-change-no-plan:4, jx-design-questions:2, maturity-greenfield:1 | docs-plan-file:strong | — | beads-workflow, idea-wizard | 2/1 | — |
| profiling-software-performance | universal | jx-perf-complaints:4, jx-perf-commits:3, code-simd-hot-loops:1, bench-harness-present:1, jx-wasm-si… | — | — | extreme-software-optimization, repeatedly-apply-s… | 1/0 | — |
| rch | lang-rust, lang-c-cpp, lang-typescript, jx-slow-builds, use… | jx-slow-builds:4, user-asked-remote-build:4, jx-swarm-active:1, build-cargo-workspace:1 | — | — | ntm | 1/0 | — |
| readme-writing | universal | docs-readme-weak:4, docs-readme-missing:4, jx-docs-drift:3, jx-going-public:3, jx-release-imminent:1 | — | — | de-slopify, changelog-md-workmanship, gh-og-share… | 1/1 | 2 |
| reality-check-for-project | universal | jx-beads-queue-dry:4, jx-beads-stale-epics:3, jx-ceremony-smell:3, jx-swarm-active:2, docs-plan-fil… | maturity-greenfield:weak | — | modes-of-reasoning-project-analysis, beads-compli… | 2/0 | — |
| redacting-sensitive-parts-of-screencast-videos | screencast-present, user-asked-video-edit | screencast-present:3, jx-going-public:1 | — | — | video-obs-youtube-music | 1/0 | — |
| release-preparations | universal | jx-release-imminent:4, jx-release-overdue:3, jx-dependency-bump:2, release-tags-present:1 | jx-failing-ci:weak, maturity-greenfield:weak | — | dsr, changelog-md-workmanship, readme-writing, in… | 2/4 | — |
| repeatedly-apply-skill | universal | jx-perf-complaints:3, jx-perf-commits:2, jx-ux-complaints:1 | — | — | extreme-software-optimization, profiling-software… | 3/2 | — |
| research-software | proj-research-code, jx-design-questions | proj-research-code:3, jx-design-questions:1 | — | — | — | 1/0 | — |
| rg-optimized | universal | jx-onboarding:1 | — | — | codebase-archaeology | 0/0 | — |
| ru-multi-repo-workflow | user-asked-multi-repo-commit, jx-uncommitted-work, jx-issue… | user-asked-multi-repo-commit:4, jx-uncommitted-work:2 | — | — | gh-triage-ru | 1/2 | — |
| running-the-gauntlet-on-your-rust-port | code-port-of-other-language, code-spec-reimplementation | jx-port-in-progress:4, code-port-of-other-language:3, jx-perf-complaints:2, gap-spec-no-conformance… | — | — | testing-conformance-harnesses, extreme-software-o… | 4/2 | — |
| rust-cli-with-sqlite | proj-cli | code-sqlite-persistence:3, proj-cli:1, jx-beads-corrupt:1 | lang-rust(absent):strong | — | agent-ergonomics-and-intuitiveness-maximization-f… | 1/2 | — |
| rust-crates-publishing | lang-rust | jx-release-imminent:3, published-registry:1, proj-library:1 | — | release-preparations | release-preparations, dsr | 1/4 | — |
| rust-undefined-behavior-exorcist | code-unsafe-any, code-ffi-boundary | code-unsafe-heavy:3, gap-unsafe-no-miri:3, jx-recurring-panics:2, code-ffi-boundary:2 | code-unsafe-any(absent):strong | rust-unsafe-code-exorcist | rust-unsafe-code-exorcist, gdb-for-debugging | 3/2 | — |
| rust-unsafe-code-exorcist | code-unsafe-any | code-unsafe-heavy:3, jx-unsafe-touched:3, gap-unsafe-no-miri:2, code-port-of-other-language:2, jx-g… | code-unsafe-any(absent):strong | — | rust-undefined-behavior-exorcist | 3/2 | — |
| saas-billing-patterns-for-stripe-and-paypal | fw-stripe, fw-paypal, code-payments-billing | jx-payments-bugs:4, gap-payments-no-webhook-replay:4, code-webhooks:2, code-payments-billing:2 | fw-stripe(absent):strong | — | stripe-checkout, security-audit-for-saas, testing… | 3/3 | — |
| saas-cli-auth-flow | proj-saas, proj-cli | jx-auth-loops:4, code-crypto-auth:2 | — | — | security-audit-for-saas | 2/2 | — |
| saas-customer-analytics | proj-saas | fw-ga4:2, proj-saas:1 | — | — | ga4, ab-testing | 2/1 | — |
| security-audit-for-saas | proj-saas, proj-web-app, code-crypto-auth, fw-supabase | jx-security-concern:4, jx-going-public:3, code-crypto-auth:2, fw-supabase:2, jx-beads-queue-dry:1 | — | — | saas-billing-patterns-for-stripe-and-paypal, supa… | 2/0 | — |
| seo-for-saas-businesses | proj-saas, proj-marketing-site | proj-marketing-site:2, jx-going-public:2, proj-saas:1 | — | — | og-share-images, de-slopify | 2/1 | — |
| simplify-and-refactor-code-isomorphically | universal | tangled-code:3, jx-large-refactor-discussed:3, jx-bug-fix-churn:1, jx-dead-code-sprawl:2 | tests-none:strong, maturity-greenfield:weak | — | de-monolithize-your-codebase-isomorphically | 2/3 | — |
| slack-migration-to-mattermost-phase-1-extraction | user-asked-mattermost-migration, slack-export-present | user-asked-mattermost-migration:4, slack-export-present:3 | — | — | slack-migration-to-mattermost-phase-2-setup-and-i… | 3/1 | — |
| slack-migration-to-mattermost-phase-2-setup-and-import | user-asked-mattermost-migration, slack-export-present | user-asked-mattermost-migration:4 | — | slack-migration-to-mattermost-phase-1-e… | slack-migration-to-mattermost-phase-3-ongoing-mai… | 3/3 | — |
| slack-migration-to-mattermost-phase-3-ongoing-maintenance | user-asked-mattermost-migration | user-asked-mattermost-migration:3 | — | slack-migration-to-mattermost-phase-2-s… | — | 2/2 | — |
| slb | code-agent-swarm-scaffolding, jx-swarm-active | jx-agents-deleted-things:2, jx-swarm-active:1 | — | — | dcg | 1/0 | — |
| ssh | user-asked-editor-tooling, jx-swarm-active | user-asked-editor-tooling:2 | — | — | — | 0/0 | — |
| stripe-checkout | fw-stripe | jx-payments-bugs:3, fw-stripe:2, maturity-greenfield:1 | — | — | saas-billing-patterns-for-stripe-and-paypal | 1/2 | — |
| supabase | fw-supabase | fw-supabase:2, jx-auth-loops:2, jx-deploy-failures:1 | — | — | security-audit-for-saas | 0/0 | — |
| system-performance-remediation | jx-machine-unresponsive, jx-slow-builds, jx-swarm-active | jx-machine-unresponsive:4, jx-slow-builds:2 | — | — | rch | 0/2 | — |
| tanstack | fw-tanstack | fw-tanstack:2 | — | — | — | 0/0 | — |
| tax-return-preparation-and-advice-generic | user-asked-tax-return | user-asked-tax-return:4 | — | — | — | 3/0 | — |
| testing-conformance-harnesses | code-spec-reimplementation, code-port-of-other-language | gap-spec-no-conformance:4, code-spec-reimplementation:3, jx-port-in-progress:3, code-port-of-other-… | tests-conformance:weak | — | running-the-gauntlet-on-your-rust-port, testing-f… | 2/1 | — |
| testing-fuzzing | code-parser, code-binary-format, code-network-protocol | gap-parser-no-fuzz:4, jx-recurring-panics:3, code-parser:2, code-binary-format:2, code-network-prot… | tests-fuzz-targets:weak | — | multi-pass-bug-hunting, testing-conformance-harne… | 2/1 | — |
| testing-golden-artifacts | code-codegen-renderer, code-json-robot-mode, code-tui-rende… | gap-renderer-no-golden:4, gap-cli-no-json-snapshot:3, code-codegen-renderer:2, jx-regressions:2 | tests-golden:weak | — | testing-metamorphic | 1/1 | — |
| testing-metamorphic | code-numeric-transforms, code-storage-engine, code-search-i… | gap-numeric-no-metamorphic:4, code-numeric-transforms:2, jx-regressions:2, jx-mock-suspicion:2 | tests-metamorphic:weak | — | testing-golden-artifacts, testing-fuzzing | 2/1 | — |
| testing-real-service-e2e-no-mocks | tests-use-mocks, proj-web-app, proj-cli, code-installer-scr… | gap-mocks-without-real-e2e:4, jx-regressions:3, jx-mock-suspicion:3, tests-use-mocks:2 | tests-real-services:weak | — | e2e-testing-for-webapps, mock-code-finder | 2/1 | — |
| threejs-visualizations-with-good-quality-and-real-physics | fw-threejs, user-asked-3d-visual | user-asked-3d-visual:4, fw-threejs:3, proj-marketing-site:1 | — | — | optimizing-your-rust-projects-for-wasm-in-browser… | 2/2 | — |
| transcribing-audio-from-calls-and-meetings | user-asked-transcription, media-audio-files-present | user-asked-transcription:4, media-audio-files-present:2 | — | — | cass | 1/0 | — |
| transcribing-youtube-videos | user-asked-youtube-transcript | user-asked-youtube-transcript:4 | — | — | — | 0/0 | — |
| tui-glamorous | lang-go, fw-charm-bubbletea, proj-tui | fw-charm-bubbletea:3, lang-go:1, jx-ux-complaints:2 | lang-rust:weak | — | installer-workmanship | 1/2 | — |
| tui-inspector | proj-tui | proj-tui:2, jx-ux-complaints:2 | — | — | frankentui, tui-glamorous | 1/0 | — |
| ubs | universal | tests-static-analysis-gate(absent):3, jx-bug-fix-churn:2, jx-unwrap-density-high:2 | tests-static-analysis-gate:strong | — | multi-pass-bug-hunting | 1/1 | 2 |
| ui-polish | proj-web-app, proj-tui, proj-mobile | jx-ux-complaints:4, jx-going-public:2 | — | ux-audit | ux-audit, repeatedly-apply-skill | 2/2 | — |
| user-support-ticketing-system-for-saas | proj-saas | proj-saas:1, jx-open-issue-backlog:1 | — | — | user-support-triage-for-saas-and-open-source-proj… | 3/2 | — |
| user-support-triage-for-saas-and-open-source-projects | public-facing, proj-saas | jx-open-issue-backlog:3, jx-issues-triage-due:2 | — | — | gh-triage-ru | 1/1 | — |
| ux-audit | proj-web-app, proj-tui, proj-mobile | jx-ux-complaints:4, jx-going-public:1 | — | — | ui-polish | 1/0 | — |
| vercel | fw-vercel, fw-nextjs | jx-deploy-failures:4, fw-vercel:1 | — | — | — | 0/3 | — |
| vibing-with-ntm | code-agent-swarm-scaffolding, jx-swarm-active, jx-beads-man… | jx-beads-many-open:3, jx-swarm-active:3, jx-ceremony-smell:2 | maturity-greenfield:weak | beads-workflow | ntm, just-say-no-to-process-porn-and-ceremony, ag… | 4/2 | — |
| video-obs-youtube-music | user-asked-video-edit, screencast-present, media-video-file… | user-asked-video-edit:4, screencast-present:2 | — | — | — | 0/0 | — |
| wezterm | user-asked-editor-tooling, proj-uses-frankenterm | user-asked-editor-tooling:2, proj-uses-frankenterm:2 | — | — | — | 0/0 | — |
| wills-and-estate-planning-skill | user-asked-estate-planning | user-asked-estate-planning:4 | — | — | — | 3/0 | — |
| world-class-doctor-mode-for-cli-tools | proj-cli | doctor-missing-for-cli:4, jx-deploy-failures:2, code-cli-subcommands:2, jx-cli-ergonomics-complaint… | code-doctor-command:strong | — | agent-ergonomics-and-intuitiveness-maximization-f… | 1/2 | 2 |
| wrangler | fw-cloudflare-workers | jx-deploy-failures:3, fw-cloudflare-workers:2 | — | — | — | 0/3 | — |
| xf | user-asked-mail-search | user-asked-mail-search:4 | — | — | — | 0/0 | — |

Kickoff phrasings, expected artifacts, and stop conditions live in the JSON — the scorer reads them verbatim.
