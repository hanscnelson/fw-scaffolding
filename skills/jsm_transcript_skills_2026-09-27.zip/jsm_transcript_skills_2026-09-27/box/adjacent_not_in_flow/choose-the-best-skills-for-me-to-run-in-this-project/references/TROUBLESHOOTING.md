# Troubleshooting

Failure modes and degraded paths, grouped by subsystem. The recurring theme: almost
nothing here aborts a run — a failed source degrades to `unknown` (never to absence), a
failed validation blocks artifact writing until the inputs are repaired, and only the
envelope decides what may be written or installed.

## Contents

- [Quick triage order](#quick-triage-order)
- [Reading an unknown record](#reading-an-unknown-record)
- [jsm and the catalog](#jsm-and-the-catalog)
- [cass and session history](#cass-and-session-history)
- [Remote hosts](#remote-hosts)
- [Target-shape problems](#target-shape-problems)
- [Ledger and validation failures](#ledger-and-validation-failures)
- [Catalog drift surprises](#catalog-drift-surprises)
- [Beads tooling](#beads-tooling)
- [Docs-convention conflicts](#docs-convention-conflicts)

## Quick triage order

When a run looks wrong, check in this order — each step rules out the layer below it:

1. **Was the envelope recorded?** Half of all "it refused to write/install" reports are
   the defaults working as designed (read-only, local-only, no installs, no commit).
2. **What tier did the catalog come from?** A tier-3 run with `drift_known: false`
   explains "it doesn't know about the new skill" without any bug.
3. **What do the `unknown` records say?** Grep the evidence for `state: unknown` — the
   error text on those records is usually the whole diagnosis (dead host, missing tool,
   timeout).
4. **Did `validate-run.py` pass?** If Phase 7 never ran, the fix is upstream in the
   inputs, not in the renderer.
5. **Only then** suspect the scoring — and check suppression gates before arithmetic:
   a "missing" recommendation is usually capped by `completed_recently`,
   `declined_condition_holds`, or `in_progress`, with the gate named in its tier reason.

## Reading an unknown record

Most of the fixes below produce an `unknown` evidence record rather than an error. A
healthy one carries everything needed to retry or to explain the gap
(`references/schemas/evidence.schema.json`):

```json
{
  "id": "ev-c0031",
  "claim": "remote session mining on <host> did not complete",
  "kind": "juncture", "polarity": "positive", "state": "unknown",
  "source_type": "cass", "locator": null,
  "observed_at": "2026-08-26T00:00:00Z",
  "command": "ssh <host> '... cass search ... --json ...'",
  "repo_head": "<sha>", "origin_host": "<host>", "confidence": 0,
  "signals": ["jx-user-frustration", "jx-recurring-panics"],
  "detail": "ssh: connect timed out after 60s"
}
```

Diagnostic value: `command` is re-runnable verbatim, `detail` names the actual error, and
`signals` lists exactly which signals lost their source — which is what Pass B audits and
what the docs' "unknowns" section is rendered from. An unknown record with an empty
`detail` or a null `command` is itself a bug worth fixing in the emitting charter.

Three moves that never help, whatever the subsystem: retry-looping past a budget
(the budget IS the retry policy), downgrading `unknown` to absent to make a row eligible
or an anti-signal fire, and hand-editing downstream artifacts to route around an
upstream failure.

## jsm and the catalog

| Symptom | Diagnosis | Fix |
|---|---|---|
| `jsm: command not found` | jsm not installed on this machine | Say so once; use the fallback ladder (CATALOG-ACQUISITION.md) — tier 2 (website) or tier 3 (snapshot). Never block, never re-ask the envelope. |
| `jsm whoami --json` shows `authenticated: false` | No credentials, or an interactive passphrase prompt a subagent cannot answer | Interactive: the user runs the login once. Headless: `JSM_ALLOW_ENV_PASSPHRASE=1` plus `JSM_CREDENTIALS_PASSPHRASE` from the user's secret store (both required). Meanwhile fall to tier 2. |
| whoami passes but list/show hang or error | Network or service trouble | `jsm doctor` / `jsm status` for diagnosis. The one aggregate `catalog-fetch.sh --deadline` budget caps the whole acquisition; unchanged names keep their snapshot entries; the ladder degrades a tier when the list itself fails. |
| Air-gapped, or the network is deliberately avoided | Expected, not a failure | `catalog-fetch.sh --offline` / `JSM_OFFLINE=1`; zero `jsm`/`curl` calls are made and the catalog behaves as tier 3 with `drift_known: false` — state that in the docs rather than presenting the snapshot as current. |
| `jsm related <name> --json` prints `No related skills found.` (not JSON) | Older jsm's no-edges output; current versions return the structured empty shape | Treat that exact sentinel as empty related groups. Any other malformed response is a source error and retains prior edges. |
| `jsm scan --json` returns nothing | The catalog's entries carry no `detect:` rules | A fact about the catalog, not the project. Record it; never read it as "nothing matches here". |
| `jsm suggest --json --debug` is empty or looks random | Fresh machine: the Thompson-sampling bandit has no install/outcome history to sample | Expected — it only sees INSTALLED skills. One weak signal, recorded, never decisive (anti-pattern: treating suggest/scan as ground truth). |
| `jsm install <winner>` fails at Phase 9 | Network, auth, or a retired name | Record the failure, print the manual install line, and continue — a failed install never invalidates the recommendation or the run. |

## cass and session history

| Symptom | Diagnosis | Fix |
|---|---|---|
| cass binary missing | No local session mining possible | The miner emits ONE summary `unknown` record listing every cass-derived signal, an empty already-file, exit 0. Git, beads, and smells still run; cass-anchored absence claims are simply not made. |
| `cass health --json` exits 1 | Index stale, missing, or unhealthy — **exit 1 still prints JSON**: parse the body, never gate on the exit code alone | Read the JSON for what is actually wrong; fire `jx-cass-index-stale` where the map says so; downgrade battery confidence and treat would-be absences as unclaimable until the index is refreshed. |
| Zero hits for the project everywhere | Usually a workspace-key mismatch, not a quiet history — the same repo lives under different roots on different machines | Aggregate-confirm before any zero-hit claim: `cass search "<basename>" --aggregate workspace --limit 1 --json`. Only a confirmed workspace licenses "0 hits"; no bucket at all is itself the signal `jx-onboarding`. |
| Recent work missing from results | Index lags the sessions (stale watermark) | Note the newest indexed timestamp; claims about "this week" become `unknown` beyond it. Recommend a reindex; do not block. |
| cass appears to hang | It was run bare — cass is a TUI | Only `--json`/`--robot` forms, always under a timeout. The scripts comply; ad-hoc subagent queries must too. |
| Narrow window looks empty | 14-day window too tight for this project's cadence | The batteries widen to the fallback window automatically below the hit floor; ad-hoc miners should widen to `--days 60` before concluding anything. |

## Remote hosts

| Symptom | Diagnosis | Fix |
|---|---|---|
| ssh to a host fails or times out (60s) | Host down, unreachable, or slow | ONE `unknown` record naming the host and the error. The run continues — **one bad host never blocks**, and a host timeout is never "no sessions there". |
| A host returns zero hits | Possibly a different workspace root on that machine | Remote queries are scoped by the target's basename, never the local path; still treat cross-host zero-hits as weak until that host's workspace is confirmed. |
| No hosts configured | Nothing in `cass sources list --json` or `$SKILL_SELECTION_CASS_HOSTS` | One `unknown` record for remote mining as a whole. An explicitly EMPTY `--hosts ""` is different: local-only by choice, recorded as a fact, no unknown. |
| Remote runs feel shallow | By design | Remote hosts run the error-class batteries only, in parallel — never the per-skill invocation scan, which is local-only. |
| Tempted to guess a hostname | — | Never invent a host. Hosts come only from configuration or an explicit envelope grant. |

## Target-shape problems

| Symptom | Diagnosis | Fix |
|---|---|---|
| Monorepo: the profile blurs 20 members into mush | Wrong scope | Confirm the component scope in the envelope; record it as `profile_scope` in the analysis header; per-component profiling with the component in each locator (budgets: component map first, ≤ 8 concurrent). |
| Non-git target | No commits, tags, or churn windows exist | Staleness runs digest-only (the worktree digest); every git-derived juncture signal is `unknown` with detail "not a git repository" — never absent. Sessions, beads, and smells still work. |
| Project with NO history at all (fresh clone, zero sessions confirmed, no beads, quiet window) | The juncture is genuinely unknown — the run must say so, not guess | Only baseline-hygiene items can reach RUN NOW (the hygiene route in SCORING-RUBRIC.md, worked example B). Never claim an absence that was not verified: "no tests" needs a completed search over the tree, not an empty feeling. |
| GitHub remote but `gh` absent or unauthenticated | PR/issue/CI signals unavailable | Those signals become `unknown`; git-local signals are unaffected. |
| GitHub-URL target | Nothing local to write into | Read-only clone under the temp root; the two docs go to the sibling temp directory; commit/push grants are moot and say so. |

## Ledger and validation failures

| Symptom | Diagnosis | Fix |
|---|---|---|
| `validate-run.py` exits non-zero | A ledger invariant broke — typical classes: a catalog skill with zero or two disposition rows; a row naming a skill outside the normalized catalog; a tier that contradicts its gates or thresholds; a schema violation in evidence or run JSON | Read its output; **repair the inputs** (evidence, activations, states, catalog), re-run the scorer, re-validate. Phase 7 stays blocked until exit 0. |
| Urge to patch the run JSON or ledger directly | — | Never hand-edit the ledger or scores, and never write artifacts from an invalid run. The docs are generated views; a hand-edit is a lie the next run inherits. |
| A recommendation names a skill the validator rejects | Not in the normalized catalog: typo, alias, retirement, or invention | Canonicalize via `references/data/aliases.json`; if genuinely new, it needs its provisional catalog row first — the fix is upstream in Phase 4/5, never in the ledger. |
| Byte-diff between two runs that "should" match | Clock not pinned, or inputs actually changed | Determinism is only promised under `SKILL_SELECTION_NOW` with identical inputs; diff the evidence files first, then the catalog tier. |

## Catalog drift surprises

| Symptom | Diagnosis | Fix |
|---|---|---|
| Live names the snapshot has never seen | `new` drift | Provisional rows: `provisional_mapping: true`, E capped at 2, trigger model improvised from description/use-when/tags/related edges. Recommend a snapshot/map refresh as follow-up; never block the run on it. |
| Snapshot names missing from every live source | `retired` drift | Keep the ledger row (its disposition notes apparent retirement); never recommend or install it. |
| A familiar name changed identity | A rename — check the alias map | Recognition only: canonicalize immediately, recommend the canonical name. A stale alias in any output is a bug. |
| Tier-3 run reports zero drift | `drift_known: false` — drift was unknowable, not absent | Say "drift unknowable (snapshot only)" in the docs; never present a snapshot catalog as verified-current. |

## Beads tooling

| Symptom | Diagnosis | Fix |
|---|---|---|
| `br` or `bv` commands error out | Tool missing, version-skewed, or the beads store is damaged | Every beads-derived signal becomes `unknown` — never absent. Corruption text (doctor output, schema-mismatch errors) additionally feeds `jx-beads-corrupt` as positive evidence of its own. |
| `.beads/` exists but `br` is absent | Beads present, tool missing | All beads signals `unknown`; the directory's existence remains a valid profile fact. |
| Worry about mutating the user's beads | — | The read-only forms in JUNCTURE-SIGNALS.md (`--no-auto-flush --no-auto-import`, `--no-cache`) exist precisely so mining never flushes, imports, or caches anything. |

## Docs-convention conflicts

| Symptom | Diagnosis | Fix |
|---|---|---|
| Target repo has no `docs/` directory | The two docs have no conventional home | Create `docs/` only under envelope grant 2; otherwise deliver to terminal plus a temp file. Ephemeral clones always use the sibling temp directory. |
| The target's own conventions disagree (docs live elsewhere, naming rules, AGENTS.md restrictions on committed files) | The target's conventions win — this skill is a guest | Follow the target's AGENTS.md for placement and committing (grant 6 defers to it explicitly). When conventions forbid the docs entirely: terminal + temp file, and say where they went. |
| Public repo target and the docs would leak private context | The privacy classes: local-only skill names, machine hostnames | Keep those out of the persisted docs without explicit approval; the terminal report may legitimately say more than the committed artifact. |
