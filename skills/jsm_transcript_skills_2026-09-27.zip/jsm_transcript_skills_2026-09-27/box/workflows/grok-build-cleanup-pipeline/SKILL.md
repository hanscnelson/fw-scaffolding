---
name: Grok Build cleanup pipeline
description: >-
  Use when ingest cleanup is delegated to Grok Build CLI and you need a low
  Grok-Bot-token monitor that still finishes batches quickly.
---
# Grok Build cleanup pipeline (low Bot tokens)

## Principle
Keep **throughput on the machine**; keep **Grok Bot wakes rare and skinny**. Cleanup tokens burn on **Grok Build quota**, not Bot.

## Machine side (no Bot)
1. Downloads (4KVD) + Path B ASR via `batchN/run_batch.py` (one 7-core `fw` at a time).
2. Run durable watcher:
   `python3 /workspace/ingest/lib/grok_build_pipeline.py --batch N`
   - On each `success.json` (shortest-first): start `batchN/grok_cleanup_one.py` with `GROK_CLEANUP_MODEL` / `GROK_CLEANUP_EFFORT` (default `grok-4.6` / `medium`).
   - One Grok cleanup at a time (parallel with ASR is OK).
   - On each `cleaned.md`: append Ready row to `/workspace/ingest/queues/ready_ping_queue.jsonl`.
3. Do **not** wake the Bot to CheckSubagent / read ASR logs / babysit.

## Bot side (lean routine only)
Create a finite watch routine (pause/delete when batch complete) on a **coarse** cadence (e.g. every 30 min while the batch is active — including overnight only if the batch is overnight).

Routine intent:
1. Read `ready_ping_queue.jsonl` for `state=pending`.
2. If empty → **stay silent**.
3. If any → Notion Transcript Ingest Ready (attach `cleaned.md` → FrankenTranscript, `quality.md` → Quality; set Speakers) then **one digest ping** to the user; mark those lines `state=pinged`.
4. If status `complete_asr_cleanup` and queue empty of pending → announce batch done once, pause/delete routine.
5. Never re-run cleanup, never poll fw, never open desktop.

Reference: `/workspace/ingest/lib/READY_PING_ROUTINE.md`

## Speed knobs
- Start Grok cleanup as soon as each ASR finishes (do not wait for end of batch).
- Keep ASR and Grok cleanup overlapping.
- Cap concurrent Grok cleanups at 1 unless Build rate limits allow 2.
- Prefer digest Ready pings over per-episode Bot wakes when several land in one tick.

## A/B note
When comparing Build vs Bot cleanup spend, snapshot Bot weekly % before/after the Build batch; hold the Bot-cleanup compare batch until the user says go.
