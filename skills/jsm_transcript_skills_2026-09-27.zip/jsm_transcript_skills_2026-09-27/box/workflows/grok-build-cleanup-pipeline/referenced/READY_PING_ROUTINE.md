# Lean Ready-ping routine (Grok Build cleanup mode)

Goal: minimize Grok Bot tokens while batch runs.

Machine orch (`grok_build_pipeline.py`) does ASR→cleanup fan-in and appends to
`/workspace/ingest/queues/ready_ping_queue.jsonl`.

This routine should:
1. Read that queue for `state=pending` lines.
2. If none: stay silent and exit (no filler).
3. If any: for each, Notion Transcript Ingest Ready (FrankenTranscript=cleaned.md, Quality=quality.md, Speakers) then ping user once with a digest; mark lines `state=pinged`.
4. If status says complete and queue empty: say batch N done once, pause/delete this routine.
5. Do NOT CheckSubagent, do NOT inspect ASR logs, do NOT re-run cleanup.
