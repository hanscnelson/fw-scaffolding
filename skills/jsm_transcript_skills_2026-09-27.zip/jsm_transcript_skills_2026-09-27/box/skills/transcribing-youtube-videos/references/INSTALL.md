# Install — Windows / macOS / Linux

Four pieces: **franken_whisper** (the ASR engine), a **ggml model** (what it transcribes with),
**yt-dlp** (the downloader), and **Python 3** (for `scripts/yt_transcribe.py`). `ffmpeg` is optional.
After installing, verify with `python3 scripts/yt_transcribe.py --check-deps`.

---

## 1. franken_whisper

**Linux / macOS / WSL** — one-liner (installs to `~/.local/bin`; add it to `PATH`):
```bash
curl -fsSL https://raw.githubusercontent.com/Dicklesworthstone/franken_whisper/main/install.sh | bash
```
Useful flags: `--easy-mode` (auto-edit PATH in your shell rc), `--verify` (self-test after install),
`--system` (install to `/usr/local/bin`, needs sudo), `--uninstall`, `--offline TARBALL` (airgap).

> **Want the `youtube` subcommand (Path A)?** It is in `main` but may not be in the current release
> binary yet. Until it ships in a release, build from source: `curl -fsSL …/install.sh | bash -s -- --from-source`
> (needs a Rust toolchain), or just use **Path B** (`scripts/yt_transcribe.py`), which only needs `transcribe`.

**Windows (native)** — download the zip and put the exe on `PATH`:
```powershell
# PowerShell
$u = "https://github.com/Dicklesworthstone/franken_whisper/releases/latest/download/franken_whisper-windows_amd64.zip"
$dst = "$env:USERPROFILE\bin"; New-Item -ItemType Directory -Force $dst | Out-Null
Invoke-WebRequest $u -OutFile "$env:TEMP\fw.zip"
Expand-Archive "$env:TEMP\fw.zip" -DestinationPath $dst -Force
setx PATH "$($env:PATH);$dst"    # open a new terminal afterward
```
(If the asset name differs, grab `…-windows_amd64.zip` from
https://github.com/Dicklesworthstone/franken_whisper/releases/latest.) Or use **WSL** and follow the Linux path.

---

## 2. A ggml Whisper model (required for ASR: Path A and Path B `transcribe`)

On franken_whisper **0.7.x** you do not fetch these by hand: `fw pull all` installs the
verified native set (~2.12 GB: `large-v3-turbo` + Sortformer diarization) and `fw models --json`
reports readiness. The manual downloads below are for older builds.

Pick one and drop it in the model directory. `--model tiny.en` / `--model large-v3-turbo` then resolve by name.
- **`ggml-large-v3-turbo.bin`** — best quality, ~1.6 GB, multilingual. **The default, and what you
  want for anything you intend to quote** — names, jargon, and crosstalk are exactly where small
  models fail, and a misquote is worse than a slow transcript.
- **`ggml-tiny.en.bin`** — fast, ~75 MB, English-only. Smoke tests and throwaway skims only.

Model directory (first that exists): `$FRANKEN_WHISPER_MODEL_DIR`, else `~/.cache/franken_whisper/models`,
else `~/models/whisper`.

**Linux / macOS:**
```bash
mkdir -p ~/.cache/franken_whisper/models
curl -fSL -o ~/.cache/franken_whisper/models/ggml-tiny.en.bin \
  https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-tiny.en.bin
```
**Windows (PowerShell):**
```powershell
$d = "$env:USERPROFILE\.cache\franken_whisper\models"; New-Item -ItemType Directory -Force $d | Out-Null
Invoke-WebRequest https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-tiny.en.bin -OutFile "$d\ggml-tiny.en.bin"
```
The **native engine runs from the model alone** — no whisper.cpp/Python backend binaries required
(verified on Linux x86_64). For **speaker names** (`--diarize`) you also need a HuggingFace token
(`HF_TOKEN` / `--hf-token`); `--tiny-diarize` needs no token.

---

## 3. yt-dlp

- **macOS:** `brew install yt-dlp`
- **Linux:** `pipx install yt-dlp`  (or `python3 -m pip install --user -U yt-dlp`, or your distro package, or the standalone binary into `~/.local/bin`)
- **Windows:** `winget install yt-dlp.yt-dlp`  (or `scoop install yt-dlp`, `choco install yt-dlp`, or drop `yt-dlp.exe` on `PATH`)

**Keep it current** — YouTube changes constantly and yt-dlp ships frequent fixes; franken_whisper warns
if the resolved yt-dlp is >90 days old. Update with `yt-dlp -U` (standalone binary), `pipx upgrade yt-dlp`,
`brew upgrade yt-dlp`, or `winget upgrade yt-dlp.yt-dlp`.

---

## 4. Python 3 (for `scripts/yt_transcribe.py`)

- **macOS / Linux:** already present (`python3`).
- **Windows:** the `python.exe` in `WindowsApps` is a Microsoft Store *stub*, not a usable interpreter.
  Install a real one: `winget install Python.Python.3.12` (or from python.org), then use `py -3 scripts\yt_transcribe.py …`.

---

## 5. ffmpeg (optional)

franken_whisper decodes MP3/AAC/FLAC/WAV/OGG/ALAC **in-process** (no ffmpeg). ffmpeg is only used as a
fallback for video files, exotic codecs, and mic capture — and it **auto-downloads on Linux x86_64** when
missing. If you need it elsewhere: `brew install ffmpeg` (macOS), your distro package (Linux),
`winget install Gyan.FFmpeg` / `scoop install ffmpeg` (Windows).

---

## Verify (any platform)
```bash
python3 scripts/yt_transcribe.py --check-deps    # yt-dlp / franken_whisper / model / ffmpeg presence
python3 scripts/yt_transcribe.py --self-test     # offline: parser + deep-link logic
franken_whisper youtube --help                   # Path A available? (else use Path B)
```
