# Reference — yt-dlp + franken_whisper

Install is in `INSTALL.md` (both are linked from SKILL.md). This is the command/flag/schema reference.

## franken_whisper — Path A: `youtube`
```bash
fw youtube "<URL|playlist|urls.txt>"          # omit --model: default is large-v3-turbo
```
| Flag | Meaning |
|---|---|
| `--model <M>` | model name/path forwarded to the engine (`tiny.en`, `large-v3-turbo`, …) |
| `--output-dir DIR` | where transcripts land (default `youtube_transcripts/`) |
| `--no-keep-audio` | delete the downloaded audio after transcription |
| `--concurrency N` | max concurrent downloads (default 3) |
| `--no-retry` / `--abort-on-error` | manifest retry / stop-on-first-failure behavior |

Writes one `<upload_date> - <title> [<id>].md` + a `.json` sidecar per video, each with deep links; a
`.fw_youtube_manifest.json` makes runs resumable (skips `done`, retries `failed`). Requires a build that
has the subcommand — check `franken_whisper youtube --help`.

## franken_whisper — Path B: `transcribe`
```bash
fw transcribe --input FILE --json             # add --model tiny.en only for smoke tests
```
| Flag | Meaning |
|---|---|
| `--input FILE` | audio (mp3/wav/flac/…) or video (ffmpeg auto-extracts) |
| `--model <M>` | model name/path |
| `--json` | emit the machine JSON envelope (below) |
| `--language en` | language hint (else auto) |
| `--tiny-diarize` | whisper.cpp speaker-turn detection, **no token** |
| `--diarize --hf-token "$HF_TOKEN"` | pyannote named-speaker diarization (needs a HF token) |
| `--backend whisper_cpp` | force a backend (`franken_whisper robot backends` lists them) |

**`transcribe --json` schema (verified on the release binary).** The result is a run envelope; the
transcript is under **`result.segments`**, each segment `{ "start_sec": float, "end_sec": float,
"text": str, "speaker": str|null, "confidence": float }`. Full text is `result.transcript`. Top-level keys
include `run_id`, `request`, `result`, `warnings`, `evidence`, `replay`. (Deep links use `start_sec`.)
`scripts/yt_transcribe.py` parses this and falls back to a recursive search, so minor schema changes don't break it.

Native engine: with a model present it runs in-process (`whisper.cpp-native`), no external backend
binary needed; `franken_whisper robot backends` / `robot health` report availability.

## Stage budgets (long recordings)
franken_whisper runs the pipeline as **timed stages**; each has a budget and is **cancelled** if it
overruns. The **backend (ASR) stage default is 900_000 ms (15 min)**, so a long recording fails with
``stage `backend` exceeded budget of 900000ms`` — an empty result that looks like a bug but is just the
timeout. Override per stage with `FRANKEN_WHISPER_STAGE_BUDGET_<STAGE>_MS` (milliseconds):

| Stage | Env var | When to raise |
|---|---|---|
| `backend` | `FRANKEN_WHISPER_STAGE_BUDGET_BACKEND_MS` | **the common one** — long audio (ASR is the bottleneck) |
| `normalize` | `FRANKEN_WHISPER_STAGE_BUDGET_NORMALIZE_MS` | huge/exotic files needing a long ffmpeg pass |
| `align` / `diarize` | `FRANKEN_WHISPER_STAGE_BUDGET_ALIGN_MS` / `..._DIARIZE_MS` | long files with alignment/diarization on |

Full stage set: `INGEST, NORMALIZE, PROBE, VAD, SEPARATE, BACKEND, ACCELERATION, ALIGN, PUNCTUATE,
DIARIZE, PERSIST, CLEANUP`. Rule of thumb: **~3× real-time for `backend`** (a 2-hour video ≈
`21600000` ms). `scripts/yt_transcribe.py` sets these automatically from the video duration
(`--backend-budget-ms` to override); for **Path A** (`franken_whisper youtube`) or a raw `transcribe`,
export the env var yourself before the command.

## yt-dlp — the flags this skill uses
| Goal | Command |
|---|---|
| List subtitle tracks | `yt-dlp --list-subs "URL"` |
| Metadata only | `yt-dlp --no-warnings --no-playlist --print '%(id)s' --print '%(title)s' --print '%(uploader)s' --print '%(upload_date)s' "URL"` |
| Creator captions | `yt-dlp --skip-download --no-playlist --write-subs --sub-langs 'en.*' --sub-format vtt -o '%(id)s.%(ext)s' "URL"` |
| Auto captions | swap `--write-subs` for `--write-auto-subs` (add `--sub-format json3` for word timing) |
| Audio only (for ASR) | `yt-dlp -x --audio-format mp3 --audio-quality 0 --no-playlist -o '%(id)s.%(ext)s' "URL"` |
| Whole playlist | drop `--no-playlist`; `-o '%(playlist_index)s-%(id)s.%(ext)s'` |
| Age/members-gated | `--cookies-from-browser chrome` (content you may access only) |

Notes: use **one `--print` per field** (template `\t` isn't reliable); `%(id)s.%(ext)s` lets yt-dlp fill the
real extension; caption file lands as `<id>.<lang>.vtt`. `--no-playlist` matters — a `watch?v=…&list=…` URL
otherwise pulls the whole playlist. Auto-captions repeat lines (rolling artifact); the helper dedupes.

## Deep links
`https://www.youtube.com/watch?v=<id>&t=<seconds>s` or `https://youtu.be/<id>?t=<seconds>`. `<seconds>` is
the integer segment start. Non-YouTube: most players accept `#t=`/`?t=`; else keep url+timestamp as the locator.

## Troubleshooting
| Symptom | Fix |
|---|---|
| `franken_whisper youtube` → "unrecognized subcommand" | your build predates it — use Path B (`yt_transcribe.py`) or `install.sh --from-source` |
| yt-dlp fails on a fresh video | update it (`yt-dlp -U` / `pipx upgrade yt-dlp`); extractors change often |
| `transcribe` returns 0 segments | model not found (check `franken_whisper robot health`) or you read top-level `segments` — they're under `result.segments` |
| ``stage `backend` exceeded budget of 900000ms`` | the recording is longer than the 15-min default — raise `FRANKEN_WHISPER_STAGE_BUDGET_BACKEND_MS` (see *Stage budgets*). The helper auto-scales it from duration (`--backend-budget-ms` to override) |
| Garbled quotes / phantom repeats | ASR error / hallucination loop — see SKILL.md "Cleaning raw ASR" |
| Windows: `python` opens the Store | install real Python and use `py -3 …` (see INSTALL.md) |
