# Cleaning & quality control (self-contained)

Raw ASR (or auto-captions) is **not** a finished transcript. This is the full quality pipeline —
speaker imputation, filler/disfluency removal, garble repair, and a four-round audit — adapted for
video/podcast transcripts. It preserves each segment's **timestamp + deep link** throughout, because
the whole value of this skill is a quote you can click back to the exact moment.

## Two output modes (decide up front)
- **Verbatim** — every word as spoken (fillers included). Use for legal/evidentiary or when exact wording matters.
- **Cleaned** (default) — fillers/disfluencies removed, garbles repaired, speakers attributed, **content fully preserved**.
Quotes you surface stay **verbatim from the cleaned transcript**, each with its `&t=<sec>s` deep link.

## Step 1 — Impute speakers from the video title + full description
The audio skill asks the user for speakers; here you **derive them from the video's own metadata**, then diarize.
1. Fetch title + full description + channel + chapters (no download):
   `yt-dlp --no-warnings --no-playlist --dump-json --skip-download "URL"` → read `.title`, `.description`, `.channel`/`.uploader`, `.chapters`.
   (`scripts/yt_transcribe.py` already stores `title`, `channel`, `description`, `chapters` in its output JSON.)
2. **Read them and build the expected speaker set**, best-effort:
   - Podcast/interview descriptions almost always name the **host** and **guest(s)** ("This week I talk with **Jane Doe**, CEO of…"). Titles are often "Host × Guest", "Guest on Show", or "Guest: Topic".
   - The **channel/uploader** is usually the host/interviewer; guests are named in the description.
   - Panels/solo talks: the description or title names the speaker(s); a solo talk = one speaker (attribute everything to them).
   - Capture a **one-line persona** per speaker from the description (role/expertise) — this is what drives content-based attribution.
3. If the metadata is thin (no names), fall back to generic labels (`Host`, `Guest`, `Speaker 2`) and flag it for the user.

## Step 2 — Contextual diarization (map turns → imputed names)
1. Get speaker **turns** from the engine. On **franken_whisper ≥ 0.7** this is native and on by default (Rust Streaming Sortformer, no token, no Python) — pass `--speaker-count-hard N` when the description tells you N, and transcribe at word granularity (`--max-segment-length 90 --split-on-word`) so turns can be fused precisely. Older builds: `--tiny-diarize` (no token) or `--diarize --hf-token $HF_TOKEN`. Treat `SPEAKER_00/01…` labels as **clusters**, never names.
2. **Fuse the two timelines** — the engine does not do this for you, and `result.segments[].speaker` is null for most segments while `result.diarization.turns[]` holds the real signal:
   `python3 scripts/fuse_diarization.py run.json --names "<host>,<guest>" > turns.txt`
   The method: take word text from `result.transcript` (it keeps true casing/punctuation; `segments[].text` is force-capitalized with a period appended) zipped onto segment timings, vote per word by confidence-weighted turn overlap, suppress lone-word flips, then **snap each speaker change to the nearest sentence-punctuation boundary within ±4 words**. That snap matters: raw overlap-voting misattributes about one word at every speaker change, and because the ASR and diarizer account for silence differently the error is *local* — a global time shift cannot fix it (measured on a 45-min two-person call: 122 bad boundaries raw, ~108 at the best global shift, **84** with punctuation snapping).
   `--names` is ordered **most-talkative first**; the script ranks speakers by voiced duration. Sortformer caps at **4 speaker lanes**, so 5+ voices silently merge.
3. **Map each turn label to an imputed name using content + persona**, exactly as a human would:
   - Who asks the questions / says "welcome to the show" → the **host/interviewer**.
   - Who gives long, domain-heavy answers → the **guest/expert**.
   - Cross-check against the description's roles (the CEO discusses their company; the host bridges topics).
4. Never attribute a turn to a speaker you did not actually resolve. Mark uncertain turns and bring them to the user; do not silently guess.

## Step 3 — Remove fillers & disfluencies (content must survive)
Remove where it does **not** change meaning or voice:
- Filler sounds: **um, uh, er, ah, hmm**.
- Discourse fillers when excessive/empty: **"like", "you know", "I mean", "sort of", "kind of", "basically", "actually", "right?"**, sentence-initial **"so"/"and"**.
- **False starts** ("I— I think we should…" → "I think we should…"), **stutters**, **repeated words**, and self-corrections (keep the corrected version).
Rules: keep the conversational tone; do **NOT** summarize, paraphrase loosely, or drop content — **every substantive sentence survives**.
**Retention guardrail:** cleaned/raw word ratio **0.75–0.92** per chunk. **<0.75 = content was lost** (redo the chunk); **>0.92 = fillers were kept** (clean harder).

## Step 4 — Kill hallucination loops
Long music/silence/applause makes the model emit phantom, repeated lines: `"Thank you."` ×N, `"So, let's go."`, `"I'm going to go ahead and…"`, or a repeat of the last real sentence. Signs: runs of identical/near-identical segments; a segment far longer than its word count; repeats at suspiciously round intervals (identical text every 2.0 s). **Drop them** — they are not speech. Note the segment `confidence` field is **not** a usable signal (it is unpopulated, ~1e-3 for everything).

**When you diarized, you have a much better oracle: voiced-frame evidence.** Whisper invents fluent text over silence; the diarizer simply does not hear a speaker there, so it is an *independent* witness. Sum turn overlap across a suspect window:
```python
voiced = sum(min(b, t["end_ms"]) - max(a, t["start_ms"])
             for t in turns if t["end_ms"] > a and t["start_ms"] < b)
```
**0 s voiced** over a window of confident text → pure hallucination, delete it. **A second or two voiced in a long window** → one real utterance plus a degenerate repeat loop: keep the first instance, delete the repetitions. A leading run of words with no voiced support is the classic intro hallucination — `fuse_diarization.py` strips it automatically and reports the count as `leading_unvoiced_dropped`.

## Step 5 — Repair homophones & proper nouns
Names, tickers, products, and jargon garble ("Anthropic"→"and tropic", "Tokio"→"Tokyo", "Pydantic"→"peidantic", "Claude"→"cloud/claw"). Build a small glossary of the expected names (from the title/description/domain) and fix on sight. **Repair rule:** fix only when context proves it (phonetic similarity + domain fit + the sentence still means something); otherwise mark **`[sic]`**. Never `[sic]` a word you repaired.

## The four-round audit (run all four; finish only when the mechanical audit is all-green *after the last edit* — fixes regress)
- **R1 — Mechanical** (`scripts/clean_audit.py TRANSCRIPT.json`): residual `um/uh` count → 0, monotonic timestamps, every deep link intact, speaker set ⊆ the imputed set, duplicate/hallucination lines flagged, retention ratio in-band. Fix and re-run.
- **R2 — Adversarial vs raw** (per chunk): compare cleaned against the raw segments — **no substantive content omitted** (filler removal is fine, content loss is NOT), no misattribution, garbles repaired correctly, timestamps still anchored to the right segment.
- **R3 — Fresh-eyes whole-document**: read end-to-end as a skeptical editor — does each turn's content fit its speaker? cross-chunk naming consistency, cleanup residue (dangling fragments, lost verbs), domain garbles a specialist would trip on. Per-chunk checks structurally cannot catch cross-chunk issues.
- **R4 — Final sweep**: homophone/acronym inventory (every ALL-CAPS acronym is real), `[sic]` audit (each marks an unrepaired garble), mixed-casing harmonization, re-adjudicate any fix new evidence challenges. **Re-run R1 after every fix batch.**

Apply fixes as **one batch** of `(old, new)` replacements, each asserting `old` is present (an unasserted replace is a silent no-op once an earlier fix moved the text); re-audit after each batch.

## Escalate, don't guess
Bring the user the things only they can resolve, batched: unresolved speaker attributions, a surviving `[sic]` garble, an unknown name the description didn't cover, an unexpected third voice. Silent guessing is how errors ship.
