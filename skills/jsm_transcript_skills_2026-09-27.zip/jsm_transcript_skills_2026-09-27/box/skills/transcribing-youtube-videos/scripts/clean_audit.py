#!/usr/bin/env python3
"""clean_audit.py — mechanical audit (Rounds 1 & 4) of a transcript produced by this skill.

Cross-platform (Windows/macOS/Linux). Reads a transcript JSON
({segments:[{start,end,text,deep_link,speaker?}], ...}) and flags the defect classes that a
mechanical pass can catch, so the agent fixes them before the human-judgment rounds. See
references/CLEANING.md for the full four-round pipeline.

Usage:
  python3 clean_audit.py TRANSCRIPT.json [--speakers "Host,Guest"] [--raw RAW.json] [--json]
Exit: 0 = all green, 1 = issues found.
"""
import argparse, json, re, sys

FILLERS_HARD = ["um", "uh", "er", "ah", "erm", "uhh", "umm"]           # should be ~0 after cleaning
FILLERS_SOFT = ["like", "you know", "i mean", "sort of", "kind of", "basically", "actually"]  # advisory

def words(t):
    return re.findall(r"[a-z0-9']+", (t or "").lower())

def load(path):
    return json.load(open(path, encoding="utf-8"))

def audit(doc, speakers=None, raw=None):
    segs = doc.get("segments", []) or []
    issues, notes = [], []
    if not segs:
        issues.append("no segments in transcript")
        return issues, notes

    text_all = " ".join(s.get("text", "") for s in segs)
    toks = words(text_all)
    joined = " " + " ".join(toks) + " "

    # 1. residual fillers
    hard = {f: len(re.findall(r"\b" + re.escape(f) + r"\b", joined)) for f in FILLERS_HARD}
    hard = {f: n for f, n in hard.items() if n}
    if hard:
        issues.append("residual hard fillers: " + ", ".join("%s×%d" % (f, n) for f, n in hard.items()))
    soft = {f: joined.count(" " + f + " ") for f in FILLERS_SOFT}
    soft = {f: n for f, n in soft.items() if n > 2}
    if soft:
        notes.append("possibly-excessive soft fillers (judgment): " + ", ".join("%s×%d" % (f, n) for f, n in soft.items()))

    # 2. monotonic timestamps
    last = -1.0
    nonmono = 0
    for s in segs:
        st = float(s.get("start", 0))
        if st + 1e-6 < last:
            nonmono += 1
        last = max(last, st)
    if nonmono:
        issues.append("non-monotonic timestamps: %d segment(s) start before a previous one" % nonmono)

    # 3. deep-link integrity (t param matches start)
    bad_links = 0
    for s in segs:
        dl = s.get("deep_link", "")
        m = re.search(r"[?&]t=(\d+)s?", dl)
        if not dl or not m:
            bad_links += 1
        elif abs(int(m.group(1)) - int(float(s.get("start", 0)))) > 1:
            bad_links += 1
    if bad_links:
        issues.append("deep-link problems: %d segment(s) missing or mismatched &t=" % bad_links)

    # 4. hallucination / duplicate runs (>=3 identical consecutive lines)
    run, run_txt, dup_runs = 1, None, 0
    for s in segs:
        t = (s.get("text") or "").strip().lower()
        if t and t == run_txt:
            run += 1
        else:
            if run >= 3:
                dup_runs += 1
            run, run_txt = 1, t
    if run >= 3:
        dup_runs += 1
    if dup_runs:
        issues.append("hallucination/duplicate suspicion: %d run(s) of >=3 identical consecutive segments" % dup_runs)

    # 5. empty segments
    empties = sum(1 for s in segs if not (s.get("text") or "").strip())
    if empties:
        notes.append("%d empty segment(s)" % empties)

    # 6. speaker-set containment
    spk = sorted({s.get("speaker") for s in segs if s.get("speaker")})
    if spk:
        notes.append("speakers present: " + ", ".join(spk))
        if speakers:
            allowed = {x.strip() for x in speakers.split(",") if x.strip()}
            extra = [x for x in spk if x not in allowed]
            if extra:
                issues.append("speakers outside the imputed set %s: %s" % (sorted(allowed), extra))
    elif speakers:
        notes.append("no per-segment speaker labels present (diarization not applied)")

    # 7. retention ratio vs raw
    if raw is not None:
        raw_words = len(words(" ".join(s.get("text", "") for s in (raw.get("segments") or []))))
        if raw_words:
            ratio = len(toks) / raw_words
            band = "ok" if 0.75 <= ratio <= 0.92 else ("CONTENT LOST" if ratio < 0.75 else "fillers kept")
            (notes if band == "ok" else issues).append("retention ratio %.2f (%s; want 0.75-0.92)" % (ratio, band))

    return issues, notes

def main():
    ap = argparse.ArgumentParser(description="Mechanical audit of a transcript JSON.")
    ap.add_argument("transcript")
    ap.add_argument("--speakers", help='imputed speaker set, e.g. "Host,Guest"')
    ap.add_argument("--raw", help="raw (pre-cleaning) transcript JSON, for the retention-ratio check")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    doc = load(a.transcript)
    raw = load(a.raw) if a.raw else None
    issues, notes = audit(doc, a.speakers, raw)
    if a.json:
        print(json.dumps({"ok": not issues, "issues": issues, "notes": notes}, indent=2, ensure_ascii=False))
    else:
        for n in notes:
            print("  note: " + n)
        if issues:
            print("ISSUES (%d):" % len(issues))
            for i in issues:
                print("  - " + i)
        else:
            print("all green")
    sys.exit(1 if issues else 0)

if __name__ == "__main__":
    main()
