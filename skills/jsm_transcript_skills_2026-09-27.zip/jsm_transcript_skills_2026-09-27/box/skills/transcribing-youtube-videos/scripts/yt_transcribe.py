#!/usr/bin/env python3
"""yt_transcribe.py — cross-platform (Windows / macOS / Linux) video/podcast -> timestamped,
deep-linked transcript, using yt-dlp + franken_whisper.

Two modes (pick with --mode):
  transcribe (default) : yt-dlp downloads audio -> `franken_whisper transcribe --json` (ASR)
                         -> deep-linked JSON. Works on the current franken_whisper *release*
                         (which ships `transcribe`) and on non-YouTube sites.
  captions             : yt-dlp fetches existing captions (creator, else auto) -> deep-linked
                         JSON. No model / no ASR needed — fastest when captions exist.

If your franken_whisper build has the `youtube` subcommand (in source/main; may not be in your
installed release yet), prefer that single command instead:
    fw youtube "<URL>"

Usage:
  python3 yt_transcribe.py "<URL>" [--mode transcribe|captions] [--model MODEL] [--out DIR] [--keep-audio]
  python3 yt_transcribe.py --check-deps
  python3 yt_transcribe.py --self-test        # offline: validates the parsers + deep-link logic

Output: <OUT>/<id>.transcript.json
  {video_id,url,title,uploader,upload_date,source,segments:[{start,end,text,deep_link}]}
"""
import argparse, json, os, re, shutil, subprocess, sys
from pathlib import Path

# ---------------------------------------------------------------- helpers
def find_ytdlp():
    return shutil.which("yt-dlp") or shutil.which("yt-dlp.exe")

def find_fw():
    for name in (os.environ.get("FRANKEN_WHISPER_BIN"), "franken_whisper", "fw"):
        if name and shutil.which(name):
            return shutil.which(name)
    exe = "franken_whisper.exe" if os.name == "nt" else "franken_whisper"
    cand = Path.home() / ".local" / "bin" / exe
    return str(cand) if cand.exists() else None

def deep_link(vid, secs):
    return "https://www.youtube.com/watch?v=%s&t=%ds" % (vid, int(float(secs)))

# ---------------------------------------------------------------- parsers (importable + tested)
_START_KEYS = ("start_sec", "start", "s", "t0", "offset")   # release CLI uses start_sec; native fixture uses start; NDJSON uses s
_END_KEYS   = ("end_sec", "end", "e")
_TEXT_KEYS  = ("text", "t")

def parse_fw_json(text, vid):
    """Parse `franken_whisper transcribe --json`. Segments live under result.segments in the
    release CLI envelope ({start_sec,end_sec,text,...}); fall back to a defensive recursive search."""
    data = json.loads(text)
    raw = None
    if isinstance(data, dict):
        raw = (data.get("result") or {}).get("segments")
    if not raw:
        def looks(seg): return isinstance(seg, dict) and any(k in seg for k in _START_KEYS)
        def find(o):
            if isinstance(o, list) and o and looks(o[0]): return o
            if isinstance(o, dict):
                for v in o.values():
                    r = find(v)
                    if r: return r
            if isinstance(o, list):
                for v in o:
                    r = find(v)
                    if r: return r
            return None
        raw = find(data) or []
    out = []
    for s in raw:
        st = next((s[k] for k in _START_KEYS if k in s), 0)
        en = next((s[k] for k in _END_KEYS if k in s), st)
        tx = (next((s[k] for k in _TEXT_KEYS if k in s), "") or "").strip()
        if tx:
            out.append({"start": round(float(st), 2), "end": round(float(en), 2),
                        "text": tx, "deep_link": deep_link(vid, st)})
    return out

_VTT_TS = re.compile(r"(?:(\d+):)?(\d{1,2}):(\d{2})[.,](\d{3})")   # HH:MM:SS.mmm or MM:SS.mmm
def _vtt_sec(m):
    return int(m.group(1) or 0) * 3600 + int(m.group(2)) * 60 + int(m.group(3)) + int(m.group(4)) / 1000.0

def parse_vtt(text, vid):
    """Parse a WebVTT file line-by-line (robust to optional hours, cue settings, inline tags,
    and the rolling-duplicate artifact of auto-captions)."""
    segs, lines, i = [], text.splitlines(), 0
    while i < len(lines):
        if "-->" in lines[i]:
            left, right = lines[i].split("-->", 1)
            ms, me = _VTT_TS.search(left), _VTT_TS.search(right)
            st = _vtt_sec(ms) if ms else 0.0
            en = _vtt_sec(me) if me else st
            i += 1
            body = []
            while i < len(lines) and lines[i].strip() and "-->" not in lines[i]:
                body.append(lines[i]); i += 1
            txt = re.sub(r"<[^>]+>", "", " ".join(body)).strip()
            if txt and (not segs or segs[-1]["text"] != txt):
                segs.append({"start": round(st, 2), "end": round(en, 2),
                             "text": txt, "deep_link": deep_link(vid, st)})
        else:
            i += 1
    return segs

# ---------------------------------------------------------------- orchestration
def yt(args):
    return subprocess.run([find_ytdlp()] + args, capture_output=True, text=True)

def metadata(url):
    # Full metadata JSON: gives the title, channel, AND description/chapters used
    # to impute speakers (see references/CLEANING.md). Multi-line descriptions
    # make one-line `--print` unreliable, so use --dump-json.
    r = yt(["--no-warnings", "--no-playlist", "--skip-download", "--dump-json", url])
    if r.returncode != 0 or not r.stdout.strip():
        sys.exit("ERROR: yt-dlp could not resolve %s\n%s" % (url, r.stderr.strip()[:500]))
    j = json.loads(r.stdout.splitlines()[0])  # one object per video (--no-playlist)
    return {
        "video_id": j.get("id", ""),
        "title": j.get("title", ""),
        "uploader": j.get("uploader") or j.get("channel") or "",
        "channel": j.get("channel") or j.get("uploader") or "",
        "upload_date": j.get("upload_date", ""),
        "duration": j.get("duration"),
        "description": j.get("description", ""),
        "chapters": [{"title": c.get("title"), "start": c.get("start_time")}
                     for c in (j.get("chapters") or [])],
    }

def do_captions(url, vid, outdir):
    # creator subs first (best), else auto
    yt(["--skip-download", "--no-playlist", "--write-subs", "--sub-langs", "en.*",
        "--sub-format", "vtt", "-o", str(outdir / "%(id)s.%(ext)s"), url])
    vtts = list(outdir.glob(vid + ".*.vtt"))
    if not vtts:
        yt(["--skip-download", "--no-playlist", "--write-auto-subs", "--sub-langs", "en",
            "--sub-format", "vtt", "-o", str(outdir / "%(id)s.%(ext)s"), url])
        vtts = list(outdir.glob(vid + ".*.vtt"))
    if not vtts:
        sys.exit("ERROR: no captions (creator or auto) for %s — use --mode transcribe" % vid)
    return parse_vtt(vtts[0].read_text(encoding="utf-8", errors="replace"), vid)

def backend_budget_ms(duration, override):
    """Per-stage budget (ms) for the `transcribe` backend (ASR) stage. franken_whisper's
    default is 900_000 ms (15 min); a long recording — a 2-hour podcast is ~7200 s of audio —
    blows it and the stage is cancelled ("stage `backend` exceeded budget of 900000ms"), so a
    naive run *silently fails on anything long*. Scale generously to the audio duration
    (3x real-time, floored at the 15-min default) so long videos just work; honor an override."""
    if override:
        return max(1, int(override))
    return max(900_000, int(float(duration or 0) * 3_000))

def do_transcribe(url, vid, outdir, model, keep_audio, duration=None, budget_ms=None):
    fw = find_fw()
    if not fw:
        sys.exit("ERROR: franken_whisper not found. Install it (see references/INSTALL.md) or "
                 "use --mode captions (no ASR needed).")
    audio = outdir / (vid + ".mp3")
    r = yt(["-x", "--audio-format", "mp3", "--audio-quality", "0", "--no-playlist",
            "-o", str(outdir / "%(id)s.%(ext)s"), url])
    if r.returncode != 0 or not audio.exists():
        sys.exit("ERROR: audio download failed for %s\n%s" % (vid, r.stderr.strip()[:500]))
    budget = backend_budget_ms(duration, budget_ms)
    sys.stderr.write(">> transcribing (~%.0f min audio; backend-stage budget %d ms)\n"
                     % ((float(duration or 0)) / 60.0, budget))
    # Raise the per-stage budgets so a long recording is not cancelled mid-transcription. The
    # backend (ASR) stage is the bottleneck; normalize/align get a generous floor too. All stage
    # budgets follow FRANKEN_WHISPER_STAGE_BUDGET_<STAGE>_MS (see references/REFERENCE.md).
    # DIARIZE is its own stage on 0.7.x and is the SLOWER half of a run (~7 min of
    # Sortformer vs ~6 min of ASR per 45 min of audio), so it needs the same scaling as
    # the backend stage; budgeting only the backend leaves long videos to die in
    # diarization instead.
    env = dict(os.environ, FRANKEN_WHISPER_NATIVE_EXECUTION="1",
               FRANKEN_WHISPER_STAGE_BUDGET_BACKEND_MS=str(budget),
               FRANKEN_WHISPER_STAGE_BUDGET_DIARIZE_MS=str(budget),
               FRANKEN_WHISPER_STAGE_BUDGET_NORMALIZE_MS=str(max(600_000, budget)),
               FRANKEN_WHISPER_STAGE_BUDGET_ALIGN_MS=str(max(600_000, budget)))
    # Omit --model unless the caller named one: franken_whisper's own default is
    # large-v3-turbo, which is what you want for anything you intend to quote. Passing a
    # small model here silently degrades every transcript this helper produces.
    cmd = [fw, "transcribe", "--input", str(audio), "--json"]
    if model:
        cmd[3:3] = ["--model", model]
    tr = subprocess.run(cmd, capture_output=True, text=True, env=env)
    if tr.returncode != 0 or not tr.stdout.strip():
        hint = ("\nHINT: `stage `backend` exceeded budget` means the recording is longer than the "
                "budget — raise it with --backend-budget-ms (this helper already auto-scales from "
                "the video duration; pass a bigger value if the duration was unknown).") \
               if "budget" in (tr.stderr or "") else ""
        sys.exit("ERROR: franken_whisper transcribe failed\n%s%s" % (tr.stderr.strip()[:800], hint))
    segs = parse_fw_json(tr.stdout, vid)
    if not keep_audio:
        try: audio.unlink()
        except OSError: pass
    return segs

def main():
    ap = argparse.ArgumentParser(description="Transcribe a video/podcast to timestamped, deep-linked JSON.")
    ap.add_argument("url", nargs="?", help="video URL")
    ap.add_argument("--mode", choices=["transcribe", "captions"], default="transcribe")
    ap.add_argument("--model", default=None,
                    help="franken_whisper model. Default: let franken_whisper choose "
                         "(large-v3-turbo on 0.7.x). Pass tiny.en only for smoke tests")
    ap.add_argument("--out", default="yt_transcripts", help="output directory")
    ap.add_argument("--keep-audio", action="store_true", help="keep the downloaded audio (default: delete, per rights posture)")
    ap.add_argument("--backend-budget-ms", type=int, default=None,
                    help="override the transcribe backend-stage timeout in ms (default: auto-scaled to "
                         "3x the video duration, floor 900000 = 15 min). Raise this if a long recording "
                         "fails with 'stage `backend` exceeded budget'.")
    ap.add_argument("--check-deps", action="store_true")
    ap.add_argument("--self-test", action="store_true")
    a = ap.parse_args()

    if a.self_test:
        return _self_test()
    if a.check_deps:
        return _check_deps()
    if not a.url:
        ap.error("a URL is required (or use --check-deps / --self-test)")
    if not find_ytdlp():
        sys.exit("ERROR: yt-dlp not found (see references/INSTALL.md)")

    outdir = Path(a.out); outdir.mkdir(parents=True, exist_ok=True)
    m = metadata(a.url)
    vid = m["video_id"]
    sys.stderr.write(">> %s — %s (%s, %s)\n" % (vid, m["title"], m["channel"], m["upload_date"]))
    if a.mode == "captions":
        segs, src = do_captions(a.url, vid, outdir), "captions"
    else:
        segs, src = do_transcribe(a.url, vid, outdir, a.model, a.keep_audio,
                                  duration=m["duration"], budget_ms=a.backend_budget_ms), "asr"
    # title/description/channel/chapters are carried through so the cleaning step
    # can impute speakers from them (see references/CLEANING.md).
    doc = {"video_id": vid, "url": a.url, "title": m["title"], "uploader": m["uploader"],
           "channel": m["channel"], "upload_date": m["upload_date"], "duration": m["duration"],
           "description": m["description"], "chapters": m["chapters"],
           "source": src, "segments": segs}
    out = outdir / (vid + ".transcript.json")
    out.write_text(json.dumps(doc, indent=2, ensure_ascii=False), encoding="utf-8")
    sys.stderr.write(">> wrote %s (%s, %d segments)\n" % (out, src, len(segs)))

def _check_deps():
    print("platform:", sys.platform, "| python:", sys.version.split()[0])
    yd, fw = find_ytdlp(), find_fw()
    print(("  ok  yt-dlp   " + yd) if yd else "  MISSING  yt-dlp   (see references/INSTALL.md)")
    print(("  ok  franken_whisper   " + fw) if fw else "  MISSING  franken_whisper   (see references/INSTALL.md; captions mode works without it)")
    mdirs = [os.environ.get("FRANKEN_WHISPER_MODEL_DIR"), str(Path.home()/".cache"/"franken_whisper"/"models"), str(Path.home()/"models"/"whisper")]
    models = [p for d in mdirs if d for p in Path(d).glob("ggml-*.bin")] if any(mdirs) else []
    print(("  ok  model(s)   " + ", ".join(m.name for m in models)) if models else "  MISSING  ggml model   (see references/INSTALL.md; needed only for --mode transcribe)")
    print(("  ok  ffmpeg   " + shutil.which("ffmpeg")) if shutil.which("ffmpeg") else "  note  ffmpeg absent   (optional; franken_whisper decodes common audio in-process)")

def _self_test():
    ok = True
    fw = json.dumps({"result": {"segments": [
        {"start_sec": 0.0, "end_sec": 9.0, "text": "Hello world.", "speaker": None, "confidence": 0.9},
        {"start_sec": 9.0, "end_sec": 12.5, "text": "Second line.", "confidence": 0.8}]}})
    s = parse_fw_json(fw, "abc123")
    ok &= (len(s) == 2 and s[0]["start"] == 0.0 and s[1]["start"] == 9.0
           and s[1]["deep_link"] == "https://www.youtube.com/watch?v=abc123&t=9s")
    print("fw_json parser:", "PASS" if ok else "FAIL", s[:1])
    vtt = "WEBVTT\n\n00:00:01.000 --> 00:00:03.500 align:start\nHello <c>there</c>\n\n01:02:03.000 --> 01:02:05.000\nLater line\n"
    v = parse_vtt(vtt, "abc123")
    okv = (len(v) == 2 and v[0]["text"] == "Hello there" and v[0]["start"] == 1.0
           and v[1]["start"] == 3723.0 and v[1]["deep_link"].endswith("&t=3723s"))
    print("vtt parser:    ", "PASS" if okv else "FAIL", v)
    ok &= okv
    okb = (backend_budget_ms(7200, None) == 21_600_000   # 2h video -> 6h budget
           and backend_budget_ms(10, None) == 900_000     # short video -> 15-min floor
           and backend_budget_ms(7200, 5000) == 5000)     # explicit override wins
    print("budget scaler: ", "PASS" if okb else "FAIL", backend_budget_ms(7200, None))
    ok &= okb
    print("SELF-TEST:", "PASS" if ok else "FAIL")
    sys.exit(0 if ok else 1)

if __name__ == "__main__":
    main()
