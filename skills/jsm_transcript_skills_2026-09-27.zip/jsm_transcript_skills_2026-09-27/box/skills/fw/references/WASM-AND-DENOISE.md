# Browser, WASM, and FastEnhancer

## Table of Contents

- [Native denoiser](#native-denoiser)
- [Browser path](#browser-path)
- [Stall diagnosis](#stall-diagnosis)
- [Stale assets](#stale-assets)
- [Memory boundary](#memory-boundary)
- [Quality boundary](#quality-boundary)

## Native denoiser

The native normalization wrapper engages FastEnhancer when its pinned artifact is present
unless `FW_DENOISE=0`. Resolution is `FW_DENOISER_PATH` first, then
`<model-cache>/denoiser/fastenhancer-s-48k-denoise.safetensors`.

It processes 60-second chunks with one second of context, resamples through 48 kHz, and
preserves sample length. `fw pull all` does not currently provision it. Native audio calls
the denoiser without an inner cancellation token; cancellation is checked after the call,
so a chunk is not cooperatively interruptible mid-compute.

Caller census matters: current ordinary native transcription backends call the raw WAV
reader and bypass this wrapper. The direct, evaluation-only `sortformer-diarize` command is
the current non-browser native CLI caller. Therefore `FW_DENOISE=0 fw transcribe ...` is not
a valid denoiser A/B.

## Browser path

The production browser worker is `site/engine-worker.js`, backed by `fw-wasm/src/lib.rs`.
It emits `audio:denoise:completed/total` heartbeat stages. The page watches progress; after
180 seconds without denoise progress it terminates the worker, resets readiness, boots a
new worker, and recommends reload plus cleanup-off retry.

Browser cancellation is hard worker termination, not cooperative kernel cancellation.

## Stall diagnosis

1. Capture browser version, page build/cache state, audio duration, and last stage.
2. Confirm whether denoise heartbeat advanced.
3. Allow the 180-second no-progress watchdog to fire; do not wait indefinitely.
4. Click **Reload cached models**, clear **Clean up the audio first**, and retry.
5. If raw transcription works, isolate denoiser/liveness rather than ASR.
6. For direct native Sortformer, use
   `FW_DENOISE=0 fw sortformer-diarize --input AUDIO`; ordinary native transcription is
   already outside the wrapper.

## Stale assets

Current production initialization uses wasm-bindgen object form:
`engine.default({ module_or_path: wasmUrl })`. The superseded `site/fw-worker.js` retains an
old initializer but is excluded from deployment. A production deprecation warning therefore
suggests stale deployed or browser-cached assets until proven otherwise.

## Memory boundary

WASM traps/OOM can reflect the browser's roughly 4 GB memory ceiling. Shorten the recording,
use a native CLI, or split work. Do not mislabel OOM as a denoiser timeout without stage and
worker evidence.

## Quality boundary

Enhancement may improve noisy speech but can raise WER on clean speech or remove acoustic
cues used by diarization. Compare raw and enhanced transcript, timing, and diarization on
representative audio. Length preservation stabilizes timestamps; it does not certify words
or speaker turns.
