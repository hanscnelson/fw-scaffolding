# Diarization Reference

## Table of Contents

- [Default behavior](#default-behavior)
- [Engine families](#engine-families)
- [Evidence hierarchy](#evidence-hierarchy)
- [Speaker identity](#speaker-identity)
- [Coverage audit](#coverage-audit)
- [Failure policy](#failure-policy)

## Default behavior

Diarization is on by default. Use `--no-diarize` to opt out. Explicit `--diarize` is
accepted but redundant on the current CLI.

## Engine families

| Engine | Boundary |
|---|---|
| `auto` | policy selection; inspect actual route |
| `sortformer` | native default package, four lanes, development-uncertified |
| `acoustic` | native heuristic, uncertified |
| `external` | Python/external dependency route |
| `ecapa`, `ecapa-fused` | require operator-local authenticated ECAPA artifact |

Fallback policies currently include `unknown`, `acoustic`, `external`, and `error`.
Fail-closed is appropriate when speaker separation is a correctness requirement.

## Evidence hierarchy

1. Authenticated artifact/package and exact engine route.
2. Real audio completion with structured diarization output.
3. Duration/turn coverage, confidence, overlap, and lane-capacity checks.
4. Pinned corpus DER/JER and oracle evidence.
5. External identity evidence if names are assigned.

Static model readiness or a synthetic conformance seam does not prove production DER.

## Speaker identity

`SPEAKER_00` is a cluster label, not a person. Authenticated enrollment profiles or strongly
controlled channel/roster evidence can support identity with consent. Self-introduction and
content are spoofable contextual hints, not strong independent proof. Preserve uncertainty;
never silently map by lane order. `--speaker-hints` fields may persist with a run, while
`--persist-speaker-profiles` records explicit consent for reusable profile persistence.

## Coverage audit

Compare diarization turns against audio duration, VAD/energy, and transcript segments. The
ASR segment `speaker` field can be sparse even when the separate diarization timeline has
useful turns. Join timelines explicitly and test boundary behavior; do not assume the join
was performed for you.

Sortformer currently has four lanes. More speakers can be merged; a speaker-count hint is a
constraint, not proof of the real count.

## Failure policy

Use `error` when unlabeled or fallback output would be unsafe. Use `unknown` when downstream
code can preserve uncertainty. Record requested engine, selected engine, fallback reason,
artifact identity, lane cap, and coverage evidence.
