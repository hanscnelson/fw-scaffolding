# Troubleshooting fw

## Table of Contents

- [Old CLI syntax](#old-cli-syntax)
- [Stale binary](#stale-binary)
- [Models or doctor seem stuck](#models-or-doctor-seem-stuck)
- [Missing model or backend](#missing-model-or-backend)
- [Denoiser cleanup stuck](#denoiser-cleanup-stuck)
- [Browser deprecation warning](#browser-deprecation-warning)
- [WASM memory failure](#wasm-memory-failure)
- [Stage timeout or cancellation](#stage-timeout-or-cancellation)
- [Missing long-form speech](#missing-long-form-speech)
- [Diarization surprises](#diarization-surprises)
- [Persistence or sync failure](#persistence-or-sync-failure)
- [Performance claim confusion](#performance-claim-confusion)

## Old CLI syntax

**Symptom:** filename needs `--input`; `--robot` is unrecognized.

```bash
fw transcribe --input meeting.m4a --no-persist --json
fw robot run --input meeting.m4a --no-persist
```

Verify with exact binary help. Fix the docs/site if they disagree; do not add a compatibility
shim without a product decision. These diagnostic forms avoid a run-DB write; omit
`--no-persist` only when the operator intentionally wants a durable run.

## Stale binary

**Symptom:** help or behavior differs from current source/release.

Record `type -a fw`, path, `fw --version`, package-manager version, release target commit,
and source HEAD. Reinstall/upgrading is justified only after identifying which surface is
stale. Do not test a build-tree binary and report the installed package fixed.

## Models or doctor seem stuck

`models --json` and `doctor --json` can hash roughly 2.1 GB of artifacts. They are network-free
and cancellable. Observe process/disk activity before diagnosing a hang. `pull` is the only
in-binary native-model provisioning command; explicit external backends may fetch their own
models, while YouTube and ffmpeg auto-provision are separate network paths.

## Missing model or backend

```bash
fw robot triage
fw models --json
fw pull all --json
fw doctor --json
```

For ECAPA, follow the pinned local-conversion instructions; `pull all` will not install it.
For external bridges, inspect the relevant `FRANKEN_WHISPER_*_BIN` override and availability.

## Denoiser cleanup stuck

Direct evaluation-only native Sortformer bypass:

```bash
FW_DENOISE=0 fw sortformer-diarize --input audio.m4a
```

Browser: inspect `audio:denoise:x/y` heartbeat, wait no longer than the 180-second no-progress
watchdog, reload cached models, retry with cleanup off, and compare raw transcription. Native
chunks are not cancellable inside the FastEnhancer call. Current ordinary native
`fw transcribe` bypasses the denoiser wrapper entirely, so its kill switch cannot diagnose a
browser cleanup problem.

## Browser deprecation warning

Current production worker uses object-form wasm-bindgen initialization. Since the old demo
worker is excluded from deployment, a production warning points first to stale deployed or
cached assets. Confirm the served `engine-worker.js`, cache-bust/reload, and deploy revision.

## WASM memory failure

Browser memory has a roughly 4 GB ceiling. Shorten/split the recording or use native `fw`.
Preserve the trap/stage evidence; do not call every worker death a denoiser stall.

## Stage timeout or cancellation

Inspect the named stage in `FW-STAGE-TIMEOUT`. Raise only
`FRANKEN_WHISPER_STAGE_BUDGET_<STAGE>_MS`, based on audio duration and measured host speed.
Exit 130 / `FW-CANCELLED` is terminal; stop downstream work and keep partial audit events.

## Missing long-form speech

Inspect `dropped_windows`, warnings, `backend.dropped_windows` events, transcript time
coverage, and voiced diarization/VAD evidence. Retry is already default-on. If content is
still missing, create overlapping sub-30-second slices with ffmpeg and mark unresolved gaps.

## Diarization surprises

Check actual engine route, artifact readiness, fallback policy, four-lane capacity, turn
coverage, and confidence. Sparse segment speaker fields do not mean the separate turn
timeline is empty. Cluster labels are not names.

## Persistence or sync failure

Run DB, orchestrator temp state, model cache, auto-provisioned tools, and YouTube output have
different roots; use the matrix in [Artifacts and Environment](ARTIFACTS-AND-ENV.md#storage-roots).
SQLite uses WAL and bounded busy retries. Check disk space, permissions, process contention,
and the exact `--db`. Imports mutate under lock; resolve the exact target, obtain authority,
export/backup first, choose an explicit conflict policy, and run post-import validation.

## Performance claim confusion

Inspect the encoder route, not a generic confidence/acceleration summary. Require matched
model/audio/decode parameters and same-invocation incumbent timing. If quiescence or output
equivalence fails, the result is undecidable—not a win.
