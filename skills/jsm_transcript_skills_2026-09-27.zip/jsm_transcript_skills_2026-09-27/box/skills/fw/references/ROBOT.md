# Robot Mode Reference

## Table of Contents

- [Purpose](#purpose)
- [Commands](#commands)
- [NDJSON rules](#ndjson-rules)
- [Event families](#event-families)
- [Parser pattern](#parser-pattern)
- [Errors and recovery](#errors-and-recovery)
- [Contract checks](#contract-checks)

## Purpose

Robot mode is the stable agent-first surface. Human decoration belongs on stderr or outside
machine mode; stdout must remain line-oriented data.

## Commands

```bash
fw robot run --input audio.wav --no-persist
fw robot triage
fw robot schema
fw robot backends
fw robot health
fw robot routing-history
fw robot-docs guide
```

There is no root `--robot` flag.

## NDJSON rules

- One complete JSON object per line.
- Parse incrementally; do not wait for EOF to decode one document.
- Dispatch by schema and event kind, not by line number.
- Preserve unknown additive fields.
- Treat `run_complete` and `run_error` as terminal events.
- Honor process exit code as well as the terminal event.
- Never merge stderr into stdout before parsing.

## Event families

The current schema advertises events including:

- `run_start`, `stage`, `run_complete`, `run_error`;
- `backends.discovery`, `routing_decision`;
- speculative partial/confirm/retract/correct/stats events;
- health events.

The pipeline may emit `stage: "backend"` with a detailed code such as
`code: "backend.dropped_windows"`. Branch on the correct field and inspect `fw robot schema`
for the exact current payload instead of hard-coding this list.

## Parser pattern

```bash
(
  set -o pipefail
  fw robot run --input audio.wav --no-persist |
  while IFS= read -r event; do
    printf '%s\n' "$event" | jq -e . >/dev/null || exit 1
    printf '%s\n' "$event"
  done
  pipeline_status=("${PIPESTATUS[@]}")
  test "${pipeline_status[0]}" -eq 0 && test "${pipeline_status[1]}" -eq 0
)
```

This status capture is Bash-specific and must occur immediately after the pipeline. The
single `&&` chain prevents a successful parser status from masking a failed producer. In
application code, keep the child exit and parser status separately, bound line size, reject
invalid UTF-8/JSON, record schema versions, verify one terminal event, and keep all prior
valid events if the terminal line is malformed.

Treat real robot streams, terminal reports, stderr, run databases, and JSONL exports as
sensitive. `run_start` can include a database path, and stage events can expose
typed/materialized/normalized input paths. Only selected terminal and syntax-error surfaces
are path-sanitized; never publish a raw stream or report assuming path safety.

## Errors and recovery

| Signal | Response |
|---|---|
| `FW-INVALID-REQUEST` | fix arguments; do not retry unchanged |
| `FW-MISSING-ARTIFACT` | run model discovery/pull, then recheck |
| `FW-STAGE-TIMEOUT` | inspect stage and raise only that budget if justified |
| `FW-CANCELLED` / exit 130 | stop downstream work; preserve partial audit events |
| backend unavailable | inspect routing and package/binary state |
| dropped-window event | mark transcript incomplete until reviewed/recovered |

## Contract checks

Test stdout purity, every line's JSON validity, schema/version fields, terminal-event
cardinality, nonzero failure exits, and Ctrl-C exit 130. Parse failures in robot mode should
still produce one structured `run_error` rather than Clap decoration.
