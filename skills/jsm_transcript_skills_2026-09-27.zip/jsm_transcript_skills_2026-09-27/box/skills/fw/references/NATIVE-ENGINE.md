# Native Whisper Engine

## Table of Contents

- [Scope](#scope)
- [Decode stack](#decode-stack)
- [Routing](#routing)
- [Long-form correctness](#long-form-correctness)
- [Parity](#parity)
- [Performance discipline](#performance-discipline)
- [Behavior levers](#behavior-levers)

## Scope

`src/native_engine/` is the real in-process Rust Whisper implementation. It is not a thin
wrapper around Homebrew `whisper-cli`.

## Decode stack

The engine owns GGML parsing, log-mel frontend, BPE tokenization, encoder/decoder
transformers, greedy and beam paths, whisper.cpp timestamp rules, and cross-attention DTW
word timestamps. Matmuls route through FrankenTorch path dependencies.

## Routing

Native execution is default. Inspect backend result provenance and native encoder route
before saying CPU, Metal, fused GPU, or bridge. `FRANKEN_WHISPER_NATIVE_EXECUTION=0` requests
bridge-first execution, but default-on `FRANKEN_WHISPER_BRIDGE_NATIVE_RECOVERY` can still
recover a failed bridge through native and report `bridge_only_native_recovery`. A forced
bridge/incumbent or route-isolation probe must set both variables false and then assert
result provenance:

```bash
FRANKEN_WHISPER_NATIVE_EXECUTION=0 FRANKEN_WHISPER_BRIDGE_NATIVE_RECOVERY=0 \
  fw transcribe --input audio.wav --backend whisper-cpp --no-diarize --no-persist --json
```

Then assert report provenance. Change the explicit backend only when comparing another named
incumbent; disabling native-first without disabling recovery is not route isolation.

## Long-form correctness

Failed windows that close without output now surface as structured `dropped_windows`,
warnings, evidence, and robot stage events. Prompt-reset retry is default-on and can be
disabled with false values of `FW_RETRY_FAILED_WINDOW`.

This does not prove all long-form tails are complete. `bd-r0qd` remains open for final-window
early termination. For important audio:

1. inspect structured dropped-window records;
2. compare transcript temporal coverage with audio duration;
3. use diarization/VAD as independent voiced-coverage evidence;
4. create overlapping sub-window probes when a region is suspect;
5. label unresolved gaps in downstream artifacts.

## Parity

Always pin model hash, audio hash, language, timestamps, beam size/best-of, temperature,
thread count, and preprocessing. Greedy and beam may differ in punctuation at zero WER;
byte equality between them is not a valid universal gate. Replace a defective gate only
with an explicit evidence-backed admitted/rejected split.

## Performance discipline

A self-speedup is maintenance, not a competitive win. A win requires the incumbent live in
the same invocation, matched decode parameters, transcript equivalence, a quiet/admissible
host, and preserved raw artifacts. Current Apple Silicon fused encoder work is promising but
the tracked quiet-host incumbent row remains undecidable.

## Behavior levers

`FW_*`/`FRANKEN_WHISPER_*` flags are often `OnceLock`-cached. Read their initialization and
the relevant `docs/NEGATIVE_EVIDENCE.md` / `docs/PERF_LEDGER.md` row before changing or
claiming defaults. `FW_TEMP_FALLBACK` changes decode behavior and is not a casual recovery
toggle.
