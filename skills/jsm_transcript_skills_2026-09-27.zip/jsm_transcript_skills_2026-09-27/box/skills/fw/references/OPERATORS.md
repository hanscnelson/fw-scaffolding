# fw Expert Operators

## Table of Contents

- [How to use operators](#how-to-use-operators)
- [Recommended stacks](#recommended-stacks)
- [OP-LC: Live Contract Probe](#op-lc-live-contract-probe)
- [OP-IH: Input Handshake](#op-ih-input-handshake)
- [OP-RP: Robot Purity](#op-rp-robot-purity)
- [OP-MD: Model and Package Discovery](#op-md-model-and-package-discovery)
- [OP-SQ: Stale Binary Quarantine](#op-sq-stale-binary-quarantine)
- [OP-DR: Doctor Proof Boundary](#op-dr-doctor-proof-boundary)
- [OP-DN: Denoiser Liveness](#op-dn-denoiser-liveness)
- [OP-LF: Long-Form Completeness](#op-lf-long-form-completeness)
- [OP-DI: Diarization Evidence](#op-di-diarization-evidence)
- [OP-CC: Cancellation and Stage Budgets](#op-cc-cancellation-and-stage-budgets)
- [OP-RS: Run Store and Sync](#op-rs-run-store-and-sync)
- [OP-VG: Verification Gate Reality](#op-vg-verification-gate-reality)
- [OP-SG: Release Ship Gate](#op-sg-release-ship-gate)
- [OP-PG: Performance and Parity Guard](#op-pg-performance-and-parity-guard)
- [OP-TI: Tracker-Informed Claim](#op-ti-tracker-informed-claim)

## How to use operators

Each operator is a reusable decision unit. Activate it only when a trigger matches. Execute
the action, preserve the named evidence, and check the failure modes before declaring an
outcome. Canonical tags make handoffs auditable.

## Recommended stacks

| Incident | Stack |
|---|---|
| CLI/docs mismatch | `LC -> IH -> SQ -> VG` |
| Agent event integration | `LC -> RP -> VG` |
| Install/model failure | `LC -> MD -> DR -> VG` |
| Browser cleanup stall | `SQ -> DN -> VG` |
| Long-form speaker gap | `LF -> DI -> VG` |
| Source change | `LC -> VG` |
| Release | `LC -> MD -> SG -> VG` |
| Performance/parity | `LC -> PG -> VG` |

Use the first operator only to establish the next required evidence; do not execute every
probe when an earlier one resolves the request.

## OP-LC: Live Contract Probe

**Definition:** establish the exact executable grammar before prescribing commands.

**When-to-use triggers:** CLI question, bug report, docs/site example, package upgrade,
“flag not recognized,” or source/install disagreement.

**Action:** resolve binary path/version; inspect top-level and nested help; run a bounded
valid and invalid invocation; compare to `src/cli.rs` when developing.

**Failure modes:** testing another binary on PATH; treating README as parser truth; copying
an old example; accepting a compatibility shim as the first fix.

**Prompt module:** “Probe the exact `fw` binary and nested command help. Report path, version,
accepted grammar, invalid legacy form, and whether source/release/install agree.”

**Tag:** `FW.OP-LC`

## OP-IH: Input Handshake

**Definition:** choose exactly one audio input boundary.

**When-to-use triggers:** transcription command construction, `FW-INVALID-REQUEST`, stdin/mic work.

**Action:** select one of `--input FILE`, `--stdin`, or `--mic`; validate exclusivity before
starting model work. Semantic exclusivity failures occur after Clap parsing and return exit 1;
exit 2 is pre-dispatch syntax/value rejection.

**Failure modes:** positional filename; two input modes; reading a binary stream as a path;
retrying an invalid request unchanged.

**Prompt module:** “Select exactly one input mode and prove the current help accepts it.”

**Tag:** `FW.OP-IH`

## OP-RP: Robot Purity

**Definition:** preserve line-oriented, machine-only stdout and exact terminal semantics.

**When-to-use triggers:** agent integration, pipes, event parser, schema change, parse error.

**Action:** use `fw robot run`; parse each stdout line; branch on schema/event/error code;
keep stderr separate; verify terminal event and exit code.

**Failure modes:** root `--robot`; one-document parser; decorations on stdout; ignoring exit
130; assuming fixed line order beyond the schema.

**Prompt module:** “Treat stdout as NDJSON, validate every line, and preserve terminal event,
exit status, stderr, and unknown additive fields.”

**Tag:** `FW.OP-RP`

## OP-MD: Model and Package Discovery

**Definition:** separate local registry, static health, network pull, and real inference.

**When-to-use triggers:** missing artifact, new machine, slow doctor, model mismatch.

**Action:** start with cheap `capabilities --json`; use `robot triage` only when model/backend
diagnosis justifies hashing the packages; inspect `models --json` only when detail is needed;
run a named `pull --json` if absent; then refresh `doctor` and run a bounded model-backed probe.

**Failure modes:** conflating download-free native inference with external backends that may
fetch their own models; claiming `pull all` installs ECAPA or FastEnhancer; calling hash scans
hangs; treating presence or an operator model path as authentication/certification.

**Prompt module:** “Report registry state, authenticated package, network action, doctor
authority, and real runtime proof as separate rows.”

**Tag:** `FW.OP-MD`

## OP-SQ: Stale Binary Quarantine

**Definition:** prevent facts from one revision being attached to another surface.

**When-to-use triggers:** help/source disagreement, website warning after a fix, package lag.

**Action:** record executable path/version/hash, source HEAD, release tag/target/assets,
formula version, served asset revision, and cache state; identify the stale layer.

**Failure modes:** reinstalling blindly; testing source and claiming Homebrew fixed; blaming
current production worker for an excluded demo file.

**Prompt module:** “Build a source/release/install/served/cache matrix and quarantine claims
to the row actually tested.”

**Tag:** `FW.OP-SQ`

## OP-DR: Doctor Proof Boundary

**Definition:** keep static preflight readiness below operational verification.

**When-to-use triggers:** green doctor output, release readiness, “is it working?”

**Action:** inspect `runtime_probe_performed`, `operationally_verified`, and
`readiness_authority`; the current value is `static_preflight_not_transcription_proof`.
Run a real audio probe for runtime claims.

**Failure modes:** treating `ready=true` as successful ASR/diarization; hiding missing runtime
proof behind `--strict`.

**Prompt module:** “Quote doctor authority fields, then run or explicitly decline the
model-backed probe required for the requested claim.”

**Tag:** `FW.OP-DR`

## OP-DN: Denoiser Liveness

**Definition:** distinguish slow bounded enhancement, stale browser assets, OOM, and a true
no-progress stall.

**When-to-use triggers:** “cleaning up audio” stuck, no heartbeat, wasm warning, worker death.

**Action:** capture last stage and heartbeat; apply the browser 180-second watchdog boundary;
verify served initializer; retry with browser cleanup off; use `FW_DENOISE=0` only for direct
evaluation-only native `sortformer-diarize`; compare raw.

**Failure modes:** waiting indefinitely; assuming progress once means completion; treating
hard worker termination as cooperative cancellation; forgetting `pull all` lacks denoiser;
claiming ordinary native transcription traverses the denoiser wrapper.

**Prompt module:** “Classify heartbeat, cache revision, memory signal, watchdog outcome, and
cleanup-off result before assigning root cause.”

**Tag:** `FW.OP-DN`

## OP-LF: Long-Form Completeness

**Definition:** prove that important audio was not silently omitted.

**When-to-use triggers:** long call/video, timeline gaps, truncated ending, dropped-window event.

**Action:** inspect structured drops/warnings/events, transcript duration coverage, VAD/energy
and diarization over gaps; probe overlapping short slices; preserve explicit gap markers.

**Failure modes:** equating silence gap with dropped speech; assuming default retry always
recovers; one same-geometry reslice; hiding gaps in cleaned output.

**Prompt module:** “Audit temporal completeness with structured ASR evidence plus independent
voiced evidence and label every unresolved interval.”

**Tag:** `FW.OP-LF`

## OP-DI: Diarization Evidence

**Definition:** turn diarization output into bounded cluster evidence without inventing identity.

**When-to-use triggers:** speaker labels, participant count, DER claim, fallback routing.

**Action:** record requested/actual engine, artifact, lane cap, fallback, coverage/confidence,
oracle metric, and independent identity mapping.

**Failure modes:** naming `SPEAKER_00`; ignoring four-lane cap; treating sparse segment labels
as no turns; calling development-uncertified production-certified.

**Prompt module:** “Separate turn clustering, cluster quality, and real-world identity into
three independently evidenced claims.”

**Tag:** `FW.OP-DI`

## OP-CC: Cancellation and Stage Budgets

**Definition:** keep work bounded and cancellation-correct across kernels, stages, and processes.

**When-to-use triggers:** timeout, Ctrl-C, long audio, embedding, subprocess bridge.

**Action:** identify the active boundary, size CLI environment budgets from measured wall time,
use request `timeout_ms` where public, terminate child trees, preserve `FW-CANCELLED`/130,
and document that current engine cancellation is not independently scoped per request.

**Failure modes:** one global huge timeout; detached worker; cancellation mapped to empty success;
claiming native FastEnhancer stops mid-chunk.

**Prompt module:** “Trace cancellation from caller through the active stage and subprocess or
kernel boundary; report the longest non-interruptible region.”

**Tag:** `FW.OP-CC`

## OP-RS: Run Store and Sync

**Definition:** preserve durable state and auditable one-way exchange.

**When-to-use triggers:** `runs`, JSONL export/import, DB busy, recovery, privacy.

**Action:** resolve state root, inspect SQLite run, export under lock atomically, verify
checksums, resolve the exact import target, obtain mutation authority, back up/export, import
with explicit conflict policy, and validate post-import.

**Failure modes:** treating import as read-only; using overwrite-strict without recognizing
replacement/pruning; two-way magic merge; copying a live DB; ignoring disk full/busy;
assuming raw speaker vectors persist; importing without validation.

**Prompt module:** “Name the authoritative store, direction, lock, conflict policy, checksum,
and post-import validation.”

**Tag:** `FW.OP-RS`

## OP-VG: Verification Gate Reality

**Definition:** match each claim to the strongest gate actually completed.

**When-to-use triggers:** handoff, CI, skipped tests, gate repair, release decision.

**Action:** classify static/focused/model/E2E/release/perf proof; record exact commands,
artifacts, exits, skips, and blockers.

**Failure modes:** proof-class inflation; gate weakening; golden regeneration reflex;
simulator/local proxy promoted to hardware or release proof.

**Prompt module:** “For every claim, name the gate, artifact, provenance, outcome, and what it
does not prove.”

**Tag:** `FW.OP-VG`

## OP-SG: Release Ship Gate

**Definition:** establish that source, tag, assets, installers, package managers, docs, and
installed behavior are one coherent release.

**When-to-use triggers:** cut release, update Brew, platform support, shipped-fix claim.

**Action:** verify clean target commit/version and current release authority; run gates; use
the canonical DSR path when current source names it; publish checksummed platform assets and
signatures only when the release contract actually provides them; update formula; install
from distribution; pull packages; run real smoke.

**Failure modes:** publishing without explicit authority; tag without assets; formula pointing
at wrong hashes; inventing a signature claim; testing local build; docs ahead of release;
claiming every platform from one host.

**Prompt module:** “Produce a release matrix for target commit, asset/hash, installer/formula,
installed version, model pull, and platform smoke.”

**Tag:** `FW.OP-SG`

## OP-PG: Performance and Parity Guard

**Definition:** admit only matched, quality-preserving comparisons.

**When-to-use triggers:** speedup, regression, GPU claim, native versus whisper.cpp.

**Action:** run candidate and incumbent in the same invocation with identical model/audio and
decode parameters; disable default-on bridge-to-native recovery when a forced bridge is
required; verify route and output; enforce host quiescence; retain raw samples.

**Failure modes:** self-speedup as win; greedy versus beam; different preprocessing; stale
incumbent; bench-path hardcoding; averaging an undecidable host into a claim.

**Prompt module:** “Report matched parameters and transcript equivalence on every row; if the
incumbent is absent or host inadmissible, label the result maintenance or undecidable.”

**Tag:** `FW.OP-PG`

## OP-TI: Tracker-Informed Claim

**Definition:** use refreshed Beads as scoped context, not runtime authority.

**When-to-use triggers:** open gap, closed fix, roadmap, owner handoff.

**Action:** refresh JSONL, show the bead, read comments/close reason, verify source/tests, and
state residual scope.

**Failure modes:** stale description over later close reason; status as capability; closing
without named probe; scope-splitting or close pumping.

**Prompt module:** “Cite current bead status and close evidence, then independently verify the
code/runtime boundary before making the capability claim.”

**Tag:** `FW.OP-TI`
