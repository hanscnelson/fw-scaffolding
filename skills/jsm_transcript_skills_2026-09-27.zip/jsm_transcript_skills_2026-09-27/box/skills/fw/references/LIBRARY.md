# franken_whisper Library Integration

## Table of Contents

- [Public shape](#public-shape)
- [Integration sequence](#integration-sequence)
- [Cancellation](#cancellation)
- [Results and provenance](#results-and-provenance)
- [Embedding checklist](#embedding-checklist)
- [Anti-patterns](#anti-patterns)

## Public shape

`src/lib.rs` exports the main contract:

- `FwError`, `FwResult`;
- `BackendKind`, `RunReport`, `TranscribeRequest`, `TranscriptionResult`;
- `FrankenWhisperEngine`, `PipelineBuilder`, `PipelineConfig`, `PipelineStage`.

Read the current type definitions before coding; this skill intentionally avoids freezing
method signatures that are cheaper to verify from source.

## Integration sequence

1. Resolve and authenticate model artifacts before accepting work.
2. Construct a `PipelineConfig`/`PipelineBuilder` with explicit policy.
3. Reuse a long-lived engine where the current API permits it.
4. Set the request's current `timeout_ms` boundary when appropriate.
5. Submit a `TranscribeRequest` with one input source.
6. Consume `RunReport` and structured result fields.
7. Persist or export only after successful validation.

## Cancellation

Cancellation is a correctness property, not an error-string convention. The current public
engine methods accept `TranscribeRequest` and do not accept an independently scoped caller
token. The request exposes `timeout_ms`; CLI shutdown is process-global through its shutdown
controller; stage budgets are private and environment-derived. Preserve `FwError::Cancelled`
inside project changes, terminate subprocess trees, and do not advertise per-request
cancellation isolation until the public API actually exposes it.

## Results and provenance

Use structured fields for transcript, segments, warnings, diarization, raw backend output,
routing, and stage evidence. Do not scrape tracing logs. Inspect engine/route provenance
before making native/GPU/bridge claims. Treat dropped-window records as an explicit
incompleteness signal.

## Embedding checklist

- Artifact root is explicit and absolute where overridden.
- Input lifetime and temporary files are owned.
- Stage budgets match target audio duration and hardware.
- Cancellation is tested during normalization, inference, and subprocess execution.
- Tokens are redacted, but `RunReport`, robot streams, stderr, run DBs, JSONL, and YouTube
  artifacts can contain content or DB/input/normalized paths; redact before publication.
- Persistence policy is explicit.
- Output schema changes are additive or deliberately versioned.
- Model-backed tests fail visibly when their artifact is required.

## Anti-patterns

- Shelling out to `fw` from Rust when the public library fits.
- Calling bridge subprocesses directly and bypassing cancellation/provenance.
- Treating `RunReport.warnings` as decorative.
- Reusing a request with two input modes.
- Converting cancellation into an empty transcript.
- Assuming diarization turn labels are names.
