# fw CLI Reference

## Table of Contents

- [Contract](#contract)
- [Binary selection](#binary-selection)
- [Commands](#commands)
- [Output contracts](#output-contracts)
- [Transcribe](#transcribe)
- [Models and health](#models-and-health)
- [Run state and sync](#run-state-and-sync)
- [YouTube and TTY](#youtube-and-tty)
- [Exit codes](#exit-codes)
- [Validation](#validation)

## Contract

The CLI contract lives in `src/cli.rs`; parsing and dispatch live in `src/main.rs`.
Probe the exact installed binary because release, source, website, and package manager can
be on different revisions.

## Binary selection

Both `fw` and `franken_whisper` are installed by the current Homebrew formula. Prefer `fw`
in examples, but record the resolved path and version in incident evidence.

```bash
type -a fw
command -v fw
fw --version
```

## Commands

Current 0.9.2 command families:

| Command | Purpose |
|---|---|
| `transcribe` | file, stdin, or microphone transcription |
| `robot` (`agent`) | NDJSON run and machine discovery |
| `runs` | persisted-run list/detail inspection |
| `sync` | SQLite/JSONL audit exchange |
| `tty-audio` (`tty`) | low-bandwidth terminal streaming |
| `diarization-*` | evaluation, corpus, and oracle tooling |
| `sortformer-diarize` (`sortformer`) | direct diarization path |
| `tui` | human terminal UI |
| `youtube` | yt-dlp orchestration and transcript artifacts |
| `capabilities`, `models`, `pull`, `doctor` | discovery and setup |
| `robot-docs` | machine-integration guide |

Always verify the nested help before using a flag.

## Output contracts

| Surface | Stdout contract | Failure contract |
|---|---|---|
| `transcribe --json` | one JSON `RunReport` on success | may be empty; human diagnostics on stderr + exit 1 |
| `robot run` | NDJSON events | structured `run_error` + nonzero exit |
| `robot triage/schema/backends/health` | one JSON document | inspect structured payload and exit |
| `robot routing-history` | NDJSON | nonzero exit + diagnostics/error surface |
| `runs --format json` | one JSON array on success | nonzero exit; do not assume structured failure |
| `runs --format ndjson` | one JSON object per listed run | nonzero exit; do not assume structured failure |
| `youtube --json-summary` | one terminal summary on success | may fail before a JSON summary exists |
| `sortformer-diarize` | one terminal JSON object; evaluation-only | nonzero exit + diagnostics |

Use `fw robot run` when automation requires structured failures as well as structured
success. For all other structured-result flags, check the child exit before parsing stdout.
Never publish raw stdout/stderr: reports and streams can contain input, normalized, database,
or artifact paths plus transcript and speaker-hint content.

## Transcribe

Exactly one input mode is required:

```bash
fw transcribe --input audio.m4a --no-persist --json
producer | fw transcribe --stdin --no-persist --json
fw transcribe --mic --no-persist --json
```

The filename is not positional. `--diarize` is currently redundant because diarization is
on by default; `--no-diarize` disables it.

Useful boundaries:

- `--json` emits one terminal JSON document on success. Parsed semantic request failures
  return exit 1 and can leave stdout empty with human diagnostics on stderr.
- `--no-persist` avoids durable run-state writes.
- `--backend` requests a backend route, but inspect raw provenance before claiming which
  engine actually ran.
- `--diarization-engine` currently accepts `auto`, `sortformer`, `acoustic`, `external`,
  `ecapa`, and `ecapa-fused`.
- Speaker count hints constrain lanes; they do not identify people.

## Models and health

```bash
fw pull all --json
fw pull whisper --json
fw pull sortformer --json
fw models --json
fw capabilities --json
fw doctor --json
fw doctor --json --strict
fw robot triage
```

`models` is local registry/package state. `capabilities` is a machine-readable contract.
`doctor` is static preflight unless its output explicitly says a runtime probe ran. Model
discovery/doctor/triage can hash roughly 2.1 GB; do not run all three reflexively.

## Run state and sync

```bash
fw runs --format json
fw runs --format ndjson --limit 100
fw runs --id RUN_ID --format json
fw sync export-jsonl --output ./audit
```

`runs` is one option-based command, not a `list`/`show`/`export` subcommand family.
`fw runs --id RUN_ID` is valid transcript-only output; add `--format json` for full details.
Current sync conflict policies are `reject`, `overwrite`, `overwrite-strict`, and `skip`.
Opening a missing `--db` path can create its parent/database/schema. Import mutates the target
database; overwrite policies can replace rows, and `overwrite-strict` can prune rows absent
from the snapshot. Resolve the exact target, obtain mutation authority, and export/backup
first. Then, if authorized:

```bash
fw sync import-jsonl --input ./audit --conflict-policy reject
```

Validate afterward. SQLite is authoritative; JSONL is for audit/recovery.

## YouTube and TTY

```bash
fw youtube URL --output-dir ./youtube_transcripts
fw youtube --url URL --json-summary
fw tty-audio --help
fw tty-audio encode --help
fw tty-audio decode --help
```

`yt-dlp` is external and controlled by `FRANKEN_WHISPER_YTDLP_BIN`. Current YouTube
machine output is a terminal summary, not the proposed per-video robot event stream.
`--no-keep-audio` deletes downloaded media and requires explicit deletion authority.

## Exit codes

| Code | Meaning |
|---|---|
| 0 | success |
| 1 | parsed request failed, including semantic invalid-request errors |
| 2 | Clap rejected syntax or a value before command dispatch |
| 130 | interrupted/cancelled by signal |

Machine errors carry stable codes such as `FW-INVALID-REQUEST`, `FW-MISSING-ARTIFACT`,
`FW-CANCELLED`, `FW-STAGE-TIMEOUT`, `FW-CMD-MISSING`, and `FW-BACKEND-UNAVAILABLE`.
Exactly-one-input validation occurs after parsing and therefore returns 1, not 2. Robot mode
emits structured error events; terminal `transcribe --json` errors are not guaranteed JSON.

## Validation

For docs or website changes, test the exact copied examples against the built/current
binary. A green Rust unit test that only compares strings does not replace an invocation.
