# Beads and BV Reality for franken_whisper

## Table of Contents

- [Purpose](#purpose)
- [Refresh commands](#refresh-commands)
- [Current signals](#current-signals)
- [Evidence pattern](#evidence-pattern)
- [Caution patterns](#caution-patterns)

## Purpose

The tracker provides current work intent and preserved evidence; it does not outrank source,
runtime, or release artifacts. Refresh before citing any status.

## Refresh commands

```bash
br sync --import-only
br list --json
br list --status closed --json
br dep cycles
bv --robot-triage
```

Only the graph writer should modify dependency structure. Use `br`, never bare `bv`.

## Current signals

Verified 2026-08-13; recheck before use:

| Bead | State | Boundary |
|---|---|---|
| `bd-z6kz` | closed | browser/direct-wrapper FastEnhancer evidence; source caller census limits ordinary native reachability |
| `bd-longform-window-drop-silent-nqzf` | closed | dropped windows now structured and visible |
| `bd-r0qd` | open | final-window/tail completeness remains a risk |
| `bd-453z` | open | Apple Silicon quiet-host incumbent ratio still undecidable |
| `bd-i92d` | in progress | beam/greedy/reference punctuation contract |
| `bd-27v1.1` | open | YouTube per-video robot NDJSON proposed, not current |
| `bd-m2jm` | open | broader browser/WASM port work remains |

The live registry also labels native acoustic and Sortformer diarization as uncertified.

## Evidence pattern

For a tracker-informed claim, cite the issue id, current status, source/test paths, exact
runtime artifact, and residual boundary. Closed means the acceptance claim was recorded; it
does not prove every adjacent capability.

## Caution patterns

- Do not repeat old bead descriptions after a later close reason supersedes them.
- Do not convert “in progress” into capability.
- Do not close a blocker until its named probe ran.
- Do not split scope to manufacture completion.
- Do not edit specs/gates to make an implementation look conformant.
- Keep `br dep cycles` empty.
