# Development Reference

## Table of Contents

- [Orientation](#orientation)
- [Source truth probes](#source-truth-probes)
- [Editing discipline](#editing-discipline)
- [Quality gates](#quality-gates)
- [Shared-tree discipline](#shared-tree-discipline)
- [Commit and handoff](#commit-and-handoff)

## Orientation

Read the repository `AGENTS.md`, complete README, and suite `AGENTS.md` when present at the
checkout parent, `/data/projects`, or `/dp`. The project is Rust 2024 on pinned nightly. Crate-level
`deny(unsafe_code)` rejects unannotated unsafe, while audited native kernels use scoped
`allow(unsafe_code)`; this is not an unsafe-free codebase. The governing prose still states
`forbid`, so do not add or broaden unsafe without an explicit policy decision.

For port work, follow the mandated order:

1. `PLAN_TO_PORT_WHISPER_STACK_TO_RUST.md`
2. `EXISTING_LEGACY_WHISPER_STRUCTURE.md`
3. `PROPOSED_ARCHITECTURE.md`
4. `FEATURE_PARITY.md`

## Source truth probes

```bash
git log --oneline -10
rg -n "enum Command|struct TranscribeArgs" src/cli.rs
rg -n "pub struct FrankenWhisperEngine|pub struct PipelineBuilder" src/orchestrator.rs
rg -n "get_or_init|DEFAULT_ON" src/native_engine src/backend src/denoise.rs
fw --version
fw capabilities --json
```

Use `fw robot triage` only when model/backend diagnosis justifies hashing large packages.

## Editing discipline

- Revise existing files for existing functionality.
- Do not use scripts or regex rewrites to modify source.
- Never delete a file without exact written permission and the required reconfirmation.
- Keep robot schemas stable, deterministic, line-oriented, and decoration-free.
- Add happy, edge, and error tests near each changed module.
- Preserve cancellation, secret redaction, and artifact authentication.

## Quality gates

After substantive code changes, run via RCH when available:

```bash
cargo fmt --check
rch exec -- cargo check --all-targets
rch exec -- cargo clippy --all-targets -- -D warnings
rch exec -- cargo test
ubs path/to/changed.rs
```

Focused/model-backed proof comes before broad gates. A skipped test is not a pass for the
capability it skipped.

## Shared-tree discipline

Peer changes are expected. Never stash, reset, revert, overwrite, or broadly stage them.
Reserve exact paths through Agent Mail where available. Stage exact pathspecs, inspect the
cached diff, and inspect the resulting commit.

For Beads, use `br` CRUD and only robot variants of `bv`. JSONL is truth; keep dependency
cycles empty and close only on cited evidence. Run `br sync --flush-only` before a handoff
that changed tracker state.

## Commit and handoff

Report changed paths, focused and full gates, model/artifact provenance, skipped gates,
remaining risks, and exact next probes. `main` is primary; do not describe `master` as the
primary branch. When release instructions require mirroring, push `main` first and then
`main:master`. Push only when the user's task and repository workflow authorize it.
