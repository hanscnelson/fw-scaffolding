# Verification Reference

## Table of Contents

- [Proof ladder](#proof-ladder)
- [Default gates](#default-gates)
- [CLI and robot contract](#cli-and-robot-contract)
- [Model-backed proof](#model-backed-proof)
- [Long-form and diarization proof](#long-form-and-diarization-proof)
- [Release workflow](#release-workflow)
- [Release proof](#release-proof)
- [Performance proof](#performance-proof)
- [Blocked gates](#blocked-gates)

## Proof ladder

1. Static source/config evidence.
2. Focused unit or contract test.
3. Built binary help/usage probe.
4. Authenticated model-backed runtime.
5. End-to-end artifact/output validation.
6. Installed release/platform smoke.
7. Matched incumbent performance or external quality oracle.

State the highest rung actually reached.
Routine answers need outcome, exact command, and persistence choice. Diagnostic/release/perf
handoffs also name revision/artifacts, output contract, proof rung, residual gap, and next probe.

## Default gates

```bash
cargo fmt --check
rch exec -- cargo check --all-targets
rch exec -- cargo clippy --all-targets -- -D warnings
rch exec -- cargo test
ubs path/to/changed.rs
```

Do not weaken a test to land a change. A legitimate defective-gate repair must preserve
the old behavior split, cite evidence, and report what the new gate admits and rejects.

## CLI and robot contract

Test correct and incorrect invocations, stdout/stderr separation, JSON and NDJSON parsing,
exit codes 0/1/2/130, schema version, event order, terminal cardinality, and path/secret
redaction. Website examples should execute against the actual CLI grammar.

## Model-backed proof

Record binary hash/version, model/package digest, audio hash/duration, backend/route,
parameters, output artifact, and exit status. Fail closed if the required model is missing;
do not count an ignored or early-returning test as proof.

## Long-form and diarization proof

For long audio, inspect transcript coverage, structured dropped windows, warnings, and
voiced evidence over gaps. For diarization, record engine, package digest, lane cap, turn
coverage, confidence, DER/JER oracle when applicable, and identity mapping evidence.

## Release workflow

Current source declares DSR the canonical release authority; `.github/workflows/dist.yml` is
the manually dispatched fail-closed fallback. Recheck those files because release authority
can change. Publication is an external mutation: do not run `dsr release`, dispatch `dist`,
create/push a tag, or update Homebrew without explicit release authorization.

Preflight without publishing:

```bash
git status --short --branch
git log --oneline -10
scripts/prepare_release_siblings.sh --verify-only
cargo fmt --check
rch exec -- cargo check --all-targets
rch exec -- cargo clippy --all-targets -- -D warnings
rch exec -- cargo test
```

Verify that `Cargo.toml`, CLI version, changelog/release notes, target commit, privacy gate,
and all promised platform targets agree. The current canonical publish form is
`dsr release franken_whisper vX.Y.Z`; treat it as a mutation, not a probe. If repository
release instructions require branch mirroring, push `main` first and then `main:master`—never
write `master` as the primary branch.

After authorized publication, verify the release object/target, five advertised platform
archives, aggregate and per-asset checksums, optional signatures only if actually emitted,
Homebrew formula version/hash, installed binary path/version, model pull, doctor authority,
and a real audio smoke from the distributed binary. A failed Homebrew notification is not
hidden by a successful GitHub release; surface and repair the distribution row separately.

## Release proof

Verify tag and target commit, non-draft/non-prerelease state, every advertised platform
asset/checksum, any claimed signature, installed binary version, package-manager formula
values, model pull, doctor authority, and at least one model-backed smoke per claimed
platform. Build success alone does not prove the downloadable artifact.

## Performance proof

An admissible comparison requires:

- incumbent and candidate in the same invocation;
- exact model/audio hashes and matched decoding parameters;
- transcript equivalence or an explicit discrepancy classification;
- warmup/run count, raw samples, host/load/quiescence evidence;
- no bench-path hardcoding or hidden preprocessing difference.

Self-speedups are maintenance. An undecidable or losing row is a successful experiment and
must remain in the ledger.

## Blocked gates

When a required model, host, RCH worker, network, or hardware gate cannot run, report
PARTIAL/BLOCKED and preserve the exact error. Static or local proof cannot inherit the
stronger claim.
