# Research Notes for the fw Skill

## Table of Contents

- [Sources inspected](#sources-inspected)
- [Method](#method)
- [Ground-truth findings](#ground-truth-findings)
- [Historical evidence](#historical-evidence)
- [Design decisions](#design-decisions)
- [Known caveats](#known-caveats)
- [Update discipline](#update-discipline)

## Sources inspected

- Complete `franken_whisper/AGENTS.md` and README (5,252 lines at research time).
- Current source CLI, dispatcher, robot, orchestrator, native engine, backends, audio,
  denoise, model distribution, persistence/sync, YouTube, WASM, and site files.
- Live Homebrew `fw` 0.9.2 help and machine outputs.
- GitHub `v0.9.2` release object/assets and Homebrew formula.
- Current open/closed Beads, evidence ledgers, and focused tests.
- CASS searches for CLI, robot, error, and FastEnhancer history.
- FOCR skill structure plus `$sc`, `$sw`, and `$operationalizing-expertise` workflows.
- Adjacent meeting and YouTube transcription skills as historical operator input.
- Independent read-only architecture-agent investigation.

The source repository also contains the creation-time pack
`COMPREHENSIVE_BACKGROUND_RESEARCH_FOR_CREATING_THE_FW_CC_SKILL.md`. It is provenance only
and is not shipped in deployed skill directories; this reference contains the operational
conclusions needed by deployed agents.

## Method

Building this skill required research before synthesis. Claims were triangulated
across live help/output, current source/tests, release/package state, and tracker evidence.
Operationalizing-expertise converted recurring decisions into trigger/action/failure-mode
cards. The sw framework supplied routing, references, self-tests, metadata, and a
staleness validator.

## Ground-truth findings

- Input is flag-based and exclusive: `--input`, `--stdin`, or `--mic`.
- Robot mode is a subcommand and emits NDJSON.
- Diarization defaults on but current native registries remain uncertified.
- `doctor` is static/detect-only and explicitly disclaims runtime verification.
- Native inference, `models`, and `doctor` do not download native packages; only `pull`
  provisions the pinned native model packages. Explicit external backends can fetch their own
  models, YouTube fetches media, and Linux ffmpeg auto-provision is a separate network path.
- `pull all` covers Whisper and Sortformer, not ECAPA or FastEnhancer.
- FastEnhancer browser liveness is heartbeat plus a 180-second watchdog. The native wrapper
  is used by direct `sortformer-diarize`, but current ordinary native transcription backends
  bypass it; native chunk compute is not cancellable inside a denoise call.
- Structured dropped-window visibility is fixed, while final-tail completeness remains open.
- Current production wasm initialization is object-form; an old no-argument form remains
  only in an excluded demo worker.
- Final live probes on the installed 0.9.2 binary completed the JFK fixture as both terminal
  JSON and robot NDJSON. The robot run produced 21 independently valid lines with one start,
  19 stages, one completion, and diagnostics kept on stderr.
- Probing `fw runs --help` corrected an inherited assumption: current `runs` is option-based,
  not a nested subcommand family. The custom validator now rejects that stale shape.
- Fresh caller-census review also corrected native denoiser reachability, public cancellation
  scope, TTY input boundaries, unsafe-code policy, robot path sensitivity, and Linux ffmpeg
  auto-provision. These source-level corrections outrank closed-bead/README wording.
- Terminal `transcribe --json`/YouTube summary formats are success-result surfaces, not
  structured-error promises; robot mode is the stable structured-failure surface.
- Explicit model paths and bridge-binary overrides are operator trust boundaries, and
  `FRANKEN_WHISPER_NATIVE_EXECUTION=0` alone does not forbid default-on native recovery.

## Historical evidence

CASS was stale and yielded weak actionable results. Adjacent skills documented real prior
failures, but some advice was superseded by source changes. Beads close reasons were valuable
for the FastEnhancer ship/follow-up and long-form visibility fix. Current executable/source
evidence outranks all of these.

## Design decisions

- Closely mirror FOCR's entrypoint sequence and reference taxonomy.
- Keep frequently changing flags out of copied prose where live help is cheaper.
- Give browser/WASM/denoise and diarization dedicated references because their proof and
  recovery boundaries differ from core ASR.
- Encode current open gaps in a dated boundary card and Beads reference, not as timeless
  product identity.
- Use a custom validator to reject the exact public stale-command forms and common proof
  inflation.

## Known caveats

- Release/version, Beads state, model status, and environment flags drift quickly.
- The project README contains some stale counts/error-code descriptions relative to source.
- Broader WASM work and YouTube per-video robot events remain open at research time.
- No new model-backed transcription or browser execution was needed to write the skill; the
  skill reports existing current runtime evidence and commands for refreshing it.

## Update discipline

On refresh, rerun live help and machine discovery, inspect source tests, query release/formula,
refresh Beads, and rerun the validators. Update the dated boundary card and research record;
never just bump version strings.
