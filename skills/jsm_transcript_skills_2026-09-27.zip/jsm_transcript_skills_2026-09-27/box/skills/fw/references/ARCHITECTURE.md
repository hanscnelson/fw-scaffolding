# franken_whisper Architecture

## Table of Contents

- [Mission](#mission)
- [Data flow](#data-flow)
- [Module map](#module-map)
- [Engine and backend boundary](#engine-and-backend-boundary)
- [Cancellation and persistence](#cancellation-and-persistence)
- [Truth boundaries](#truth-boundaries)

## Mission

The project combines local Whisper transcription, diarization, alignment, streaming,
durable state, and robot output in a Rust library and CLI with audited, locally scoped unsafe
native-kernel boundaries.

## Data flow

```text
input (file/stdin/mic; YouTube materializes a file)
  -> ingest and normalize (16 kHz mono)
  -> probe/VAD/source-separate policy
  -> backend routing and Whisper decode
  -> alignment/punctuation/diarization
  -> RunReport + events
  -> optional SQLite persistence / JSONL export
```

`tty-audio` is a separate encode/decode/control protocol, not a `TranscribeRequest` input.
The FastEnhancer wrapper is used by the browser and evaluation-only direct
`sortformer-diarize`; current ordinary native transcription backends bypass that wrapper.

Every stage is budgeted and must preserve cancellation. “Skipped,” “unavailable,”
“cancelled,” and “completed” are different outcomes.

## Module map

| Path | Responsibility |
|---|---|
| `src/cli.rs` | Clap grammar |
| `src/main.rs`, `src/bin/fw.rs` | parse, dispatch, process output |
| `src/orchestrator.rs` | pipeline, engine, budgets, cancellation |
| `src/model.rs` | public requests/results/reports |
| `src/backend/` | native and external backend adapters/routing |
| `src/native_engine/` | in-process Whisper implementation |
| `src/audio.rs` | decode/normalize/ffmpeg fallback |
| `src/denoise.rs` | FastEnhancer wrapper used by specific callers |
| `src/robot.rs` | machine schemas/events |
| `src/storage.rs`, `src/sync.rs` | SQLite run state and JSONL audit |
| `src/model_distribution.rs` | package manifest, cache, digest, locks |
| `src/sortformer_*` | diarization inference/conformance/evidence |
| `src/youtube/` | yt-dlp workflow |
| `src/tty_audio.rs`, `src/tui.rs` | terminal input/UI |
| `fw-wasm/`, `site/` | browser engine and playground |

## Engine and backend boundary

`FrankenWhisperEngine` is the reusable orchestration boundary. Native execution is the
default. Bridge executables (`whisper-cli`, `insanely-fast-whisper`, Python diarization,
ffmpeg/ffprobe, yt-dlp) are user-installed subprocesses with explicit environment overrides.
Provenance in the result decides which engine ran; command names do not.

## Cancellation and persistence

Cancellation flows through stage tokens and subprocess lifetime handling. Finalizers and
state commits must not turn cancellation into success. Persistence is default-on for CLI
runs unless `--no-persist`; SQLite is authoritative, with atomic one-direction JSONL sync.

## Truth boundaries

- A native module existing does not mean its route engaged.
- A package present does not certify quality.
- A pipeline stage event does not imply its semantic result is complete.
- A bridge discovered on PATH does not mean it was selected.
- A browser worker completing does not prove native CLI parity.
