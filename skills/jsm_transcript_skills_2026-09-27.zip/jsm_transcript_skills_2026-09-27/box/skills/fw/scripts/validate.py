#!/usr/bin/env python3
"""Validate the fw skill's structure, links, and high-risk product contracts."""

from __future__ import annotations

import argparse
import json
import re
import shlex
import shutil
import subprocess  # nosec B404 - optional live check runs an argv-only version probe
import sys
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKILL = ROOT / "SKILL.md"
SELF_TEST = ROOT / "SELF-TEST.md"
AGENT = ROOT / "agents" / "openai.yaml"
REFS = ROOT / "references"

REQUIRED_REFS = [
    "CLI.md",
    "ROBOT.md",
    "ARCHITECTURE.md",
    "LIBRARY.md",
    "ARTIFACTS-AND-ENV.md",
    "NATIVE-ENGINE.md",
    "DIARIZATION.md",
    "WASM-AND-DENOISE.md",
    "VERIFICATION.md",
    "DEVELOPMENT.md",
    "BEADS-REALITY.md",
    "TROUBLESHOOTING.md",
    "OPERATORS.md",
    "RESEARCH.md",
]

REQUIRED_BY_FILE = {
    "references/ARTIFACTS-AND-ENV.md": [
        "FRANKEN_WHISPER_AUTO_PROVISION_FFMPEG",
        "explicit external backends can download their own models",
        "operator trust",
        "terminal reports",
    ],
    "references/CLI.md": [
        "fw runs --format json",
        "structured failures",
        "Exactly-one-input validation occurs after parsing",
    ],
    "references/LIBRARY.md": ["timeout_ms"],
    "references/OPERATORS.md": ["FW.OP-LC", "FW.OP-PG"],
    "references/RESEARCH.md": ["success-result surfaces", "operator trust boundaries"],
    "references/ROBOT.md": [
        "jq -e . >/dev/null || exit 1",
        'test "${pipeline_status[0]}" -eq 0 && test "${pipeline_status[1]}" -eq 0',
    ],
    "SKILL.md": [
        "fw robot run --input",
        "fw transcribe --input",
        "success emits one document; failures may be stderr-only",
        "Clean up the audio first",
        "--no-persist",
        "development_uncertified",
        "jq -ce . || exit 1",
        'test "${pipeline_status[0]}" -eq 0 && test "${pipeline_status[1]}" -eq 0',
    ],
    "references/TROUBLESHOOTING.md": ["FW-STAGE-TIMEOUT", "FW-CANCELLED"],
    "references/VERIFICATION.md": ["dsr release franken_whisper", "path/to/changed.rs"],
    "references/WASM-AND-DENOISE.md": [
        "FW_DENOISE=0 fw sortformer-diarize --input",
        "evaluation-only",
    ],
}

FORBIDDEN_PROSE = [
    (r"doctor[^.\n]{0,100}(?:proves|certifies|guarantees)[^.\n]{0,100}(?:runtime|transcription|diarization)",
     "doctor is static preflight unless a separate runtime probe ran"),
    (r"fw pull all\s+(?:installs|downloads|provisions)[^.\n]{0,100}(?:ECAPA|FastEnhancer)",
     "pull all installs Whisper and Sortformer, not ECAPA or FastEnhancer"),
    (r"(?:all\s+)?(?:fw\s+)?(?:inference|commands?)[^.\n]{0,80}(?:never|do not|does not)\s+(?:use\s+the\s+)?network",
     "network claims must preserve external-backend, YouTube, and ffmpeg exceptions"),
]


def markdown_files() -> list[Path]:
    return [SKILL, SELF_TEST, *sorted(REFS.glob("*.md"))]


def fenced_shell_lines(text: str) -> list[tuple[str, bool]]:
    """Return shell commands with pipefail state scoped to their own fence."""
    lines: list[tuple[str, bool]] = []
    fence_marker = ""
    shell_fence = False
    has_pipefail = False
    pending = ""
    for raw in text.splitlines():
        stripped = raw.strip()
        marker = "```" if stripped.startswith("```") else "~~~" if stripped.startswith("~~~") else ""
        if marker:
            if not fence_marker:
                lang = stripped[len(marker) :].strip().lower()
                fence_marker = marker
                shell_fence = lang in {"", "bash", "console", "sh", "shell", "zsh"}
                has_pipefail = False
            elif marker == fence_marker:
                if pending:
                    lines.append((pending.strip(), has_pipefail))
                    pending = ""
                fence_marker = ""
                shell_fence = False
                has_pipefail = False
            continue
        if fence_marker and shell_fence:
            if stripped.startswith(("$ ", "> ")):
                stripped = stripped[2:]
            if stripped.endswith("\\"):
                pending += stripped[:-1].strip() + " "
            else:
                command = (pending + stripped).strip()
                enables_pipefail = any(
                    re.search(r"\bset\s+(?:-[A-Za-z]+\s+)*-o\s+pipefail\b", segment)
                    or re.search(r"\bset\s+-[A-Za-z]*o[A-Za-z]*\s+pipefail\b", segment)
                    for segment in shell_segments_text(command)
                )
                disables_pipefail = any(
                    re.search(r"\bset\s+\+o\s+pipefail\b", segment)
                    for segment in shell_segments_text(command)
                )
                has_pipefail = (has_pipefail and not disables_pipefail) or enables_pipefail
                lines.append((command, has_pipefail))
                pending = ""
    return lines


def shell_segments_text(line: str) -> list[str]:
    """Return trimmed shell-list segments for exact built-in checks."""
    return [segment.strip() for segment in re.split(r"(?:&&|;)", line) if segment.strip()]


def shell_segments(line: str) -> list[list[str]]:
    """Return tokenized commands from pipelines and command lists."""
    try:
        lexer = shlex.shlex(line, posix=True, punctuation_chars="|;&")
        lexer.whitespace_split = True
        lexer.commenters = "#"
        tokens = list(lexer)
    except ValueError:
        return []
    segments: list[list[str]] = []
    current: list[str] = []
    for token in tokens:
        if token and set(token) <= {"|", ";", "&"}:
            if current:
                segments.append(current)
                current = []
        else:
            current.append(token)
    if current:
        segments.append(current)
    return segments


def unwrap_command(tokens: list[str]) -> list[str]:
    """Remove common wrappers without accepting prefix lookalikes as fw flags."""
    tokens = list(tokens)
    while tokens:
        while tokens and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*=.*", tokens[0]):
            tokens.pop(0)
        if not tokens:
            break
        wrapper = Path(tokens[0]).name
        if wrapper in {"command", "exec"}:
            tokens.pop(0)
            while tokens and tokens[0].startswith("-"):
                tokens.pop(0)
            continue
        if wrapper in {"time", "nice", "sudo"}:
            tokens.pop(0)
            value_options = {
                "time": {"-f", "--format", "-o", "--output"},
                "nice": {"-n", "--adjustment"},
                "sudo": {"-u", "--user", "-g", "--group", "-h", "--host", "-C", "--close-from"},
            }[wrapper]
            while tokens and tokens[0].startswith("-"):
                option = tokens.pop(0)
                if option in value_options and tokens:
                    tokens.pop(0)
            continue
        if wrapper == "env":
            tokens.pop(0)
            while tokens and (tokens[0].startswith("-") or "=" in tokens[0]):
                option = tokens.pop(0)
                if option in {"-u", "--unset", "-C", "--chdir", "-S", "--split-string"} and tokens:
                    tokens.pop(0)
            continue
        break
    return tokens


VALUE_OPTIONS = {
    "--audio-ctx", "--backend", "--batch-file", "--batch-size", "--beam-size",
    "--best-of", "--concurrency", "--conflict-policy", "--correction-tolerance-wer",
    "--db", "--diarization-engine", "--diarization-fallback",
    "--diarization-max-prototypes", "--diarization-model", "--duration-ms",
    "--enrollment-edge-guard-ms", "--entropy-threshold", "--fast-model", "--format",
    "--gpu-device", "--hf-token", "--id", "--input", "--language", "--limit",
    "--logprob-threshold", "--max-context", "--max-segment-length", "--mic-device",
    "--mic-ffmpeg-format", "--mic-ffmpeg-source", "--mic-seconds", "--model",
    "--no-speech-threshold", "--offset-ms", "--output", "--output-dir", "--package",
    "--processors", "--prompt", "--quality-model", "--receipt", "--run-id",
    "--speaker-count-hard", "--speaker-count-prior", "--speaker-count-range",
    "--speaker-hints", "--speculative-overlap-ms", "--speculative-window-ms",
    "--suppress-regex", "--temperature", "--temperature-increment", "--threads",
    "--timeout", "--timestamp-level", "--transcript-path", "--url", "--vad-max-speech-s",
    "--vad-min-silence-ms", "--vad-min-speech-ms", "--vad-model", "--vad-samples-overlap",
    "--vad-speech-pad-ms", "--vad-threshold", "--word-threshold",
}


def option_positionals(tokens: list[str], start: int) -> list[str]:
    """Find bare positionals in documented examples after consuming known option values."""
    found: list[str] = []
    index = start
    while index < len(tokens):
        token = tokens[index]
        if re.match(r"^\d*>>?", token):
            index += 2 if re.fullmatch(r"\d*>>?", token) else 1
        elif token in {"--"}:
            found.extend(tokens[index + 1 :])
            break
        elif token in VALUE_OPTIONS:
            index += 2
        elif any(token.startswith(f"{name}=") for name in VALUE_OPTIONS) or token.startswith("-"):
            index += 1
        else:
            found.append(token)
            index += 1
    return found


def input_mode_count(tokens: list[str]) -> int:
    return sum(
        argument in {"--stdin", "--mic", "--input"}
        or (
            argument.startswith("--input=")
            and bool(argument.removeprefix("--input="))
        )
        for argument in tokens
    )


def missing_option_values(tokens: list[str]) -> list[str]:
    missing: list[str] = []
    for index, argument in enumerate(tokens):
        next_argument = tokens[index + 1] if index + 1 < len(tokens) else ""
        invalid_next = (
            not next_argument
            or bool(re.match(r"^\d*[<>]", next_argument))
            or (
                next_argument.startswith("-")
                and not re.fullmatch(r"-\d+(?:\.\d+)?", next_argument)
            )
        )
        if argument in VALUE_OPTIONS and invalid_next:
            missing.append(argument)
        elif argument.endswith("=") and argument[:-1] in VALUE_OPTIONS:
            missing.append(argument[:-1])
    return missing


def has_option(tokens: list[str], name: str) -> bool:
    return any(argument == name or argument.startswith(f"{name}=") for argument in tokens)


def validate_shell_line(line: str, label: str, has_pipefail: bool) -> list[str]:
    errors: list[str] = []
    if "<changed-files>" in line:
        errors.append(f"{label}: angle-bracket shell placeholder becomes redirection: {line}")
    if re.search(r"/t[m]p/fw-probe[.]json", line):
        errors.append(f"{label}: fixed shared transcript path is unsafe: {line}")
    if "tests/fixtures/native/jfk.wav" in line:
        errors.append(f"{label}: local gitignored fixture is not portable: {line}")
    segments = shell_segments(line)
    if not segments and re.search(r"(?:^|\s)(?:fw|franken_whisper)(?:\s|$)", line):
        errors.append(f"{label}: could not tokenize fw shell example: {line}")
    for raw_tokens in segments:
        tokens = unwrap_command(raw_tokens)
        if len(tokens) < 2 or Path(tokens[0]).name not in {"fw", "franken_whisper"}:
            continue
        command = tokens[1]
        if has_option(tokens[1:], "--robot"):
            errors.append(f"{label}: root --robot example: {line}")
        for option in missing_option_values(tokens[2:]):
            errors.append(f"{label}: option {option} lacks a value: {line}")
        if command in {"transcribe"}:
            modes = input_mode_count(tokens[2:])
            if "--help" not in tokens and modes != 1:
                errors.append(f"{label}: transcribe example requires exactly one input mode: {line}")
            if option_positionals(tokens, 2):
                errors.append(f"{label}: positional transcribe input/example token: {line}")
            assignments = {
                key: value
                for item in raw_tokens
                if (match := re.fullmatch(r"([A-Za-z_][A-Za-z0-9_]*)=(.*)", item))
                for key, value in [match.groups()]
            }
            if assignments.get("FW_DENOISE", "").lower() in {"0", "off", "false", "no"}:
                errors.append(f"{label}: ordinary native transcribe bypasses the denoiser wrapper: {line}")
        elif command in {"robot", "agent"} and len(tokens) >= 3 and tokens[2] in {"run"}:
            if "|" in line and not has_pipefail:
                errors.append(
                    f"{label}: robot pipeline must preserve producer failure with pipefail: {line}"
                )
            if re.search(r"\|\|\s*(?:true\b|:(?:\s|$))", line):
                errors.append(f"{label}: robot pipeline failure is explicitly swallowed: {line}")
            modes = input_mode_count(tokens[3:])
            if "--help" not in tokens and modes != 1:
                errors.append(f"{label}: robot run example requires exactly one input mode: {line}")
            if option_positionals(tokens, 3):
                errors.append(f"{label}: positional robot-run input/example token: {line}")
            if has_option(tokens, "--json"):
                errors.append(f"{label}: robot run --json is redundant/misleading; output remains NDJSON: {line}")
        elif command in {"runs"}:
            if any(token in {"list", "show", "export"} for token in option_positionals(tokens, 2)):
                errors.append(f"{label}: runs is option-based, not subcommand-based: {line}")
        elif command in {"pull"}:
            models = option_positionals(tokens, 2)
            if any(model.lower() in {"ecapa", "fastenhancer"} for model in models):
                errors.append(f"{label}: unsupported package pull: {line}")
    return errors


def slugify(heading: str) -> str:
    heading = re.sub(r"`([^`]*)`", r"\1", heading.strip().lower())
    heading = re.sub(r"[^a-z0-9 _-]", "", heading)
    return re.sub(r"[ _]+", "-", heading).strip("-")


def anchors(path: Path) -> set[str]:
    found: set[str] = set()
    seen: dict[str, int] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        match = re.match(r"^#{1,6}\s+(.+?)\s*$", line)
        if not match:
            continue
        base = slugify(match.group(1))
        count = seen.get(base, 0)
        seen[base] = count + 1
        found.add(base if count == 0 else f"{base}-{count}")
    return found


def validate_links(path: Path, errors: list[str]) -> None:
    text = path.read_text(encoding="utf-8")
    for target in re.findall(r"\[[^\]]+\]\(([^)]+)\)", text):
        if target.startswith(("http://", "https://", "mailto:")):
            continue
        file_part, _, fragment = target.partition("#")
        destination = (path.parent / file_part).resolve() if file_part else path.resolve()
        if not destination.exists():
            errors.append(f"{path.relative_to(ROOT)}: missing link target {target}")
            continue
        if fragment and fragment not in anchors(destination):
            try:
                destination_label = str(destination.relative_to(ROOT))
            except ValueError:
                destination_label = str(destination)
            errors.append(
                f"{path.relative_to(ROOT)}: missing anchor #{fragment} in "
                f"{destination_label}"
            )


def documented_versions() -> dict[str, str]:
    patterns = {
        "SKILL.md": r"Current public release\s*\|\s*`v([0-9]+\.[0-9]+\.[0-9]+)",
        "references/CLI.md": r"Current ([0-9]+\.[0-9]+\.[0-9]+) command families",
        "references/RESEARCH.md": r"installed ([0-9]+\.[0-9]+\.[0-9]+) binary",
    }
    versions: dict[str, str] = {}
    for relative, pattern in patterns.items():
        match = re.search(pattern, (ROOT / relative).read_text(encoding="utf-8"))
        if match:
            versions[relative] = match.group(1)
    return versions


def validate_metadata(errors: list[str]) -> None:
    text = AGENT.read_text(encoding="utf-8")
    if "\t" in text:
        errors.append("agents/openai.yaml: tabs are not permitted")
    required_patterns = {
        "interface": r"(?m)^interface:\s*$",
        "display_name": r'(?m)^\s{2}display_name:\s*"[^"\n]+"\s*$',
        "short_description": r'(?m)^\s{2}short_description:\s*"[^"\n]+"\s*$',
        "default_prompt": r'(?m)^\s{2}default_prompt:\s*"[^"\n]*\$fw[^"\n]*"\s*$',
        "policy": r"(?m)^policy:\s*$",
        "allow_implicit_invocation": r"(?m)^\s{2}allow_implicit_invocation:\s*true\s*$",
    }
    for name, pattern in required_patterns.items():
        if len(re.findall(pattern, text)) != 1:
            errors.append(f"agents/openai.yaml: expected exactly one valid {name} field")
    allowed = [re.compile(pattern) for pattern in required_patterns.values()]
    for line_number, line in enumerate(text.splitlines(), 1):
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        if not any(pattern.fullmatch(line) for pattern in allowed):
            errors.append(f"agents/openai.yaml:{line_number}: unknown or malformed field")


def run_self_test() -> list[str]:
    failures: list[str] = []
    bad_cases = [
        "fw transcribe meeting.m4a --robot",
        "fw transcribe --input meeting.m4a --robot=true",
        "producer | fw transcribe meeting.m4a --robot",
        "fw --version; fw transcribe meeting.m4a --robot",
        "time fw transcribe meeting.m4a --robot",
        "command fw transcribe meeting.m4a --robot",
        "env -i PATH=/bin fw transcribe meeting.m4a --robot",
        "sudo -u root fw transcribe meeting.m4a --robot",
        "nice -n 5 fw transcribe meeting.m4a --robot",
        "fw transcribe --input a.wav --stdin --json",
        "fw transcribe --input --json",
        "fw transcribe --input >report.json",
        "fw transcribe --input= --json",
        "fw transcribe --input a.wav extra.wav",
        "fw transcribe --input-file a.wav --json",
        "fw transcribe --mic-seconds 5 --json",
        "fw robot run --mic-device default",
        "fw robot run --input a.wav --json=true",
        "fw robot run --input a.wav | jq -c .",
        "set -o pipefail; fw robot run --input a.wav | jq -c . || true",
        "fw runs --db state.sqlite list",
        "fw pull --json ecapa",
        "FW_DENOISE=off fw transcribe --input a.wav",
        "FW_DENOISE='off' fw transcribe --input a.wav",
    ]
    for case in bad_cases:
        if not validate_shell_line(case, "self-test", has_pipefail=False):
            failures.append(f"self-test failed to reject: {case}")

    good_cases = [
        "fw transcribe --input a.wav --no-persist --json",
        "fw transcribe --stdin --json",
        "fw transcribe --mic --mic-seconds 5 --json",
        "fw transcribe --input a.wav --prompt hello --json # operator note",
        "fw robot run --input a.wav --no-persist",
        "fw robot run --input a.wav --no-persist | jq -c .",
        "fw runs --id abc --format json",
        "fw runs --id=abc --format=json",
        "fw runs --id abc",
        "fw pull whisper --json",
        "FW_DENOISE=0 fw sortformer-diarize --input a.wav",
    ]
    for case in good_cases:
        findings = validate_shell_line(case, "self-test", has_pipefail=True)
        if findings:
            failures.append(f"self-test rejected valid case: {case}: {findings}")

    bad_fences = """```bash
set -o pipefail
fw robot run --input a.wav | jq -c .
```
```bash
fw robot run --input b.wav | jq -c .
```"""
    fence_findings = [
        finding
        for line, has_pipefail in fenced_shell_lines(bad_fences)
        for finding in validate_shell_line(line, "self-test-fence", has_pipefail)
    ]
    if len(fence_findings) != 1:
        failures.append(
            "self-test expected exactly one unprotected cross-fence robot pipeline finding"
        )

    bash = shutil.which("bash")
    if bash:
        status_tail = (
            'pipeline_status=("${PIPESTATUS[@]}")\n'
            'test "${pipeline_status[0]}" -eq 0 && '
            'test "${pipeline_status[1]}" -eq 0\n'
        )
        failing = subprocess.run(  # nosec B603 - fixed local shell proof, no user input
            [bash, "-c", "set -o pipefail\n(exit 7) | while read -r _; do :; done\n" + status_tail],
            check=False,
            timeout=5,
        )
        passing = subprocess.run(  # nosec B603 - fixed local shell proof, no user input
            [bash, "-c", "set -o pipefail\nprintf 'x\\n' | while read -r _; do :; done\n" + status_tail],
            check=False,
            timeout=5,
        )
        parser_failing = subprocess.run(  # nosec B603 - fixed local shell proof, no user input
            [
                bash,
                "-c",
                "set -o pipefail\nprintf 'x\\n' | "
                "while read -r _; do false || exit 1; done\n" + status_tail,
            ],
            check=False,
            timeout=5,
        )
        if (
            failing.returncode == 0
            or parser_failing.returncode == 0
            or passing.returncode != 0
        ):
            failures.append("self-test robot pipeline status harness did not fail closed")
    return failures


def argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Validate the fw skill structure, links, examples, and high-risk contracts."
    )
    parser.add_argument("--json", action="store_true", help="emit one JSON result object")
    parser.add_argument("--self-test", action="store_true", help="run adversarial parser tests")
    parser.add_argument("--strict", action="store_true", help="treat freshness warnings as errors")
    parser.add_argument("--live", action="store_true", help="compare the documented version with fw on PATH")
    parser.add_argument("--fw-bin", default="fw", help="binary for --live (default: fw on PATH)")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = argument_parser().parse_args(argv)
    errors: list[str] = []
    warnings: list[str] = []

    for path in [SKILL, SELF_TEST, AGENT]:
        if not path.is_file():
            errors.append(f"missing required file: {path.relative_to(ROOT)}")
    for name in REQUIRED_REFS:
        if not (REFS / name).is_file():
            errors.append(f"missing required reference: references/{name}")

    if errors:
        return emit_result(args.json, errors, warnings)

    skill_text = SKILL.read_text(encoding="utf-8")
    validator_path = Path(__file__)
    if not validator_path.read_text(encoding="utf-8").startswith("#!/usr/bin/env python3\n"):
        errors.append("scripts/validate.py: missing portable Python shebang")
    if validator_path.stat().st_mode & 0o111 == 0:
        errors.append("scripts/validate.py: must be executable")
    frontmatter = re.match(r"\A---\n(.*?)\n---\n", skill_text, re.DOTALL)
    if not frontmatter:
        errors.append("SKILL.md: missing YAML frontmatter")
    else:
        fm = frontmatter.group(1)
        if len(re.findall(r"(?m)^name:\s*fw\s*$", fm)) != 1:
            errors.append("SKILL.md: frontmatter name must be fw")
        if len(re.findall(r"(?m)^description:\s*>-\s*$", fm)) != 1:
            errors.append("SKILL.md: frontmatter requires one folded description")
        if "Use when" not in fm:
            errors.append("SKILL.md: description must contain an explicit Use when trigger")
        if "not for generic" not in fm.lower():
            errors.append("SKILL.md: implicit trigger must exclude generic overlapping ASR/WASM work")

    for relative, terms in REQUIRED_BY_FILE.items():
        text = (ROOT / relative).read_text(encoding="utf-8")
        for term in terms:
            if term not in text:
                errors.append(f"{relative}: missing required contract term: {term}")

    for name in REQUIRED_REFS:
        if f"references/{name}" not in skill_text:
            errors.append(f"SKILL.md: required reference is not discoverable: references/{name}")

    for path in markdown_files():
        text = path.read_text(encoding="utf-8")
        if path not in {SKILL, SELF_TEST} and "## Table of Contents" not in text:
            errors.append(f"{path.relative_to(ROOT)}: missing Table of Contents")
        validate_links(path, errors)
        for pattern, reason in FORBIDDEN_PROSE:
            if re.search(pattern, text, re.IGNORECASE):
                errors.append(f"{path.relative_to(ROOT)}: stale/proof-inflating prose: {reason}")

        for line, has_pipefail in fenced_shell_lines(text):
            errors.extend(validate_shell_line(line, str(path.relative_to(ROOT)), has_pipefail))

    validate_metadata(errors)

    versions = documented_versions()
    if len(versions) != 3:
        errors.append(f"version markers missing: found {versions}")
    elif len(set(versions.values())) != 1:
        errors.append(f"documented versions disagree: {versions}")

    date_match = re.search(r"Cold-Start Boundary Card \(([^)]+)\)", skill_text)
    if not date_match:
        errors.append("SKILL.md: missing dated Cold-Start Boundary Card")
    else:
        try:
            snapshot = datetime.strptime(date_match.group(1), "%B %d, %Y").replace(tzinfo=UTC)
            age_days = (datetime.now(UTC) - snapshot).days
            if age_days < -1:
                errors.append("SKILL.md: Cold-Start Boundary Card is future-dated")
            elif age_days > 45:
                warnings.append(f"Cold-Start Boundary Card is {age_days} days old; refresh live truth")
        except ValueError:
            errors.append("SKILL.md: Cold-Start Boundary Card date is not 'Month DD, YYYY'")

    if args.live and versions:
        binary = shutil.which(args.fw_bin) if "/" not in args.fw_bin else args.fw_bin
        if not binary or not Path(binary).is_file():
            errors.append("--live requested but fw is not on PATH")
        else:
            try:
                probe = subprocess.run(  # nosec B603 - exact operator-selected binary, fixed --version argv
                    [binary, "--version"], capture_output=True, text=True, check=False, timeout=10
                )
            except (OSError, subprocess.TimeoutExpired) as exc:
                errors.append(f"live fw version probe could not run: {exc}")
                probe = None
            if probe is None:
                return emit_result(args.json, errors, warnings)
            match = re.search(r"([0-9]+\.[0-9]+\.[0-9]+)", probe.stdout + probe.stderr)
            expected = next(iter(versions.values()))
            if probe.returncode != 0 or not match:
                errors.append(f"live fw version probe failed: exit {probe.returncode}")
            elif match.group(1) != expected:
                errors.append(f"live fw {match.group(1)} disagrees with documented {expected}")

    if args.self_test:
        errors.extend(run_self_test())
    if args.strict and warnings:
        errors.extend(f"strict freshness: {warning}" for warning in warnings)

    return emit_result(args.json, errors, warnings)


def emit_result(json_mode: bool, errors: list[str], warnings: list[str]) -> int:
    payload = {
        "ok": not errors,
        "markdown_files": len(markdown_files()),
        "errors": errors,
        "warnings": warnings,
    }
    if json_mode:
        print(json.dumps(payload, sort_keys=True))
    else:
        for warning in warnings:
            print(f"WARNING: {warning}", file=sys.stderr)
        for error in errors:
            print(f"ERROR: {error}", file=sys.stderr)
        if not errors:
            print(f"fw skill validation passed ({len(markdown_files())} markdown files)")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
