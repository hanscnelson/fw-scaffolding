---
name: fw
description: >-
  Use when work names fw/franken_whisper or its FastEnhancer browser: CLI, models, robot
  NDJSON, diarization, release, WASM, or native engine. Not for generic ASR/Whisper/WASM.
---

<!-- TOC: One Rule | Start Here | Truth Stack | Cold-Start Boundary Card | Task-Matched First Actions | Fresh-Agent Reading Plan | Claim Taxonomy | Fast Probe | Common Workflows | Library Integration | Development Rules | Do Not | Reference Index | Validate This Skill -->

# fw / franken_whisper

## One Rule

**Probe the exact binary and checkout before prescribing a command or making a capability
claim.** `fw` has shipped quickly; remembered examples and even nearby documentation can lag.

## Start Here

Choose one row. Do not load every reference or hash every model package by default.

First run `command -v fw`; if it fails, stop issuing `fw` commands and use the installation
workflow. If it succeeds, record its path and `fw --version` before remembered syntax.

| Intent | First action | Then read |
|---|---|---|
| Transcribe one file | `fw transcribe --help` | [CLI](references/CLI.md) |
| Consume machine events | `fw robot run --help` | [Robot](references/ROBOT.md) |
| Install or repair models | `fw capabilities --json` | [Artifacts and Environment](references/ARTIFACTS-AND-ENV.md) |
| Diagnose browser cleanup | capture build/cache + last stage | [WASM and Denoise](references/WASM-AND-DENOISE.md) |
| Change source or architecture | read all governing docs + README | [Development](references/DEVELOPMENT.md) |
| Cut or verify a release | inspect current release authority first | [Verification](references/VERIFICATION.md#release-workflow) |
| Make a performance claim | locate same-invocation incumbent harness | [Native Engine](references/NATIVE-ENGINE.md) |

For a broader meeting/YouTube transcript-production request, let the task-specific skill own
the deliverable workflow and use `$fw` for this tool's live CLI, model, output, and proof truth.

## Truth Stack

Use this order, and name the surface you actually proved:

1. User request and nearest governing `AGENTS.md` files.
2. Exact binary behavior: path/version, nested help, bounded real probe.
3. Current source, tests, and evidence ledgers.
4. Authenticated release/installer/package artifacts.
5. Refreshed tracker state, then README/website/history.

Never turn static discovery, compilation, a simulator, a skipped model test, or a closed
bead into runtime proof.

## Cold-Start Boundary Card (August 13, 2026)

| Boundary | Current verified shape | Recheck with |
|---|---|---|
| Short binary | `fw` | `command -v fw; fw --version` |
| Current public release | `v0.9.2` at `6b3ad16b...` | `gh release view --repo Dicklesworthstone/franken_whisper` |
| File input | `fw transcribe --input FILE` | `fw transcribe --help` |
| Input cardinality | exactly one of `--input`, `--stdin`, `--mic` | semantic-invalid probe exits 1 |
| Terminal JSON | `fw transcribe --input FILE --json` | success emits one document; failures may be stderr-only |
| Streaming machine mode | `fw robot run --input FILE` | parse stdout one line at a time |
| Doctor authority | static preflight, not a transcription proof | inspect authority fields |
| Sortformer status | `development_uncertified` | inspect registry and package evidence |
| FastEnhancer | browser and evaluation-only direct Sortformer path; ordinary native `transcribe` bypasses wrapper | source caller census |

This is a dated orientation card, not permanent truth. Apply [OP-LC](references/OPERATORS.md#op-lc-live-contract-probe)
and [OP-SQ](references/OPERATORS.md#op-sq-stale-binary-quarantine) before acting.

## Task-Matched First Actions

Start with:

```bash
command -v fw
fw --version
```

Then run only the task's narrow help or discovery surface:

```bash
fw transcribe --help
fw robot run --help
fw capabilities --json
```

Use `fw robot triage` only for install/model/backend diagnosis. It calls doctor and model
discovery and may hash roughly 2.1 GB of packages. Once it runs, do not immediately repeat
`models` and `doctor`; drill into one only when its fields require it.

For source, architecture, release, or docs work, first establish the checkout and governing
documents:

```bash
git status --short --branch
git log --oneline -10
FW_REPO_ROOT="$(git rev-parse --show-toplevel)"
for doc in \
  "$FW_REPO_ROOT/AGENTS.md" \
  "$(dirname "$FW_REPO_ROOT")/AGENTS.md" \
  "$FW_REPO_ROOT/README.md"; do
  test -f "$doc" && printf '%s\n' "$doc"
done
br list --json
br dep cycles
```

Read all governing documents before exploration or edits. Shared-tree changes are peer work:
never stash, reset, revert, overwrite, or broadly stage them.

## Fresh-Agent Reading Plan

1. Installed operation: live nested help plus the routed reference.
2. Source/architecture/release: all governing docs and the complete README, then task source,
   focused tests, and ledgers.
3. Use the matching [operator stack](references/OPERATORS.md#recommended-stacks); consult
   Beads/CASS only after current evidence.

## Claim Taxonomy

| Claim | Minimum evidence |
|---|---|
| Command exists | exact binary `--help` |
| Static readiness | `models`/`doctor` fields, labeled static |
| Transcription works | real audio, model-backed completion, parsed output |
| Robot-safe | NDJSON parsing + stdout-purity + exit-code probe |
| Diarization works | real audio, complete coverage, lane/confidence inspection |
| Speaker identity | independent mapping evidence; clusters alone never suffice |
| Browser denoise works | real worker run with progress and completion |
| Release shipped | tag, target commit, assets/checksums, install and smoke |
| Performance win | same-invocation matched incumbent, equivalent decode/output, admissible host |

## Fast Probe

Set `FW_PROBE_AUDIO` to authorized audio; never assume an installed/fresh-checkout fixture.
The private temporary directory contains sensitive transcript and path data.

```bash
export FW_PROBE_AUDIO="/absolute/path/to/operator-authorized-audio.wav"
(
  set -eu
  : "${FW_PROBE_AUDIO:?set FW_PROBE_AUDIO to a readable recording}"
  test -r "$FW_PROBE_AUDIO"
  umask 077
  FW_PROBE_DIR="$(mktemp -d "${TMPDIR:-/tmp}/fw-probe.XXXXXX")"
  fw transcribe --input "$FW_PROBE_AUDIO" --no-diarize --no-persist --json >"$FW_PROBE_DIR/report.json"
  jq -e '.result.transcript | length > 0' "$FW_PROBE_DIR/report.json"
  printf 'private probe: %s\n' "$FW_PROBE_DIR/report.json"
)
```

Model/doctor/triage can hash large packages. An absent artifact or skipped run is not proof.

## Common Workflows

### Install and prepare

```bash
brew install dicklesworthstone/tap/franken-whisper
fw --version
fw pull all --json
fw models --json
fw doctor --json
```

Models are separate. See [Artifacts and Environment](references/ARTIFACTS-AND-ENV.md) for
installer/offline choices and network/disk effects.

### Transcribe a file

Ephemeral one-off (no SQLite write):

```bash
(
  set -e
  umask 077
  FW_OUTPUT_DIR="$(mktemp -d "${TMPDIR:-/tmp}/fw-output.XXXXXX")"
  fw transcribe --input meeting.m4a --no-persist --json >"$FW_OUTPUT_DIR/meeting.json"
  jq -e . "$FW_OUTPUT_DIR/meeting.json" >/dev/null
  printf 'private report: %s\n' "$FW_OUTPUT_DIR/meeting.json"
)
```

`--no-persist` disables the run DB write, not transient normalized audio/orchestrator state.

Omit `--no-persist` only for an intentional auditable run; default DB is
`.franken_whisper/storage.sqlite3`. Diarization is already on; `--no-diarize` disables it.

### Stream machine events

```bash
(
  set -o pipefail
  fw robot run --input meeting.m4a --no-persist |
  while IFS= read -r line; do
    printf '%s\n' "$line" | jq -ce . || exit 1
  done
  pipeline_status=("${PIPESTATUS[@]}")
  test "${pipeline_status[0]}" -eq 0 && test "${pipeline_status[1]}" -eq 0
)
```

Bash only. Stderr stays separate. In application code, preserve child/parser status, verify
terminal cardinality, and parse by event kind/schema.

### Denoiser recovery

```bash
FW_DENOISE=0 fw sortformer-diarize --input meeting.m4a
```

This is only for the evaluation-only native caller. In the browser, after watchdog reset,
click **Reload cached models**, clear **Clean up the audio first**, and retry. Ordinary native
`transcribe` already bypasses the wrapper.

### Inspect runs and sync audit state

```bash
fw runs --format json
fw runs --id RUN_ID --format json
fw sync export-jsonl --output ./fw-audit
```

Opening a missing DB can create it. Export first. Only with explicit mutation authority,
exact-target resolution, and backup/export:

```bash
fw sync import-jsonl --input ./fw-audit --conflict-policy reject
```

Overwrite policies replace rows and `overwrite-strict` may prune. See [CLI](references/CLI.md)
for stdin/mic, YouTube, pulls, output contracts, and sync details.

## Library Integration

Use exported engine/request/report types and structured `RunReport`, not log scraping. The
public request has `timeout_ms` but no independently scoped caller token or public stage-
budget object; recheck current signatures in [Library](references/LIBRARY.md).

## Development Rules in `franken_whisper`

- Discover and read the nearest project and suite `AGENTS.md` files plus the full README;
  suite roots differ by host (`/data/projects`, `/dp`, or the checkout's parent).
- Follow spec-first order, pinned nightly/Rust 2024, and current `OnceLock`/ledger defaults.
- Audited local unsafe kernels exist; do not claim unsafe-free.
- Run focused proof, then fmt/check/clippy/test via RCH and `ubs` on changed paths.
- Never weaken gates, reflexively regenerate goldens, mismatch decode modes, disturb peer
  work, or call a self-speedup a win. See [Development](references/DEVELOPMENT.md).

## Do Not

- No positional audio for `transcribe`/`robot run`, root `--robot`, one-document NDJSON
  parsing, or hidden persistence. `youtube` legitimately accepts positional URLs.
- No `doctor`-as-runtime proof, ECAPA-in-`pull all`, or cluster-as-person claims.
- No blanket offline claim: external backends, YouTube, and ffmpeg provisioning differ.
- No raw report/stream/stderr/DB/JSONL publication or unreviewed explicit model/binary trust.
- No forced-bridge claim without disabling native recovery and asserting provenance.
- No ignored dropped windows, indefinite browser wait, route inference, mismatched perf row,
  file deletion, history rewrite, or peer-work disturbance.

## Reference Index

- [CLI](references/CLI.md) — command grammar, inputs, outputs, exit codes.
- [Robot](references/ROBOT.md) — NDJSON, events, parsing, recovery.
- [Architecture](references/ARCHITECTURE.md) — pipeline and module map.
- [Library](references/LIBRARY.md) — embedding boundaries and cancellation.
- [Artifacts and Environment](references/ARTIFACTS-AND-ENV.md) — packages, cache, env.
- [Native Engine](references/NATIVE-ENGINE.md) — GGML Whisper, long form, parity, perf.
- [Diarization](references/DIARIZATION.md) — engines, evidence, identity boundary.
- [WASM and Denoise](references/WASM-AND-DENOISE.md) — FastEnhancer and browser liveness.
- [Verification](references/VERIFICATION.md) — proof ladder, gates, release/perf evidence.
- [Development](references/DEVELOPMENT.md) — repo workflow and quality gates.
- [Beads Reality](references/BEADS-REALITY.md) — refreshed tracker signals.
- [Troubleshooting](references/TROUBLESHOOTING.md) — symptom-driven recovery.
- [Operators](references/OPERATORS.md) — reusable expert decision cards.
- [Research](references/RESEARCH.md) — provenance and design decisions.

Trigger and regression tests are in [SELF-TEST.md](SELF-TEST.md).

## Validate This Skill

From the canonical private-skills repository root:

```bash
python3 .claude/skills/fw/scripts/validate.py --self-test
python3 .claude/skills/fw/scripts/validate.py --json
```

Then run the generic skill validator from the installed `$sw` skill location if available;
do not assume one fixed `~/.agents` versus `~/.codex` deployment path.
