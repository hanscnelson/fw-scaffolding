# fw Skill Self-Test

## Table of Contents

- [Positive trigger cases](#positive-trigger-cases)
- [Negative trigger cases](#negative-trigger-cases)
- [Contract regression cases](#contract-regression-cases)
- [Proof-boundary cases](#proof-boundary-cases)
- [Executable validation](#executable-validation)

## Positive trigger cases

The skill should trigger for:

1. “Transcribe this meeting with `fw` and give me JSON.”
2. “Why is `fw robot run` producing several JSON objects?”
3. “FastEnhancer is stuck cleaning up audio in the browser.”
4. “Which franken_whisper model packages do I need?”
5. “Add cancellation to a `FrankenWhisperEngine` integration.”
6. “Audit native Whisper long-form completeness.”
7. “Cut a franken_whisper release and update Homebrew.”
8. “Can I trust these Sortformer speaker names?”
9. “Benchmark native turbo against whisper.cpp on my Mac.”
10. “Export the fw run store to JSONL.”

## Negative trigger cases

The skill should not trigger for:

1. Generic audio editing with no ASR or franken_whisper context.
2. Asking how the Whisper paper works in theory.
3. A cloud speech API unrelated to `fw`.
4. A request to write marketing copy that contains the word “whisper.”
5. Generic Rust formatting in another repository.
6. Generic NDJSON parsing, WASM debugging, diarization, or Whisper work that does not name
   `fw`, `franken_whisper`, this repository, or its FastEnhancer product surface.

## Contract regression cases

The skill must correct these prompts before execution:

- `fw transcribe meeting.m4a --diarize --robot`
- “Parse `fw robot run` as one JSON object.”
- “`fw doctor --json` is green, so runtime diarization is certified.”
- “`fw pull all` downloaded ECAPA.”
- “Sortformer says SPEAKER_00, therefore that is Alice.”
- “The denoiser still has no progress after several minutes; keep waiting.”
- “Compare greedy native to beam whisper.cpp and report a speedup.”
- “`transcribe --json` guarantees a JSON error body.”
- “Input-cardinality errors are Clap usage exit 2.”
- “`FRANKEN_WHISPER_NATIVE_EXECUTION=0` guarantees no native recovery.”
- “Any explicit model path or backend executable is authenticated because it exists.”
- “Import this snapshot with `overwrite-strict`; it is only a read.”

Expected corrected forms:

```bash
fw transcribe --input meeting.m4a --no-persist --json
fw robot run --input meeting.m4a --no-persist
FW_DENOISE=0 fw sortformer-diarize --input meeting.m4a
```

## Proof-boundary cases

For every answer, verify that the skill distinguishes:

- command discovery from real execution;
- static package readiness from model-backed completion;
- diarization clusters from named identities;
- compile/test proof from release asset proof;
- dropped-window visibility from full long-form completeness;
- local timing from a matched same-invocation incumbent ratio;
- website-worker recovery from native CLI denoiser behavior;
- success-only terminal JSON from structured robot failures;
- pinned release packages from operator-trusted model/binary overrides;
- native package provisioning from external-backend/YouTube/ffmpeg network paths;
- export/read operations from DB import, overwrite/pruning, and media deletion.

## Executable validation

From any directory, set the deployed or canonical skill directory explicitly:

```bash
FW_SKILL_DIR="/absolute/path/to/fw-skill"
python3 "$FW_SKILL_DIR/scripts/validate.py" --self-test
python3 "$FW_SKILL_DIR/scripts/validate.py" --json
python3 "$FW_SKILL_DIR/scripts/validate.py" --live --fw-bin /absolute/path/to/fw
```

The adversarial corpus must reject positional input, dual inputs, ancillary `--mic-*` without
`--mic`, missing option values, root `--robot`, wrapped/pipelined stale commands, unsupported
pulls, `runs` pseudo-subcommands, and denoiser flags on ordinary native transcribe. It must
accept each legal input mode, transcript-only and structured run lookup, current pulls, and
direct Sortformer bypass.
