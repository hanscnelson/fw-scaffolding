#!/usr/bin/env python3
"""audit_final.py FINAL.md --segments SEGMENTS.TXT [--speakers "Name1,Name2,..."]

The Round-1/Round-4 mechanical verification battery. Every check here corresponds to a
real defect found in production transcripts. PASS/FAIL table on stdout; exit 0 all
green | 2 failures. Re-run after EVERY batch of edits (fixes regress).

Checks:
  STRUCTURE   every labeled line is a well-formed turn: **Name** *(m:ss[:ss])*: text
  SPEAKERS    every turn name is in the --speakers list (catches silent renames and
              phantom speakers introduced by later edits)
  TIMESTAMPS  monotonic; (m:ss) only under 60 min; (h:mm:ss) above; no minutes>=60
  SEAMS       no turn starting with "..." or lowercase (mid-sentence chunk split);
              consecutive same-speaker turns listed for eyeball (seams are usual cause)
  RETENTION   whole-doc cleaned/raw word ratio: 0.75-0.92 healthy
              (<0.75 content lost; >0.92 fillers kept; per-chunk version: check each
              chunk_N.md against its raw line range during Round 1)
  COVERAGE    content-words (>=7 chars, filler-stoplist) per raw window present in
              final >=85%. NOTE: naive phrase probes false-alarm -- removed fillers and
              repaired garbles make raw phrases legitimately absent.
  FILLERS     residual " um, ", " uh, " == 0; "you know,"/"sort of" counted (warn only)
  HOMOPHONES  the burned-list: complimentary, "wall file", toolie, "ratio codes", ...
  SIC         "[sic]" never follows a repaired/normal word (each occurrence listed)
  CONTAM      prompt-leak strings (chunk_, segments.txt, persona, context-only)
  MARKDOWN    balanced ** / quotes / parens
  ACRONYMS    inventory of ALL-CAPS tokens for eyeball (one garbled acronym = one bug)
  CASING      same tool name in multiple casings (e.g. cass vs CASS) -- bare-pattern
              counts, NOT context-padded grep (padding misses long-line duplicates)
"""
import re, sys, pathlib
from collections import Counter

FILL = {"um","uh","like","you","know","i","mean","sort","of","kind","basically",
        "actually","just","so","and","the","a","to","that","it","is","was","this","really"}
HOMOPHONES = ["complimentary", "wall file", "toolie", "ratio codes", "peidantic",
              "Tokyo", "Ratatouille", "ButterFS", "cloud code", "claw ", "Grock",
              "Yamlokun", "a super sync", "a super sink", "ext forum"]
# Prompt-leak strings only -- must be phrases that CANNOT occur in real speech.
# ("persona" was here once: false positive, speakers say "agent personas" for real.)
CONTAM = ["chunk_", "segments.txt", "context-only", "[mmm:ss",
          "do not include in output", "low-confidence attribution"]

def ts_secs(m):
    a, b, c = m
    return int(a)*3600 + int(b)*60 + int(c) if c else int(a)*60 + int(b)

def main():
    args = sys.argv[1:]
    if not args or args[0] in ("-h", "--help"):
        print(__doc__); return 0
    final_p = pathlib.Path(args[0])
    t = final_p.read_text()
    segs_p = args[args.index("--segments") + 1] if "--segments" in args else None
    speakers = (set(s.strip() for s in args[args.index("--speakers") + 1].split(","))
                if "--speakers" in args else None)
    if not segs_p:
        print("WARN: no --segments given -- RETENTION and COVERAGE checks SKIPPED "
              "(they catch content loss; pass the segments file)", file=sys.stderr)
    fails = 0
    def report(name, ok, detail=""):
        nonlocal fails
        print(f"{'PASS' if ok else 'FAIL'} {name}" + (f": {detail}" if detail else ""))
        if not ok: fails += 1

    body = t.split("---\n", 1)[1] if "---\n" in t else t
    turn_re = re.compile(r"^\*\*([A-Z][\w .'-]*)\*\* \*\((\d+:\d{2}(?::\d{2})?)\)\*: \S", re.M)

    # STRUCTURE
    bad = [l[:70] for l in body.split("\n")
           if l.startswith("**") and not turn_re.match(l)]
    n_turns = len(turn_re.findall(body))
    report("STRUCTURE", not bad and n_turns > 0,
           bad[:5] if bad else f"{n_turns} well-formed turns" if n_turns else "NO turns found")

    # SPEAKERS
    names = set(m[0] for m in turn_re.findall(body))
    if speakers is not None:
        unknown = names - speakers
        report("SPEAKERS", not unknown,
               f"unexpected speaker names {sorted(unknown)} (expected {sorted(speakers)})"
               if unknown else f"all turns from {sorted(names)}")
    else:
        print(f"INFO SPEAKERS found (pass --speakers to enforce): {sorted(names)}")

    # TIMESTAMPS
    ts = re.findall(r"\*\((\d+):(\d{2})(?::(\d{2}))?\)\*", body)
    secs = [ts_secs(m) for m in ts]
    mono = [i for i in range(1, len(secs)) if secs[i] < secs[i-1]]
    fmt = [f"({a}:{b}{':'+c if c else ''})" for a, b, c in ts
           if (not c and int(a) >= 60) or (c and (int(b) >= 60 or int(a) == 0))]
    report("TIMESTAMPS", not mono and not fmt,
           f"{len(secs)} turns; non-monotonic idx {mono[:5]}; bad-format {fmt[:5]}" if (mono or fmt)
           else f"{len(secs)} turns monotonic")

    # SEAMS
    ell = re.findall(r"\)\*: (?:\.\.\.|…)", body)
    lower = re.findall(r"\)\*: [a-z]", body)
    pairs = re.findall(r"\*\*([\w .'-]+)\*\* \*\(([\d:]+)\)\*", body)
    same = [(pairs[i-1], pairs[i]) for i in range(1, len(pairs))
            if pairs[i][0] == pairs[i-1][0]]
    report("SEAMS", not ell and not lower,
           f"ellipsis-starts={len(ell)} lowercase-starts={len(lower)}"
           f"{' (a lowercase BRAND name starting a turn is legit -- eyeball before fixing)' if lower else ''}; "
           f"same-speaker consecutive turns (eyeball each): {same[:8]}")

    if segs_p:
        raw_lines = open(segs_p).readlines()
        rawtext = " ".join(l.split("] ", 1)[1] for l in raw_lines if "] " in l)
        # RETENTION (whole-doc; per-chunk needs chunk bounds -- run during R1 on chunks)
        clean_words = len(re.sub(r"\*\*[\w .'-]+\*\* \*\([\d:]+\)\*:", "", body).split())
        ratio = clean_words / max(1, len(rawtext.split()))
        report("RETENTION", 0.70 <= ratio <= 0.95, f"clean/raw={ratio:.2f} (healthy 0.75-0.92)")
        # COVERAGE per 16 windows
        fl = set(re.sub(r"[^a-z0-9 ]", " ", t.lower()).split())
        low = []
        for w in range(16):
            a, b = int(w*len(raw_lines)/16), int((w+1)*len(raw_lines)/16)
            text = " ".join(l.split("] ", 1)[1] for l in raw_lines[a:b] if "] " in l).lower()
            words = [x for x in re.sub(r"[^a-z0-9 ]", " ", text).split()
                     if len(x) >= 7 and x not in FILL]
            uniq = list(dict.fromkeys(words))
            if not uniq: continue
            pct = sum(1 for x in uniq if x in fl) / len(uniq) * 100
            if pct < 85: low.append((w+1, f"{pct:.0f}%",
                                     [x for x in uniq if x not in fl][:4]))
        report("COVERAGE", not low, low or "all 16 windows >=85% content words")

    # FILLERS
    lt = t.lower()
    hard = lt.count(" um, ") + lt.count(" uh, ")
    report("FILLERS", hard == 0,
           f"um/uh={hard}; you-know={lt.count('you know,')} sort-of={lt.count('sort of')} (latter two: warn only)")

    # HOMOPHONES (bare patterns -- context-padded grep misses long-line dups)
    hits = [(h, t.lower().count(h.lower())) for h in HOMOPHONES if h.lower() in t.lower()]
    report("HOMOPHONES", not hits, hits or "burned-list clean (also eyeball domain-specific ones)")

    # SIC
    sics = [t[max(0,m.start()-60):m.end()+10].replace("\n"," ") for m in re.finditer(r"\[sic\]", t)]
    report("SIC", True, f"{len(sics)} occurrences -- verify each marks an UNREPAIRED garble: {sics[:3]}")

    # CONTAM
    leaks = [c for c in CONTAM if c in t]
    report("CONTAM", not leaks, leaks or "no prompt-leak strings")

    # MARKDOWN (precompute counts -- a backslash inside an f-string expression is a
    # SyntaxError on Python <3.12, so never write f"{t.count('\"')}")
    n_bold, n_quote = t.count("**") % 2, t.count('"') % 2
    n_paren = t.count("(") - t.count(")")
    report("MARKDOWN", n_bold == 0 and n_quote == 0 and n_paren == 0,
           f"** %2={n_bold} quotes%2={n_quote} parens={n_paren}")

    # ACRONYMS + CASING (informational eyeball lists)
    caps = sorted(set(re.findall(r"\b[A-Z]{2,}[A-Za-z0-9]*\b", body)))
    print(f"INFO ACRONYMS (verify each is real): {caps}")
    # Sentence-case vs lowercase is normal English -- only ALLCAPS or internal-capital
    # variants (CASS vs cass, FrankenTUI vs frankentui) signal tool-name drift.
    def odd(w):
        return (len(w) >= 2 and w.isupper()) or any(c.isupper() for c in w[1:])
    toks = Counter(re.findall(r"\b[a-zA-Z][\w-]{1,15}\b", body))
    cased = {}
    for w, c in toks.items():
        cased.setdefault(w.lower(), []).append((w, c))
    mixed = {k: v for k, v in cased.items()
             if len(v) > 1 and any(odd(w) for w, _ in v)}
    print(f"INFO MIXED-CASING (tool-name drift? harmonize per-tool, leave cross-product"
          f" styling alone): {mixed}")

    print(f"\n{'ALL GREEN' if not fails else f'{fails} FAILURES'}")
    if fails:
        print("NEXT: fix each FAIL against the RAW segments file, re-assemble, re-run "
              "this audit. Then verify+fresh-eyes agent rounds.", file=sys.stderr)
    else:
        print("NEXT: spawn adversarial verify agents (assets/verify_agent_prompt.md), "
              "then ONE whole-document fresh-eyes agent (assets/fresh_eyes_prompt.md)",
              file=sys.stderr)
    return 2 if fails else 0

if __name__ == "__main__":
    sys.exit(main())
