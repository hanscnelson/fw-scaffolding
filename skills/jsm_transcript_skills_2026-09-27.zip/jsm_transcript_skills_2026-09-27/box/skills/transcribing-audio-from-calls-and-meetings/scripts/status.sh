#!/usr/bin/env bash
# Where am I in the pipeline? Inspect a workdir and print state + the exact next command.
case "${1:-}" in -h|--help|"") cat <<'EOF'
status.sh WORKDIR [FINAL.md]
  Reads the artifacts in WORKDIR and prints a stage-by-stage checklist plus the exact
  NEXT command. Resume tool: run this first when picking up a transcription mid-flight
  (after a compaction, a new session, or someone else's half-done job).
  Stages: convert -> onset/trim -> transcribe -> segments -> chunks -> assembled.
  Exit 0 (informational only).
EOF
exit 0;; esac
set -u
W="$1"; FINAL="${2:-}"
S="$(cd "$(dirname "$0")" && pwd)"
ok()   { printf "  [x] %s\n" "$1"; }
todo() { printf "  [ ] %s\n" "$1"; }
NEXT=""

echo "Pipeline state in $W:"
if ls "$W"/*.wav >/dev/null 2>&1; then
  # Only name the pipeline's own WAVs; probe/gap-recovery slices pile up in the workdir
  # and listing every one of them buries the rest of the status output.
  main_wavs=$(ls "$W"/audio_16k.wav "$W"/trimmed.wav 2>/dev/null | tr '\n' ' ')
  n_wav=$(ls "$W"/*.wav 2>/dev/null | wc -l | tr -d ' ')
  ok "converted WAV: ${main_wavs:-none of audio_16k/trimmed}(${n_wav} .wav total in workdir)"
else
  todo "no WAV"; NEXT="${NEXT:-$S/convert.sh <AUDIO> $W/audio_16k.wav}"
fi
# onset state only gates the NOT-yet-transcribed path -- once run.json is complete,
# onset was either handled or moot (don't send a finished pipeline backwards)
run_done=0
[ -s "$W/run.json" ] && python3 -c "import json,sys;json.load(open(sys.argv[1]))" "$W/run.json" 2>/dev/null && run_done=1
if ls "$W"/*trimmed*.wav >/dev/null 2>&1; then
  ok "trimmed WAV present (onset handled -- OFFSET should be recorded in your notes)"
elif [ "$run_done" = 1 ]; then
  ok "no trimmed WAV but run complete (onset was 0, or transcribed untrimmed -- confirm OFFSET=0)"
elif ls "$W"/*.wav >/dev/null 2>&1; then
  todo "onset not yet evaluated"
  NEXT="${NEXT:-$S/energy_sweep.sh $W/audio_16k.wav && $S/find_onset.sh $W/audio_16k.wav}"
fi
if [ "$run_done" = 1 ]; then
  ok "run.json complete ($(wc -c < "$W/run.json" | tr -d ' ') bytes)"
elif [ -f "$W/run.json" ]; then
  todo "run.json EXISTS but empty/invalid -- transcription running or dead"
  NEXT="${NEXT:-$S/watch_run.sh $W/run.json}"
else
  todo "not transcribed"; NEXT="${NEXT:-$S/transcribe.sh $W/<wav> $W/run.json --prompt '<nouns>'}"
fi
if [ -s "$W/segments.txt" ]; then
  ok "segments.txt ($(wc -l < "$W/segments.txt" | tr -d ' ') lines)"
else
  todo "no segments.txt"
  NEXT="${NEXT:-$S/fuse_diarization.py $W/run.json --names '<A,B>' --no-speaker > $W/segments.txt  # non-diarized runs: $S/make_segments.py $W/run.json --offset <OFFSET> > $W/segments.txt}"
fi
if [ -s "$W/turns.txt" ]; then
  ok "turns.txt ($(wc -l < "$W/turns.txt" | tr -d ' ') speaker-attributed turns)"
elif [ -s "$W/run.json" ]; then
  todo "no turns.txt (diarization not fused)"
  NEXT="${NEXT:-$S/fuse_diarization.py $W/run.json --names '<A,B>' > $W/turns.txt}"
fi
n_chunks=$(ls "$W"/clean/chunk_*.md 2>/dev/null | wc -l | tr -d ' ')
if [ "$n_chunks" -gt 0 ]; then
  ok "cleanup chunks: $n_chunks in $W/clean/"
else
  todo "no cleaned chunks"
  NEXT="${NEXT:-$S/chunk_plan.py \$(wc -l < $W/segments.txt) --chunks 8  # then spawn cleanup agents}"
fi
if [ -n "$FINAL" ] && [ -s "$FINAL" ]; then
  ok "assembled: $FINAL ($(wc -c < "$FINAL" | tr -d ' ') bytes)"
  NEXT="${NEXT:-$S/audit_final.py $FINAL --segments $W/segments.txt --speakers '<A,B>'  # then verify + fresh-eyes agents}"
elif [ -n "$FINAL" ]; then
  todo "FINAL not found/empty at: $FINAL (wrong path, or not assembled yet)"
  NEXT="${NEXT:-$S/assemble.py $W/clean '<title>' '<participants>' '<note>' -o $FINAL}"
elif [ "$n_chunks" -gt 0 ]; then
  todo "not assembled (or pass FINAL.md as 2nd arg to check it)"
  NEXT="${NEXT:-$S/assemble.py $W/clean '<title>' '<participants>' '<note>' -o <FINAL.md>}"
fi
echo
echo "NEXT: ${NEXT:-all artifacts present -- run the verification rounds (audit_final.py, verify agents, fresh-eyes)}" >&2
