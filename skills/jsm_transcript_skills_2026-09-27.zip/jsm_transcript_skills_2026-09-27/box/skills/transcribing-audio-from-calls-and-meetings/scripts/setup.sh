#!/usr/bin/env bash
# One-time setup (idempotent): ffmpeg, franken_whisper, whisper-cli (probe tool), whisper model.
case "${1:-}" in -h|--help) cat <<'EOF'
setup.sh [--model MODEL_NAME]
  Installs/verifies the full transcription toolchain:
    ffmpeg          brew (macOS) / apt|dnf|pacman (Linux). franken_whisper auto-provisions
                    its own ffmpeg on Linux x86_64, so a miss there is non-fatal.
    franken_whisper official installer one-liner (SHA-256-verified prebuilt binary;
                    Linux amd64/arm64, macOS Intel/AS, WSL; Windows: manual zip from releases)
    whisper-cli     used for onset probes + no-speech verification (brew whisper-cpp on mac;
                    on Linux optional — franken_whisper's native engine covers transcription)
    model           ggml-large-v3-turbo.bin (~1.5GB) from HF ggerganov/whisper.cpp into
                    ~/models/whisper (a franken_whisper default model dir). --model to override
                    (e.g. ggml-tiny.en.bin for a fast smoke test).
  Progress on stderr, summary on stdout. Exit 0 ok | 1 missing hard dep.
EOF
exit 0;; esac
set -u
MODEL="ggml-large-v3-turbo.bin"
[ "${1:-}" = "--model" ] && MODEL="${2:?--model needs a value, e.g. ggml-tiny.en.bin}"
fail=0
say() { echo "$@" >&2; }

# --- ffmpeg ---
if ! command -v ffmpeg >/dev/null 2>&1; then
  say "Installing ffmpeg..."
  if command -v brew >/dev/null 2>&1; then brew install ffmpeg >&2
  elif command -v apt-get >/dev/null 2>&1; then sudo apt-get install -y ffmpeg >&2
  elif command -v dnf >/dev/null 2>&1; then sudo dnf install -y ffmpeg >&2
  elif command -v pacman >/dev/null 2>&1; then sudo pacman -S --noconfirm ffmpeg >&2
  else say "WARN: no package manager found for ffmpeg (franken_whisper auto-provisions on Linux x86_64; decodes m4a/mp3/flac natively anyway)"; fi
fi
command -v ffmpeg >/dev/null 2>&1 && echo "ffmpeg: $(ffmpeg -version 2>/dev/null | head -1)" || echo "ffmpeg: MISSING (ok unless input is video/exotic)"

# --- franken_whisper ---
if ! command -v franken_whisper >/dev/null 2>&1 && [ ! -x "$HOME/.local/bin/franken_whisper" ]; then
  say "Installing franken_whisper (official installer)..."
  curl -fsSL "https://raw.githubusercontent.com/Dicklesworthstone/franken_whisper/main/install.sh?$(date +%s)" | bash >&2 || { say "ERROR: franken_whisper install failed"; fail=1; }
fi
FW="$(command -v franken_whisper || echo "$HOME/.local/bin/franken_whisper")"
[ -x "$FW" ] && echo "franken_whisper: $FW ($("$FW" --version 2>/dev/null | head -1))" || { echo "franken_whisper: MISSING"; fail=1; }

# --- whisper-cli (probe tool; optional but strongly recommended) ---
if ! command -v whisper-cli >/dev/null 2>&1; then
  if command -v brew >/dev/null 2>&1; then say "Installing whisper-cpp..."; brew install whisper-cpp >&2
  else say "WARN: whisper-cli not installed (probes will fall back to franken_whisper --offset-ms/--duration-ms windows)"; fi
fi
command -v whisper-cli >/dev/null 2>&1 && echo "whisper-cli: $(command -v whisper-cli)" || echo "whisper-cli: MISSING (fallback mode)"

# --- model ---
MDIR="${FRANKEN_WHISPER_MODEL_DIR:-$HOME/models/whisper}"
if [ ! -f "$MDIR/$MODEL" ]; then
  mkdir -p "$MDIR"
  say "Downloading $MODEL to $MDIR (large-v3-turbo is ~1.5GB)..."
  curl -fL --progress-bar "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/$MODEL" -o "$MDIR/$MODEL" || { say "ERROR: model download failed"; fail=1; }
fi
[ -f "$MDIR/$MODEL" ] && echo "model: $MDIR/$MODEL ($(du -h "$MDIR/$MODEL" 2>/dev/null | cut -f1))"

say "NEXT: scripts/probe.sh <audio-file>"
exit $fail
