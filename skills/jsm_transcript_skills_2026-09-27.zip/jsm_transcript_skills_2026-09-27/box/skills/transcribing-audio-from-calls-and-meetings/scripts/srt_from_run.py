#!/usr/bin/env python3
"""srt_from_run.py RUN_JSON [--offset SECS] [--vtt] [-o OUTPUT]

Generate SRT (or WebVTT) subtitles from a franken_whisper --json run report,
with the trim offset added back so cues align with the ORIGINAL recording/video.

Why not franken_whisper --output-srt? That sidecar is timed against the TRIMMED
input -- when you cut a hold-music intro, every cue would be early by the trim
amount. This script corrects for it. Writes via python (dcg-safe). Exit 0.
"""
import json, sys, pathlib

def fmt(t, vtt):
    # round to total ms FIRST -- rounding the fractional part alone can yield ms=1000
    # (e.g. 12.9996s -> "00:00:12,1000")
    total_ms = round(t * 1000)
    s, ms = divmod(total_ms, 1000)
    h, rem = divmod(s, 3600)
    m, s = divmod(rem, 60)
    sep = "." if vtt else ","
    return f"{h:02d}:{m:02d}:{s:02d}{sep}{ms:03d}"

def main():
    args = sys.argv[1:]
    if not args or args[0] in ("-h", "--help"):
        print(__doc__); return 0
    offset = float(args[args.index("--offset") + 1]) if "--offset" in args else 0.0
    vtt = "--vtt" in args
    out = pathlib.Path(args[args.index("-o") + 1]) if "-o" in args else None
    d = json.load(open(args[0]))
    segs = d["result"]["segments"]
    lines = ["WEBVTT", ""] if vtt else []
    for i, s in enumerate(segs, 1):
        a, b = s["start_sec"] + offset, s["end_sec"] + offset
        if not vtt:
            lines.append(str(i))
        lines.append(f"{fmt(a, vtt)} --> {fmt(b, vtt)}")
        lines.append(s["text"].strip())
        lines.append("")
    text = "\n".join(lines)
    if out:
        out.write_text(text)
        print(f"wrote {out} ({len(segs)} cues, offset {offset}s)", file=sys.stderr)
    else:
        print(text)
    return 0

if __name__ == "__main__":
    sys.exit(main())
