#!/usr/bin/env python3
"""make_segments.py RUN_JSON [--offset SECS]

Convert a franken_whisper --json run report into the line-oriented segments file the
cleanup agents consume:  [mmm:ss.s] text   (mmm = total minutes, zero-padded)

--offset adds back the seconds trimmed off the front (from find_onset/convert), so
timestamps map to the ORIGINAL recording. Data on stdout; stats on stderr. Exit 0.
"""
import json, sys

def main():
    args = sys.argv[1:]
    if not args or args[0] in ("-h", "--help"):
        print(__doc__); return 0
    path = args[0]
    offset = 0.0
    if "--offset" in args:
        offset = float(args[args.index("--offset") + 1])
    try:
        d = json.load(open(path))
    except json.JSONDecodeError:
        print(f"ERROR: {path} is not valid JSON -- the run likely hasn't finished "
              f"(run.json stays 0 bytes until the end) or it crashed; check the .err log",
              file=sys.stderr)
        return 1
    if "result" not in d or "segments" not in d.get("result", {}):
        print(f"ERROR: no result.segments in {path} -- keys: {list(d)[:8]}; "
              f"check the .err log for a budget/backend failure", file=sys.stderr)
        return 1
    segs = d["result"]["segments"]
    for s in segs:
        st = s["start_sec"] + offset
        m = int(st // 60)
        print(f"[{m:03d}:{st - m*60:04.1f}] {s['text'].strip()}")
    last = segs[-1]["end_sec"] + offset if segs else 0
    print(f"segments={len(segs)} transcript_chars={len(d['result']['transcript'])} "
          f"last_end_orig={last:.1f}s offset={offset}", file=sys.stderr)
    print("NEXT: scripts/sanity_check.py RUN_JSON --duration <trimmed-secs>", file=sys.stderr)
    return 0

if __name__ == "__main__":
    sys.exit(main())
