#!/usr/bin/env python3
"""sanity_check.py RUN_JSON [--duration TRIMMED_AUDIO_SECS]

Detects the known raw-transcript failure modes BEFORE any cleanup effort is spent:
  LOOPS     runs of >=3 consecutive identical segments (context-carryover hallucination)
  REPEATS   any single text appearing >25x ("Thank you." x202 = poisoned file)
  UNIFORM   many segments of near-identical ~30s duration (hold-music windows)
  GAPS      inter-segment gaps >8s (possible dropped speech -- probe each)
  COVERAGE  last segment end vs --duration (tail loss)
  MARKERS   music annotations the model emitted
PASS/FAIL table on stdout. Exit 0 all pass | 2 any FAIL (investigate before chunking).
"""
import json, sys
from collections import Counter

def main():
    args = sys.argv[1:]
    if not args or args[0] in ("-h", "--help"):
        print(__doc__); return 0
    d = json.load(open(args[0]))
    dur = float(args[args.index("--duration") + 1]) if "--duration" in args else None
    segs = d["result"]["segments"]
    fails = 0

    def report(name, ok, detail):
        nonlocal fails
        print(f"{'PASS' if ok else 'FAIL'} {name}: {detail}")
        if not ok: fails += 1

    # LOOPS -- track WHERE each run starts, not just that one exists. The onset
    # timestamp is the actionable number: a loop that begins mid-file is a signal
    # to re-transcribe the remainder with context reset, not junk to filter out.
    run, worst = 1, []
    run_start = segs[0] if segs else None
    for a, b in zip(segs, segs[1:]):
        if a["text"].strip() == b["text"].strip() and len(a["text"].strip()) > 8:
            run += 1
        else:
            if run >= 3:
                worst.append((run, run_start["start_sec"], a["text"].strip()[:40]))
            run = 1
            run_start = b
    if run >= 3 and run_start is not None:
        worst.append((run, run_start["start_sec"], segs[-1]["text"].strip()[:40]))

    def hhmmss(t):
        return f"{int(t) // 60:02d}:{t % 60:04.1f}"

    report("LOOPS", not worst,
           [f"x{n} from {hhmmss(t)}: {txt!r}" for n, t, txt in worst]
           or "no identical-segment runs")

    # MID-FILE LOOP -- a loop whose onset is meaningfully after the start of the
    # file, with real transcription before it. Distinct failure mode from a
    # leading hold-music intro poisoning the whole run: here the head of the
    # transcript is GOOD and must be preserved, and the audio after the loop
    # onset is recoverable via a context-reset rescue pass. Filtering the
    # repeated segments alone silently discards that post-loop content.
    if worst and segs:
        first_onset = min(t for _, t, _ in worst)
        head_secs = first_onset - segs[0]["start_sec"]
        tail_secs = segs[-1]["end_sec"] - first_onset
        if head_secs >= 30 and tail_secs >= 30:
            rescue_from = max(segs[0]["start_sec"], first_onset - 30)
            report("MIDFILE_LOOP", False,
                   f"loop starts {hhmmss(first_onset)} after {head_secs:.0f}s of good "
                   f"transcription, {tail_secs:.0f}s of audio remains -- do NOT just "
                   f"filter the repeats; run the mid-file rescue pass from "
                   f"~{hhmmss(rescue_from)} (see references/WORKFLOWS.md sec I)")
        else:
            report("MIDFILE_LOOP", True,
                   "loop is not mid-file (starts at/near file head -- treat as "
                   "leading-intro poisoning, WORKFLOWS.md sec C)")

    # REPEATS
    counts = Counter(s["text"].strip() for s in segs if len(s["text"].strip()) > 5)
    hot = [(t, c) for t, c in counts.most_common(5) if c > 25]
    report("REPEATS", not hot, hot or f"top repeat x{counts.most_common(1)[0][1] if counts else 0}")

    # UNIFORM 30s windows
    dur30 = sum(1 for s in segs if 28 <= s["end_sec"] - s["start_sec"] <= 31)
    report("UNIFORM", dur30 < max(10, len(segs) * 0.05), f"{dur30} segments of ~30s")

    # GAPS
    gaps = [(round(b["start_sec"] - a["end_sec"], 1), round(a["end_sec"], 1))
            for a, b in zip(segs, segs[1:]) if b["start_sec"] - a["end_sec"] > 8]
    report("GAPS", not gaps, gaps[:8] or "no gaps >8s")

    # COVERAGE
    if dur is not None and segs:
        tail = dur - segs[-1]["end_sec"]
        report("COVERAGE", tail < 30, f"last segment ends {tail:.1f}s before audio end"
               " (probe the tail if >30s)")

    # MARKERS
    n = sum(s["text"].count(x) for s in segs for x in ("♪", "[Music", "(Music", "Loud music"))
    report("MARKERS", n == 0, f"{n} music markers")

    print(f"\nsegments={len(segs)} chars={len(d['result']['transcript'])}")
    if fails:
        print("NEXT: FAILs above mean hallucination/poisoning or dropped audio -- "
              "probe the flagged regions (find_onset.sh / verify_no_speech.sh) before chunking",
              file=sys.stderr)
    else:
        print("NEXT: scripts/chunk_plan.py <n-segment-lines> --chunks 8, then spawn cleanup agents",
              file=sys.stderr)
    return 2 if fails else 0

if __name__ == "__main__":
    sys.exit(main())
