#!/usr/bin/env bash
# Map mean-volume across the file -- the CHEAPEST first-pass structure probe (no ASR).
case "${1:-}" in -h|--help|"") cat <<'EOF'
energy_sweep.sh WAV [WINDOW_SECS] [STEP_SECS]
  Prints mean dB per window (default 60s window every 300s). Run BEFORE whisper
  probes: it's ~free and reveals the file's energy structure:
    hold music   -> steady mean (often LOUDER than speech, e.g. -15dB constant)
    speech       -> fluctuating -18..-28dB
    silence      -> < -45dB
  A level SHIFT between windows marks a structural boundary worth whisper-probing
  (find_onset.sh) -- energy alone cannot distinguish music from speech, it only
  tells you WHERE to spend ASR probes. Exit 0.
EOF
exit 0;; esac
set -eu
WAV="$1"; WIN="${2:-60}"; STEP="${3:-300}"
DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$WAV" | cut -d. -f1)
[ -n "$DUR" ] && [ "$DUR" -gt 0 ] 2>/dev/null || { echo "ERROR: cannot read duration of $WAV" >&2; exit 1; }
ss=0
while [ "$ss" -lt "$DUR" ]; do
  v=$(ffmpeg -hide_banner -ss "$ss" -t "$WIN" -i "$WAV" -af volumedetect -f null /dev/null 2>&1 \
      | grep mean_volume | grep -oE '[-0-9.]+' | tail -1) || v="n/a"
  printf "t=%-6s mean=%sdB\n" "$ss" "${v:-n/a}"
  ss=$((ss + STEP))
done
echo "NEXT: whisper-probe the boundaries between distinct energy regimes: scripts/find_onset.sh $WAV <t1> <t2> ..." >&2
