#!/usr/bin/env bash
# Poll a background franken_whisper run without blocking a long foreground call.
case "${1:-}" in -h|--help|"") cat <<'EOF'
watch_run.sh RUN_JSON [MAX_MINUTES]
  Polls every 60s until the run finishes (RUN_JSON non-empty valid JSON) or
  MAX_MINUTES (default 30) elapses. Liveness = whisper-cli/franken_whisper child
  process present OR .err file mtime advancing -- RUN_JSON stays 0 bytes until the
  very end, so its size is NOT a progress signal.
  Exit 0 done | 3 timeout | 4 process died without output (check the .err).
EOF
exit 0;; esac
set -u
OUT="$1"; MAXMIN="${2:-30}"; ERR="${OUT%.json}.err"
json_ok() { [ -s "$1" ] && python3 -c "import json,sys;json.load(open(sys.argv[1]))" "$1" 2>/dev/null; }
for i in $(seq 1 "$MAXMIN"); do
  if json_ok "$OUT"; then
    echo "DONE after ~${i}m: $(wc -c < "$OUT" | tr -d ' ') bytes"
    echo "NEXT: scripts/make_segments.py $OUT --offset <OFFSET> > segments.txt" >&2
    exit 0
  fi
  # NOTE: system-wide match -- an unrelated transcription elsewhere keeps this "alive"
  if ! pgrep -f "whisper-cli|franken_whisper transcribe" >/dev/null 2>&1; then
    sleep 5  # grace: json write may be in flight
    if json_ok "$OUT"; then continue; fi
    echo "ERROR: no transcription process and no valid output -- last .err lines:" >&2
    tail -5 "$ERR" >&2 2>/dev/null
    exit 4
  fi
  echo "[$i/${MAXMIN}m] running (err mtime: $(stat -f %Sm "$ERR" 2>/dev/null || stat -c %y "$ERR" 2>/dev/null))" >&2
  sleep 60
done
echo "TIMEOUT after ${MAXMIN}m -- still running; re-invoke to keep waiting, or check budgets" >&2
exit 3
