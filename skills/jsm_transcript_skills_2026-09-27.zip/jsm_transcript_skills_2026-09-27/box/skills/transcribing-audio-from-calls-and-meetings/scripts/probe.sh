#!/usr/bin/env bash
# Probe an audio file: duration, codec, channels, volume levels.
case "${1:-}" in -h|--help|"") cat <<'EOF'
probe.sh AUDIO
  Prints duration/codec/sample-rate/channels and mean/max volume (volumedetect).
  Interpreting volume: mean around -20..-26dB is normal for a phone/Zoom recording and
  transcribes fine; mean below ~-40dB or max at 0.0dB (clipping) deserves a listen.
  Data on stdout. Exit 0 ok | 1 unreadable.
EOF
exit 0;; esac
set -eu
F="$1"
[ -f "$F" ] || { echo "ERROR: no such file: $F" >&2; exit 1; }
ffprobe -v error -show_entries format=duration,bit_rate -show_entries stream=codec_name,sample_rate,channels -of default=noprint_wrappers=1 "$F"
ffmpeg -hide_banner -i "$F" -af volumedetect -f null - 2>&1 | grep -E "mean_volume|max_volume" || true
echo "NEXT: scripts/convert.sh \"$F\" <workdir>/audio_16k.wav" >&2
