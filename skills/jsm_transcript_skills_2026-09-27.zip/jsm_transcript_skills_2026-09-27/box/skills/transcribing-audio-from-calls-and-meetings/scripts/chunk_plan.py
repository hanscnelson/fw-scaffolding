#!/usr/bin/env python3
"""chunk_plan.py TOTAL_LINES [--chunks N] [--start LINE]

Prints the line ranges for the parallel cleanup agents (default 8 chunks; use --start
to skip leading lines you've decided to drop). ~165 segment lines per chunk is the
sweet spot: big enough for speaker-attribution context, small enough that one agent
cleans it carefully in a single pass. Each agent also reads the ~8 lines BEFORE its
range as context-only. Exit 0.
"""
import sys

def main():
    args = sys.argv[1:]
    if not args or args[0] in ("-h", "--help"):
        print(__doc__); return 0
    end = int(args[0])
    n = int(args[args.index("--chunks") + 1]) if "--chunks" in args else 8
    start = int(args[args.index("--start") + 1]) if "--start" in args else 1
    size = (end - start + 1 + n - 1) // n
    for i in range(n):
        a = start + i * size
        b = min(a + size - 1, end)
        ctx = f"context-only {max(start, a-8)}-{a-1}, " if i else ""
        print(f"chunk_{i+1}: {ctx}clean lines {a}-{b}")
    print("NEXT: fill assets/cleanup_agent_prompt.md per chunk; spawn ALL agents in "
          "parallel; retry any that hit rate limits", file=sys.stderr)
    return 0

if __name__ == "__main__":
    sys.exit(main())
