#!/usr/bin/env bash
# Conclusively verify a region holds NO real speech before excluding it from the transcript.
case "${1:-}" in -h|--help|"") cat <<'EOF'
verify_no_speech.sh WAV START_SECS END_SECS
  Re-scans [START,END) with whisper-cli -mc 0 (zero carried context -> every window
  independent; brew whisper-cli 1.8.6 has no -nc flag, -mc 0 is the tool):
    pure music/noise -> incoherent window-salad, uniform-30s "Thank you." loops
    real speech      -> surfaces verbatim
  REVIEW THE ENTIRE OUTPUT. Do not pipe through `head` -- a truncated review once left
  3.5 minutes unverified across two review rounds. Output is one line per window; a
  600s region is ~25-40 lines. Exit 0.
EOF
exit 0;; esac
set -eu
WAV="$1"; START="$2"; END="$3"   # integer seconds
command -v whisper-cli >/dev/null 2>&1 || { echo "ERROR: whisper-cli not found (brew install whisper-cpp)" >&2; exit 1; }
MDIR="${FRANKEN_WHISPER_MODEL_DIR:-$HOME/models/whisper}"
MODEL="$(ls "$MDIR"/ggml-*.bin 2>/dev/null | head -1)"
[ -n "$MODEL" ] || { echo "ERROR: no ggml model in $MDIR (run setup.sh)" >&2; exit 1; }
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
DUR=$((END - START))
ffmpeg -y -hide_banner -loglevel error -ss "$START" -t "$DUR" -i "$WAV" "$TMP/region.wav"
whisper-cli -m "$MODEL" -t 8 -l en -mc 0 -np "$TMP/region.wav" 2>/dev/null
echo "NEXT: if all windows are salad/loops, the region is safe to exclude; any verbatim sentence means REAL SPEECH - move the trim point earlier" >&2
