#!/usr/bin/env python3
"""assemble.py CLEAN_DIR TITLE PARTICIPANTS RECORDED_NOTE -o OUTPUT.md [--source NAME]

Concatenate CLEAN_DIR/chunk_1.md..chunk_N.md (natural order) under a standard header
and write OUTPUT.md. Use this instead of shell redirection -- dcg blocks `>` into
~/Downloads and similar guarded paths; python writes are fine.

  TITLE          "Transcript: <event name>"
  PARTICIPANTS   "Jane Doe (host, Acme), John Smith (guest)"
  RECORDED_NOTE  "March 3, 2026 (Zoom webinar via phone voice memo; 1h 51m raw, first
                  ~10 min is pre-webinar hold music and was excluded)"
  --source       original filename for the timestamps line

Re-run after every fix round (idempotent). Exit 0 | 1 missing chunks.
"""
import pathlib, re, sys

def main():
    args = sys.argv[1:]
    if not args or args[0] in ("-h", "--help"):
        print(__doc__); return 0
    out = pathlib.Path(args[args.index("-o") + 1])
    src = args[args.index("--source") + 1] if "--source" in args else None
    clean, title, who, note = pathlib.Path(args[0]), args[1], args[2], args[3]
    chunks = sorted(clean.glob("chunk_*.md"),
                    key=lambda p: int(re.search(r"\d+", p.stem).group()))
    if not chunks:
        print(f"ERROR: no chunk_*.md in {clean}", file=sys.stderr); return 1
    hdr = [f"# {title}", "", f"**Participants:** {who}", f"**Recorded:** {note}"]
    if src:
        hdr.append(f"**Timestamps** are relative to the original recording ('{src}').")
    hdr += ["", "**Transcribed:** franken_whisper (whisper.cpp backend, large-v3-turbo)"
            " · cleaned and speaker-attributed by Claude", "", "---", ""]
    body = "\n".join(hdr) + "\n" + "\n\n".join(c.read_text().strip() for c in chunks) + "\n"
    out.write_text(body)
    print(f"wrote {out} ({out.stat().st_size} bytes, {len(chunks)} chunks)")
    print("NEXT: scripts/audit_final.py OUTPUT.md --segments segments.txt", file=sys.stderr)
    return 0

if __name__ == "__main__":
    sys.exit(main())
