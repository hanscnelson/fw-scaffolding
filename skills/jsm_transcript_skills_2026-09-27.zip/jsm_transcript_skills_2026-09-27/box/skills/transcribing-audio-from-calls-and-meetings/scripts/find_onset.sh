#!/usr/bin/env bash
# Probe short slices across a WAV to locate the real-speech onset (vs hold music/silence).
case "${1:-}" in -h|--help|"") cat <<'EOF'
find_onset.sh WAV [T1 T2 T3 ...]
  Transcribes a 18s slice at each offset (default coarse pass: 0 60 180 420 900 1500)
  and prints the first text per slice. READ THE OUTPUT:
    hold music / silence -> generic hallucination ("I'm going to go ahead and...",
                            "So, let's go.", bare "...", single words)
    real speech          -> verbatim, specific content
  Workflow: coarse pass -> note the first REAL slice -> re-run with a tighter ladder
  between the last fake and first real offsets (e.g. 605 615 625 635 645) -> onset is
  the first real slice; trim at onset-10 via convert.sh.
  Uses whisper-cli + ggml model from $FRANKEN_WHISPER_MODEL_DIR or ~/models/whisper.
  DO NOT run while the main transcription is running (GPU contention ~2x slowdown).
  Exit 0.
EOF
exit 0;; esac
set -eu
WAV="$1"; shift
if [ $# -gt 0 ]; then TIMES=("$@"); else TIMES=(0 60 180 420 900 1500); fi
command -v whisper-cli >/dev/null 2>&1 || { echo "ERROR: whisper-cli not found (brew install whisper-cpp, or probe manually with franken_whisper --offset-ms/--duration-ms)" >&2; exit 1; }
MDIR="${FRANKEN_WHISPER_MODEL_DIR:-$HOME/models/whisper}"
MODEL="$(ls "$MDIR"/ggml-*.bin 2>/dev/null | head -1)"
[ -n "$MODEL" ] || { echo "ERROR: no ggml model in $MDIR (run setup.sh)" >&2; exit 1; }
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
for ss in "${TIMES[@]}"; do
  printf "t=%-6s " "$ss"
  ffmpeg -y -hide_banner -loglevel error -ss "$ss" -t 18 -i "$WAV" "$TMP/p.wav"
  whisper-cli -m "$MODEL" -t 8 -l en -np "$TMP/p.wav" 2>/dev/null | head -2 | tr '\n' ' '
  echo
done
echo "NEXT: bisect between last-fake and first-real offsets, then verify_no_speech.sh 0 <trim>, then convert.sh with TRIM_START=onset-10" >&2
