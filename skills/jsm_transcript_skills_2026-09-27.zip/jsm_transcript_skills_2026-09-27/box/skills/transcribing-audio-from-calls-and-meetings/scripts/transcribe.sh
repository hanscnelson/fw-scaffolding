#!/usr/bin/env bash
# Run franken_whisper on a prepared WAV, in the background, with sane long-audio budgets.
case "${1:-}" in -h|--help|"") cat <<'EOF'
transcribe.sh WAV RUN_JSON [--prompt "Proper Nouns, To Seed"] [--model PATH] [--threads N]
             [--language LANG] [--backend KIND]
  Launches:
    FRANKEN_WHISPER_STAGE_BUDGET_BACKEND_MS=10800000 \
    franken_whisper transcribe --input WAV --backend <whisper-cpp> --model <ggml> \
      --threads <8> --language <en> --no-persist --timeout 10800 --json > RUN_JSON
  (defaults in <>; all overridable via the flags above)
  nohup'd in the background; prints the PID. Poll with:
    ps -p <PID> >/dev/null && echo running || echo done; ls -la RUN_JSON
  RUN_JSON stays 0 bytes until the pipeline finishes (json lands at the end) -- watch
  the .err file mtime / whisper-cli child process for liveness, not the json size.
  Notes:
   * --backend values are KEBAB-CASE (whisper-cpp | insanely-fast | whisper-diarization |
     auto). The README shows snake_case; the binary rejects it.
   * default backend stage budget is 15 MINUTES -- the env var raise is mandatory for
     long audio. --timeout is the overall pipeline deadline in seconds.
   * --prompt seeds domain proper nouns ("frankenterm, Asupersync, Claude Code") and
     measurably reduces homophone garbling -- pass the nouns the user gave you.
   * ~2h audio ~= 7 min on Apple Metal. Don't run probes concurrently (GPU contention).
  Exit 0 launch ok | 1 setup error.
EOF
exit 0;; esac
set -eu
WAV="$1"; OUT="$2"; shift 2
PROMPT=""; MODEL=""; THREADS=8; LANG_="en"; BACKEND="whisper-cpp"
while [ $# -gt 0 ]; do case "$1" in
  --prompt)   PROMPT="${2:?--prompt needs a value}"; shift 2;;
  --model)    MODEL="${2:?--model needs a value}"; shift 2;;
  --threads)  THREADS="${2:?--threads needs a value}"; shift 2;;
  --language) LANG_="${2:?--language needs a value}"; shift 2;;
  --backend)  BACKEND="${2:?--backend needs a value}"; shift 2;;
  *) echo "unknown arg: $1" >&2; exit 1;;
esac; done
FW="$(command -v franken_whisper || echo "$HOME/.local/bin/franken_whisper")"
[ -x "$FW" ] || { echo "ERROR: franken_whisper not found (run setup.sh)" >&2; exit 1; }
if [ -z "$MODEL" ]; then
  MDIR="${FRANKEN_WHISPER_MODEL_DIR:-$HOME/models/whisper}"
  MODEL="$(ls "$MDIR"/ggml-large-v3-turbo.bin "$MDIR"/ggml-*.bin 2>/dev/null | head -1)"
fi
[ -f "$MODEL" ] || { echo "ERROR: no model file (run setup.sh)" >&2; exit 1; }
ARGS=(transcribe --input "$WAV" --backend "$BACKEND" --model "$MODEL"
      --threads "$THREADS" --language "$LANG_" --no-persist --timeout 10800 --json)
[ -n "$PROMPT" ] && ARGS+=(--prompt "$PROMPT")
ERR="${OUT%.json}.err"
nohup env FRANKEN_WHISPER_STAGE_BUDGET_BACKEND_MS=10800000 "$FW" "${ARGS[@]}" > "$OUT" 2> "$ERR" &
echo "PID=$!"
echo "model=$MODEL"
echo "NEXT: poll until done, then scripts/make_segments.py $OUT --offset <OFFSET> > segments.txt && scripts/sanity_check.py $OUT" >&2
