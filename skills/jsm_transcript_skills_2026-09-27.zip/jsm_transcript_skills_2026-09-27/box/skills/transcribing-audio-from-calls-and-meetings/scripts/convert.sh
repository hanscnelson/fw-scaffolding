#!/usr/bin/env bash
# Convert any audio/video input to whisper-native 16kHz mono s16 PCM WAV.
case "${1:-}" in -h|--help|"") cat <<'EOF'
convert.sh INPUT OUTPUT.wav [TRIM_START_SECS]
  ffmpeg -> 16kHz mono pcm_s16le. Pre-normalizing here makes franken_whisper's
  Normalize stage a passthrough (deterministic, no surprises). Optional third arg
  trims the start (use after find_onset.sh: pass onset-10).
  Exit 0 ok | 1 ffmpeg error.
EOF
exit 0;; esac
set -eu
IN="$1"; OUT="$2"; SS="${3:-}"
if [ -n "$SS" ]; then
  ffmpeg -y -hide_banner -loglevel error -ss "$SS" -i "$IN" -ar 16000 -ac 1 -c:a pcm_s16le "$OUT"
  echo "OFFSET=$SS  # add this back when emitting timestamps"
else
  ffmpeg -y -hide_banner -loglevel error -i "$IN" -ar 16000 -ac 1 -c:a pcm_s16le "$OUT"
fi
ls -la "$OUT"
echo "NEXT: scripts/find_onset.sh $OUT   (NEVER skip onset detection)" >&2
