#!/usr/bin/env python3
"""Fuse franken_whisper native (Sortformer) diarization onto word-level ASR output.

franken_whisper >= 0.7 returns ASR segments and diarization turns on two timelines and
does not join them: `segments[].speaker` is null for most segments. This script does the
join and emits speaker-attributed turns.

Pipeline (see references/DIARIZATION.md):
  words from result.transcript (true casing/punctuation) zipped onto segment timings
  -> confidence-weighted overlap vote per word
  -> lone-flip smoothing (one short word cannot flip the speaker)
  -> boundary snapping to sentence punctuation within +/-4 words
  -> merge runs into turns, splitting on pauses

Expects the run to have been produced with word granularity:
  fw transcribe --input a.wav --backend whisper-cpp --diarize \
     --diarization-engine sortformer --speaker-count-hard 2 \
     --max-segment-length 90 --split-on-word --language en --no-persist --json > run.json

Usage:
  fuse_diarization.py run.json --names "Alice,Bob" > turns.txt
  fuse_diarization.py run.json --names "Alice,Bob" --no-speaker > segments.txt
  fuse_diarization.py run.json --names "Alice,Bob" --offset 635 > turns.txt
  fuse_diarization.py run.json --names "Alice,Bob" --gap-run gap.json --gap-offset 508
  fuse_diarization.py run.json --json > turns.json

--names is ordered by speaking time, most-talkative first. Omit it to keep SPEAKER_NN.
--offset adds the phase-1 trim offset back so timestamps map to the ORIGINAL recording.
--no-speaker emits the speaker-free `segments.txt` the audit/verify rounds expect.
Data goes to stdout; diagnostics and a NEXT: breadcrumb go to stderr; non-zero on failure.
"""
import argparse
import json
import sys

ENDS = (".", "?", "!", "…")
TRAILING = '"”’\')]'     # closers stripped before testing for sentence-final punctuation
PAUSE_SPLIT_S = 2.5      # same-speaker gap that still starts a new turn
LONE_WORD_MAX_S = 0.6    # a flip shorter than this is noise, not an interjection
SNAP_WINDOW = 4          # words to search either side for a sentence boundary
ORPHAN_REACH_MS = 1500   # how far an unvoiced word may reach for a nearby turn
BUCKET_MS = 1000         # time-index granularity for turn lookup


def die(msg):
    sys.exit(f"ERROR: {msg}")


def load_words(result, offset=0.0, label="run", required=True, **extra):
    """Timings from segments, text from result.transcript.

    segments[].text is normalized per segment (force-capitalized, '.' appended), which
    under --split-on-word turns every word into "Word." result.transcript keeps the real
    casing and punctuation and aligns 1:1 with the segments. Check the alignment rather
    than trusting it: a future version that changes either side must fail loudly here.

    `required=False` (gap slices) tolerates an empty result: a recovery slice that
    transcribes to nothing may simply mean that region really was silence, which must not
    abort the whole fusion.
    """
    segs = [s for s in result.get("segments", []) if s.get("text", "").strip()]
    toks = result.get("transcript", "").split()
    if not segs:
        if required:
            die(f"{label} has no non-empty segments")
        print(f"WARNING: {label} transcribed to nothing; contributing no words "
              "(that region may genuinely be silence)", file=sys.stderr)
        return []
    if len(segs) != len(toks):
        die(f"{label}: segments ({len(segs)}) and transcript words ({len(toks)}) are not "
            "1:1 -- was it made with --max-segment-length 90 --split-on-word?")
    return [dict(start=s["start_sec"] + offset, end=s["end_sec"] + offset, text=t, **extra)
            for s, t in zip(segs, toks)]


def name_map(diar, turns, names):
    """Rank speakers by voiced time and map them onto the caller's names.

    Prefers speaker_count.speaker_evidence, but that block is not guaranteed to be
    present (the acoustic fallback engine is the default and may not populate it), so
    fall back to summing turn durations.
    """
    ev = {}
    for e in diar.get("speaker_count", {}).get("speaker_evidence", []) or []:
        if "speaker_ref" in e:
            ev[e["speaker_ref"]] = e.get("voiced_duration_ms", 0)
    if not ev:
        for t in turns:
            ev[t["speaker_ref"]] = (ev.get(t["speaker_ref"], 0)
                                    + t["end_ms"] - t["start_ms"])
    # every ref that actually appears in turns must be mappable, evidence or not
    for t in turns:
        ev.setdefault(t["speaker_ref"], 0)

    ranked = sorted(ev, key=lambda r: (-ev[r], r))
    mapping = {r: r for r in ranked}
    for ref, name in zip(ranked, names):
        mapping[ref] = name
    return mapping, ev


def index_turns(turns):
    """Bucket turns by time so each word scans only nearby turns, not all of them.

    A 2-hour recording is ~23k words against ~3.5k turns; the naive all-pairs scan is
    ~80M iterations. Bucketing makes it linear in practice.
    """
    idx = {}
    for t in turns:
        lo = int((t["start_ms"] - ORPHAN_REACH_MS) // BUCKET_MS)
        hi = int((t["end_ms"] + ORPHAN_REACH_MS) // BUCKET_MS)
        for k in range(lo, hi + 1):
            idx.setdefault(k, []).append(t)
    return idx


def nearby(idx, a, b):
    seen, out = set(), []
    for k in range(int(a // BUCKET_MS), int(b // BUCKET_MS) + 1):
        for t in idx.get(k, ()):
            if id(t) not in seen:
                seen.add(id(t))
                out.append(t)
    return out


def vote(words, idx, names):
    """Confidence-weighted overlap vote; `voiced` records genuine overlap only."""
    for w in words:
        a, b = w["start"] * 1000.0, w["end"] * 1000.0
        cands = nearby(idx, a, b)
        tally = {}
        for t in cands:
            ov = min(b, t["end_ms"]) - max(a, t["start_ms"])
            if ov > 0:
                tally[t["speaker_ref"]] = (tally.get(t["speaker_ref"], 0.0)
                                           + ov * t["speaker_confidence"])
        w["voiced"] = bool(tally)
        if not tally:  # reach for a nearby turn; word timings drift against the diarizer
            for t in cands:
                d = max(t["start_ms"] - b, a - t["end_ms"], 0)
                if d < ORPHAN_REACH_MS:
                    tally[t["speaker_ref"]] = (tally.get(t["speaker_ref"], 0.0)
                                               + (ORPHAN_REACH_MS - d) * 0.1)
        # names.get(): a ref present in turns but absent from speaker_evidence (e.g. an
        # UNKNOWN lane) must degrade to its raw label, never raise.
        w["spk"] = names.get(max(tally, key=tally.get)) if tally else None


def smooth(words):
    for i, w in enumerate(words):        # fill gaps from neighbours
        if w["spk"] is None:
            w["spk"] = (words[i - 1]["spk"] if i else None) or next(
                (x["spk"] for x in words[i + 1:] if x["spk"]), None)
    sm = [w["spk"] for w in words]
    for i in range(1, len(words) - 1):
        if sm[i] != sm[i - 1] and sm[i - 1] == sm[i + 1]:
            if words[i]["end"] - words[i]["start"] < LONE_WORD_MAX_S:
                sm[i] = sm[i - 1]
    for w, s in zip(words, sm):
        w["spk"] = s


def snap(words):
    """Move each speaker change to the nearest sentence boundary within SNAP_WINDOW.

    The transcript's punctuation is a better boundary oracle than any timing correction:
    the residual ASR-vs-diarizer error is local, so a global shift cannot fix it.
    """
    def brk(i):
        return i == 0 or words[i - 1]["text"].rstrip(TRAILING).endswith(ENDS)

    moved = 0
    for i in [i for i in range(1, len(words)) if words[i]["spk"] != words[i - 1]["spk"]]:
        # Reassignments below mutate labels, so a boundary recorded earlier may already
        # have been resolved by a previous snap. Re-check before acting on it.
        if words[i]["spk"] == words[i - 1]["spk"] or brk(i):
            continue
        cand = [j for d in range(1, SNAP_WINDOW + 1) for j in (i - d, i + d)
                if 0 < j < len(words) and brk(j)]
        if not cand:
            continue
        j, moved = cand[0], moved + 1
        if j < i:      # boundary is earlier: give words j..i-1 to the NEW speaker
            new = words[i]["spk"]
            for k in range(j, i):
                words[k]["spk"] = new
        else:          # boundary is later: keep words i..j-1 with the OLD speaker
            old = words[i - 1]["spk"]
            for k in range(i, j):
                words[k]["spk"] = old
    return moved


def merge(words):
    out, cur = [], None
    for w in words:
        if cur and w["spk"] == cur["speaker"] and w["start"] - cur["end"] < PAUSE_SPLIT_S:
            cur["words"].append(w["text"])
            cur["end"] = w["end"]
        else:
            if cur:
                out.append(cur)
            cur = dict(speaker=w["spk"], start=w["start"], end=w["end"], words=[w["text"]])
    if cur:
        out.append(cur)
    for t in out:
        t["text"] = " ".join(t.pop("words"))
    return out


def read_json(path):
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except OSError as exc:
        die(f"cannot read {path}: {exc}")
    except ValueError as exc:
        die(f"{path} is not valid JSON: {exc}")


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("run_json")
    ap.add_argument("--names", default="",
                    help="comma-separated speaker names, MOST TALKATIVE FIRST")
    ap.add_argument("--offset", type=float, default=0.0,
                    help="seconds to ADD to every emitted timestamp. Pass the trim "
                         "OFFSET from phase 1 so timestamps map to the ORIGINAL "
                         "recording, not the trimmed WAV (0 if you did not trim)")
    ap.add_argument("--gap-run", action="append", default=[], metavar="RUN.JSON",
                    help="run.json of a re-transcribed dropped window. Repeatable, and "
                         "usually needs to be: recovering a dropped window generally "
                         "takes two overlapping sub-30s slices, because re-transcribing "
                         "the region at its original length reproduces the drop. Pair "
                         "each with a --gap-offset, in order")
    ap.add_argument("--gap-offset", action="append", default=[], type=float,
                    metavar="SECONDS",
                    help="where the corresponding --gap-run starts, in the SAME timebase "
                         "as run_json (i.e. trimmed-audio seconds); --offset is applied "
                         "afterwards. Repeat once per --gap-run")
    ap.add_argument("--json", action="store_true", help="emit JSON instead of text")
    ap.add_argument("--no-speaker", action="store_true",
                    help="emit '[mmm:ss.s] text' with no speaker label -- the raw "
                         "reference format the rest of the skill calls segments.txt "
                         "(audit_final.py counts everything after '] ' as transcript "
                         "words, so speaker labels there would skew retention)")
    args = ap.parse_args()

    # Transcripts carry curly quotes and ellipses; do not let a non-UTF-8 console
    # (Windows) turn that into a UnicodeEncodeError halfway through the output.
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")

    res = read_json(args.run_json).get("result")
    if not res:
        die(f"{args.run_json} has no 'result' block -- is it a franken_whisper run?")
    diar = res.get("diarization")
    if not diar:
        die("run has no diarization block -- re-run without --no-diarize")
    turns = diar.get("turns") or []
    if not turns:
        die("diarization produced no turns; nothing to attribute "
            "(check diarization.fallback_status and speaker_count in the run)")

    given = [n.strip() for n in args.names.split(",") if n.strip()]
    names, ev = name_map(diar, turns, given)
    if len(given) > len(ev):
        print(f"WARNING: {len(given)} names given but diarization found {len(ev)} "
              f"speaker(s); extra names ignored", file=sys.stderr)
    if len(args.gap_offset) != len(args.gap_run):
        die(f"got {len(args.gap_run)} --gap-run but {len(args.gap_offset)} --gap-offset; "
            "pass one --gap-offset per --gap-run, in the same order")

    words = load_words(res, label=args.run_json)
    if args.gap_run:
        # Keep only gap-fill words that fall in a hole. `covered` grows as each slice is
        # accepted, so overlapping slices (the normal case) do not double-insert their
        # shared words -- the first slice to cover a moment wins.
        covered = [(w["start"], w["end"]) for w in words]
        for path, off in zip(args.gap_run, args.gap_offset):
            gap = read_json(path).get("result")
            if not gap:
                die(f"{path} has no 'result' block")
            fresh = [w for w in load_words(gap, off, label=path, required=False,
                                           gapfill=True)
                     if not any(a - 0.3 <= w["start"] <= b + 0.3 for a, b in covered)]
            print(f"gap-fill {path} (+{off}s): {len(fresh)} new word(s)", file=sys.stderr)
            words += fresh
            covered += [(w["start"], w["end"]) for w in fresh]
        words.sort(key=lambda w: w["start"])

    vote(words, index_turns(turns), names)

    # Leading words with no voiced support anywhere are the classic intro hallucination.
    first_voiced = next((i for i, w in enumerate(words) if w["voiced"]), None)
    if first_voiced is None:
        die("no word overlaps any diarization turn -- the ASR and diarization timelines "
            "do not line up; do not trust this run")
    words = words[first_voiced:]

    smooth(words)
    moved = snap(words)
    out = merge(words)

    # Fusion runs entirely in the run's own timebase (words and diarization turns come
    # from the same normalized audio). The trim offset is added once, at emit time, so
    # timestamps map to the ORIGINAL recording -- a skill-wide invariant.
    if args.offset:
        for t in out:
            t["start"] += args.offset
            t["end"] += args.offset

    if args.json:
        json.dump(out, sys.stdout, indent=1, ensure_ascii=False)
        sys.stdout.write("\n")
    else:
        for t in out:
            m, s = divmod(t["start"], 60)
            label = "" if args.no_speaker else f"{t['speaker']}: "
            print(f"[{int(m):03d}:{s:04.1f}] {label}{t['text']}")

    print(f"turns={len(out)} words={len(words)} snapped={moved} "
          f"leading_unvoiced_dropped={first_voiced}", file=sys.stderr)
    print(f"voiced_ms={ev} map={names}", file=sys.stderr)
    print(f"unknown_voiced_share={diar.get('speaker_count', {}).get('unknown_voiced_share')} "
          f"fallback={diar.get('fallback_status')}", file=sys.stderr)
    print("NEXT: eyeball turn boundaries, then chunk for cleanup "
          "(scripts/chunk_plan.py)", file=sys.stderr)


if __name__ == "__main__":
    main()
