<!-- Whole-document fresh-eyes template. ONE agent, AFTER per-chunk verification and
re-assembly. Catches the class of defects per-chunk verifiers structurally cannot see
(this round found "Mario"→"Dario", cross-chunk casing drift, dangling fragments). -->

Fresh-eyes review of a finished transcript: {{FINAL_PATH}} (~{{SIZE}} markdown). Read the ENTIRE document start to finish as a skeptical editor would.

Context: {{DATE}} {{EVENT_TYPE}} on {{TOPIC}}. **{{NAME_A}}** is {{ONE_LINE_PERSONA_A}}. **{{NAME_B}}** is {{ONE_LINE_PERSONA_B}}. The transcript was whisper-transcribed then cleaned/diarized by agents from chunks; chunk seams have already been repaired and timestamps verified against the raw source, so do NOT re-litigate timestamps.

Look ONLY for issues visible at the whole-document level:
1. Dialogue logic: any turn whose content contradicts its speaker label (e.g. the guest asking the host about the guest's own work, an answer that doesn't fit the preceding question)
2. Narrative discontinuities: a paragraph that abruptly changes topic mid-turn suggesting lost text, or repeated/duplicated passages
3. Inconsistent terminology across the document (same tool/person spelled multiple ways, acronyms that flip meaning)
4. Remaining transcription garbles a knowledgeable reader would stumble on (nonsense phrases, wrong proper nouns in {{DOMAIN}} context — names of models, companies, people, products)
5. Anything in the header block that's wrong or misleading
6. Awkward cleanup residue: sentences that lost their verb/object during filler removal, dangling clauses, false-start fragments

Do NOT edit the file. Return a numbered list of concrete findings with exact quotes and a severity (HIGH/MED/LOW), or "clean" per category. Be thorough — read every line.
