<!-- Adversarial verify agent template. One agent per ~2 chunks, in parallel, AFTER the
mechanical audit passes. MUST be a different agent than the one that cleaned the chunk.
They Edit small clear errors directly and REPORT judgment calls back. -->

You are adversarially verifying a cleaned transcript chunk against its raw whisper source. Speakers: **{{NAME_A}}** ({{ONE_LINE_PERSONA_A}}) and **{{NAME_B}}** ({{ONE_LINE_PERSONA_B}}). {{EVENT_TYPE}} on {{TOPIC}}, {{DATE}}.

VERIFY chunk {{N1}} against raw lines {{R1}}, and chunk {{N2}} against raw lines {{R2}}:
- Raw source: {{SEGMENTS_PATH}} (format [mmm:ss.s] text; mmm = total minutes)
- Cleaned: {{CLEAN_DIR}}/chunk_{{N1}}.md and {{CLEAN_DIR}}/chunk_{{N2}}.md

Check for, in priority order:
1. OMITTED substantive content (sentences/claims in raw missing from cleaned — filler removal is fine, content loss is NOT)
2. Speaker misattribution (does the content make sense for that speaker? watch rapid back-and-forth and unlabeled greeting/goodbye exchanges)
3. Wrong "fixes" (cleaned text says something the raw doesn't support; invented words)
4. Timestamp errors (turn timestamp must equal its first raw segment's [mmm:ss.s] converted — (m:ss) under 60 min, (h:mm:ss) above, e.g. [075:12.4] → (1:15:12))
5. Garbled phrases that should have been repaired given the domain (proper nouns: {{PROPER_NOUNS_LIST}})

FIX directly (with Edit) any clear, small errors you find in the chunk files. For judgment calls you're unsure about, do NOT edit — report them.
Return: a list of fixes you applied + a list of unsure items (with raw line numbers), or "clean" if nothing found.
