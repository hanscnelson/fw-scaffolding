<!-- Cleanup agent prompt template. Fill every {{...}}. One agent per chunk, ALL in
parallel. The persona speech-style cues ("long fast monologues" vs "short bursts")
are what make content-based diarization work — don't skimp on them. -->

You are cleaning a chunk of a raw whisper-transcribed {{EVENT_TYPE: 2-person phone call / Zoom webinar / interview}} (recorded {{DATE}}, ~{{DURATION}} of speech) about {{TOPIC}}, between:
- **{{NAME_A}}** ({{FULL_NAME_A}}): {{BIO_A — role, expertise, the projects/terms they'll mention}}. {{SPEECH_STYLE_A — e.g. "Gives long, fast, detailed monologues with lots of 'like, you know' fillers; does live demos."}} {{WHO_RECORDS — e.g. "He's the one recording (iPhone voice memo)."}}
- **{{NAME_B}}** ({{FULL_NAME_B}}, {{AFFILIATION_B}}): {{BIO_B}}. {{SPEECH_STYLE_B — e.g. "Asks probing questions, speaks in shorter bursts, moderates and may relay audience/chat questions."}} {{DOMINANCE_NOTE — e.g. "Nearly all non-A speech is B."}}

TASK:
1. Read {{SEGMENTS_PATH}} lines {{CTX_START}}-{{CTX_END}} for context ONLY (do not include in output), then clean lines {{START}}-{{END}}.{{SPECIAL_NOTES — e.g. "This is the END of the recording — the final segment 'Record.' is the speaker stopping their voice memo; drop it." / "This is the very start — greetings then intro."}}
2. Produce a cleaned, speaker-attributed dialogue in markdown:
   - Format each turn as: `**{{NAME_A}}** *(m:ss)*:` or `**{{NAME_B}}** *(m:ss)*:` followed by the turn text, blank line between turns. Timestamp = the turn's first segment's timestamp. The file format is [mmm:ss.s] = total-minutes:seconds; convert e.g. [022:05.3] → (22:05); for ≥60 minutes use h:mm:ss, e.g. [075:12.4] → (1:15:12).
   - Merge consecutive segments from the same speaker into one turn.
   - Attribute speakers from content using the personas above. Be careful at rapid back-and-forth ("Sure, yeah", "Okay" interjections). If a clearly distinct third voice appears, attribute as `**Audience**` (or a name if identifiable) and note it in your summary.
   - Remove filler words (um, uh, excessive "like", "you know", "sort of", "I mean") and false starts/stutters where removal doesn't change meaning or voice. Keep the conversational tone — do NOT summarize, paraphrase loosely, or omit content. Every substantive sentence must survive.
   - Fix obvious mis-transcriptions using context (e.g. {{DOMAIN_FIXES — seed with the user's proper nouns, e.g. '"cloud code" → "Claude Code", "open AI" → "OpenAI", "Yamlokun" → "Yann LeCun"'}}). If a phrase is garbled beyond confident repair, keep it and append [sic].
3. Write the cleaned markdown to {{CLEAN_DIR}}/chunk_{{N}}.md (no header, no commentary — just the dialogue turns).
4. Return a one-line summary: topics covered + which speaker the chunk ENDS with, plus any low-confidence attribution spots (line numbers).
