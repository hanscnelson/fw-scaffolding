# Troubleshooting

Symptom → cause → fix. First reflex for ANY weird output: `sanity_check.py`, then
`probe.sh` — decide whether the problem is the audio, the run, or the model context.

| Symptom | Cause | Fix |
|---|---|---|
| `error: invalid value 'whisper_cpp' for '--backend'` | README shows snake_case; CLI is kebab-case | `--backend whisper-cpp`; trust `transcribe --help` |
| Run dies ~15 min with budget/deadline error | Default backend stage budget = 15 min | `FRANKEN_WHISPER_STAGE_BUDGET_BACKEND_MS=10800000` + `--timeout 10800` (transcribe.sh sets both) |
| run.json stays 0 bytes "forever" | JSON lands only at the end | `watch_run.sh` — liveness = process/err-mtime, not file size |
| Transcript = one phrase repeated, uniform 30s segments | Hold-music/silence context poisoning | WORKFLOWS.md C: energy-sweep → onset → trim → re-transcribe |
| Tiny transcript, suspiciously fast run | Same poisoning (or wrong input file) | Same; also `probe.sh` the input you actually passed |
| Run is ~2× slower than expected | whisper-cli probes running concurrently (GPU contention) | Serialize: probe → transcribe → verify |
| `no ggml model in ~/models/whisper` | Model not fetched / nonstandard dir | `setup.sh`; or `FRANKEN_WHISPER_MODEL_DIR=...`; resolution order: env → ~/.cache/franken_whisper/models → ~/models/whisper |
| `whisper-cli: command not found` (Linux) | brew-only tool | Use the native engine + `--offset-ms/--duration-ms` windows for probes (WORKFLOWS.md D) |
| `unknown flag -nc` from whisper-cli | 1.8.6 has no `--no-context` | `-mc 0` is the context-killer |
| ffmpeg missing | Fresh box | `setup.sh`; Linux x86_64: franken_whisper auto-provisions; m4a/mp3/flac decode natively anyway |
| Diarization backend errors about HF/auth | pyannote needs a token | `HF_TOKEN`/`FRANKEN_WHISPER_HF_TOKEN`; or token-free `--tiny-diarize` |
| Proper nouns garbled everywhere | Model never saw the jargon | Re-run with `--prompt "Term1, Term2, ..."`; or batch-fix via the homophone sweep |
| Segment `confidence` all ~0.0005 | Field unpopulated by design | Don't filter on it; use the verification rounds |
| First turn's timestamp looks ~15s early | Whisper first-segment span slop | Convention: timestamp = segment start; document, don't guess-fix |
| `dcg blocked` writing the final .md | Shell redirect into guarded dir | `assemble.py` / python writes (already the default path) |
| Audit SPEAKERS fails with a name you don't know | The file was edited outside the session | Diff against your /tmp working copy (Ship-Sync); ask the user before "fixing" |
| Cleanup agent returned rate-limit error | Transient API throttle on parallel spawn | Respawn just the failed chunks, identical prompts (stateless) |
| Audit COVERAGE fails on one window | Real omission OR a window of repaired garbles | Read the missing-words list: fixed garbles = fine; real words = find the dropped lines in raw |
| Building from source: `fsqlite` not found | Sibling path dependency | Clone `frankensqlite` next to `franken_whisper`, or use the prebuilt installer |
| (dev) `cargo test` hangs ~30 min | Gated e2e tests oversubscribe threads | `cargo test -- --test-threads=8`; CI runs `--lib` only |

Still stuck → `franken_whisper robot health` (JSON env/backend/db diagnostic) and the
`.err` log tail tell you which stage died.
