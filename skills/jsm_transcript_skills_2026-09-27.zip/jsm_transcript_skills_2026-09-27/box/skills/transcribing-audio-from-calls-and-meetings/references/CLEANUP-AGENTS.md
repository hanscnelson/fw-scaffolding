# Chunked cleanup agents: chunking, personas, diarization

## Why chunks + parallel agents

A 2h call is ~1,300 segment lines / ~20K raw words — one agent cleaning it all degrades
(fatigue, drift, context bloat). 8 chunks ≈ 165 lines each: enough context to attribute
speakers, small enough for one careful pass. All 8 run in parallel (~1 min wall-clock);
each writes `chunk_N.md` and returns a summary.

`chunk_plan.py TOTAL --chunks 8 [--start N]` computes ranges. Use `--start` to skip
leading lines you decided to drop (hallucinated intro residue before the trim point).

**Rate limits**: with 8 parallel spawns, expect 0-3 transient "server limiting requests"
failures. Just respawn the failed chunks with identical prompts — there is no state.

## The prompt (assets/cleanup_agent_prompt.md) — what each part buys

| Element | Why it matters |
|---|---|
| Persona bios w/ projects & vocabulary | The agent fixes garbles by recognizing what the speaker WOULD say ("Frank and SQLI" → FrankenSQLite). Seed the user's proper nouns here. |
| **Speech-style cues** | The actual diarization mechanism: "long fast monologues, heavy filler" vs "short probing bursts" resolves ambiguous turns better than anything else. |
| Dominance note ("nearly all non-A speech is B") | Collapses the prior for 2-speaker recordings; prevents phantom third speakers. |
| Context-only preamble (~8 lines before range) | Boundary turns attribute correctly without duplicating content. Say "context ONLY (do not include in output)". |
| Timestamp conversion rule with worked example | Agents get [mmm:ss.s]→(h:mm:ss) wrong without an example like [075:12.4] → (1:15:12). |
| "Every substantive sentence must survive" | The single most important constraint — without it agents summarize. Retention ratio 0.75–0.92 verifies compliance. |
| [sic] policy | Keep-and-mark beats guessing; the verify rounds re-adjudicate the [sic]s. |
| Return summary + END speaker + low-confidence spots | The END speaker chains attribution across chunk seams; low-confidence spots become the verify round's worklist. |
| Special notes for first/last chunk | First: "greetings then intro". Last: name the stop-button artifact to drop ("Record."). |

## Diarization heuristics (content-based, 2-speaker)

- The recording owner narrates demos and says things like "I'll send you the link to
  the recording" — anchor identity on such facts.
- Hosts: greet first, introduce, interrupt with "sorry to cut you off", batch audience
  questions, close the session.
- High-risk zones: rapid back-and-forth ("Sure." / "Yeah." / "Okay."), unlabeled
  greeting/goodbye exchanges, interjections mid-monologue. Expect the verify round to
  focus there; ask cleanup agents to flag them rather than guess silently.
- Mechanical signal (optional): `--tiny-diarize` adds speaker-turn tokens (no HF token);
  pyannote (`--diarize --num-speakers 2`, HF token) gives neural labels. Both give
  TURN BOUNDARIES, not identities — you still map turns→names by content.

## Assembly

`assemble.py` (python — dcg blocks shell `>` into ~/Downloads). Header carries:
participants, recorded date + capture chain, what was excluded and why ("first ~10.5
min is pre-webinar hold music and was excluded"), timestamps-are-original-file note,
and the transcribed-by credit. Re-run after every fix round — chunks are the source of
truth until the final audit rounds start editing FINAL.md directly (after that, edit
FINAL.md and treat chunks as stale).
