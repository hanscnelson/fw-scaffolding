# Pitfalls (every one of these actually happened)

<!-- TOC: README casing | 15-min budget | 0-byte run.json | GPU contention | head-truncated scan | padded-grep misses | seam splits | phrase-probe false alarms | [sic] misuse | wrong-name re-adjudication | dcg redirects | stop-button artifact | first-turn slop | quiet≠broken | rate limits | over-harmonizing | ship-sync drift | batch fixes | external edits | -nc trap | (dev) test threads -->

## The README lies about --backend casing
README documents `--backend whisper_cpp`; the binary takes **kebab-case** `whisper-cpp`
and errors on snake_case. Cost a failed launch + relaunch. `transcribe --help` is truth.

## Default backend budget kills long jobs at 15 min
`FRANKEN_WHISPER_STAGE_BUDGET_BACKEND_MS=10800000` (and `--timeout 10800`) or a 2h file
dies mid-transcription with a budget error.

## run.json is 0 bytes until the very end
Don't conclude the run is stuck because the output file isn't growing. Poll the child
whisper-cli process / `.err` mtime instead.

## GPU contention doubles the main run
Running whisper-cli onset probes or `-mc 0` scans WHILE franken_whisper is transcribing
contends for Metal: a ~6.7 min run became 12.4 min. Probe first, then transcribe, then
verify — serialized.

## `head` on a verification scan = unverified audio
Piping the `-mc 0` no-speech scan through `head -40` silently dropped minutes 7–10.5 of
the excluded region; the gap survived TWO review rounds before a fresh-eyes pass caught
it. Verification output gets read in FULL, always.

## Context-padded grep misses long-line duplicates
`grep -o ".{60}complimentary.{60}"` found one occurrence; a second hid mid-paragraph in
the same long line (regex needs 60 chars each side; line-oriented matching had already
consumed them). Count with the BARE pattern; only then locate with padding.

## Chunk seams split sentences
Cleanup agents given hard line ranges end chunk N mid-sentence and start chunk N+1 with
`...continuation` or a lowercase fragment as a NEW turn. Audit every seam against raw;
merge the sentence; re-anchor the next turn's timestamp to the next sentence's segment.

## Naive phrase probes false-alarm on good cleaning
Probing "5 raw words present in final?" failed 11/16 windows on a transcript that was
actually fine — the probes contained the very fillers and garbles the cleaning is
supposed to remove. Use ≥7-char non-filler content-word coverage instead (≥85%).

## [sic] on a repaired word
An agent wrote "ext4 [sic]" after confidently repairing "ext forum"→ext4. [sic] means
"kept unrepaired" — audit every occurrence.

## A "wrong name" can be a right name from the wrong frame
A sentence about AI-lab rivalry contained "Mario", confidently repaired to "Dario"
from context. A later review round discovered a real "Mario" exists in the speaker's
own tool ecosystem — suddenly the earlier fix looked like it might have destroyed a
correct reference. Raw-context re-adjudication (every surrounding sentence was about
the rival lab's leadership) confirmed the repair was right — now with far stronger
evidence than the original fix had. Lesson: re-judge against raw when new evidence
appears; don't assume either direction.

## dcg blocks shell redirects into ~/Downloads
`echo > ~/Downloads/x.md` is blocked by the destructive-command guard. Assemble and
edit final files with python/Write/Edit tools.

## Stop-button artifacts
Voice-memo recordings end with the speaker tapping stop — whisper renders it as a final
"Record." segment. Drop it (instruct the last-chunk agent), but probe the tail so real
closing words aren't lost.

## First-turn timestamp slop
Whisper's first segment can span ~20s with the utterance at its tail; the displayed
turn time can be ~15s early. Convention (documented in the header): timestamp = segment
start. Don't "fix" it by guesswork.

## Quiet ≠ broken
−22dB mean volume transcribes fine. When a transcription looks bad, the cause is
context poisoning (see HALLUCINATION.md), not gain. volumedetect first, then onset
probes — don't reach for loudness filters.

## Rate-limited parallel agents
Spawning 8 cleanup agents at once: expect 0-3 transient API rate-limit failures.
Stateless — respawn the failed ones with identical prompts.

## Don't harmonize what's authentically different
`frankentui` (lowercase) and `FrankenSQLite` (camel) are both official stylings of
different products. Harmonize a SINGLE tool's mixed casing (cass/CASS); leave
cross-product differences alone — "fixing" them introduces errors.

## The shipped copy silently diverges from the working copy
Post-assembly fixes get applied to one of the two copies (working /tmp vs shipped
~/Downloads) and the other ships stale — or a later re-assembly from chunks
overwrites fixes made directly to the final. Rule: after the audit rounds start
editing FINAL.md, chunks are stale; keep BOTH copies in sync and prove it:
`diff /tmp/<w>/transcript_final.md ~/Downloads/<final>.md && echo "SHIPPED == FINAL"`.

## Ad-hoc fixes are unreviewable; batch them
Apply accumulated repairs as one python list of `(old, new)` tuples, each guarded by
`assert old in t` — a tuple that doesn't assert is a silent no-op when an earlier fix
already changed the text. Then re-run the audit: fixes regress.

## The file can change under you between sessions
A transcript audited ALL-GREEN was later found with 9 turns renamed to a speaker name
that never existed in the session — edited externally (user/another agent) hours
after shipping. `audit_final.py --speakers "A,B"` catches this mechanically. When it
fires on a name you don't know: diff against your working copy and ASK the user —
it's probably their correction (the real greeter's name), not corruption. Never "fix"
back without asking.

## whisper-cli flag trap
There is no `-nc/--no-context` in brew whisper-cli 1.8.6 — the zero-context scan flag
is `-mc 0`. Check `whisper-cli --help` before assuming a flag from whisper.cpp docs.

## (dev) franken_whisper test suite oversubscription
`cargo test` on the full lib suite spawns gated e2e tests that each run
multi-threaded inference — default test parallelism oversubscribes cores and the
suite "hangs" ~30 min. `cargo test -- --test-threads=8` (~305s). CI runs `--lib`
only, so integration breakage can lurk — relevant when you patch franken_whisper
itself mid-transcription-project.
