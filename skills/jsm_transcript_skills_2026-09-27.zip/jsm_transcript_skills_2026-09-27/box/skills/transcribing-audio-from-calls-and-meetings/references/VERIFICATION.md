# The four verification rounds

<!-- TOC: R1 Mechanical | R2 Adversarial Per-Chunk | R3 Fresh-Eyes | Applying Fixes (Batch-Fix/Ship-Sync) | R4 Final Sweep | Burned Homophone Table -->

Every check below corresponds to a defect actually found in production transcripts.
Each round catches a class the previous round structurally cannot. Run all four; finish
only when `audit_final.py` is ALL GREEN **after the last edit** (fixes regress).

## Round 1 — mechanical (audit_final.py + per-chunk retention)

- **Seams**: chunk agents emit `**Name**: ...continuation` ellipsis turns and
  lowercase-start turns when a sentence spans a chunk boundary. Fix by merging the
  split sentence into the prior turn and re-anchoring the new turn's timestamp to the
  next sentence's raw segment. Audit EVERY seam's raw lines (`sed -n '<b-1>,<b+2>p'
  segments.txt` at each boundary b).
- **Retention ratio** per chunk: cleaned/raw words 0.75–0.92. <0.75 = content lost
  (reject the chunk, respawn); >0.92 = fillers kept.
- **Content-word coverage**: per raw window, % of ≥7-char non-filler words present in
  the final; ≥85% passes. **Do NOT use raw 5-word phrase probes** — they false-alarm
  because removed fillers and repaired garbles make raw phrases legitimately absent.
  The "missing" words list is itself useful: it should contain only garbles you FIXED
  (butterfs, peidantic, ratatouille...) — a real word there means an omission.
- **Timestamps**: monotonic; (m:ss) under 60 min, (h:mm:ss) above; no minutes≥60.
- **Speakers**: every turn name ∈ the expected set (`--speakers "A,B"`) — catches
  phantom speakers from cleanup AND external edits to the shipped file later.
- Markdown balance, residual um/uh, music markers.

## Round 2 — adversarial per-chunk verify agents (assets/verify_agent_prompt.md)

Different agents than the cleaners; 2 chunks each; checks ordered: omissions →
misattribution → wrong fixes → timestamps vs raw → unrepaired garbles. They Edit
small clear errors directly and REPORT judgment calls. Found in practice: timestamp
drift (turn anchored to the wrong segment), "ratio codes"→erasure-codes flags.
You adjudicate every reported item against the raw segments yourself.

## Round 3 — whole-document fresh-eyes agent (assets/fresh_eyes_prompt.md)

ONE agent reads FINAL.md end-to-end as a skeptical editor: dialogue logic (does this
turn's content fit its speaker label?), narrative discontinuities, cross-chunk naming
consistency, garbles a domain reader trips on, header accuracy, cleanup residue
(dangling fragments, lost verbs). It does NOT edit — it reports with severity.
Per-chunk verifiers structurally cannot catch cross-chunk issues; this round found
"Mario"→"Dario", "toolie"→TUI, wall→WAL, complimentary→complementary, a false-start
fragment, and a misused [sic] — all AFTER two earlier rounds passed.

## Applying fixes between rounds

- **Batch-Fix**: apply accumulated repairs as one python list of `(old, new)` tuples,
  each with `assert old in t` (an unasserted tuple is a silent no-op when an earlier
  fix already touched the text). One reviewable block beats N ad-hoc edits.
- **Ship-Sync**: if a working copy and a shipped copy both exist, every fix batch ends
  with `diff working shipped && echo "SHIPPED == FINAL"`. Once audit rounds edit
  FINAL.md directly, the chunk files are stale — never re-assemble over fixes.
- Re-run `audit_final.py` after EVERY batch — fixes regress (a "fixed" homophone came
  back twice via a second occurrence hiding in a long line).

## Round 4 — final mechanical sweep (audit_final.py again, plus eyeballs)

- **Homophone sweep** with bare patterns (see table). Context-padded grep
  (`grep -o ".{60}WORD.{60}"`) **misses duplicates in long paragraph lines** — count
  with the bare word, then locate.
- **ALL-CAPS acronym inventory**: every acronym verified real (one garbled acronym =
  one bug; "HITS" turned out to be HITS centrality — verify, don't assume).
- **Mixed-casing harmonization**: same tool as `cass`/`CASS`, `bv`/`BV` → one form
  (prefer the project's official styling). Leave authentic per-product differences
  alone (frankentui vs FrankenSQLite) — harmonizing by guess introduces errors.
- **Contamination scan**: prompt-leak strings, names from OTHER transcripts' prompts.
- **[sic] audit**: each must mark an unrepaired garble; never a repaired word.
- **Re-adjudication**: when new evidence challenges an earlier fix (the misheard
  name also belongs to a real person in the speaker's domain — was the repair
  wrong?), pull the raw context and re-judge. Strengthen or revert; never let two
  fixes silently conflict.

## The burned homophone table (extend per domain)

| Whisper wrote | Reality | Clue |
|---|---|---|
| complimentary | complementary | "complementary and different" |
| wall file(s) | WAL file(s) | SQLite write-ahead log context |
| toolie | TUI | "too-ee"; terminal UI context |
| Mario | Dario (Amodei) | AI-lab-leadership context |
| a ratio codes | erasure codes | fountain-code/RaptorQ context |
| Tokyo | Tokio | Rust async |
| Ratatouille | Ratatui | Rust TUI lib |
| IOC | IOI | programming olympiad |
| peidantic | Pydantic | Python |
| Western | WezTerm | terminal |
| cloud code / claw | Claude Code / Claude | |
| codecs | Codex(es) | OpenAI agent |
| cast | cass | session search |
| ButterFS / ext forum | btrfs / ext4 | filesystems |
| a super sync/sink/sin/saying | Asupersync | |
| Frank and X / Franken X | FrankenX | product family |
| T'Angelo's | tiangolo's | FastAPI author |
| rust QLite | rusqlite | |
| step chain | step change | |
| Yamlokun | Yann LeCun | |
| Grock | Grok | |
| starts | stars | GitHub context |
| re-off | re-auth | |

Repair rule: fix only when context proves it; phonetic similarity + domain fit + the
sentence still meaning something = proof. Otherwise `[sic]`.
