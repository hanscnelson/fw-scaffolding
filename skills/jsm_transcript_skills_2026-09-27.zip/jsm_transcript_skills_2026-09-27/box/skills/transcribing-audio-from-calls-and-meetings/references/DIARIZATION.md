# Native diarization: from Sortformer turns to speaker-attributed dialogue

<!-- TOC: The Shape of the Problem | Step 1 Transcribe | Step 2 Name the Speakers | Step 3 Fuse | Step 4 Smooth | Step 5 Snap | Free Hallucination Filter | 3+ Speakers | What Not To Do | Checks -->

## The shape of the problem

franken_whisper 0.7.x ships real neural diarization (NVIDIA Streaming Sortformer, in
Rust, on by default). It is good — 0.89–0.93 mean assignment confidence on ordinary
2-person call audio. But it hands you **two artifacts on two timelines** and does not
join them: an ASR segment list, and a separate `result.diarization.turns` list. The join
is yours to do, and the naive version of it is wrong in a specific, predictable way.

This file is that join. `scripts/fuse_diarization.py` implements it.

```
result.segments[]              text + start_sec/end_sec, speaker mostly null
result.diarization.turns[]     start_ms/end_ms/speaker_ref/speaker_confidence, no text
```

Two failure modes if you join them carelessly:

1. **Coarse segments swallow both speakers.** Default segmentation runs up to 30 s per
   segment. A segment holding `"Hey — how are you? Good, should I share my screen?"` has
   no single correct speaker. Fix at the source: transcribe at **word granularity**.
2. **Boundaries lag by about one word.** Even at word granularity, overlap-voting puts
   the first/last word of each turn on the wrong speaker. This is not a constant offset —
   sweeping a global time shift over ±1.2 s barely helped, because the ASR windowing and
   the diarizer account for silence differently. Fix it with punctuation, not with a
   timing model. Measured on a 45-minute 2-person call, counting turns that begin
   mid-sentence (a lowercase first word):

   | Approach | Bad boundaries |
   |---|---|
   | overlap vote only | 122 |
   | best global time shift (−0.1 s, swept over ±1.2 s) | ~108 |
   | **punctuation snapping, no shift** | **84** |

   The residual 84 are mostly *genuine* interruptions, where one speaker really does cut
   in mid-sentence. `scripts/fuse_diarization.py` reproduces the 122 → 84 figure; it
   deliberately has no shift knob, because the shift is the worse tool.

Why it matters more than it sounds: the words at turn edges are disproportionately short
confirmations — "Yeah", "Right", "No, no", "Exactly" — so edge errors systematically put
one person's agreement in the other person's mouth.

## Step 1 — transcribe at word granularity

```bash
FW_RETRY_FAILED_WINDOW=1 fw transcribe \
  --input audio_16k.wav --backend whisper-cpp \
  --diarize --diarization-engine sortformer --speaker-count-hard 2 \
  --language en --no-persist \
  --max-segment-length 90 --split-on-word \
  --prompt "<proper nouns from the user>" \
  --json > run.json 2> run.err
```

`--split-on-word` with a small `--max-segment-length` yields one word per segment (mean
~0.38 s). `--speaker-count-hard 2` on a known 2-person call is the highest-value flag
here. Take the **text** from `result.transcript`, not from `segments[].text` — see
`references/FRANKEN-WHISPER.md`, gotcha 4.

## Step 2 — name the speakers from voiced duration, not from `SPEAKER_00`

The refs are arbitrary. Map them using the evidence block, then confirm against the
personas the user gave you:

```python
ev = {e["speaker_ref"]: e["voiced_duration_ms"]
      for e in diar["speaker_count"]["speaker_evidence"]}
ranked = sorted(ev, key=ev.get, reverse=True)
NAMES = {ranked[0]: "<person who talks most>", ranked[1]: "<the other>"}
```

Ask the user up front **who did most of the talking** — that one question turns an
unlabeled clustering into named speakers deterministically. A 2.5:1 voiced-duration split
matching "one asks short questions, the other explains at length" is strong confirmation. If the
split is near 50/50, do not guess from duration: attribute the first few turns by content
(who greets, who answers) and propagate.

Sanity-check the labeling against the opening exchange. A greeting pair
("Hey <Name>." / "Hey, how are you?") tells you unambiguously who is who, because one
speaker says the *other's* name.

## Step 3 — fuse: confidence-weighted overlap vote per word

For each word, tally every diarization turn that overlaps it, weighting by turn
confidence so a shaky turn cannot outvote a confident one:

```python
tally = collections.defaultdict(float)      # plain dict + `+=` would KeyError
for t in turns:
    ov = min(word_end, t["end_ms"]) - max(word_start, t["start_ms"])
    if ov > 0:
        tally[t["speaker_ref"]] += ov * t["speaker_confidence"]
```

Words with no overlap at all: widen to the nearest turn within ~1.5 s. Words still with
nothing are non-voiced — see the hallucination filter below.

Two things the naive version of this gets wrong, both of which bite in practice:

- **Scanning every turn per word is quadratic.** A 2-hour recording is ~23k words against
  ~3.5k turns — 80M comparisons. Bucket the turns into a time index (1-second buckets) and
  look up only the neighbourhood; measured 7.8× faster on a 45-minute call with
  byte-identical output.
- **A `speaker_ref` in `turns` need not appear in `speaker_evidence`.** An `UNKNOWN` lane
  (or an evidence block the acoustic fallback never populated) will `KeyError` a
  name-lookup dict. Degrade to the raw label instead of raising.

## Step 4 — smooth: one word may not flip the speaker

A single word bracketed by the same speaker on both sides is almost always noise, not a
one-word interjection — unless it is long enough to be one. This is a lone-flip filter
(not a true median filter) with a duration escape hatch, so a real one-word interjection
still survives:

```python
if smoothed[i] != smoothed[i-1] and smoothed[i-1] == smoothed[i+1]:
    if words[i]["end"] - words[i]["start"] < 0.6:   # too short to be a real turn
        smoothed[i] = smoothed[i-1]
```

## Step 5 — snap boundaries to sentence punctuation (the important one)

The transcript's own punctuation is a better boundary oracle than any timing correction.
At each speaker change, look ±4 words for a position preceded by `.` `?` `!` or `…`, and
move the boundary there:

```python
for i in speaker_changes:
    if sentence_break_before(i):      continue
    j = nearest position within ±4 words with a sentence break before it
    reassign the words between i and j to whichever side j implies
```

Terminator set: `.` `?` `!` `…` — tested, don't widen it by guess. Adding `--`/`—`
(Whisper's interruption marker) is neutral: same mid-sentence-start count, slightly fewer
snaps. Adding `,` is **worse** (83 → 90), because commas are far too common to mark a
turn. Strip trailing closers (`"` `’` `)` `]`) before testing the last character.

Measured effect on a 45-minute call: turns starting mid-sentence fell **122 → 84**,
against ~108 for the best global time shift (see the table in "The shape of the problem").
Cheap, model-free, and strictly better than a timing correction.

One implementation note: reassigning words mutates the labels the boundary list was
computed from, so re-check each recorded boundary before acting on it — a previous snap
may already have resolved it. On 2-speaker data, and across 400 fuzzed 3-speaker layouts,
this guard changed nothing; it is cheap insurance against acting on stale state, not a
fix for an observed misattribution.

## The free hallucination filter (do not skip this)

Diarization voiced-frame evidence is an **independent** witness to whether a region
contains speech at all — which makes it the best hallucination detector in the pipeline.
Whisper invents fluent text over silence; Sortformer does not hear a speaker there.

```python
voiced = sum(min(b, t["end_ms"]) - max(a, t["start_ms"])
             for t in turns if t["end_ms"] > a and t["start_ms"] < b)
```

Interpretation over a suspect window:
- **0 s voiced** → pure hallucination. Delete the text. (A real case: 70 s of a
  confidently-repeated sentence over a region with exactly zero voiced frames.)
- **a couple of seconds voiced in a long window** → one real utterance plus a degenerate
  repeat loop. Keep the first instance, delete the repetitions. Repeats at suspiciously
  round intervals (identical text every 2.0 s) confirm it.
- **leading words with no voiced support at all** → the classic intro hallucination
  ("I'm going to go ahead and see you in the next video" over a quiet lead-in). Drop the
  leading unvoiced run before anything else.

This does not replace the onset check in the main workflow — it complements it. Onset
detection protects against context poisoning *before* transcribing; this catches loops
*after*, anywhere in the file, using evidence the older pipeline did not have.

## Three or more speakers

Sortformer is **capped at 4 lanes** (`speaker_lane_capacity: 4`), and
`capacity_semantics` says plainly that the true count is unknown beyond that. So:

- 3–4 speakers: `--speaker-count-hard N` if you know N, else
  `--speaker-count-range 2..4`. Verify `speaker_count.status == "satisfied"`.
- 5+ speakers: the cap will silently merge people. Use `--speaker-count-range` and treat
  the labels as *clusters*, resolving identities by content; tell the user the transcript
  cannot be fully separated by the model and which stretches are uncertain.
- Watch `unknown_voiced_share`. A quarter of voiced time unattributed is normal on
  crosstalk-heavy calls; much more means the count is wrong.
- `overlap_suspected: true` on a turn marks simultaneous speech — a good place to expect
  errors and to check by hand. **The fusion has a specific, reproducible failure there:**
  a short interjection that lands *inside* another speaker's long bracketing turn gets
  absorbed by that speaker, because both turns overlap the word fully and the vote falls
  through to confidence. Typical shape: A is mid-worry, B cuts in with a short denial,
  and the denial is absorbed into A's turn — so the transcript shows the worried party
  dismissing their own worry. Content adjudication is the only fix: the person raising a
  concern is not the person waving it away. Neither the vote nor the punctuation snap can
  see that; you can.

## What not to do

- **Don't trust `segments[].speaker`.** Mostly `null`; using it drops most of the file.
- **Don't fix boundaries with a global time shift.** Measured: barely helps. The error is
  local.
- **Don't diarize on 30-second segments** and hope. Re-transcribe at word granularity;
  ASR is the cheap half of the run.
- **Don't let the diarizer name people.** It produces `SPEAKER_00`. Names come from the
  user plus content evidence.
- **Don't treat `speaker_confidence` like the ASR `confidence` field.** The ASR one is
  unpopulated noise; the diarization one is real and worth weighting by.

## Checks before you hand off

```bash
jq '.result.diarization | {implementation, fallback_status,
    status: .speaker_count.status, unknown: .speaker_count.unknown_voiced_share,
    ev: [.speaker_count.speaker_evidence[] | {speaker_ref, voiced_duration_ms,
         mean_assignment_confidence}]}' run.json
```

- `fallback_status == "not_needed"` and `speaker_count.status == "satisfied"`
- `mean_assignment_confidence` ≥ ~0.85 per speaker
- voiced-duration split matches the dominance the user described
- turn count is plausible (a 45-min 2-person call ≈ 250 turns after fusing; thousands
  means smoothing is not running, dozens means it is over-merging)
