# Operator Library

<!-- TOC: ⚡Energy-Sweep | 🎯Onset-Bisect | 🔓Context-Decouple | 🎭Persona-Diarize | 🧩Chunk-Clean | 📏Retention-Gate | 🔍Content-Word-Coverage | 🪡Seam-Audit | 🔊Homophone-Sweep | ⚔️Adversarial-Verify | 👁Fresh-Eyes-Read | ⚖️Re-Adjudicate | 🔁Ship-Sync | 📦Batch-Fix -->

## The cards

Composable cognitive moves. Each card: definition, triggers, failure modes, and what to
actually do. Compose freely — a poisoned-file rescue is Energy-Sweep → Onset-Bisect →
Context-Decouple → re-transcribe → the full clean/verify stack.

### ⚡ Energy-Sweep
**Definition**: Map mean-dB per window across the whole file before any ASR.
**Triggers**: every new recording; transcript came back suspicious; unknown structure.
**Failure modes**: treating energy as speech-detection (music is often LOUDER than
speech — energy finds boundaries, not content); windows too sparse (missing a short
regime).
**Do**: `energy_sweep.sh WAV` → note level shifts → whisper-probe each boundary.

### 🎯 Onset-Bisect
**Definition**: Locate real-speech onset by transcribing short slices, coarse→fine.
**Triggers**: intro region suspected non-speech; energy regime shift; REPEATS/UNIFORM
sanity failures.
**Failure modes**: probe window catching only the tail of an utterance (looks empty —
pad the trim by 10s); declaring onset from one probe (always bracket with a fake AND
a real slice); probing concurrently with the main run (GPU contention).
**Do**: `find_onset.sh WAV` coarse ladder → tighter ladder between last-fake/first-real
→ trim at onset−10 → record OFFSET.

### 🔓 Context-Decouple
**Definition**: Re-scan a region with zero carried context (`whisper-cli -mc 0`) so
each window is judged independently — music yields salad, speech surfaces verbatim.
**Triggers**: before excluding ANY audio from the transcript; adjudicating "is there
speech in here?".
**Failure modes**: truncating the output review (`head` left 3.5 min unverified once);
relying on the normal contexted pass (carryover masks isolated speech).
**Do**: `verify_no_speech.sh WAV START END` → read EVERY line; loop-count with
`sed 's/^\[[^]]*\] *//' out | sort | uniq -c | sort -rn`.

### 🎭 Persona-Diarize
**Definition**: Attribute speakers by content against rich persona bios with
speech-style cues, anchored on identity facts ("I'll send you the recording" = the
recorder).
**Triggers**: any multi-speaker recording without reliable mechanical diarization.
**Failure modes**: thin personas (style cues are the mechanism — "long monologues,
heavy filler" vs "short probing bursts"); guessing silently at rapid back-and-forth
(flag instead); phantom third speakers (state the dominance prior).
**Do**: fill assets/cleanup_agent_prompt.md personas from the user's answers; require
agents to report low-confidence spots.

### 🧩 Chunk-Clean
**Definition**: Split segments into ~165-line chunks, one parallel agent each, with
context-only preamble and hard fidelity rules.
**Triggers**: anything longer than ~15 minutes of speech.
**Failure modes**: seam sentence-splits (audit every boundary); agents summarizing
(the "every substantive sentence must survive" line + Retention-Gate catch it);
rate-limit losses (respawn, stateless).
**Do**: `chunk_plan.py` → spawn all → collect END-speaker summaries to chain seams.

### 📏 Retention-Gate
**Definition**: cleaned/raw word ratio as a mechanical fidelity contract: 0.75–0.92.
**Triggers**: after every cleanup pass; after any large edit batch.
**Failure modes**: applying to a translated/paraphrased deliverable (it's for
verbatim-clean only); accepting 0.94 because "it reads fine" (fillers were kept).
**Do**: below 0.75 → reject chunk, respawn; above 0.92 → second filler pass.

### 🔍 Content-Word-Coverage
**Definition**: % of ≥7-char non-filler raw words present in the final, per window.
**Triggers**: omission anxiety; replaces naive phrase-probing (which false-alarms on
removed fillers/repaired garbles).
**Failure modes**: reading "missing" garbles as losses — the missing list should
contain ONLY garbles you fixed (butterfs, peidantic); a real word there = an omission.
**Do**: `audit_final.py` COVERAGE; investigate any window <85%.

### 🪡 Seam-Audit
**Definition**: Inspect every chunk boundary in the final against raw for mid-sentence
splits, `...` continuation turns, lowercase turn-starts.
**Triggers**: after assembly; after any re-chunking.
**Failure modes**: merging without re-anchoring the timestamp (anchor the new turn to
the NEXT sentence's raw segment); assuming consecutive same-speaker turns are wrong
(monologue re-anchors are fine — only sentence splits are bugs).
**Do**: `audit_final.py` SEAMS + `sed -n '<b-1>,<b+2>p' segments.txt` at each boundary.

### 🔊 Homophone-Sweep
**Definition**: Hunt phonetically-plausible wrong words that survive cleanup, with
bare-pattern counting.
**Triggers**: Round 4; any domain with proper nouns; after adding new vocabulary.
**Failure modes**: context-padded grep missing long-line duplicates (count bare,
THEN locate); auto-fixing without context proof ([sic] instead); not extending the
burned table with the user's domain nouns.
**Do**: `audit_final.py` HOMOPHONES + the table in VERIFICATION.md + `--prompt`
seeding at transcribe-time to prevent them at the source.

### ⚔️ Adversarial-Verify
**Definition**: A different agent re-derives each chunk's correctness from raw:
omissions → misattribution → wrong fixes → timestamps → garbles.
**Triggers**: after mechanical audit passes (don't waste agent time on what a script
catches).
**Failure modes**: verifier = cleaner (fresh agent, always); letting verifiers fix
judgment calls (they fix only CLEAR errors, report the rest).
**Do**: assets/verify_agent_prompt.md, 2 chunks per agent, parallel.

### 👁 Fresh-Eyes-Read
**Definition**: One agent reads the assembled document end-to-end as a skeptical
editor — dialogue logic, cross-chunk consistency, domain garbles, header truth.
**Triggers**: after per-chunk verification; before declaring done.
**Failure modes**: skipping because "chunks were verified" (Mario→Dario, wall→WAL,
toolie→TUI were ALL found only at this level); letting it edit (report-only keeps
adjudication with you).
**Do**: assets/fresh_eyes_prompt.md.

### ⚖️ Re-Adjudicate
**Definition**: When new evidence challenges an earlier fix, pull the raw context and
re-judge from scratch — strengthen or revert, never assume.
**Triggers**: a "fixed" name turns out to also belong to a real person in the
speaker's domain; two fixes conflict; a verifier disputes a cleaner.
**Failure modes**: defending the earlier fix (anchor on raw, not on your edit
history); reverting without re-reading raw either.
**Do**: locate the raw lines, read ±10 lines of context, decide on content alone.

### 🔁 Ship-Sync
**Definition**: Keep the working copy (/tmp) and shipped copy (~/Downloads) identical;
prove with `diff` after every fix batch.
**Triggers**: any time fixes are applied post-assembly; end of session.
**Failure modes**: editing the shipped copy only (regenerating from chunks then
overwrites fixes); trusting memory that they match ("SHIPPED == FINAL" or it didn't
happen).
**Do**: `diff /tmp/.../transcript_final.md ~/Downloads/<final>.md && echo "SHIPPED == FINAL"`.

### 📦 Batch-Fix
**Definition**: Apply accumulated small repairs as one reviewable python list of
(old, new) tuples with assertions, not N ad-hoc edits.
**Triggers**: ≥3 pending small fixes; fixes spanning multiple locations.
**Failure modes**: tuples without `assert old in text` (silent no-ops); fixing in
prose order instead of grouping (hard to re-audit).
**Do**: `fixes = [(old, new), ...]; for o,n in fixes: assert o in t; t = t.replace(o,n)`
then re-run the audit (fixes regress).
