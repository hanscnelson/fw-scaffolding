# franken_whisper: install, CLI truth, models, native diarization

<!-- TOC: Install | What Changed in 0.7 | CLI Truth Table | Models | Diarization Engines | Flags | Env Vars | Known Gotchas | Other Commands | Dev Notes -->

## Install

Verified against **v0.7.2**. As of 0.7.x the stack is **fully native**: in-process Rust
Whisper + in-process Rust Sortformer diarization. No Python, no HF token, no pyannote, no
whisper.cpp binary. ffmpeg is still used for normalization and video/mic input.

```bash
curl -fsSL "https://raw.githubusercontent.com/Dicklesworthstone/franken_whisper/main/install.sh?$(date +%s)" | bash
```

The installer resolves the latest release, verifies a SHA-256, and installs **two**
binaries — `franken_whisper` and the short alias **`fw`** — into `~/.local/bin`. It then
offers to pull the native model set (**~2.12 GB**: Whisper weights + Sortformer
artifacts) into `~/.cache/franken_whisper/models`. Say yes; without it there is nothing
to run. Useful installer flags: `--easy-mode` (PATH/rc update), `--verify`, `--system`,
`--offline TARBALL`, `--from-source`, `--uninstall`.

Pull models later or on another box:

```bash
fw pull all --json          # both packages
fw pull whisper             # native Whisper ggml weights
fw pull sortformer          # diarization artifacts
fw models --json            # readiness without downloading
```

Both pulls are idempotent and re-verify checksums, so re-running after an upgrade is
cheap and is the right way to confirm an install.

**First move on any new machine** — these are read-only and answer "can this box do
useful work" in one shot:

```bash
fw robot triage             # readiness + next command + model registry, one JSON blob
fw doctor --json            # per-check diagnosis
fw capabilities --json      # stable command/schema contract
```

Note `triage` reports `status: preflight_ready_unverified` even when everything is
present — it is a static check. Only an actual transcription proves the install.

## What changed in 0.7 (if you learned this tool on 0.2)

| Then (0.2.x) | Now (0.7.x) |
|---|---|
| Diarization = pyannote bridge (HF token, python) or a text/temporal heuristic | **Native Sortformer, on by default.** No token, no Python. |
| `--diarize` to opt in | Diarization is **already on**; `--no-diarize` opts *out* |
| Speaker labels were hints | Real neural speaker activity with per-turn confidence + evidence |
| One binary name | `franken_whisper` **and** `fw` |
| Models fetched by hand from HF | `fw pull whisper` / `fw pull sortformer`, checksum-verified |

## Everything is native by default — including diarization

This is the point of 0.7.x, and the `--backend` names obscure it, so state it plainly:

| Backend name | What actually runs | In-process? |
|---|---|---|
| *(default / `auto`)* | **`insanely-fast-native`** — pure Rust | yes |
| `whisper-cpp` | **`whisper.cpp-native`** — pure Rust, *not* the brew binary | yes |
| `whisper-diarization` | `whisper-diarization-native` | yes |

Verified on a box that has `/opt/homebrew/bin/whisper-cli` installed and where
`fw robot backends` lists the `whisper.cpp` *bridge* as available: runs still resolve to
`whisper.cpp-native`, and forcing `FRANKEN_WHISPER_NATIVE_EXECUTION=0` does not change
that. So `--backend whisper-cpp` is **not** opting into a subprocess bridge — no Python,
no external binary, no HF token anywhere in the pipeline. Diarization is likewise the
in-process Rust Sortformer (`implementation: "native-sortformer-v1"`).

**Why this skill pins `--backend whisper-cpp`** even though the default is already native:
only the whisper.cpp family honors `--max-segment-length` / `--split-on-word`, and
word-level segments are what make diarization fusion precise. The default engine emits
chunk-level segments and **ignores `--timestamp-level word`** (verified: 8 chunk segments
either way on a 20 s clip). Text output from the two engines was identical on the same
audio; they differ in segmentation granularity, not transcription quality.

Assert it rather than trusting it — one line, and it catches a future version quietly
routing to a subprocess:

```bash
jq -e '.result.raw_output | .in_process == true and (.engine | endswith("-native"))' run.json \
  || echo "WARNING: not the in-process native engine"
```

## CLI truth table (binary beats README)

| Fact | Truth |
|---|---|
| `--backend` values | **kebab-case**: `auto`, `whisper-cpp`, `insanely-fast`, `whisper-diarization`. `whisper-cpp` resolves to the **native in-process engine** — no brew binary involved. |
| Confirming you got the native engine | `result.backend` is only `"whisper_cpp"` (the *family*). The native identity lives in `result.raw_output.engine` and `replay.backend_identity`, both `"whisper.cpp-native"`. Check those, not `result.backend`. |
| Output | NO `--output` flag. `--json` → full run report on **stdout** (redirect it). `--output-txt/-vtt/-srt/-csv/-lrc/-json-full` write sidecars next to the *input* file. |
| `result.transcript` vs `segments[].text` | **They differ.** `transcript` keeps real casing and punctuation; each `segments[].text` is force-capitalized with a `.` appended. Take timing from segments, text from `transcript` — see Known Gotchas. |
| run.json | Stays **0 bytes until the end**. Poll the `.err` log or the child process for liveness. |
| `confidence` field | Still unpopulated on segments (~1e-3 for everything). **Not** a usable signal. The diarization confidences, by contrast, are real. |
| Speed (Apple Silicon, 45-min stereo call) | ASR ≈ **6 min** (~7× realtime), Sortformer ≈ **7 min**. Budget ~13 min wall-clock for a 45-minute recording and run it in the background. |
| `result.acceleration` is **not** about the GPU | It reports *confidence normalization* (`input_values`, `normalized_confidences`, `pre_mass`/`post_mass`). `"acceleration_backend": "none"` / `"mode": "cpu_normalization"` is the normal, healthy reading on a GPU machine and says nothing about where the encoder ran. Do not read it as "no GPU". |
| GPU | On by default on Apple Silicon, no flags. Measured on 120 s of audio: **29.9 s default vs 42.8 s with `FRANKEN_WHISPER_GPU=0`** (~1.4×). That A/B is the reliable way to confirm the GPU is live, since no JSON field states it plainly. |

## Models

Resolution order: `$FRANKEN_WHISPER_MODEL_DIR` → `~/.cache/franken_whisper/models`.
`fw models --json` prints the registry with `runtime_status` per entry:

| Model | Role | Notes |
|---|---|---|
| `native-whisper-ggml` (`ggml-large-v3-turbo`, 1.6 GB) | ASR | the default; quality/speed sweet spot for meetings |
| `nvidia/diar_streaming_sortformer_4spk-v2.1` (492 MB) | diarization | **capped at 4 speaker lanes**; `capacity_semantics: four_lane_capped_output_true_speaker_count_unknown` |
| `speechbrain/spkrec-ecapa-voxceleb` (83 MB) | speaker embedding | used by the `ecapa` engines |
| `native-acoustic-diarization` | diarization fallback | built-in signal processing, no artifact |

Sortformer ships under the **NVIDIA Open Model License** and its status is
`development_uncertified` — good enough to drive a transcript, not a compliance artifact.
Its 4-lane cap means a 6-person meeting cannot be fully separated; see
`references/DIARIZATION.md`.

## Diarization engines (`--diarization-engine`)

| Value | What it is | When |
|---|---|---|
| `auto` *(default)* | native learned diarizer, acoustic fallback if its package is unavailable | **use this** |
| `sortformer` | Rust-native Streaming Sortformer explicitly | pinning behavior for reproducibility |
| `acoustic` | waveform-only, no neural model | no artifacts installed |
| `ecapa` / `ecapa-fused` | ECAPA speaker identity (fused adds bounded acoustic channel evidence) | re-identifying known voices via enrollment |
| `external` | user-installed subprocess backend | legacy setups |

`--diarization-fallback {unknown,acoustic,external,error}` (default `acoustic`) controls
what happens when the chosen engine lacks evidence. For an archival transcript prefer
`--diarization-fallback error` when you would rather fail loudly than silently accept a
worse diarizer.

Check what you actually got — never assume:

```bash
jq '.result.diarization | {implementation, fallback_status,
     speakers: .speaker_count.status, unknown: .speaker_count.unknown_voiced_share}' run.json
```

`fallback_status: "not_needed"` plus `speaker_count.status: "satisfied"` is the good case.

## Flags worth knowing

| Flag | Why you'd care |
|---|---|
| `--speaker-count-hard N` | Hard speaker count. On a known 2-person call, **always set `2`** — it is the single highest-value diarization flag. Unsupported speakers stay `UNKNOWN`. |
| `--speaker-count-range MIN..MAX` / `--speaker-count-prior K=P,...` | Soft alternatives when the count is uncertain (panel, unknown attendees) |
| `--max-segment-length N --split-on-word` | Segment granularity in characters. **`--max-segment-length 90 --split-on-word` yields one word per segment** — the granularity you need to fuse diarization cleanly. Without it segments run up to 30 s and swallow both speakers. |
| `--prompt "Noun, List"` | Seeds proper nouns → fewer homophone garbles. Feed it the user's project/people/product names. |
| `--speaker-hints '<json>'` | speaker-hints-v1: anchor known intervals to known speakers |
| `--persist-speaker-profiles` | keep voice profiles across runs (recurring participants) |
| `--no-persist` | do not write the run to the SQLite state DB — the default for one-off work |
| `--vad` + `--vad-threshold/...` | voice-activity pre-filter; another defense against non-speech intros |
| `--language en` | skip language detection; small but free |
| `--suppress-regex` | kill recurring junk tokens at the source |
| `--speculative --fast-model … --quality-model …` | dual-model streaming (live captioning, not archival) |

## Env vars

Read out of the 0.7.2 binary, so this list reflects the shipped stages rather than the
0.2.x set (which had no VAD/SEPARATE/PUNCTUATE/DIARIZE stages):

```
FRANKEN_WHISPER_STAGE_BUDGET_<STAGE>_MS   for STAGE in
  INGEST NORMALIZE PROBE VAD SEPARATE BACKEND ACCELERATION ALIGN
  PUNCTUATE DIARIZE PERSIST CLEANUP
FRANKEN_WHISPER_MODEL_DIR / TEST_MODEL_DIR / STATE_DIR
FRANKEN_WHISPER_NATIVE_EXECUTION / NATIVE_DEFAULT_MODEL / NATIVE_ROLLOUT_STAGE
FRANKEN_WHISPER_NATIVE_TAIL_TRUNCATE / BRIDGE_NATIVE_RECOVERY
FRANKEN_WHISPER_GPU / FUSED_ENC / PERF_SPANS
FRANKEN_WHISPER_FFMPEG_BIN / FFPROBE_BIN / FFMPEG_TIMEOUT_MS / AUTO_PROVISION_FFMPEG
FRANKEN_WHISPER_WAV_PASSTHROUGH / FORCE_FFMPEG_NORMALIZE
FRANKEN_WHISPER_WHISPER_CPP_BIN / INSANELY_FAST_BIN / PYTHON_BIN / YTDLP_BIN
FRANKEN_WHISPER_HF_TOKEN / DIARIZATION_DEVICE / ACOUSTIC_DIARIZATION_ROLLOUT
FRANKEN_WHISPER_ROUTING_SAFE_MODE / ROUTING_MIN_CALIBRATION
```

Plus a short unprefixed `FW_` family, one of which matters a great deal:
**`FW_RETRY_FAILED_WINDOW=1`** (see gotcha 1), `FW_INITIAL_PROMPT`, `FW_NO_CONTEXT`,
`FW_PIPELINE_WINDOWS`.

**Long audio needs two budgets raised, not one.** The ASR budget is the familiar one, but
diarization is now its own stage with its own budget — and it is the *slower* half
(~7 min of Sortformer per 45 min of audio vs ~6 min of ASR). For a multi-hour recording:

```bash
export FRANKEN_WHISPER_STAGE_BUDGET_BACKEND_MS=10800000   # ASR
export FRANKEN_WHISPER_STAGE_BUDGET_DIARIZE_MS=10800000   # Sortformer
fw transcribe … --timeout 10800                            # overall deadline, seconds
```

## Known gotchas (all verified on 0.7.2 — check whether your version still has them)

**1. Dropped long-form windows are announced on stderr only.** When a decode window
closes without a timestamp the engine discards ~30 s of audio and logs:

```
long-form window closed no timestamp — ~30 s of audio dropped
(set FW_RETRY_FAILED_WINDOW=1 to attempt prompt-reset recovery)  seek_sec=…
```

This does **not** appear in `result.warnings`, so a `--json`-only consumer never learns
the transcript has a hole. **Always capture stderr and grep it**, and prefer running with
`FW_RETRY_FAILED_WINDOW=1` set:

```bash
FW_RETRY_FAILED_WINDOW=1 fw transcribe … --json > run.json 2> run.err
grep -c "audio dropped" run.err          # must be 0
```

**Recovering a dropped window is not as simple as re-slicing it.** Re-transcribing the
region as one similar-length input *reproduces the drop* — the failure follows the window
geometry, not the invocation. Cut the region into **overlapping sub-30-second slices** so
the audio cannot sit on a long-form window boundary:

```bash
# lost 514-544: two 18 s slices with a 2 s overlap, not one 44 s slice
ffmpeg -ss 512 -t 18 -i in.wav -c copy g1.wav
ffmpeg -ss 528 -t 18 -i in.wav -c copy g2.wav
for f in g1 g2; do FW_RETRY_FAILED_WINDOW=1 fw transcribe --input $f.wav \
  --backend whisper-cpp --no-diarize --no-persist --language en --json; done
```

Then splice the words back by timestamp. `scripts/fuse_diarization.py` takes the slices
directly — `--gap-run` is repeatable, paired with one `--gap-offset` each, and it
de-duplicates the overlap for you (first slice to cover a moment wins):

```bash
scripts/fuse_diarization.py run.json --names "A,B" \
  --gap-run g1.json --gap-offset 512 \
  --gap-run g2.json --gap-offset 528 > turns.txt
# stderr reports how many words each slice actually contributed
```

**Do not assume a dropped window was silence.** Check the run's own diarization: voiced
turn coverage across the gap is independent evidence. A gap with seconds of voiced
activity — or a stderr `no_speech_prob` near zero, as in the example above — was speech.

**2. Segment gaps are not all drops.** Compare consecutive `end_sec`/`start_sec`; a gap
is only a *drop* if it also appears in stderr. Ordinary silence produces gaps too.

**3. `--offset-ms` and `--duration-ms` are silently ignored** by the native backend. A
"20-second probe" decodes the entire file at full cost and returns the entire file. Use
`ffmpeg -ss/-t` to cut a slice and transcribe the slice.

**4. `segments[].text` is lossily normalized** (first letter upper-cased, `.` appended);
`result.transcript` is not. Under `--split-on-word` every word arrives as `Word.` The two
views align **1:1** (verified: 5707 segments vs 5707 whitespace tokens, 0 mismatches), so
zip them:

```python
segs = [s for s in result["segments"] if s["text"].strip()]
words = result["transcript"].split()
assert len(segs) == len(words)          # assert it; don't trust it silently
pairs = [(s["start_sec"], s["end_sec"], w) for s, w in zip(segs, words)]
```

**5. `segments[].speaker` is often `null`** even when diarization succeeded — on a clean
2-speaker call roughly 60% of segments came back unlabeled while
`result.diarization.turns` covered the same audio with 0.89–0.93 confidence. The evidence
is in the payload; the join is not done for you. Do it yourself:
`references/DIARIZATION.md`.

## Other commands worth knowing

| Command | Use |
|---|---|
| `fw robot triage` | readiness + next command + model registry — first move on a new box |
| `fw robot run --input f.wav` | NDJSON stage events; streaming progress for orchestrators |
| `fw robot-docs guide` | compact integration docs printed from the running binary |
| `fw robot schema` / `robot backends` | event schemas; backend capability discovery |
| `fw runs list/show/export` | persisted run history (skipped under `--no-persist`) |
| `fw sync` | export/import the SQLite state as auditable JSONL |
| `fw youtube` | download + transcribe YouTube videos/playlists |
| `fw diarization-eval` | score references/hypotheses, aggregates only |
| `fw tui` | optional human-facing terminal UI |

Exit codes: `0` success, `1` runtime error, `2` usage error, `130` interrupted.

## Dev notes (when you patch franken_whisper itself)

- Sibling path deps: `fsqlite`/`fsqlite-types` from `../frankensqlite` — clone it next
  door or builds fail. Optional features pull `../frankentui`/`../frankentorch`.
- Full test suite: `cargo test -- --test-threads=8`; default parallelism oversubscribes
  (gated e2e tests run real inference). CI is `--lib` only.
- Perf work: `release-perf` cargo profile + `FRANKEN_WHISPER_PERF_SPANS=1`; the
  distribution profile (`opt-level="z"`) costs ~26% on large models.
- `FRANKEN_WHISPER_NATIVE_TAIL_TRUNCATE=0` disables tail-window encoder truncation if you
  suspect it on quality.
