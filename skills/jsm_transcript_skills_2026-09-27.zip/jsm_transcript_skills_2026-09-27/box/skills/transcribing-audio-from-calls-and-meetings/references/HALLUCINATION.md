# Hold-music poisoning and hallucination forensics

## Two distinct shapes — classify before you act

Both produce repeated segments, and the correct response is opposite in each case.
`sanity_check.py` tells them apart (`LOOPS` gives the onset timestamp;
`MIDFILE_LOOP` gives the verdict).

| | **Leading-intro poisoning** | **Mid-file loop** |
|---|---|---|
| Trigger | Long non-speech head (hold music, waiting room, silence) | Low-confidence region partway in — common in short voice memos with pauses |
| Loop onset | At/near 00:00 | After real, correct transcription |
| Head of transcript | Garbage | **Good — must be preserved** |
| Audio after onset | Contaminated, re-transcribe from onset | **Recoverable via a context-reset pass** |
| Correct response | Trim to onset, re-transcribe whole file, discard old run.json | Splice: rescue window before the failure point, `-mc 0`, offset re-add |
| Recipe | `references/WORKFLOWS.md` §C | `references/WORKFLOWS.md` §I |

**The dangerous mistake is treating a mid-file loop as if it were §C.** Two ways
to get it wrong, both of which lose real content:

1. *Discard the run and re-transcribe from the onset* — throws away a correct head.
2. *Just filter out the repeated segments* — this is the subtle one. The repeats
   are not merely junk to delete; they mark the point where decoding went bad.
   Real speech continues underneath them, and filtering alone silently drops it.
   A rescue pass from 02:30 on one real memo recovered a substantial block of
   content (Tailscale/MagicDNS, outbound agent, content agent, FAQs, LinkedIn
   content, case studies, white papers) that the filtered view had discarded
   without any indication anything was missing.

Everything below concerns the leading-intro shape.

---

## The failure mode (observed, twice)

Whisper carries decoding context across windows. A long non-speech intro (hold music,
waiting room, silence) seeds garbage context that **poisons the ENTIRE file**: one
phrase repeats in uniform ~30s segments to the end, even through perfectly good speech,
and even when running whisper-cli directly.

Observed: a 1h44m call with a 21-min hold-music intro transcribed as "Thank you." ×202
in uniform 30s segments — the audio itself was fine (−22dB mean). The sibling recording
with ~10.5 min of the same hold music transcribed perfectly after trimming.

**Tells that a run was poisoned** (check BEFORE spending any cleanup effort):
- suspiciously fast run; tiny transcript for the duration
- one phrase repeated tens/hundreds of times (`sort | uniq -c | sort -rn` on segment text)
- segments in uniform ~30s windows
- generic-filler text: "Thank you.", "So, let's go.", "I'm going to go ahead and…"

`sanity_check.py` automates all four (LOOPS/REPEATS/UNIFORM checks).

## Onset detection procedure

0. **Energy pre-pass (free)**: `energy_sweep.sh WAV` — per-window mean dB across the
   whole file. Hold music is often a steady (frequently LOUDER) level; speech
   fluctuates −18..−28dB; silence < −45dB. Energy can't distinguish music from
   speech, but a level SHIFT tells you exactly where to spend the ASR probes —
   on the 1h44m poisoned file this collapsed the search to one boundary region.
1. **Coarse pass**: `find_onset.sh WAV` (default offsets 0 60 180 420 900 1500) — 18s
   slice each. Hold music reads as generic loops/single words; real speech reads
   verbatim and specific. For very long intros widen the ladder
   (`find_onset.sh WAV 0 150 300 ... 1650` found a 21-min music intro).
2. **Bisect**: re-run with a ladder between last-fake and first-real (e.g.
   `find_onset.sh WAV 480 540 600 660 720`, then `605 615 625 635 645`). ~5 probes per
   level; converges in 2-3 levels.
3. **Trim at onset−10s**: `convert.sh IN OUT.wav <onset-10>` — records OFFSET. The 10s
   pad absorbs probe-window slop (a greeting can sit at the tail of a 20s window and
   timestamps at file start have ±15s slop).
4. **Add OFFSET back** when emitting timestamps (`make_segments.py --offset`).

## Conclusive no-speech verification (required before excluding audio)

```bash
verify_no_speech.sh WAV 0 <TRIM_POINT>
```
`whisper-cli -mc 0` = zero carried context → every window decoded independently:
- pure music/noise → incoherent window-salad ("cheese on the table"), uniform loops
- real speech → surfaces verbatim

**Review the ENTIRE output.** A `| head -40` truncation once left minutes 7–10.5 of an
excluded region unverified through two review rounds. ~25-40 lines per 10 min — read all.

Loop-census recipe (quantifies how fake a region is at a glance):
```bash
sed -E 's/^\[[^]]*\] *//' mc0_output.txt | sort | uniq -c | sort -rn | head -12
# music: a few phrases with huge counts; speech: long tail of unique lines
```

Historical note: the obvious flag, `whisper-cli -nc/--no-context`, does NOT exist in
brew 1.8.6 — it errors. `-mc 0` (max carried context = 0 tokens) is the working
equivalent and was discovered by reading `whisper-cli --help | grep -i context`.

Also probe the **tail** (last ~15s) — recordings end with stop-button artifacts
("Record.") that should be dropped, but real closing words must not be.

## Things that look like problems but aren't

- Mean volume −20..−26dB: normal phone/Zoom level, transcribes fine. Don't "fix" audio
  before proving transcription actually fails.
- Whisper's first segment spanning ~20s with the utterance at its tail: timestamp slop,
  not data loss. Convention: turn timestamp = segment start; mention slop in the report.
- Natural repeats ("Okay." ×19, "Yeah." ×10 across 2h): conversational, fine. The
  poisoning signature is identical CONSECUTIVE segments and 30s uniformity.
- A trimmed-file transcription ending ~10s before audio end: trailing silence/rustle.
  Probe it once; "Record."-style stop artifacts confirm it's the end.
