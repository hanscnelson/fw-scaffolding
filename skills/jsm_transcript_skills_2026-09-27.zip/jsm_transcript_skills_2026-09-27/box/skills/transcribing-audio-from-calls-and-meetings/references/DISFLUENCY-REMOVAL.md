# Removing fillers and speech errors without losing content

<!-- TOC: The Standard | What to Remove | What to Keep | Fixing Casing and Punctuation | Worked Examples | Retention | Common Failures -->

## The standard

A transcript should read like the person meant to say it, not like a court reporter's
dump. Cleaning that up is most of the value — and it is also where transcripts get
quietly destroyed, because the same edit that removes a filler can remove a fact.

**Delivery is cleaned. Content is untouched.**

Every substantive claim, number, name, qualification, hedge-with-meaning, and joke
survives verbatim or near-verbatim. Nothing is summarized, compressed, or reworded for
style. If you find yourself improving someone's argument, stop — that is a different
document.

Verify compliance mechanically, not by feel: **retention ratio 0.75–0.92** (cleaned words
÷ raw words, per chunk). Below 0.75, content was lost. Above 0.92, fillers were kept.
`scripts/audit_final.py` computes it.

## What to remove

| Category | Examples | Notes |
|---|---|---|
| **Hesitation sounds** | um, uh, er, ah, mm, hmm | Always remove. Zero information. |
| **Discourse fillers** | *like*, *you know*, *I mean*, *sort of*, *kind of*, *basically*, *actually*, *right?*, *so yeah* | Remove **when semantically empty**. See the keep-list below — several of these are real words too. |
| **False starts / restarts** | "I want to — I wanted to make sure" → "I wanted to make sure" | Keep the completed version. |
| **Stutters & doubled words** | "the the", "from your, from your repo", "how, how it handles" | Collapse to one. |
| **Repair sequences** | "on Tuesday — sorry, Wednesday" → "on Wednesday" | Keep the corrected fact. Preserve the correction only if the mistake itself matters. |
| **Backchannel noise** | isolated "mm-hmm", "yeah" that only acknowledges | Remove when it stands alone mid-monologue; keep when it is an actual answer. |
| **Trailing dead air** | "and so...", "it's just, you know..." at a turn's end | Remove if it adds nothing; do not fabricate an ending. |

Aggressiveness calibration: a speaker who says "like" 400 times in 45 minutes should end
up with maybe 15 instances of "like" in the transcript — the ones that mean *similar to*
or introduce a genuine example. Removing 95% of them is correct, not over-editing.

## What to keep

- **"Like" / "kind of" / "sort of" as real hedges or comparisons.** "It's *like* a local
  cache" is a definition. "It's *sort of* working" is a claim about degree. Both stay.
- **"I mean" introducing a genuine restatement** that adds precision.
- **"Actually" marking contrast** ("no, actually the opposite") — that is meaning.
- **Hedges that carry epistemic weight**: "I think", "I'm not sure", "probably",
  "roughly". Deleting these turns a guess into a fact. This is the most damaging possible
  cleanup error.
- **Interruptions and crosstalk that shape the conversation.** If one person cuts the
  other off, the transcript should show it — a turn ending mid-sentence with "..." is
  honest.
- **Profanity, jokes, tangents, small talk.** Not your call to sanitize.
- **The speaker's voice.** Contractions, sentence fragments, characteristic phrasing. The
  goal is readable, not formal.

## Fixing casing and punctuation

Whisper output degrades over long files — it commonly drifts into unpunctuated lowercase
partway through a long recording, so the back half of a transcript can arrive as a single
uncapitalized run-on while the front half is clean. Restore sentence boundaries,
capitalization, and proper-noun casing during cleanup. This is a rendering fix, not a
content edit — but re-read afterwards, because inserting a period in the wrong place
changes meaning ("no, we can't" vs "no we can't").

Also normalize:
- Numbers as spoken ("two twenty-three" → "223") when unambiguous.
- Tool and product names to their official styling, consistently, once you have confirmed
  the styling. Do not harmonize by guess — genuinely different products styled
  differently must stay different.
- Spoken punctuation ("slash", "dot com") only where the speaker clearly meant the
  symbol; otherwise leave the word.

## Worked examples

Raw:
> Yeah, yeah. So I took the, you know, the spec basically and I showed it to, you know,
> the team, and it was like, what, you know, what should we do here? Because it's like,
> there's a lot of different, you know, ways you could handle it.

Cleaned:
> Yeah. So I took the spec and showed it to the team — what should we do here? Because
> there's a lot of different ways you could handle it.

Retention 0.62 on this passage alone — fine locally, because a filler-dense stretch
prunes hard; the 0.75 floor applies per *chunk*, not per passage. (The second example
below lands at 0.76. Averaging toward the floor across a whole chunk is the expectation;
a single passage may sit well outside it in either direction.)

---

Raw:
> I mean, technically it doesn't — all of that caching stuff was basically so that it
> could be more, um, like, economical and like about like fetching the data

Cleaned:
> Technically it doesn't — all of that caching stuff was basically so that it could be
> more economical about fetching the data

Note "basically" survived here (it modifies the claim) while three "like"s and an "um"
went. Judgment per instance beats a global find-and-replace.

---

Wrong (content destroyed):
> Raw: "I think it's probably going to be fine, but I'd want to test it."
> Bad:  "It's going to be fine."

Two hedges and a condition deleted. This is the failure the retention floor exists to
catch.

## Common failures

- **Global regex filler removal.** `s/like//g` eats "it's like a cache" and "I'd like
  to". Every removal is a judgment call about that instance.
- **Removing the hedge with the filler.** "I think, you know, maybe" → "" instead of
  "I think maybe".
- **Merging turns while removing backchannel.** Deleting an interjected "Yeah" is fine;
  silently merging the two surrounding turns into one speaker's monologue is not.
- **Cleaning a garble into fluency.** If a phrase is mis-transcribed, repair it only with
  context proof, else keep it and mark `[sic]`. Never `[sic]` a word you repaired.
- **Over-cleaning short turns.** A turn that is *only* "Yeah." is content — it is
  someone's answer. Do not delete it as filler.
- **Stopping at the fillers.** Casing, punctuation, and false starts matter as much;
  a transcript with no "um"s but no sentence boundaries is still unreadable.
