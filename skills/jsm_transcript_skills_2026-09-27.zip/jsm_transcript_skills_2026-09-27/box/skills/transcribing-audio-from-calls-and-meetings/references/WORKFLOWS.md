# Worked Workflows

Eight end-to-end recipes. A, B, C are reconstructions of real production runs; the
rest extend the same machinery. `S=scripts`, `W=/tmp/transcribe_<slug>`.

## A. Two-person phone call, mac (the baseline)
Real run: a 2h01m iPhone voice memo, two speakers; ~6.7 min transcription.
```bash
$S/probe.sh "$AUDIO"                              # 64kb/s aac mono, -22dB mean: normal
$S/convert.sh "$AUDIO" $W/audio_16k.wav
$S/find_onset.sh $W/audio_16k.wav                 # speech at t=0 -> no trim, OFFSET=0
$S/transcribe.sh $W/audio_16k.wav $W/run.json --prompt "Names, Products, Jargon"
$S/watch_run.sh $W/run.json
$S/make_segments.py $W/run.json > $W/segments.txt
$S/sanity_check.py $W/run.json --duration <secs>
$S/chunk_plan.py <lines> --chunks 8               # -> spawn 8 cleanup agents (parallel)
$S/assemble.py $W/clean "Transcript: Call with <Guest>" "<You>, <Guest>" \
  "<Month D, YYYY> (iPhone voice memo, 2h 01m)" --source "$AUDIO" -o ~/Downloads/transcript.md
$S/audit_final.py ~/Downloads/transcript.md --segments $W/segments.txt --speakers "<You>,<Guest>"
# -> verify agents -> fresh-eyes agent -> fix -> re-audit until ALL GREEN
```

## B. Webinar with hold-music intro (the poisoning defense)
Real run: 1h51m Zoom webinar voice memo; first 10.5 min hold music.
Same as A, plus after convert:
```bash
$S/energy_sweep.sh $W/audio_16k.wav               # level shift ~600s
$S/find_onset.sh $W/audio_16k.wav                 # coarse: fake@0-600, real@900
$S/find_onset.sh $W/audio_16k.wav 605 615 625 635 645   # onset=645
$S/verify_no_speech.sh $W/audio_16k.wav 0 635     # READ ALL OUTPUT: salad only
$S/convert.sh "$AUDIO" $W/trimmed.wav 635         # OFFSET=635
$S/transcribe.sh $W/trimmed.wav $W/run.json
$S/make_segments.py $W/run.json --offset 635 > $W/segments.txt
```
Last-chunk agent note: drop the trailing stop-button "Record." segment.

## C. Poisoned-file rescue (transcript already ruined)
Real run: 1h44m call transcribed as "Thank you." ×202 in uniform 30s segments.
You're here when `sanity_check.py` FAILs REPEATS/UNIFORM on an existing run.
1. Confirm audio is fine: `probe.sh` (a −22dB mean means blame context, not gain).
2. `energy_sweep.sh` → whisper-probe regime boundaries → onset (was 1250s ≈ 21 min).
3. Trim, RE-transcribe the trimmed WAV, proceed as B. Do not try to salvage the
   poisoned run.json — every segment after the music is contaminated.

## D. Linux box / remote host (no brew, no whisper-cli)
franken_whisper's native pure-Rust engine needs NO external binaries (v0.2.0: 2.33×
whisper.cpp CPU on tiny.en, parity on large-v3-turbo).
```bash
curl -fsSL "https://raw.githubusercontent.com/Dicklesworthstone/franken_whisper/main/install.sh?$(date +%s)" | bash
mkdir -p ~/models/whisper && curl -fL "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-large-v3-turbo.bin" -o ~/models/whisper/ggml-large-v3-turbo.bin
FRANKEN_WHISPER_NATIVE_EXECUTION=1 FRANKEN_WHISPER_STAGE_BUDGET_BACKEND_MS=10800000 \
  franken_whisper transcribe --input audio.wav --backend whisper-cpp \
  --model ~/models/whisper/ggml-large-v3-turbo.bin --threads 16 --language en \
  --no-persist --timeout 10800 --json > run.json
```
Onset probes without whisper-cli: use franken_whisper windowing —
`--offset-ms 600000 --duration-ms 20000` per probe (tiny.en model keeps probes fast).
Transcribe on the big box, then bring run.json HOME and do cleanup/verification
locally where your agents run. ffmpeg auto-provisions on Linux x86_64.

## E. Video input (meeting recording .mp4/.mkv)
ffmpeg path (proven): `ffmpeg -i meeting.mkv -vn -ar 16000 -ac 1 -c:a pcm_s16le a.wav`
then workflow A/B. For captions back onto the video:
`srt_from_run.py run.json --offset $OFFSET -o meeting.srt` — offset-corrected so cues
match the ORIGINAL video timeline (franken_whisper's own --output-srt would be early
by the trim amount).

## F. Non-English / translation
`transcribe.sh ... --language de` (ISO 639-1 hint; omit for auto-detect, or
`--detect-language-only` first). `--translate` produces English output directly.
For a bilingual deliverable: transcribe verbatim in source language → clean (same
personas/rules, filler lists differ per language — adapt) → translate as a SEPARATE
deliverable pass so the verbatim transcript stays auditable. Retention-Gate applies
only to the verbatim layer.

## G. Three+ speakers
Content-based persona diarization degrades past 2 speakers — add mechanical turn
signals and let content map turns→names:
- `--tiny-diarize` (whisper.cpp speaker-turn tokens, no HF account)
- or pyannote: `--diarize --num-speakers 3` + `HF_TOKEN` (needs python3 + pyannote.audio)
Feed BOTH the segments and the turn markers to cleanup agents; personas still decide
WHO each mechanical turn is. Expect more low-confidence flags; budget a second
verify round. Panel/webinar shortcut: the host's name is usually said when handing
the floor ("over to you, X") — tell agents to anchor on hand-offs.

## H. Short clip, quick answer (when NOT to run the machine)
< ~10 min, you just need the text, no publishable artifact:
```bash
ffmpeg -i clip.m4a -ar 16000 -ac 1 -c:a pcm_s16le /tmp/c.wav
whisper-cli -m ~/models/whisper/ggml-large-v3-turbo.bin -t 8 -l en -np /tmp/c.wav
```
Read it, fix the obvious garbles inline, done. The full pipeline earns its cost from
~15 min up, or whenever the output will be shared/published — then fidelity
verification is not optional.

## I. Mid-file repeat-loop rescue (good head, loop starts partway in)

**Not the same failure as C.** In C a leading non-speech region poisons the whole
run, so you trim to the onset and re-transcribe everything — the old run.json is
worthless. Here the transcript is *correct* up to some point and only then enters
a repeat loop. Discarding the run throws away good content, and simply filtering
the repeated segments silently discards **real speech that occurs after the loop
starts**. The loop is a signal to re-transcribe the remainder with context reset,
not junk to delete.

Common trigger: short voice memos with pauses or quiet sections. A low-confidence
region mid-file seeds a bad decoding context that then repeats to the end.

`sanity_check.py` classifies this for you: a `FAIL MIDFILE_LOOP` line names the
loop onset and the suggested rescue start. (`PASS MIDFILE_LOOP` means the loop
begins at the file head — that is workflow C.)

Real run: memo transcribed correctly to 02:54, then `"I think it's a good thing."`
repeated to the end. A context-reset pass from 02:30 recovered genuinely missed
content — Tailscale/MagicDNS, outbound agent, content agent, FAQs, LinkedIn
content, case studies, white papers, one-pagers — none of which existed in the
filtered view.

```bash
W=/tmp/work                       # your run dir
RUN=$W/run.json                   # ORIGINAL run -- never overwrite it
LOOP=174                          # loop onset (secs) from sanity_check.py
RESCUE=$(( LOOP - 30 ))           # 10-30s before the failure point

# 1. Preserve the originals. Everything below is additive.
cp "$RUN" "$W/run.raw.json"
scripts/make_segments.py "$RUN" --offset "$OFFSET" > "$W/segments.raw.txt"

# 2. Re-transcribe from the rescue window with context DISABLED (-mc 0).
#    -mc 0 is what breaks the poisoned carry-over; see HALLUCINATION.md.
ffmpeg -i "$W/audio_16k.wav" -ss "$RESCUE" -ar 16000 -ac 1 -c:a pcm_s16le \
  "$W/rescue_${RESCUE}s.wav"
whisper-cli -m ~/models/whisper/ggml-large-v3-turbo.bin -t 8 -l en -np -mc 0 \
  -oj -of "$W/tail-rescue-${RESCUE}s" "$W/rescue_${RESCUE}s.wav"

# 3. Add BOTH offsets back: the original trim offset plus the rescue start.
scripts/make_segments.py "$W/tail-rescue-${RESCUE}s.json" \
  --offset "$(( OFFSET + RESCUE ))" > "$W/segments.rescued.txt"

# 4. Diff the rescue against the raw segments over the overlap window.
diff <(grep -A5 "$(printf '%03d' $((RESCUE/60)))" "$W/segments.raw.txt") \
     "$W/segments.rescued.txt" | head -40

# 5. Sanity-check the rescue pass itself -- it can loop too.
scripts/sanity_check.py "$W/tail-rescue-${RESCUE}s.json"
```

Rules for the splice:

- **Replace only the filtered segment view, never the raw transcript.** The raw
  run stays as the audit artifact; the rescue is a second layer over it.
- **Keep rescue artifacts under their own names** — `<slug>_tail-rescue-<offset>s.json`
  and `<slug>_segments.rescued.txt` — so a reviewer can see exactly which text
  came from which pass.
- **Overlap deliberately.** The 10-30s of pre-loop pad exists so you can align the
  rescue against known-good text. If the rescue's first lines do not match the raw
  transcript in that window, your offset arithmetic is wrong — fix it before splicing.
- **Do not silently include still-generic lines.** If the rescue also produces
  filler ("I think it's a good thing.", "Thank you."), mark those spans
  low-confidence rather than passing them off as recovered speech.
- **Verify the excluded span really is dead.** Run `verify_no_speech.sh` over the
  region you are dropping. Review the ENTIRE output, not `| head -40`.
- **If the rescue also loops**, move the rescue start earlier and retry once. Two
  failed rescues means treat the tail as unrecoverable and say so in the report,
  rather than shipping hallucinated filler.

Required review note (goes in the transcript review section):

```
Mid-file loop rescue
  loop onset:        02:54  ("I think it's a good thing." x40)
  rescue window:     from 02:24, context reset (-mc 0)
  recovered:         02:54-19:40, ~1,180 words previously absent
  excluded:          none / <span> as likely hallucination
  confidence:        rescued span reviewed against raw; N lines flagged low-confidence
```

Without that note a reader cannot tell which parts of the final transcript came
from a second pass, and the whole point of preserving the raw layer is lost.
