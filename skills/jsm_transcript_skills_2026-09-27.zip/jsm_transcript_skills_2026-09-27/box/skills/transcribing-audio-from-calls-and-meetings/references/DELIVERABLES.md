# Post-Transcript Deliverables

The verified transcript is the raw material; these are what users usually actually
want. Always build deliverables FROM the verified transcript (never from raw
segments — you'd re-import the garbles you fixed). Offer them after shipping the
transcript: "Want a summary / action items / quotes / show notes from this?"

## Ground rules (all deliverables)
- **Quotes stay verbatim** from the cleaned transcript, with `(m:ss)` timestamps so
  the user can jump to the audio. Never "improve" a quote.
- **Attribute claims to speakers** — a summary that merges who-said-what destroys the
  document's value for follow-up.
- **Mark inference**: anything not directly in the transcript gets "(implied)" or is
  left out.
- Deliverables are derivative — when the transcript gets a fix, regenerate or patch
  affected deliverables (Ship-Sync applies here too).

## Executive summary
One agent, whole transcript: 1 paragraph context (who/when/why) → 5-10 bullet key
points with speaker attribution + timestamp → decisions made → open questions. Length
scales with meeting length (~1 bullet per 10 min of content).

## Action items
Extract ONLY explicit commitments and requests ("I'll send you...", "Can you...",
"Let's get X done by Y"). Format: `- [ ] OWNER: action (committed at m:ss)`.
Flag soft commitments ("we should probably...") separately as "Discussed, not
committed". The wrap-up section of a call holds most of them — but sweep the whole
transcript; mid-call commitments get forgotten.

## Quote bank
For content marketing / recaps: 10-20 verbatim quotes, each self-contained, with
speaker + timestamp, grouped by theme. Prefer the speaker's vivid phrasings (the
analogies, the numbers, the hot takes) over summary-ish lines.

## Show notes (podcast/webinar publishing)
Chaptered outline: `(m:ss) Chapter title — 1-2 sentence description`, derived from
topic shifts in the transcript. Plus: guest bio (from the intro turns), links/products
mentioned (every proper noun the cleanup pass repaired is a candidate), one-paragraph
episode description. Pair with `srt_from_run.py` captions for the video upload.

## Follow-up email draft
From the action items + decisions: short recap addressed to the counterparty,
"as discussed" framing, the user's commitments and the counterparty's, proposed next
step. Have the user review names/commitments before sending — attribution errors in
email are expensive.

## Terminology glossary
Every domain term/proper noun that needed repair during cleanup, with a one-line
definition from context. Doubles as the `--prompt` seed and homophone-table extension
for the user's NEXT recording — each transcription should make the following one
better.

## Speaker-separated digest
Per speaker: their main positions, claims, questions asked, and commitments — useful
for interview analysis and due-diligence calls. Strictly from their attributed turns.
