---
name: transcribing-audio-from-calls-and-meetings
description: >-
  Transcribe and diarize calls, meetings, interviews (.m4a/.mp3/.wav/.mp4) into clean
  speaker-attributed markdown. Use when transcribing audio, diarizing speakers, or
  cleaning a whisper transcript.
---

<!-- TOC: Quick Start | Mental Model | Clarifying Questions | Which Path | Setup | Workflow (5 phases) | Invariants | Reference Index | Quick Search -->

# Transcribing Audio from Calls and Meetings

> **Core insight:** raw ASR output of a real call is NOT a transcript. It has
> hold-music hallucination loops that can poison the whole file, no speakers, fillers,
> and homophone garbles ("Dario"→"Mario", "TUI"→"toolie"). The transcript is earned by
> the pipeline below — and the four verification rounds each catch what the previous
> one structurally cannot.

## Quick start (the 90% path)

Ask the user the [intake questions](#clarifying-questions-ask-dont-guess) first — speakers
and setting are not guessable. Then, for a 2-person call with no long non-speech intro:

```bash
W=/tmp/transcribe_$(date +%s); mkdir -p $W; OFFSET=0    # OFFSET stays 0 unless you trim
S=<this skill>/scripts                                  # scripts/ dir of this skill
$S/probe.sh "$AUDIO"                                    # duration, codec, level
$S/convert.sh "$AUDIO" $W/audio_16k.wav                 # 16k mono
$S/find_onset.sh $W/audio_16k.wav                       # NEVER skip: poisoning defense
    # onset well past 0? -> $S/convert.sh "$AUDIO" $W/trimmed.wav <onset-10>
    #                       OFFSET=<onset-10>, and transcribe trimmed.wav below

FW_RETRY_FAILED_WINDOW=1 fw transcribe --input $W/audio_16k.wav \
  --backend whisper-cpp --diarize --diarization-engine sortformer \
  --speaker-count-hard 2 --language en --no-persist \
  --max-segment-length 90 --split-on-word \
  --prompt "<proper nouns>" --json > $W/run.json 2> $W/run.err &   # ~13 min per 45 min

grep -c "audio dropped" $W/run.err                      # MUST be 0 (see gotcha 1)
$S/fuse_diarization.py $W/run.json --names "<most-talkative>,<other>" \
  --offset $OFFSET > $W/turns.txt                       # speaker-attributed turns
$S/fuse_diarization.py $W/run.json --names "<most-talkative>,<other>" \
  --offset $OFFSET --no-speaker > $W/segments.txt       # raw ref for the audit
```

Then clean (phase 3) and verify (phase 4). **Lost mid-run?**
`$S/status.sh $W [FINAL.md]` prints pipeline state and the exact next command.

## Mental model

```
PHASE 0 INTAKE      ask clarifying questions ──► personas, setting, nouns, outputs
PHASE 1 AUDIO       probe ► convert ► energy_sweep ► find_onset ► verify_no_speech ► trim
                    └─ defends against the silent killer: context-poisoning intros
PHASE 2 TRANSCRIBE  fw transcribe (bg, native + Sortformer, word-level) ► gap check
PHASE 2b DIARIZE    fuse_diarization.py ──► speaker-attributed turns.txt
PHASE 3 CLEAN       chunk_plan ► N parallel persona agents ► assemble.py
PHASE 4 VERIFY      R1 audit_final.py ─► R2 verify agents ─► R3 fresh-eyes agent ─► R4 re-audit
                    (mechanical)        (per-chunk vs raw)   (whole-doc logic)      (after EVERY fix batch)
THEN                user Q&A round ► deliverables (summary/actions/quotes/captions)

Lost? scripts/status.sh WORKDIR [FINAL.md] reconstructs where you are + the next command.
```

**franken_whisper ≥ 0.7 changes phase 2.** Diarization is now native (a Rust port of
NVIDIA Streaming Sortformer), on by default, no HF token and no Python. It is good enough
to drive attribution rather than merely hint at it — but the tool returns ASR and
diarization on **two unjoined timelines**, so the fuse step is yours.
[DIARIZATION.md](references/DIARIZATION.md) is the recipe;
`scripts/fuse_diarization.py` implements it.

## Clarifying questions (ask, don't guess)

**At the start** — ask whatever context doesn't already answer (AskUserQuestion or
plain questions; speakers + setting are non-negotiable):
1. **Who spoke?** Names + a short bio for each AND how they talk ("long fast
   monologues, heavy filler" vs "short probing questions"). Content-based diarization
   lives or dies on this. Who did most of the talking? Who made the recording?
2. **Setting** — call / webinar / interview / panel? Date? Might there be hold music,
   a waiting room, or audience questions? Language? Was it recorded mid-meeting or
   does it capture the pre-start?
3. **Domain + proper nouns** — topic, and the project/people/company names likely to
   be garbled (these seed `--prompt` and the homophone sweep).
4. **Output** — destination path; verbatim-cleaned transcript only, or also
   summary / action items / show notes / captions ([DELIVERABLES.md](references/DELIVERABLES.md))?

**After transcription** — bring the user the things only they can resolve, batched:
low-confidence speaker attributions the agents flagged, garbles that survived
`[sic]`, an unknown third voice, names you can't verify ("the greeter at 10:35 —
the host or someone else?"). Don't silently guess on any of these.

## Which path?

- **Short clip (<~10 min), text only, not for publication** → skip the machine:
  one whisper-cli pass and inline garble fixes ([WORKFLOWS.md §H](references/WORKFLOWS.md)).
- **Anything ≥15 min, multi-speaker, or shared/published** → full pipeline below.

| Decision | Default | When to deviate |
|---|---|---|
| Model | `ggml-large-v3-turbo` | `tiny.en` for probes/smoke tests |
| Engine | **native in-process Rust** (`--backend whisper-cpp` resolves to it on 0.7.x) | older builds without the native path |
| Where | This machine | Huge file + a big remote box: transcribe there, clean/verify here |
| Diarization | **native Sortformer** + `--speaker-count-hard N`, fused per-word, then confirmed by persona/content | 5+ speakers exceed Sortformer's 4-lane cap — treat labels as clusters ([DIARIZATION.md](references/DIARIZATION.md)) |
| Segmentation | `--max-segment-length 90 --split-on-word` (word-level) | non-diarized quick clips can use defaults |

Situation-specific recipes — calls, webinars+hold-music, **poisoned-file rescue**,
remote/Linux, video+captions, non-English, 3+ speakers: [WORKFLOWS.md](references/WORKFLOWS.md).

## Setup (once)
```bash
S=scripts; chmod +x $S/*.sh $S/*.py
$S/setup.sh          # ffmpeg (brew/apt/dnf), franken_whisper (official one-liner),
                     # whisper-cli probe tool, ggml-large-v3-turbo model (~1.5GB)

# franken_whisper >= 0.7: installer ships `franken_whisper` AND the alias `fw`,
# then offers the native model set (~2.12 GB: Whisper + Sortformer diarization).
fw pull all --json   # idempotent, checksum-verified; safe to re-run after upgrades
fw robot triage      # readiness + next command in one JSON blob
```
Every script takes `--help`. Convention: **data on stdout; diagnostics + a `NEXT:`
breadcrumb on stderr; non-zero exit on failure.** CLI truth (kebab-case
`--backend whisper-cpp` — the README's snake_case is wrong), env vars, native engine,
diarization engines, robot mode, and the **known 0.7.2 gotchas** (silently-dropped audio
windows, inert `--offset-ms`/`--duration-ms`, lossy `segments[].text`, null
`segments[].speaker`): [FRANKEN-WHISPER.md](references/FRANKEN-WHISPER.md).

## Workflow
Work in a scratch dir `W=/tmp/transcribe_<slug>`. Resuming or confused?
`scripts/status.sh $W [FINAL.md]` prints pipeline state + the exact next command.
The methodology as composable operator cards (triggers + failure modes):
[OPERATORS.md](references/OPERATORS.md).

**PHASE 1 — AUDIO** (defends against context poisoning)
- [ ] **Probe**: `scripts/probe.sh "$AUDIO"` — duration, codec, volume. Quiet
      (−25dB mean) is fine; don't "fix" gain before proving transcription fails.
- [ ] **Convert**: `scripts/convert.sh "$AUDIO" $W/audio_16k.wav` (16kHz mono pcm_s16le).
- [ ] **Energy sweep (free)**: `scripts/energy_sweep.sh $W/audio_16k.wav` — dB map;
      level shifts mark where to spend ASR probes.
- [ ] **Find speech onset (NEVER SKIP)**: `scripts/find_onset.sh $W/audio_16k.wav
      [t1 t2 ...]` — coarse ladder then bisect. Hold music reads as generic loops
      ("I'm going to go ahead…", uniform "Thank you."); real speech reads verbatim.
      A long non-speech intro **poisons the entire file** via context carryover.
      Details: [HALLUCINATION.md](references/HALLUCINATION.md).
- [ ] **Verify the cut region is speech-free**: `scripts/verify_no_speech.sh
      $W/audio_16k.wav 0 <TRIM>` (`-mc 0` scan). Review the **entire** output — a
      `head`-truncated review once left 3.5 min unverified.
- [ ] **Trim**: `scripts/convert.sh "$AUDIO" $W/trimmed.wav <onset-10>` → records
      `OFFSET` (skip if onset ≈ 0; then trimmed = audio_16k and OFFSET=0).

**PHASE 2 — TRANSCRIBE** (native + diarization, word-level; ~13 min per 45 min of audio)
- [ ] **Transcribe in the background.** `run.json` is 0 bytes until the end, so poll the
      process, not the file:
      (`AUDIO=$W/trimmed.wav` if you trimmed in phase 1, else `AUDIO=$W/audio_16k.wav`
      with `OFFSET=0` — there is no `trimmed.wav` when onset ≈ 0.)
      ```bash
      FW_RETRY_FAILED_WINDOW=1 fw transcribe --input $AUDIO \
        --backend whisper-cpp --diarize --diarization-engine sortformer \
        --speaker-count-hard <N> --language en --no-persist \
        --max-segment-length 90 --split-on-word \
        --prompt "<user's proper nouns>" --json > $W/run.json 2> $W/run.err &
      ```
      `--speaker-count-hard N` is the highest-value flag when N is known.
      **Capture stderr** — it carries failures the JSON does not.
      Everything here is the **in-process Rust stack**: `--backend whisper-cpp` resolves
      to `whisper.cpp-native` (not the brew binary), diarization is native Sortformer, and
      the GPU is on by default. The pin exists only because that family honors
      `--split-on-word`; the default engine emits chunk-level segments and ignores
      `--timestamp-level word`. Confirm it rather than assume:
      `jq -e '.result.raw_output | .in_process and (.engine|endswith("-native"))' $W/run.json`
- [ ] **Check for silently dropped audio (NEVER SKIP)**: `grep -c "audio dropped"
      $W/run.err` must be **0**. Each hit is ~30 s of speech missing from the transcript
      and absent from `result.warnings`. Confirm whether it was speech using the run's own
      diarization (voiced coverage across the gap) — do **not** assume silence. Recover it
      with **overlapping sub-30-second slices**: re-transcribing the region as one
      similar-length slice reproduces the drop, because the failure follows the window
      geometry. Recipe: [FRANKEN-WHISPER.md](references/FRANKEN-WHISPER.md) gotcha 1.
- [ ] **Sanity**: `scripts/sanity_check.py $W/run.json --duration <secs>` — loops,
      repeats, uniform-30s, gaps, coverage, markers, plus `MIDFILE_LOOP`, which reports
      the loop *onset* and routes you to the right recipe. Any FAIL → investigate before
      spending cleanup effort ([TROUBLESHOOTING.md](references/TROUBLESHOOTING.md)).
      `FAIL MIDFILE_LOOP` → [WORKFLOWS.md §I](references/WORKFLOWS.md): the head of the
      transcript is good and the post-loop audio is recoverable, so filtering the
      repeated segments alone silently discards real speech. That is a different failure
      from leading-intro poisoning (§C), where you trim and re-transcribe everything —
      classify before acting ([HALLUCINATION.md](references/HALLUCINATION.md)).

**PHASE 2b — DIARIZE** ([DIARIZATION.md](references/DIARIZATION.md))
- [ ] **Fuse turns onto words** — emit **both** views; downstream phases use each:
      ```bash
      S=scripts
      $S/fuse_diarization.py $W/run.json --names "<most-talkative>,<other>" \
        --offset $OFFSET > $W/turns.txt     # speaker-labeled -> cleanup agents read this
      $S/fuse_diarization.py $W/run.json --names "<most-talkative>,<other>" \
        --offset $OFFSET --no-speaker > $W/segments.txt   # raw ref -> audit/verify rounds
      ```
      **`--offset $OFFSET` is not optional if you trimmed** (phase 1): fusion runs in the
      trimmed audio's timebase, and the offset is what maps timestamps back to the
      ORIGINAL recording. Pass `0` when you did not trim.
      Keep `segments.txt` speaker-free: `audit_final.py` treats everything after `"] "`
      as transcript words, so labels there inflate the raw count and under-report
      retention (measured 0.80 vs a true 0.83 on the same transcript).
      The fusion is a confidence-weighted overlap vote, lone-flip smoothing, and
      boundary-snapping to sentence punctuation — which beats any global time shift,
      because the residual ASR-vs-diarizer error is local, not a constant lag.
- [ ] **Verify the diarization block** before trusting labels: `fallback_status ==
      "not_needed"`, `speaker_count.status == "satisfied"`, per-speaker
      `mean_assignment_confidence` ≥ ~0.85, and a voiced-duration split that matches the
      dominance the user described.
- [ ] **Use voiced evidence as a hallucination oracle**: a window with ~0 voiced frames
      but confident repeated text is invented — delete it. This catches loops anywhere in
      the file, which onset detection (a pre-transcription defense) structurally cannot.

**PHASE 3 — CLEAN** (fillers, false starts, casing — [DISFLUENCY-REMOVAL.md](references/DISFLUENCY-REMOVAL.md))
- [ ] **Chunked cleanup**: `scripts/chunk_plan.py $(wc -l < $W/turns.txt) --chunks 8` →
      one agent per chunk **in parallel** (chunk over `turns.txt` — the speaker-labeled
      view — and give each agent that path as its segments file), prompt from
      [assets/cleanup_agent_prompt.md](assets/cleanup_agent_prompt.md) filled with the
      personas and chunk range. Respawn rate-limited ones (stateless). Craft guide:
      [CLEANUP-AGENTS.md](references/CLEANUP-AGENTS.md).
- [ ] **The cleanup standard is: delivery is cleaned, content is untouched.** Strip
      *um/uh*, semantically empty *like / you know / I mean / sort of / basically*,
      false starts, stutters and doubled words; restore sentence casing and punctuation
      (Whisper commonly drifts into unpunctuated lowercase partway through a long file).
      **Keep** hedges that carry meaning ("I think", "probably"), *like* used as a real
      comparison, interruptions, jokes, and one-word answers. Never summarize.
      Per-instance judgment — a global `s/like//g` destroys "it's like a cache".
- [ ] **Assemble**: `scripts/assemble.py $W/clean "<title>" "<participants>"
      "<date/source note>" --source "<orig filename>" -o <FINAL.md>` (python — dcg
      blocks shell redirects into ~/Downloads).

**PHASE 4 — VERIFY** (all four rounds, in order — [VERIFICATION.md](references/VERIFICATION.md))
- [ ] **R1 mechanical**: `scripts/audit_final.py <FINAL.md> --segments $W/segments.txt
      --speakers "<A,B>"` — seams, retention 0.75–0.92, content-word coverage
      ≥85%/window, monotonic timestamps, speaker-set, fillers, homophones, markdown,
      acronyms. Loop: fix → re-run → only proceed on ALL GREEN.
- [ ] **R2 adversarial per-chunk verify agents** (2 chunks each,
      [assets/verify_agent_prompt.md](assets/verify_agent_prompt.md)) — they fix
      small clear errors, REPORT judgment calls to you.
- [ ] **R3 whole-document fresh-eyes agent**
      ([assets/fresh_eyes_prompt.md](assets/fresh_eyes_prompt.md)) — dialogue
      logic, cross-chunk consistency, garbles per-chunk verifiers structurally
      cannot see (this round found Mario→Dario).
- [ ] **R4**: apply fixes as Batch-Fix tuples, keep copies Ship-Synced, re-run the
      audit after EVERY batch; finish only when ALL GREEN.
- [ ] **Adjudicate** flagged judgment calls against the RAW segments yourself; when
      later evidence challenges an earlier fix, re-judge from raw — don't assume.

**THEN**
- [ ] **Ask the user** the post-transcription questions (above), apply answers, final
      audit pass.
- [ ] **Offer deliverables**: summary, action items, quote bank, show notes, captions
      (`scripts/srt_from_run.py run.json --offset $OFFSET -o out.srt` — offset-aware,
      unlike franken_whisper's own sidecars). [DELIVERABLES.md](references/DELIVERABLES.md).
- [ ] Report: final path, what was excluded and why, fixes applied, remaining
      low-confidence spots.

## Non-negotiable invariants
- **Onset detection before transcribing.** The poisoning failure is silent: a fast
  "successful" run with a tiny repetitive transcript.
- **Content survives; only delivery is cleaned.** Filler/false-start removal only;
  retention ratio 0.75–0.92 per chunk (below = content lost, above = fillers kept).
  Never summarize in the transcript layer.
- **Repairs need context proof; otherwise `[sic]`.** Never `[sic]` a repaired word.
- **Every chunk verified against raw by a different agent than its cleaner**, plus
  one fresh read of the assembled whole.
- **Timestamps map to the ORIGINAL recording** (offset added back), monotonic; turn
  timestamp = first raw segment of the turn.
- **Re-verify after every edit batch** — fixes regress; count homophones with bare
  patterns (context-padded grep misses long-line duplicates).
- **Speakers and settings come from the user, not from guesses** — ask up front,
  batch the rest for after transcription.
- **Grep the ASR stderr for dropped windows.** The machine-readable output does not
  report them, so a `--json`-only pipeline loses ~30 s of speech per drop without a
  single visible symptom.
- **Never trust `segments[].speaker`** — it is null for most segments even on a clean
  run. Fuse `diarization.turns` yourself, at word granularity.

## Reference Index

| I need to... | Go to | What's in it |
|---|---|---|
| Resume / figure out where I am | `scripts/status.sh $W [FINAL.md]` | pipeline state + exact next command |
| Follow a worked end-to-end example | [WORKFLOWS.md](references/WORKFLOWS.md) | 8 recipes: §A call · §B webinar+hold-music · §C poisoned-file rescue · §D remote/Linux · §E video+captions · §F non-English · §G 3+ speakers · §H quick clip |
| Diagnose a failure (error, weird output, hang) | [TROUBLESHOOTING.md](references/TROUBLESHOOTING.md), then [PITFALLS.md](references/PITFALLS.md) | symptom → cause → fix; every mistake actually made and its prevention |
| Look up a flag, env var, install path, or a 0.7 gotcha | [FRANKEN-WHISPER.md](references/FRANKEN-WHISPER.md) | install (`fw pull all`), CLI truth table, models, diarization engines, env vars, robot mode, **v0.7.2 known gotchas**, dev notes |
| Turn Sortformer output into speaker-attributed dialogue | [DIARIZATION.md](references/DIARIZATION.md) + `scripts/fuse_diarization.py` | word-level ASR, confidence-weighted fusion, smoothing, punctuation boundary-snapping, voiced-frame hallucination filter, 3+ speakers and the 4-lane cap |
| Decide what counts as a filler vs. content | [DISFLUENCY-REMOVAL.md](references/DISFLUENCY-REMOVAL.md) | remove/keep tables, casing + punctuation repair, worked examples, the retention floor |
| Decide if a region is music vs speech | [HALLUCINATION.md](references/HALLUCINATION.md) | poisoning mechanism, energy sweep, onset bisection, `-mc 0` verification, loop census |
| Write/tune the cleanup agent prompts | [CLEANUP-AGENTS.md](references/CLEANUP-AGENTS.md) + [assets/](assets/cleanup_agent_prompt.md) | chunk math, persona craft, diarization heuristics, what each prompt element buys |
| Run the verification rounds / fix-batch discipline | [VERIFICATION.md](references/VERIFICATION.md) | the four rounds, every check, the burned homophone table, Batch-Fix/Ship-Sync, re-adjudication |
| Produce summaries/actions/quotes/captions | [DELIVERABLES.md](references/DELIVERABLES.md) + `scripts/srt_from_run.py` | summaries, action items, quote banks, show notes, follow-up emails, glossaries |
| Understand/extend a technique | [OPERATORS.md](references/OPERATORS.md) | the methodology as 14 composable operator cards with triggers and failure modes |

### Assets (fill-in agent prompts)
[cleanup_agent_prompt.md](assets/cleanup_agent_prompt.md) ·
[verify_agent_prompt.md](assets/verify_agent_prompt.md) ·
[fresh_eyes_prompt.md](assets/fresh_eyes_prompt.md)

## Note on size

This SKILL.md exceeds the ~200-line guideline. Deliberate: the workflow checklist *is*
the skill, and its steps are the ones that fail silently when skipped (onset detection,
the dropped-window grep, the offset, the retention gate). Moving them one hop into a
reference is exactly how an agent ends up not running them. Depth that is safe to defer
already lives in `references/`; the Quick start above is the short path for the common
case.

## Quick search
```bash
R=references
grep -niE "poison|uniform|30s|loop"        $R/HALLUCINATION.md $R/TROUBLESHOOTING.md   # hallucination symptoms
grep -niE "kebab|budget|0 bytes|offset-ms" $R/FRANKEN-WHISPER.md $R/TROUBLESHOOTING.md # CLI gotchas
grep -niE "retention|coverage|homophone"   $R/VERIFICATION.md                          # fidelity gates
grep -niE "persona|dominance|third voice"  $R/CLEANUP-AGENTS.md                        # diarization craft
grep -ni  "<your-domain-term>"             $R/*.md                                     # anything else
```
