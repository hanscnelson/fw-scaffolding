#!/usr/bin/env python3
"""Run one 4-round cleanup via Grok Build CLI (grok-4.6, low effort)."""
from __future__ import annotations
import json, os, shutil, subprocess, sys, time
from pathlib import Path

ROOT = Path("/workspace/ingest/batch57")
MAN = json.loads((ROOT / "manifest.json").read_text())
GROK = os.environ.get("GROK_BIN", str(Path.home() / ".local/bin/grok"))
MODEL = os.environ.get("GROK_CLEANUP_MODEL", "grok-4.6")
EFFORT = os.environ.get("GROK_CLEANUP_EFFORT", "low")

CLEANING = "/home/box/agent-data/workflows/transcribing-youtube-videos/references/CLEANING.md"
CLEANUP_PROMPT = "/home/box/agent-data/workflows/transcribing-audio-from-calls-and-meetings/assets/cleanup_agent_prompt.md"
VERIFY_PROMPT = "/home/box/agent-data/workflows/transcribing-audio-from-calls-and-meetings/assets/verify_agent_prompt.md"
FRESH_PROMPT = "/home/box/agent-data/workflows/transcribing-audio-from-calls-and-meetings/assets/fresh_eyes_prompt.md"


def stage(vid: dict) -> Path:
    vid_id = vid["id"]
    vdir = ROOT / "videos" / vid_id
    out = ROOT / "cleanup" / vid_id
    out.mkdir(parents=True, exist_ok=True)
    raw = out / "raw"
    raw.mkdir(exist_ok=True)
    for name in ("fused.txt", "fused.json", "success.json"):
        src = vdir / name
        if src.exists():
            shutil.copy2(src, raw / name)
            if name != "success.json":
                shutil.copy2(src, out / name)
    # also copy fused to expected paths at video dir already used by DISPATCH
    (out / "IN_PROGRESS.txt").write_text(f"grok-build {MODEL} effort={EFFORT} started\n")
    return out


def build_prompt(vid: dict, out: Path) -> str:
    vid_id = vid["id"]
    vdir = ROOT / "videos" / vid_id
    succ = {}
    sp = vdir / "success.json"
    if sp.exists():
        succ = json.loads(sp.read_text())
    speakers_hint = succ.get("speakers") or succ.get("asr_speakers") or "?"
    return f"""You are doing the 4-round CLEANED transcript pipeline for ONE video. Do NOT talk to a user chat. Write files to disk. Report a short quality memo when done.

VIDEO: {vid.get('title')}
- id: {vid_id}
- url: {vid.get('url')}
- channel: {vid.get('channel')}, duration {vid.get('duration')}, rank {vid.get('rank')}, views {vid.get('views')}
- batch: 45
- raw fused turns: {vdir / 'fused.txt'}
- fused json: {vdir / 'fused.json'}
- staged raw: {out / 'raw'}/

OUTPUT DIR (IN_PROGRESS.txt claimed — delete when cleaned.md exists):
  {out}/
Write: cleaned.md, TRANSCRIPT.json, glossary.md, audit_r1.txt, r2_notes.md, r3_notes.md, r4_notes.md, quality.md, speaker_map.json, token_log.json, chunks/chunk_N.md.

FOLLOW strictly (read first):
  {CLEANING}
  {CLEANUP_PROMPT}
  {VERIFY_PROMPT}
  {FRESH_PROMPT}
Audit: /home/box/agent-data/workflows/transcribing-youtube-videos/scripts/clean_audit.py

SPEAKERS: Hypothesis from channel/title/content. Do not invent surnames. Amit Kukreja only if clearly on-mic. ASR hint: {speakers_hint}

RULES: Cleaned mode. Every substantive sentence survives. Retention 0.75–0.92 preferred; ~0.94–0.98 OK if raw light on fillers — explain, do not game. Deep links youtu.be/{vid_id}?t=SEC. 0 [sic] if repairable. No thought-boundary chunking.

success notes: {json.dumps({k: succ.get(k) for k in ('dropped','segs','cores','wall_sec','rtf','download_note') if k in succ or True})}

When finished: ensure cleaned.md and quality.md exist; delete IN_PROGRESS.txt; print paths, speakers, retention, [sic], publishable.
"""


def run_one(vid_id: str) -> int:
    vid = next(v for v in MAN["videos"] if v["id"] == vid_id)
    vdir = ROOT / "videos" / vid_id
    if not (vdir / "fused.txt").exists() and not (vdir / "success.json").exists():
        print(f"SKIP no ASR yet {vid_id}", flush=True)
        return 2
    out = stage(vid)
    if (out / "cleaned.md").exists():
        print(f"SKIP already cleaned {vid_id}", flush=True)
        return 0
    prompt = build_prompt(vid, out)
    prompt_path = out / "DISPATCH_PROMPT.txt"
    prompt_path.write_text(prompt)
    log_path = out / "grok_cleanup.log"
    env = os.environ.copy()
    env["PATH"] = f"{Path.home()}/.local/bin:{Path.home()}/.grok/bin:" + env.get("PATH", "")
    cmd = [
        GROK,
        "-p", f"Execute the cleanup instructions in {prompt_path}. Read that file first and follow it completely.",
        "-m", MODEL,
        "--effort", EFFORT,
        "--always-approve",
        "--output-format", "plain",
        "--cwd", str(out),
        "--max-turns", "80",
    ]
    print(f"RUN {vid_id} model={MODEL} effort={EFFORT}", flush=True)
    t0 = time.time()
    with log_path.open("w") as log:
        proc = subprocess.run(cmd, cwd=str(out), env=env, stdout=log, stderr=subprocess.STDOUT, text=True)
    wall = round(time.time() - t0, 1)
    ok = (out / "cleaned.md").exists()
    print(f"{'OK' if ok else 'FAIL'} {vid_id} exit={proc.returncode} wall={wall}s cleaned={ok}", flush=True)
    if ok and (out / "IN_PROGRESS.txt").exists():
        (out / "IN_PROGRESS.txt").unlink()
    meta = {"model": MODEL, "effort": EFFORT, "wall_sec": wall, "exit": proc.returncode, "cleaned": ok}
    (out / "grok_cleanup_meta.json").write_text(json.dumps(meta, indent=2) + "\n")
    return 0 if ok else 1


def main(argv: list[str]) -> int:
    if len(argv) < 2:
        print("usage: grok_cleanup_one.py <video_id>|--all-ready")
        return 2
    if argv[1] == "--all-ready":
        rc = 0
        for v in MAN["videos"]:
            vid = v["id"]
            if (ROOT / "videos" / vid / "success.json").exists() and not (ROOT / "cleanup" / vid / "cleaned.md").exists():
                r = run_one(vid)
                rc = rc or r
        return rc
    return run_one(argv[1])


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
