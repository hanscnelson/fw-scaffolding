# JSM / Jeffrey-style skills used in the speaker-diarized YouTube transcript flow
Built 2026-09-27 (CT) from the Grok Bot box and casarosie2 (read-only).

## Naming note (please read)
Nothing on the box or on casarosie2 is literally named `jsm*` or `jeffreys*` except:
- `/workspace/jeffrey-skills/{calls,selector}` = byte-identical copies of `transcribing-audio-from-calls-and-meetings` and `choose-the-best-skills-for-me-to-run-in-this-project`
- `/workspace/jeffrey-fw-skill/` = byte-identical copy of `transcribing-youtube-videos` (it is **not** the `fw` skill, despite the name)
- `choose-the-best-skills.../tests/stubs/jsm` (a test stub of the `jsm` CLI). The `jsm` CLI itself is not installed on the box.
These are Jeffrey Emanuel-style SKILL.md packages (jeffreys-skills.md catalog format). Each one also exists as identical copies in
`/home/box/agent-data/workflows/<name>`, `/home/box/.agents/skills/<name>` and `/home/box/.cursor/skills/<name>` (checked with diff -rq; the only extra files are `__pycache__`).
This zip includes the skills the pipeline **actually uses**, with one copy of each (taken from `agent-data/workflows`).

**casarosie2 has NO skill files.** `find / -name SKILL.md` finds only a FastAPI SKILL.md that ships inside the venv package (`.venv/.../fastapi/.agents/skills/fastapi`). It is not part of the pipeline and is excluded.
The hcngbot account has no `~/.claude`, `~/.grok` or `~/.codex`, and no `~/.cursor/skills` (only `~/.cursor/cli-config.json` + `projects/`). A repo grep for `skill|jsm|jeffrey` has no hits.
The casarosie2 4-round cleanup prompt is written inline in Python (`cursor_backend.py::_build_dispatch_prompt`). That source is included under `casarosie2/` for reference.

## Layout
```
box/skills/transcribing-youtube-videos/                 (Jeffrey skill)
box/skills/transcribing-audio-from-calls-and-meetings/  (Jeffrey skill)
box/skills/fw/                                          (Jeffrey skill)
box/workflows/grok-build-cleanup-pipeline/              (Hans's own workflow skill + referenced READY_PING_ROUTINE.md)
box/adjacent_not_in_flow/choose-the-best-skills-for-me-to-run-in-this-project/  (the jsm skill-selector; NOT in the transcript flow)
box/evidence/        batch57 grok_cleanup_one.py + run_batch.py excerpts (the lines that reference the skills)
casarosie2/inline_prompts_no_skill_files/   cursor_backend.py, priors.py, stages/fw.py, stages/cleanup.py, docs/STACK_LOCK.md
```

## Skills in the flow

| # | Skill | Source path (box) | Pipeline step | Evidence |
|---|---|---|---|---|
| 1 | **transcribing-youtube-videos** | `/home/box/agent-data/workflows/transcribing-youtube-videos` (same as `~/.cursor/skills/…`, `~/.agents/skills/…`, `/workspace/jeffrey-fw-skill`) | YouTube → yt-dlp → franken_whisper Path B; **diarization fusion** (`scripts/fuse_diarization.py` turns fw.json + Sortformer lanes into fused.txt/json); cleanup rules (`references/CLEANING.md`); **quality audit** (`scripts/clean_audit.py`) | `batch57/run_batch.py:25 FUSE = Path("/home/box/.cursor/skills/transcribing-youtube-videos/scripts/fuse_diarization.py")`, `:611-622` runs it on fw.json; `batch57/grok_cleanup_one.py:13 CLEANING = ".../transcribing-youtube-videos/references/CLEANING.md"`, `:65 Audit: .../scripts/clean_audit.py`. The same path is used in 47+ batch run_batch.py files and many per-video `build_cleaned.py` audit calls |
| 2 | **transcribing-audio-from-calls-and-meetings** | `/home/box/agent-data/workflows/transcribing-audio-from-calls-and-meetings` (same as `/workspace/jeffrey-skills/calls`) | **4-round cleanup**: R1 clean + speaker attribution (`assets/cleanup_agent_prompt.md`), R2 retention verify (`assets/verify_agent_prompt.md`), R3 fresh-eyes speaker map/[sic] (`assets/fresh_eyes_prompt.md`), plus references on hallucination, disfluency, cleanup agents and verification | `batch57/grok_cleanup_one.py:14-16 CLEANUP_PROMPT / VERIFY_PROMPT / FRESH_PROMPT = ".../transcribing-audio-from-calls-and-meetings/assets/*.md"`, inserted into the Grok Build DISPATCH_PROMPT at lines 61-64 (also in `/workspace/ingest/_cleanup_prompt_sample.txt:18-21`) |
| 3 | **fw** (franken_whisper operator skill) | `/home/box/agent-data/workflows/fw` (same as `~/.agents/skills/fw`, `~/.cursor/skills/fw`) | **ASR + Sortformer diarization** reference for the `fw` binary (CLI flags, `references/DIARIZATION.md` on the Sortformer 4-lane cap, troubleshooting) | *Indirect.* No script loads this SKILL.md. The pipeline runs the `fw` binary it documents: `batch57/run_batch.py:27 FW = Path("/home/box/.local/bin/fw")` with `--diarize --diarization-engine sortformer … --json` (L530-545), and casarosie2 `stages/fw.py:106-127` builds the same Path B argv. Included as the operator reference for that step |
| 4 | **grok-build-cleanup-pipeline** (Hans's workflow, not Jeffrey's) | `/home/box/agent-data/workflows/grok-build-cleanup-pipeline/SKILL.md` + `/workspace/ingest/lib/READY_PING_ROUTINE.md` | Orchestration: ASR → `grok_cleanup_one.py` (Grok Build CLI, `grok-4.6`) → ready_ping_queue → Notion Transcript Ingest (cleaned.md → FrankenTranscript, quality.md → Quality, Speakers) | SKILL.md steps 2-3 name `/workspace/ingest/lib/grok_build_pipeline.py` and `batchN/grok_cleanup_one.py`; `grok_build_pipeline.py:201 script = INGEST / f"batch{batch}" / "grok_cleanup_one.py"` |

## Adjacent, NOT in the transcript flow
| Skill | Source | Why included |
|---|---|---|
| choose-the-best-skills-for-me-to-run-in-this-project | `/home/box/agent-data/workflows/choose-the-best-skills-for-me-to-run-in-this-pro` (same as `/workspace/jeffrey-skills/selector`) | This is the only skill that actually talks to `jsm`/jeffreys-skills.md (`jsm install`, `jsm suggest`). It ranks and installs skills. No transcript, ASR, cleanup or Notion script references it. It is included because you named it, and it is kept in a separate folder so it can be dropped easily |

## casarosie2 (read-only inspection)
- Repo `/home/hcngbot/transcript-pipeline` @ `5e85822`. ASR is `src/transcript_pipeline/stages/fw.py` (Path B argv: `--diarize --diarization-engine sortformer`, "No pyannote / faster-whisper").
- Cleanup is `src/transcript_pipeline/cleanup/cursor_backend.py`. It uses cursor-agent (`cursor-grok-4.6-{effort}`), `ROUND_NAMES = r1_cleanup, r2_verify, r3_fresh_eyes, r4_finalize`, and an inline prompt ("4-ROUND CONTRACT (same as CTS ingest cleanup)"). Speaker naming comes from show priors (`priors.py`, `data/shows/*.json`), not a skill. It writes cleaned.md, quality.md and speaker_map.json.
- No SKILL.md is loaded or installed. The prompt copies the same 4-round contract as the box skills (#1/#2), but it restates it inline instead of pointing at the files.

## Excluded
- Secrets: repo `.env`, `.env.bak-prewebhook`, `~/.cursor` config (not copied, not printed); `.venv`, `data/`, `artifacts/`, `tp_artifacts/`.
- Audio, media, and per-video ingest artifacts (fused/cleaned/quality outputs, Notion payloads).
- `__pycache__/*.pyc`.
- Unrelated box skills: last30days, the aip-* workflows, descript-*, log-youtube-a-b-tests, graphify-codebase-orientation, and the managed/plugin skills under sand-data.
- The FastAPI-vendored SKILL.md on casarosie2.
