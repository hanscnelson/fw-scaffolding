"""Show / job speaker priors — prefer real names over Host.

Mirrors Path B (`ingest/postprocess/triage_scan.py`) channel-host priors:
when job metadata or show config supplies host/guest names (or a known
channel matches), cleanup must use those display names. Fall back to
Host / SPEAKER_XX only when priors are missing.

Expected schemas
----------------
Job create (API) — any of these work; nested under `metadata` is fine:

  POST /jobs
  {
    "source": "https://…",
    "show_priors": {
      "channel": "Farzad",
      "hosts": ["Hans C Nelson", "Alex"],
      "guests": [],
      "speaker_hints": {"SPEAKER_00": "Alex", "SPEAKER_01": "Hans C Nelson"}
    }
  }

  # or:
  {
    "source": "…",
    "metadata": {
      "channel": "Farzad",
      "title": "…",
      "show_priors": { "hosts": ["Hans C Nelson", "Alex"] }
    }
  }

Show config file (`$SHOW_CONFIG_DIR/<slug>.json` or `data/shows/*.json`):

  {
    "channel_match": ["farzad"],
    "hosts": ["Hans C Nelson", "Alex"],
    "guests": [],
    "speaker_hints": {}
  }

Resolved priors object passed into the Cursor prompt (SHOW PRIORS JSON):

  {
    "channel": "Farzad",
    "hosts": ["Hans C Nelson", "Alex"],
    "guests": [],
    "speaker_hints": {"SPEAKER_00": "Alex", "SPEAKER_01": "Hans C Nelson"},
    "roster_source": "job_show_priors" | "show_config" | "channel_prior" | "none",
    "title": "…"
  }

speaker_map.json remains STACK_LOCK flat:
  {"SPEAKER_00":"Alex","SPEAKER_01":"Hans C Nelson"}
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Mapping, Sequence

# Path B CHANNEL_HOST_PRIORS (triage_scan.py) — substring match on lowercased channel
CHANNEL_HOST_PRIORS: list[tuple[str, list[str]]] = [
    ("brighter with herbert", ["Herbert Ong", "Hans Nelson"]),
    ("brighterwithherbert", ["Herbert Ong", "Hans Nelson"]),
    ("farzad", ["Farzad Mesbahi", "Hans Nelson"]),
    ("tesla owners silicon valley", ["John", "Joe", "Brian", "Hans Nelson"]),
    ("teslaownerssv", ["John", "Joe", "Brian", "Hans Nelson"]),
]


def _as_str_list(val: Any) -> list[str]:
    if val is None:
        return []
    if isinstance(val, str):
        s = val.strip()
        return [s] if s else []
    if isinstance(val, Sequence) and not isinstance(val, (bytes, bytearray)):
        out: list[str] = []
        for x in val:
            if x is None:
                continue
            s = str(x).strip()
            if s:
                out.append(s)
        return out
    return []


def _flat_hint_map(val: Any) -> dict[str, str]:
    """Accept flat SPEAKER_XX -> name only; ignore nested junk."""
    if not isinstance(val, Mapping):
        return {}
    out: dict[str, str] = {}
    for k, v in val.items():
        key = str(k).strip()
        if not key.startswith("SPEAKER_"):
            continue
        if isinstance(v, Mapping):
            continue
        name = str(v).strip() if v is not None else ""
        if name:
            out[key] = name
    return out


def channel_host_prior(channel: str) -> list[str]:
    """Path B interface: channel substring → default host display names."""
    ch = (channel or "").lower()
    if not ch:
        return []
    for key, hosts in CHANNEL_HOST_PRIORS:
        if key in ch:
            return list(hosts)
    return []


def default_show_config_dir() -> Path:
    env = os.environ.get("SHOW_CONFIG_DIR", "").strip()
    if env:
        return Path(env)
    here = Path(__file__).resolve()
    # .../src/transcript_pipeline/cleanup/priors.py → repo root
    repo = here.parents[3] if len(here.parents) >= 4 else Path.cwd()
    candidate = repo / "data" / "shows"
    if candidate.is_dir():
        return candidate
    fixtures = repo / "fixtures" / "shows"
    if fixtures.is_dir():
        return fixtures
    return candidate


def load_show_configs(config_dir: Path | None = None) -> list[dict[str, Any]]:
    root = config_dir or default_show_config_dir()
    if not root.is_dir():
        return []
    configs: list[dict[str, Any]] = []
    for path in sorted(root.glob("*.json")):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if isinstance(data, dict):
            data = dict(data)
            data.setdefault("_config_path", str(path))
            configs.append(data)
    return configs


def match_show_config(
    channel: str,
    *,
    config_dir: Path | None = None,
) -> dict[str, Any] | None:
    ch = (channel or "").lower().strip()
    if not ch:
        return None
    for cfg in load_show_configs(config_dir):
        matches = _as_str_list(cfg.get("channel_match") or cfg.get("channels"))
        if not matches and cfg.get("channel"):
            matches = _as_str_list(cfg.get("channel"))
        for m in matches:
            if m.lower() in ch or ch in m.lower():
                return cfg
    return None


def _extract_job_priors_blob(metadata: Mapping[str, Any] | None) -> dict[str, Any]:
    """Pull show_priors / hosts / channel from job metadata or top-level aliases."""
    if not metadata:
        return {}
    blob: dict[str, Any] = {}
    nested = metadata.get("show_priors")
    if isinstance(nested, Mapping):
        blob.update(dict(nested))
    for key in ("hosts", "guests", "speaker_hints", "speaker_map", "channel", "title"):
        if key in metadata and (key not in blob or blob.get(key) in (None, "", [], {})):
            blob[key] = metadata[key]
    if "speaker_hints" not in blob and "speaker_map" in blob:
        blob["speaker_hints"] = blob.get("speaker_map")
    return blob


def resolve_show_priors(
    metadata: Mapping[str, Any] | None = None,
    *,
    channel: str | None = None,
    title: str | None = None,
    config_dir: Path | None = None,
) -> dict[str, Any]:
    """Merge job metadata + show config + Path B channel priors.

    Preference order for host roster:
      1. Explicit job show_priors.hosts / speaker_hints
      2. Matching show config file
      3. Built-in CHANNEL_HOST_PRIORS (Path B)
      4. empty → cleanup falls back to Host / SPEAKER_XX
    """
    meta = dict(metadata or {})
    blob = _extract_job_priors_blob(meta)

    ch = (
        (channel or "").strip()
        or str(blob.get("channel") or meta.get("channel") or "").strip()
    )
    tit = (
        (title or "").strip()
        or str(blob.get("title") or meta.get("title") or "").strip()
    )

    hosts = _as_str_list(blob.get("hosts"))
    guests = _as_str_list(blob.get("guests"))
    hints = _flat_hint_map(blob.get("speaker_hints") or blob.get("speaker_map"))
    roster_source = "none"

    if hosts or hints:
        roster_source = "job_show_priors"
    else:
        cfg = match_show_config(ch, config_dir=config_dir)
        if cfg:
            hosts = _as_str_list(cfg.get("hosts"))
            guests = _as_str_list(cfg.get("guests")) or guests
            cfg_hints = _flat_hint_map(cfg.get("speaker_hints") or cfg.get("speaker_map"))
            hints = cfg_hints or hints
            if not ch:
                matches = _as_str_list(cfg.get("channel_match") or cfg.get("channel"))
                ch = matches[0] if matches else ch
            roster_source = "show_config"
        else:
            prior_hosts = channel_host_prior(ch)
            if prior_hosts:
                hosts = prior_hosts
                roster_source = "channel_prior"

    return {
        "channel": ch or None,
        "title": tit or None,
        "hosts": hosts,
        "guests": guests,
        "speaker_hints": hints,
        "roster_source": roster_source,
    }


def priors_are_empty(priors: Mapping[str, Any] | None) -> bool:
    if not priors:
        return True
    hosts = _as_str_list(priors.get("hosts"))
    guests = _as_str_list(priors.get("guests"))
    hints = _flat_hint_map(priors.get("speaker_hints"))
    return not (hosts or guests or hints)


def named_speaker_map_from_priors(
    priors: Mapping[str, Any] | None,
    *,
    cluster_ids: Sequence[str] | None = None,
) -> dict[str, str]:
    """Build a flat STACK_LOCK speaker_map from resolved priors.

    Prefer explicit speaker_hints. Else assign hosts (+ guests) in order to
    SPEAKER_00, SPEAKER_01, …. Extra clusters keep SPEAKER_XX (not invented Host).
    """
    priors = priors or {}
    hints = _flat_hint_map(priors.get("speaker_hints"))
    if hints:
        return dict(sorted(hints.items(), key=lambda kv: kv[0]))

    roster = _as_str_list(priors.get("hosts")) + _as_str_list(priors.get("guests"))
    if not roster:
        return {}

    if cluster_ids:
        ids = [str(c) for c in cluster_ids]
    else:
        ids = [f"SPEAKER_{i:02d}" for i in range(len(roster))]

    out: dict[str, str] = {}
    for i, cid in enumerate(ids):
        if i < len(roster):
            out[cid] = roster[i]
        else:
            out[cid] = cid
    return out


def write_show_priors_artifact(work_dir: Path, priors: Mapping[str, Any]) -> Path:
    path = work_dir / "show_priors.json"
    path.write_text(
        json.dumps(dict(priors), indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return path
