"""Cursor cleanup backend — 4-round contract via Cursor agent CLI.

Per Forge/Hans: cleanup ALWAYS runs through Cursor; only model/effort change.
- A/B now: CLEANUP_MODEL=grok-4.6 CLEANUP_EFFORT=low
- Later: Gemini 3.8 Flash still via Cursor (same provider path)
- CLEANUP_PROVIDER defaults to "cursor" (no separate gemini provider)

Artifacts (STACK_LOCK contract):
  cleaned.md, quality.md, speaker_map.json (flat SPEAKER_XX -> display_name; prefer priors)

Env knobs:
  CLEANUP_PROVIDER   default "cursor"
  CLEANUP_MODEL      default "grok-4.6" (do not hardcode into stage logic)
  CLEANUP_EFFORT     default "low"
  CLEANUP_DRY_RUN    "1" -> write placeholders without invoking Cursor
  CLEANUP_CURSOR_BIN optional path to cursor-agent / agent CLI
  CLEANUP_MAX_TURNS  default "80"
  CLEANUP_TIMEOUT_SEC default "3600"
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping

LogFn = Callable[[str], None]

ARTIFACT_NAMES = ("cleaned.md", "quality.md", "speaker_map.json")

ROUND_NAMES = (
    "r1_cleanup",
    "r2_verify",
    "r3_fresh_eyes",
    "r4_finalize",
)


@dataclass(frozen=True)
class CleanupConfig:
    provider: str = "cursor"
    model: str = "grok-4.6"
    effort: str = "low"
    dry_run: bool = False
    cursor_bin: str | None = None
    max_turns: int = 80
    timeout_sec: float = 3600.0

    @classmethod
    def from_env(cls) -> "CleanupConfig":
        dry = os.environ.get("CLEANUP_DRY_RUN", "").strip().lower() in (
            "1",
            "true",
            "yes",
            "on",
        )
        bin_override = os.environ.get("CLEANUP_CURSOR_BIN") or None
        return cls(
            provider=os.environ.get("CLEANUP_PROVIDER", "cursor").strip() or "cursor",
            model=os.environ.get("CLEANUP_MODEL", "grok-4.6").strip() or "grok-4.6",
            effort=os.environ.get("CLEANUP_EFFORT", "low").strip() or "low",
            dry_run=dry,
            cursor_bin=bin_override,
            max_turns=int(os.environ.get("CLEANUP_MAX_TURNS", "80") or "80"),
            timeout_sec=float(
                os.environ.get("CLEANUP_TIMEOUT_SEC", "3600") or "3600"
            ),
        )


def detect_cursor_cli(explicit: str | None = None) -> tuple[str | None, str]:
    """Locate a Cursor-compatible agent CLI.

    Preference order:
      1. CLEANUP_CURSOR_BIN / explicit
      2. cursor-agent on PATH (mise wrapper common on rosie hosts)
      3. cursor on PATH
    Returns (path_or_none, note).

    Note: Grok Build `agent` is NOT used here — cleanup must go through Cursor.
    Agent Mail `am` is coordination only, not the cleanup runner.
    """
    candidates: list[str] = []
    if explicit:
        candidates.append(explicit)
    for name in ("cursor-agent", "cursor"):
        found = shutil.which(name)
        if found:
            candidates.append(found)
    home = Path.home()
    for p in (
        home / ".local/bin/cursor-agent",
        home / ".local/bin/cursor",
        Path("/usr/local/bin/cursor-agent"),
        Path("/usr/local/bin/cursor"),
    ):
        if p.is_file() and os.access(p, os.X_OK):
            candidates.append(str(p))

    seen: set[str] = set()
    for c in candidates:
        if c in seen:
            continue
        seen.add(c)
        if Path(c).exists():
            return c, f"detected {c}"

    am = shutil.which("am")
    if am:
        return None, f"no cursor-agent/cursor CLI; agent-mail present at {am} (mail only)"

    return None, "no cursor-agent or cursor CLI on PATH"


def _read_transcript_text(fw_json: Path) -> str:
    if not fw_json.exists():
        return f"(missing ASR artifact: {fw_json})"
    try:
        raw = fw_json.read_text(encoding="utf-8", errors="replace")
        data = json.loads(raw)
    except (OSError, json.JSONDecodeError):
        return fw_json.read_text(encoding="utf-8", errors="replace")[:200_000]

    if isinstance(data, dict):
        if "text" in data and isinstance(data["text"], str):
            return data["text"]
        segs = data.get("segments") or data.get("transcription") or []
        if isinstance(segs, list) and segs:
            lines: list[str] = []
            for s in segs:
                if not isinstance(s, dict):
                    continue
                spk = s.get("speaker") or s.get("speaker_id") or "SPEAKER_?"
                txt = s.get("text") or s.get("transcript") or ""
                t0 = s.get("start") or s.get("t0") or ""
                lines.append(f"[{spk}] ({t0}) {txt}".rstrip())
            if lines:
                return "\n".join(lines)
    return raw[:200_000]


def _build_dispatch_prompt(
    work_dir: Path,
    fw_json: Path,
    transcript_preview: str,
    show_priors: Mapping[str, Any] | None,
    cfg: CleanupConfig,
) -> str:
    priors_block = json.dumps(show_priors or {}, indent=2, ensure_ascii=False)
    preview = transcript_preview[:80_000]
    r1, r2, r3, r4 = ROUND_NAMES
        # Example JSON kept out of brace-escaping hazards in the f-string body.
    example_map = '{"SPEAKER_00":"Alex","SPEAKER_01":"Hans C Nelson"}'
    example_map_ellipsis = '{"SPEAKER_00":"Alex","SPEAKER_01":"Hans C Nelson",...}'
    return f"""You are running the 4-round CLEANED transcript pipeline for ONE job.
Do NOT chat with a user. Write files to disk under:
  {work_dir}

Provider path: Cursor (CLEANUP_PROVIDER={cfg.provider}).
Model/effort come from env only (do not invent providers): model={cfg.model} effort={cfg.effort}.

INPUT ASR:
  {fw_json}

SHOW PRIORS (job metadata + show config + channel priors — USE these real names when present):
```json
{priors_block}
```
If SHOW PRIORS is non-empty (hosts/guests/speaker_hints), prefer those display names
over generic "Host". Example flat map when priors name Alex + Hans C Nelson:
  {example_map}

TRANSCRIPT PREVIEW (may be truncated; prefer reading {fw_json.name} fully):
```
{preview}
```

REQUIRED ARTIFACTS (exact names — STACK_LOCK contract):
  1. cleaned.md       — named-speaker publishable transcript
  2. quality.md       — quality / retention / QA flags (Sortformer 4-lane caveat)
  3. speaker_map.json — FLAT object only: {example_map_ellipsis}
     Keys = Sortformer cluster ids; values = display_name strings. No nested objects.

4-ROUND CONTRACT (same as CTS ingest cleanup):
  Round 1 ({r1}): clean + attribute speakers from content; soft SPEAKER_* labels
  Round 2 ({r2}): verify retention / no content loss
  Round 3 ({r3}): fresh-eyes pass on speaker map + remaining [sic]
  Round 4 ({r4}): finalize the three artifacts; short meta in quality.md

RULES:
  - Sortformer is 4-lane capped — treat SPEAKER_* as soft
  - SPEAKER NAMING (prefer real names):
      1. If SHOW PRIORS has speaker_hints (flat SPEAKER_XX -> name), USE them.
      2. Else if SHOW PRIORS lists hosts/guests (or channel/show config resolved
         them), map clusters to those display names using content cues
         (who hosts, who is addressed). Prefer "Hans C Nelson" / "Alex" style
         names from priors over the generic label "Host".
      3. Do NOT invent surnames from thin air when priors are empty — then
         fall back to short first names heard in ASR, or "Host" / leave
         SPEAKER_XX only as last resort. Flag thin naming in quality.md.
  - speaker_map.json MUST be flat SPEAKER_XX -> display_name (string values)
    e.g. {example_map} — no nested objects
  - Do NOT add youtu.be/?t= deep links unless STACK_LOCK later requires them
  - Every substantive sentence survives; do not summarize away content
  - Notion is OUT OF BAND — do not call Notion APIs
  - Do NOT invoke faster-whisper / pyannote / HF diarize

When finished: ensure the three artifacts exist; print their paths and a one-line status.
"""


def _write_placeholders(
    work_dir: Path,
    fw_json: Path,
    cfg: CleanupConfig,
    reason: str,
    rounds_note: str,
    show_priors: Mapping[str, Any] | None = None,
) -> dict[str, Path]:
    cleaned = work_dir / "cleaned.md"
    quality = work_dir / "quality.md"
    speaker_map = work_dir / "speaker_map.json"

    cleaned.write_text(
        "\n".join(
            [
                "# Cleaned transcript (Cursor cleanup placeholder)",
                "",
                f"_provider={cfg.provider} model={cfg.model} effort={cfg.effort}_",
                f"_reason: {reason}_",
                f"_source: `{fw_json.name}`_",
                "",
                "## Rounds",
                rounds_note,
                "",
                "Replace this file when live Cursor cleanup completes.",
                "",
            ]
        ),
        encoding="utf-8",
    )

    quality_lines = [
        "# Quality notes (Cursor cleanup placeholder)",
        "",
        f"- Status: placeholder ({reason})",
        f"- Provider: `{cfg.provider}` (fixed; model/effort only knobs)",
        f"- Model: `{cfg.model}`",
        f"- Effort: `{cfg.effort}`",
        "- Sortformer 4-lane caveat: treat SPEAKER_* as soft labels",
        "- Rounds: " + ", ".join(ROUND_NAMES),
        "",
    ]
    quality.write_text("\n".join(quality_lines), encoding="utf-8")

    # Prefer real names from priors when present (STACK_LOCK flat map).
    from transcript_pipeline.cleanup.priors import (
        named_speaker_map_from_priors,
        priors_are_empty,
    )
    if not priors_are_empty(show_priors):
        sm_obj = named_speaker_map_from_priors(show_priors)
        if not sm_obj:
            sm_obj = {"SPEAKER_00": "UNKNOWN"}
    else:
        sm_obj = {"SPEAKER_00": "UNKNOWN"}
    speaker_map.write_text(
        json.dumps(sm_obj, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    return {
        "cleaned.md": cleaned,
        "quality.md": quality,
        "speaker_map.json": speaker_map,
    }


def _artifacts_present(work_dir: Path) -> bool:
    return all(
        (work_dir / n).is_file() and (work_dir / n).stat().st_size > 0
        for n in ARTIFACT_NAMES
    )


def _invoke_cursor(
    cli: str,
    work_dir: Path,
    prompt_path: Path,
    cfg: CleanupConfig,
    log: LogFn,
) -> int:
    """Invoke Cursor agent CLI in headless/print mode with model + effort."""
    # CLI (2026.09.15): --model (not -m); output-format text|json|stream-json;
    # effort is a model bracket override; workspace replaces --cwd; --force replaces
    # --always-approve. --max-turns is not supported by current cursor-agent.
    # Cursor CLI lists Grok as cursor-grok-4.6-{effort}, not grok-4.6[effort=...].
    model_arg = cfg.model
    if cfg.model in ("grok-4.6", "grok-4.5") or cfg.model.startswith("grok-4."):
        model_arg = f"cursor-{cfg.model}-{cfg.effort or "low"}"
    elif cfg.model.startswith("cursor-grok-"):
        model_arg = cfg.model  # already a CLI id (effort baked into name)
    elif cfg.effort and "[" not in cfg.model:
        model_arg = f"{cfg.model}[effort={cfg.effort}]"
    cmd = [
        cli,
        "-p",
        (
            f"Execute the cleanup instructions in {prompt_path}. "
            f"Read that file first and follow it completely. "
            f"Write cleaned.md, quality.md, speaker_map.json under {work_dir}."
        ),
        "--model",
        model_arg,
        "--output-format",
        "text",
        "--workspace",
        str(work_dir),
    ]
    env = os.environ.copy()
    path_extra = str(Path.home() / ".local/bin")
    env["PATH"] = f"{path_extra}:{env.get('PATH', '')}"
    env["CLEANUP_MODEL"] = cfg.model
    env["CLEANUP_EFFORT"] = cfg.effort
    env["CLEANUP_PROVIDER"] = cfg.provider

    log_path = work_dir / "cursor_cleanup.log"
    cmd_preview = " ".join(cmd[:6])
    log(
        f"[cleanup/cursor] invoke: {cmd_preview} ... "
        f"model={cfg.model} effort={cfg.effort}"
    )

    attempts: list[list[str]] = [
        cmd + ["--force", "--trust"],
        cmd + ["--force"],
        cmd,
    ]

    last_rc = 1
    with log_path.open("w", encoding="utf-8") as lf:
        lf.write(
            f"# cursor cleanup log\n# cli={cli}\n"
            f"# model={cfg.model} effort={cfg.effort}\n\n"
        )
        for attempt in attempts:
            lf.write(f"\n## attempt: {attempt}\n")
            lf.flush()
            try:
                proc = subprocess.run(
                    attempt,
                    cwd=str(work_dir),
                    env=env,
                    stdout=lf,
                    stderr=subprocess.STDOUT,
                    text=True,
                    timeout=cfg.timeout_sec,
                )
                last_rc = proc.returncode
                lf.write(f"\n# exit={proc.returncode}\n")
                if proc.returncode == 0 or _artifacts_present(work_dir):
                    return proc.returncode
                continue
            except FileNotFoundError:
                lf.write("# FileNotFoundError\n")
                return 127
            except subprocess.TimeoutExpired:
                lf.write(f"# TimeoutExpired after {cfg.timeout_sec}s\n")
                log(f"[cleanup/cursor] timed out after {cfg.timeout_sec}s")
                return 124
    return last_rc


def run_cursor_cleanup(
    work_dir: Path,
    fw_json: Path,
    log: LogFn,
    *,
    show_priors: Mapping[str, Any] | None = None,
    config: CleanupConfig | None = None,
) -> dict[str, Path]:
    """Run 4-round cleanup via Cursor; return paths to the three artifacts.

    Interface: input transcript (+ optional show priors) -> 4 rounds -> three artifacts.
    """
    cfg = config or CleanupConfig.from_env()
    work_dir.mkdir(parents=True, exist_ok=True)

    if cfg.provider != "cursor":
        log(
            f"[cleanup/cursor] WARNING: CLEANUP_PROVIDER={cfg.provider!r} "
            "ignored — cleanup always uses Cursor path (model/effort only)"
        )
        cfg = CleanupConfig(
            provider="cursor",
            model=cfg.model,
            effort=cfg.effort,
            dry_run=cfg.dry_run,
            cursor_bin=cfg.cursor_bin,
            max_turns=cfg.max_turns,
            timeout_sec=cfg.timeout_sec,
        )

    log(
        f"[cleanup/cursor] provider=cursor model={cfg.model} effort={cfg.effort} "
        f"dry_run={cfg.dry_run}"
    )

    transcript = _read_transcript_text(fw_json)
    # Persist resolved priors next to artifacts (job/show/channel merge happens upstream)
    if show_priors:
        from transcript_pipeline.cleanup.priors import write_show_priors_artifact
        write_show_priors_artifact(work_dir, show_priors)
    prompt = _build_dispatch_prompt(work_dir, fw_json, transcript, show_priors, cfg)
    prompt_path = work_dir / "DISPATCH_PROMPT.txt"
    prompt_path.write_text(prompt, encoding="utf-8")

    rounds_note = " -> ".join(ROUND_NAMES)

    if cfg.dry_run:
        log("[cleanup/cursor] CLEANUP_DRY_RUN=1 — writing placeholders")
        outs = _write_placeholders(
            work_dir, fw_json, cfg, "CLEANUP_DRY_RUN=1", rounds_note,
            show_priors=show_priors,
        )
        meta = {
            "provider": "cursor",
            "model": cfg.model,
            "effort": cfg.effort,
            "dry_run": True,
            "rounds": list(ROUND_NAMES),
        }
        (work_dir / "cursor_cleanup_meta.json").write_text(
            json.dumps(meta, indent=2) + "\n", encoding="utf-8"
        )
        return outs

    cli, note = detect_cursor_cli(cfg.cursor_bin)
    log(f"[cleanup/cursor] CLI detect: {note}")

    if not cli:
        log("[cleanup/cursor] Cursor CLI unavailable — writing placeholders")
        outs = _write_placeholders(
            work_dir,
            fw_json,
            cfg,
            "cursor CLI not available; set CLEANUP_CURSOR_BIN or install cursor-agent",
            rounds_note,
            show_priors=show_priors,
        )
        meta = {
            "provider": "cursor",
            "model": cfg.model,
            "effort": cfg.effort,
            "dry_run": False,
            "cli": None,
            "detect_note": note,
            "rounds": list(ROUND_NAMES),
        }
        (work_dir / "cursor_cleanup_meta.json").write_text(
            json.dumps(meta, indent=2) + "\n", encoding="utf-8"
        )
        return outs

    t0 = time.time()
    rc = _invoke_cursor(cli, work_dir, prompt_path, cfg, log)
    wall = round(time.time() - t0, 1)

    if not _artifacts_present(work_dir):
        log(
            f"[cleanup/cursor] live invoke incomplete (rc={rc}, wall={wall}s) — "
            "ensuring placeholder artifacts"
        )
        outs = _write_placeholders(
            work_dir,
            fw_json,
            cfg,
            f"live Cursor invoke incomplete rc={rc}; see cursor_cleanup.log",
            rounds_note,
            show_priors=show_priors,
        )
    else:
        outs = {
            "cleaned.md": work_dir / "cleaned.md",
            "quality.md": work_dir / "quality.md",
            "speaker_map.json": work_dir / "speaker_map.json",
        }
        log(f"[cleanup/cursor] artifacts OK rc={rc} wall={wall}s")

    meta = {
        "provider": "cursor",
        "model": cfg.model,
        "effort": cfg.effort,
        "cli": cli,
        "exit": rc,
        "wall_sec": wall,
        "artifacts_ok": _artifacts_present(work_dir),
        "rounds": list(ROUND_NAMES),
    }
    (work_dir / "cursor_cleanup_meta.json").write_text(
        json.dumps(meta, indent=2) + "\n", encoding="utf-8"
    )
    return outs
