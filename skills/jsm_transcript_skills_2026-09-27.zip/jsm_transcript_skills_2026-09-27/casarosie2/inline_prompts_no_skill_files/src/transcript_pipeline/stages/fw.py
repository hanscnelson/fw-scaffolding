"""FrankenWhisper (fw) stage — Chester STACK_LOCK Path B argv only.

No pyannote / faster-whisper. FW_MOCK=1 writes a synthetic fw.json for E2E.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path
from typing import Callable

from transcript_pipeline.config import Settings

LogFn = Callable[[str], None]

DTW_MARKER = "FW-DTW-PROJECTION-PARENT-DURATION"
AUDIO_DROPPED_MARKER = "audio dropped"


def _truthy(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in ("1", "true", "yes", "on")


def _wav_duration_sec(wav_path: Path) -> float:
    """Return WAV duration in seconds via ffprobe (STACK_LOCK budget input)."""
    if not shutil.which("ffprobe"):
        raise RuntimeError("ffprobe not found on PATH (needed for stage budgets)")
    proc = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-show_entries",
            "format=duration",
            "-of",
            "default=nk=1:nw=1",
            str(wav_path),
        ],
        check=False,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        raise RuntimeError(f"ffprobe failed: {(proc.stderr or proc.stdout)[-500:]}")
    raw = (proc.stdout or "").strip()
    if not raw:
        raise RuntimeError("ffprobe returned empty duration")
    return float(raw)


def _stage_budget_ms(duration_sec: float) -> int:
    """STACK_LOCK: max(900_000, duration_sec * 3000) ms for BACKEND + DIARIZE."""
    return max(900_000, int(duration_sec * 3000))


def _outer_timeout_sec(duration_sec: float) -> int:
    """Forge: max(3600, duration_sec * 4 + 600)."""
    return max(3600, int(duration_sec * 4 + 600))


def _mock_fw_json(wav_path: Path, work_dir: Path, log: LogFn) -> Path:
    """Synthetic diarized transcript for E2E until real fw lands."""
    out_json = work_dir / "fw.json"
    err_path = work_dir / "fw.err"
    payload = {
        "mock": True,
        "backend": "whisper-cpp",
        "diarization_engine": "sortformer",
        "input": str(wav_path),
        "segments": [
            {
                "speaker": "SPEAKER_00",
                "start": 0.0,
                "end": 1.5,
                "text": "Hello, this is a mock FrankenWhisper transcript.",
            },
            {
                "speaker": "SPEAKER_01",
                "start": 1.5,
                "end": 3.0,
                "text": "FW_MOCK=1 path — replace with live fw when binary is ready.",
            },
        ],
        "text": (
            "Hello, this is a mock FrankenWhisper transcript. "
            "FW_MOCK=1 path — replace with live fw when binary is ready."
        ),
    }
    out_json.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    err_path.write_text("[fw mock] no stderr\n", encoding="utf-8")
    log(f"[fw] FW_MOCK=1 wrote {out_json.name} (+ {err_path.name})")
    return out_json


def _build_argv(
    wav_path: Path,
    settings: Settings,
    *,
    split_on_word: bool,
    timeout_sec: int | None,
) -> list[str]:
    argv = [
        settings.fw_bin,
        "transcribe",
        "--input",
        str(wav_path),
        "--backend",
        "whisper-cpp",
        "--threads",
        str(settings.fw_threads),
        "--processors",
        str(settings.fw_processors),
        "--diarize",
        "--diarization-engine",
        "sortformer",
        "--language",
        "en",
        "--no-persist",
        "--max-segment-length",
        "90",
    ]
    if split_on_word:
        argv.append("--split-on-word")
    argv.append("--json")
    if timeout_sec is not None and timeout_sec > 0:
        argv.extend(["--timeout", str(timeout_sec)])
    if settings.taskset_cpus:
        argv = ["taskset", "-c", settings.taskset_cpus, *argv]
    return argv


def _fw_env(settings: Settings, *, budget_ms: int) -> dict[str, str]:
    env = os.environ.copy()
    env["FW_RETRY_FAILED_WINDOW"] = str(settings.fw_retry_failed_window)
    env["RAYON_NUM_THREADS"] = str(settings.fw_threads)
    models = settings.fw_models_dir or "/models"
    env["FRANKEN_WHISPER_MODEL_DIR"] = models
    env["FW_MODELS_DIR"] = models
    env["FRANKEN_WHISPER_STAGE_BUDGET_BACKEND_MS"] = str(budget_ms)
    env["FRANKEN_WHISPER_STAGE_BUDGET_DIARIZE_MS"] = str(budget_ms)
    return env


def _run_once(
    argv: list[str],
    work_dir: Path,
    env: dict[str, str],
    log: LogFn,
) -> subprocess.CompletedProcess[str]:
    log(f"[fw] Path B argv: {' '.join(argv)}")
    return subprocess.run(
        argv,
        check=False,
        capture_output=True,
        text=True,
        env=env,
        cwd=str(work_dir),
    )


def run_fw(wav_path: Path, work_dir: Path, settings: Settings, log: LogFn) -> Path:
    """Invoke `fw` with Chester STACK_LOCK Path B argv, or FW_MOCK=1."""
    if not wav_path.exists():
        raise FileNotFoundError(wav_path)

    if _truthy("FW_MOCK") or getattr(settings, "fw_mock", False):
        return _mock_fw_json(wav_path, work_dir, log)

    fw_bin = settings.fw_bin
    if not shutil.which(fw_bin) and not Path(fw_bin).is_file():
        raise RuntimeError(
            f"fw binary not found ({fw_bin!r}). "
            "Set FW_MOCK=1 for E2E without binary, or see scripts/install-fw.sh."
        )

    out_json = work_dir / "fw.json"
    err_path = work_dir / "fw.err"

    duration_sec = _wav_duration_sec(wav_path)
    budget_ms = _stage_budget_ms(duration_sec)
    env_timeout = int(os.environ.get("FW_TIMEOUT_SEC", "0") or "0")
    timeout_sec = env_timeout if env_timeout > 0 else _outer_timeout_sec(duration_sec)

    env = _fw_env(settings, budget_ms=budget_ms)
    log(
        f"[fw] wav_duration_sec={duration_sec:.3f} "
        f"stage_budget_ms={budget_ms} "
        f"outer_timeout_sec={timeout_sec} "
        f"threads={settings.fw_threads} "
        f"RAYON_NUM_THREADS={env['RAYON_NUM_THREADS']} "
        f"taskset={settings.taskset_cpus!r}"
    )
    log(f"[fw] FRANKEN_WHISPER_STAGE_BUDGET_BACKEND_MS={budget_ms}")
    log(f"[fw] FRANKEN_WHISPER_STAGE_BUDGET_DIARIZE_MS={budget_ms}")

    forbidden = ("pyannote", "faster-whisper", "faster_whisper", "whisperx")

    def _guard(argv: list[str]) -> None:
        joined = " ".join(argv).lower()
        for bad in forbidden:
            if bad in joined:
                raise RuntimeError(f"refusing forbidden ASR stack token in argv: {bad}")

    split_on_word = True
    argv = _build_argv(
        wav_path, settings, split_on_word=split_on_word, timeout_sec=timeout_sec
    )
    _guard(argv)
    log(f"[fw] FW_RETRY_FAILED_WINDOW={env['FW_RETRY_FAILED_WINDOW']}")
    log(f"[fw] FRANKEN_WHISPER_MODEL_DIR={env.get('FRANKEN_WHISPER_MODEL_DIR')}")

    proc = _run_once(argv, work_dir, env, log)
    stderr = proc.stderr or ""
    stdout = proc.stdout or ""

    if DTW_MARKER in stderr and split_on_word:
        log(f"[fw] {DTW_MARKER} seen — rerunning without --split-on-word")
        split_on_word = False
        argv = _build_argv(
            wav_path, settings, split_on_word=False, timeout_sec=timeout_sec
        )
        _guard(argv)
        proc = _run_once(argv, work_dir, env, log)
        stderr = proc.stderr or ""
        stdout = proc.stdout or ""

    if AUDIO_DROPPED_MARKER in stderr.lower():
        # FW often still returns success=true with only a tiny trailing window
        # dropped. Retry once with sampling-ladder recovery, then accept if we
        # still got a usable JSON transcript (do not hard-fail on the WARN alone).
        log(
            "[fw] stderr contains 'audio dropped' — retrying once with "
            "FW_TEMP_FALLBACK=1"
        )
        env_fb = dict(env)
        env_fb["FW_TEMP_FALLBACK"] = "1"
        proc = _run_once(argv, work_dir, env_fb, log)
        stderr = proc.stderr or ""
        stdout = proc.stdout or ""
        if AUDIO_DROPPED_MARKER in stderr.lower():
            log(
                "[fw] 'audio dropped' still present after TEMP_FALLBACK retry; "
                "will accept if returncode==0 and stdout JSON has segments"
            )

    err_path.write_text(stderr, encoding="utf-8")
    if stdout:
        log(f"[fw] stdout (tail): {stdout[-4000:]}")
    if stderr:
        log(f"[fw] stderr (tail): {stderr[-2000:]}")

    if proc.returncode != 0:
        raise RuntimeError(f"fw exited {proc.returncode}; see {err_path}")

    payload = stdout.strip()
    if payload:
        try:
            parsed = json.loads(payload)
            out_json.write_text(json.dumps(parsed, indent=2) + "\n", encoding="utf-8")
        except json.JSONDecodeError:
            out_json.write_text(payload + "\n", encoding="utf-8")
            log("[fw] warning: stdout was not JSON; wrote raw text to fw.json")
    else:
        out_json.write_text("{}\n", encoding="utf-8")
        log("[fw] warning: empty stdout; wrote empty JSON object")

    # Soft gate: only fail audio-dropped if the transcript is unusable.
    if AUDIO_DROPPED_MARKER in stderr.lower():
        segs = []
        try:
            parsed_check = json.loads(out_json.read_text(encoding="utf-8"))
            segs = (
                (parsed_check.get("result") or {}).get("segments")
                or parsed_check.get("segments")
                or []
            )
        except Exception:
            segs = []
        if proc.returncode != 0 or not segs:
            raise RuntimeError(
                f"fw audio-dropped and unusable transcript "
                f"(rc={proc.returncode}, segments={len(segs)}); see {err_path}"
            )
        log(
            f"[fw] accepting transcript despite audio-dropped WARN "
            f"(rc={proc.returncode}, segments={len(segs)})"
        )

    log(f"[fw] wrote {out_json.name} stderr->{err_path.name}")
    return out_json
