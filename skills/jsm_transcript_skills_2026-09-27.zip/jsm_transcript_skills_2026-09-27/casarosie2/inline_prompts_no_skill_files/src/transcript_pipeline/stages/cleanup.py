"""Cleanup stage — always via Cursor; model/effort from env.

Contract: produce cleaned.md, quality.md, speaker_map.json under the job dir.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, Mapping

from transcript_pipeline.cleanup.cursor_backend import (
    CleanupConfig,
    run_cursor_cleanup,
)

LogFn = Callable[[str], None]


def run_cleanup(
    work_dir: Path,
    fw_json: Path,
    log: LogFn,
    *,
    show_priors: Mapping[str, Any] | None = None,
    config: CleanupConfig | None = None,
) -> dict[str, Path]:
    """
    Run 4-round cleanup through the Cursor backend.

    Model/effort: CLEANUP_MODEL / CLEANUP_EFFORT (not hardcoded).
    Provider path is always Cursor (CLEANUP_PROVIDER=cursor).
    Set CLEANUP_DRY_RUN=1 to write placeholders without invoking Cursor.
    """
    cfg = config or CleanupConfig.from_env()
    log(
        f"[cleanup] Cursor backend model={cfg.model} effort={cfg.effort} "
        f"dry_run={cfg.dry_run}"
    )
    return run_cursor_cleanup(
        work_dir,
        fw_json,
        log,
        show_priors=show_priors,
        config=cfg,
    )
